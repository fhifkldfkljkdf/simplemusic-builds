# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

The root `CLAUDE.md` is upstream's project guide: architecture, module roles, and a long changelog of traps
already hit. It loads alongside this file. This file adds what the root guide leaves out (commands, the Gradle
module map, places where the root guide is out of date) and the rules for this private copy.

## Private copy rules

This repository is a private copy of maxrave-dev/SimpMusic. See `.private-fork/README.md`.

- Never open pull requests, issues, or comments on maxrave-dev/SimpMusic or maxrave-dev/core, and never push there.
- Pull in upstream changes with `.private-fork/sync-upstream.sh`, which merges them into `main` of this repository.
- Do not commit to `upstream-main` by hand; it is a filtered mirror that only the sync script updates.
- **Do not edit the root `CLAUDE.md`.** Upstream changes it almost daily, so a local edit turns every sync into a
  merge conflict. Its "CLAUDE.md Auto-Update Rule" applies to this file instead: record changes made in this copy here.
- The root guide's "Pull Request Guidelines" and `CONTRIBUTING.md` (fork, branch from `dev`) describe upstream.
  Here, work lands on `main` of fhifkldfkljkdf/simplemusic.
- `.claude/skills/simpmusic-release-changelog` Step 1 comments on, edits and closes issues in maxrave-dev/SimpMusic
  and its Project #2 (`gh … --repo maxrave-dev/SimpMusic`). Never run those commands from this copy.
- `core/` is a git submodule cloned from the `core-main` branch of THIS repository (`.gitmodules` uses the
  relative URL `../simplemusic.git`); `core-upstream` mirrors maxrave-dev/core. Most modules live there, so run
  `git submodule update --init core` after cloning (shallow, per `.gitmodules`) and `git submodule update core` after each
  sync. To change core: commit inside `core/` on `core-main`, `git -C core push origin HEAD:core-main`, then
  commit the new `core` pointer here. Never push `core/` anywhere else.

## Commands

Full vs FOSS is **not** an Android product flavor. It is the Gradle property `isFullBuild`. It swaps
`crashlytics`/`cast`/`lastfm` for their `*-empty` stubs in `androidApp`, `composeApp`, `core/data` and
`core/media/media3`. Upstream sets it `true`; **this copy sets it `false` in `gradle.properties`** (see "No tracking"
below), so every build here is the tracking-free one. `-PisFullBuild=true` brings Sentry, Cast and Last.fm back.

Secrets come from an optional root `local.properties` (`SENTRY_DSN`, `SENTRY_AUTH_TOKEN`, `LASTFM_API_KEY`,
`LASTFM_SECRET`). If the file is missing the build still works: the values are empty and Sentry and Last.fm do nothing.

```sh
# Android
./gradlew :androidApp:assembleDebug            # applicationId com.maxrave.simpmusic.dev
./gradlew :androidApp:assembleRelease          # R8 + per-ABI splits + universal APK, unsigned
./gradlew :androidApp:assembleOptimized        # this copy: release build (R8, no debug code) as com.maxrave.simpmusic.dev,
                                               # signed with .private-fork/test-signing.keystore; what the builds repo ships
./build_and_sign_apk.sh --release              # assembles, zipaligns and signs with ./simpmusic.jks;
                                               # needs KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD, ANDROID_HOME.
                                               # --full/--foss only rename the output; set isFullBuild yourself.
./gradlew exportLibraryDefinitions             # aboutLibraries.json; upstream CI runs it before release builds

# Desktop
./gradlew :composeApp:mpvSetupAll --no-configuration-cache   # fetch + checksum libmpv natives into mpv-natives/
                                               # (without them the app falls back to a system libmpv)
./gradlew :desktopApp:run
./gradlew :desktopApp:hotRunJvm --auto         # Compose Hot Reload
# Packaging (upstream CI order): :desktopApp:writeConveyorConfig, then the external `conveyor` CLI,
# then :desktopApp:packageConveyorAppImage. Add --no-configuration-cache to these tasks.

# Tests. KMP modules run commonTest + jvmTest under the jvm target.
./gradlew :domain:jvmTest :kotlinYtmusicScraper:jvmTest :listenTogether:jvmTest :loginSync:jvmTest :nostr:jvmTest :headsetControl:jvmTest
./gradlew :domain:jvmTest --tests 'com.maxrave.domain.mediaservice.handler.RadioQueueTrimTest'
./gradlew :media3:testDebugUnitTest --tests 'com.maxrave.media3.audio.EchoAudioProcessorTest'
```

- The `:media3` audio tests compare against ffmpeg-generated reference vectors in
  `core/media/media3/src/test/resources/audio/`.
- `listenTogether`'s `Live*Test` classes talk to a real server, so they are `@Ignore`d on purpose.
- There is no ktlint/detekt/spotless task. `.editorconfig` holds the ktlint settings: 150-character lines,
  wildcard imports allowed, `@Composable` functions exempt from function naming.
- Cloud sessions: the default container has JDK 21 but no Android SDK, and Maven Central answers HTTP 429 to its
  shared egress. This recipe made every command above work (2026-09-28): unzip `cmdline-tools` from dl.google.com
  into `/root/android-sdk/cmdline-tools/latest`, accept licences, `sdkmanager "platforms;android-37.0"
  "build-tools;37.0.0" "platform-tools"`, write `sdk.dir=/root/android-sdk` to `local.properties` (gitignored), and
  add a Gradle init script in `~/.gradle/init.d/` that rewrites `https://repo.maven.apache.org/maven2` to
  `https://maven-central.storage-download.googleapis.com/maven2/` in the plugin and dependency repositories.
  A cold compile of the JVM targets then takes about 6 minutes. The root guide's verification route (JetBrains MCP)
  and research route (Context7 MCP) are not available there. Say what was not verified instead of claiming it was.

## Module map

Gradle paths do not follow directories. `settings.gradle.kts` includes the submodule's projects under short names:

| Gradle path | Directory |
|---|---|
| `:common`, `:data`, `:domain` | `core/<name>` |
| `:kotlinYtmusicScraper`, `:lyricsService`, `:spotify`, `:aiService`, `:autoEqService`, `:kizzy`, `:ktorExt`, `:listenTogether`, `:loginSync`, `:nostr` and `:headsetControl` (this copy only) | `core/service/<name>` |
| `:media3`, `:media3-ui`, `:media-jvm`, `:media-jvm-ui` | `core/media/<name>` |

Type-safe accessors are on (`projects.data`, `projects.crashlyticsEmpty`). Entry points:

- Android: `androidApp` (`SimpMusicApplication`, `MainActivity`). It only hosts `composeApp`.
- Desktop: `desktopApp/.../Main.kt` calls `runDesktopApp()` in `composeApp/src/jvmMain/.../DesktopApp.kt`, which
  starts Koin.
- All shared UI and ViewModels are in `composeApp/src/commonMain`.

## Where the root guide is out of date

- **DI is Koin only; there is no Hilt.** Modules: `core/data/.../di/` (`DatabaseModule`, `RepositoryModule`,
  `MediaHandlerModule`, `ListenTogetherModule`, plus a per-platform `loader/`),
  `composeApp/.../di/ViewModelModule.kt`, `media3/.../di/Media3ServiceModule.kt` and
  `media-jvm/.../di/DesktopPlayerModule.kt`.
- **There are no use-case classes.** `core/domain` holds models, repository interfaces and the media-service handler
  contracts. ViewModels take repositories directly (for example `AlbumViewModel(songRepository, albumRepository, …)`).
- **Room is KMP.** The database is `core/data/src/commonMain/kotlin/com/maxrave/data/db/MusicDatabase.kt`, not
  `src/main/java`. It is currently version 27 (upstream's, merged 2026-10-04), schema changes go through `AutoMigration`s, and exported schemas are in
  `core/data/schemas`. A schema change is a `core/` change (see the submodule rule above).

## Changes in this copy

Upstream does not have these; keep them working across syncs.

- **Listen Together keeps your room seat and lets you listen on your own (2026-09-28).** Written against metroserver,
  before rooms went peer to peer (next entry); the seat, solo and sharing behaviour carry over. Protocol facts, read from
  MetrolistGroup/metroserver: the server keeps a disconnected member's seat for 15 minutes (`ReconnectGracePeriod`)
  and the same session token keeps working; it has **no chat or presence** — the only message a guest can send that
  reaches anyone else is `suggest_track`, and it reaches the host alone.
  - `ReconnectPolicy` (listenTogether): while holding a seat, retry every ≤10 s for 15 minutes instead of giving up
    after 5 attempts (~31 s). Without a seat the old 5-attempt budget stays. Unit-tested in `ReconnectPolicyTest`.
  - `ListenTogetherClient`: a silence watchdog (no frame for 45 s ⇒ the socket is dead; the server pongs every
    ping) so a vanished network is noticed instead of looking connected for minutes; `reconnect` refusals
    (`session_expired`, `session_not_found`, `room_not_found` while a reconnect is outstanding) emit `SeatLost`;
    `forgetSession()` on leaving so a stale token is never replayed.
  - `ListenTogetherSession`: handles `reconnected` (it was ignored) and `SeatLost`; `sync_state` now sets
    `lastActionServerTime = lastUpdate`, because its position is already live there — the old code added the gap
    since the last command a second time.
  - Listening on your own is app state (`ListenTogetherRoom.listeningSolo`, held in `ListenTogetherRepositoryImpl`),
    not protocol state. While set, the bridge neither follows nor publishes, and still answers the buffer barrier at
    once so it never holds the room up. A host going solo first hands host to the first other connected member.
    A guest who plays a song that is not the room's (not current, not queued) for 5 s goes solo automatically; the
    wait exists because endless queue can move a guest to its own radio track a moment before the host's
    change_track at the end of a song. Room play/pause/seek is not applied while the player is on a different track.
  - "Share what I play" (`lt_share_now_playing` in DataStore, read by the bridge directly): a solo guest's song is
    sent to the host as a suggestion after 8 s on it. Hosts see it with the other suggestions; other guests cannot.
  - `LocalServerResumeTest` drives real sessions through a restart, a restart that lost its state, and a SIGSTOP
    of a metroserver running locally, never the public one. Build it from MetrolistGroup/metroserver (with its
    `metroproto` submodule): `protoc` from `pip install grpcio-tools` (`python -m grpc_tools.protoc`),
    `go install google.golang.org/protobuf/cmd/protoc-gen-go@v1.36.11`, generate into `proto/` as
    `scripts/generate_proto.sh` does, `GOTOOLCHAIN=auto go build ./cmd/metroserver`, then run the test with
    `LT_SERVER_BINARY=<binary>`. The playback bridge (following, going solo, sharing) has no automated test: it
    needs a real player handler.
- **Listen Together room QR codes (2026-09-28).** The QR holds `simpmusic://listen-together?code=<ROOM>`
  (`ListenTogetherViewModel.inviteLink`), not the bare code, so a phone's own camera app opens SimpMusic on it too;
  App.kt routes that host (and Desktop's rewritten `https://simpmusic.org/app/listen-together?code=`) to
  `ListenTogetherDestination(joinCode)`, which is now a data class. Every member can show the QR (`RoomQrDialog`);
  scanning is Android only (`RoomQrScannerSheet`, reusing login sync's `QrScanner` and camera-permission flow).
  `joinByInvite` connects if needed and joins under the remembered name (`lt_display_name`); without a name it
  stops at a filled form, and inside another room it asks the user to leave first. Encoding is an expect/actual
  (`encodeQrCode`) because ZXing is declared only in androidMain and jvmMain. Tests:
  `composeApp` commonTest `ListenTogetherInviteTest` and jvmTest `QrEncoderTest` (encode, then decode with ZXing).

- **Radio pages ranked by this device's listening history (2026-09-28).** `RadioPersonalizer` (domain,
  `mediaservice/handler/`) re-orders what a radio plays next. It is applied in `SongRepositoryImpl` to the same three
  radio sources that the audio-only filter covers: `getRadioFromEndpoint` keeps its seed first, while
  `getRelatedData` and `getContinueTrack`'s radio branch do not. A playlist, an album or Shuffle is never touched.
  - YouTube's order stays the backbone. The score is `-position` plus bounded weights, all in queue places:
    - +3·ln(1+plays) for the most-played credited artist over 90 days (≈7 places at 10 plays, ≈14 at 100)
    - −8 for each time the song was cut short, counted at most 3 times
    - +5 if the song is liked
  - A spacing pass then avoids the same artist twice in a row, looking up to 4 places ahead.
  - Songs heard in the last 3 hours are dropped while at least 10 fresh ones remain; otherwise they go to the end.
  - "Cut short" has two sources:
    - `playback_event` rows under half their length (that table only records plays of 20% or more);
    - `SkipLog`: leaving a song after ≥1 s but before 20%, recorded by both handlers in
      `mayBeTrackingListeningLocal` and therefore only while local tracking is on.
  - `SkipLog` is a DataStore string (`radio_skip_log`, `videoId:count:epochDay;…`, 500 entries, 90 days), **not a
    Room table**: a schema version of this copy's own would collide with upstream's next version bump.
    Clear-history wipes it.
  - Setting: `personalize_radio`, on by default, in Settings next to the audio-only radio row. The three DAO
    queries are read-only (`getVideoIdsPlayedSince`, `getCutShortCountsSince`, `getLikedVideoIds`).
  - Tests: domain commonTest `RadioPersonalizerTest` and `SkipLogTest`.
  - Discovery slider (`radio_discovery`, 0 familiar … 1 new; 0.5 = the ranking above unchanged; default 1.0 since
    2026-09-29, see the radio mix entry), under the switch in Settings. `lean = (d − 0.5)·2`:
    - artist term `3·(1 − 2·lean)·ln(1+plays)`;
    - song term `−6·lean·ln(1+songPlays)`, from `getVideoPlayCountsSince`;
    - liked `5·(1 − lean)`;
    - from 0.8, known songs are held back like recently heard ones.
    It can only reorder and hold back what YouTube's radio returns; it never adds songs.

- **Friends and room invites over Nostr (2026-09-28).** Peer to peer, with no SimpMusic server or account. Each
  device holds a secp256k1 key, and a friend is someone whose key was added by QR code or link
  (`simpmusic://friend?npub=…&name=…`, which Desktop receives as `https://simpmusic.org/app/friend?…`). Messages go
  through three public relays (`relay.damus.io`, `nos.lol`, `relay.primal.net`), end-to-end encrypted. Rooms stay on
  the Listen Together server; only the invitation travels this way.
  - New module `:nostr` (`core/service/nostr`). It is registered in a separate block at the bottom of
    `settings.gradle.kts` so upstream's module lists never conflict. It targets android, jvm and an iOS stub.
    - The curve is BouncyCastle's lightweight API (`bcprov-jdk18on`, already shipped by PipePipeExtractor, so no
      size cost). It lives in a custom `jvmShared` hierarchy group shared by Android and Desktop. It is not
      secp256k1-kmp, whose JNI library extracts itself to a temp dir at runtime, which hardened-runtime macOS
      builds can refuse.
    - NIP-44's ChaCha20 is plain Kotlin; SHA-256/HMAC come from okio.
    - Tests (`:nostr:jvmTest`, 25):
      - every official BIP-340 and NIP-44 vector (the NIP-44 file's sha256 is asserted);
      - two real events signed by go-nostr;
      - `TestRelay`, a local NIP-01 relay that checks ids and signatures like public relays do;
      - two or three `FriendsSession`s talking through it.
    - The public relays are not reachable from cloud sessions (the egress proxy answers 503 to a WebSocket
      upgrade), so there is no live test.
  - Protocol (`FriendsSession`): kind 30078 addressable events, `d = simpmusic:<type>:<recipient>`, a `p` tag and
    a NIP-40 `expiration`, with NIP-44 content `{"v":1,"t":type,"name":…}`.
    - `friend` (7 days) means "you are on my list". From a stranger it is a request; from a friend it confirms
      them. Adding and accepting both send one, so one scan is enough.
    - `invite` (30 min, `room` = Listen Together code) is only shown from someone on our list.
    - Handled messages are remembered per type and sender, so a dismissed invite or declined request does not
      come back after a restart.
  - Storage is DataStore (`friends_identity`, `friends_list`, `friends_handled`), never Room, for the same
    schema-version reason as `SkipLog`. The display name is Listen Together's `lt_display_name`.
  - UI:
    - `FriendsScreen` (`FriendsDestination(roomCode, addCode)`), opened from a row on the Listen Together page.
      That row reads "Invite friends" inside a room, and each friend then gets an Invite pill.
    - `FriendsInbox` in App.kt shows invites (Join → `ListenTogetherDestination(joinCode)`) and requests over any
      screen. It uses the repository, not a ViewModel, because it sits above navigation.
    - `RoomQrScannerSheet` gained optional title and hint strings so it can read friend codes.
  - Not done: Android notifications for invites while the app is closed (the socket lives only as long as the
    process), and iOS.

- **Android: songs stuck at the end (2026-09-28).** Three causes, all in `CrossfadeExoPlayerAdapter` unless noted.
  - A failed preload was handed over. `triggerPrecachingInternal` now attaches a failure listener that evicts the
    entry, and `takePrecachedPlayer()` (used by `loadAndPlayTrackInternal` and `triggerCrossfadeTransition`) drops
    any player in STATE_IDLE or with a `playerError`. `play()` on such a player does nothing, and its error fired
    before the active listener existed, so the next song sat silent at 0:00.
  - A stream that never reports STATE_ENDED. `checkForStall()` runs in the position loop:
    - a position frozen within `END_STALL_WINDOW_MS` (3 s) of the end for `END_STALL_TIMEOUT_MS` (5 s) calls
      `onCurrentTrackEnded()`, the extracted STATE_ENDED body;
    - STATE_IDLE while PLAYING for 4 s reloads the track at its position, once per track.
    - Ordinary mid-song buffering is left alone.
  - A radio page that arrives after the queue ended. `addMediaItem` (append) continues into it within 10 minutes
    of the end, and `MediaServiceHandlerImpl` calls `loadMore()` on STATE_ENDED when the queue can still grow.
  - Not on a device; Desktop (`MpvPlayerAdapter`) unchanged.

- **Listen Together is peer to peer (2026-09-28).** There is no room server any more: the device that creates a
  room runs it, and everyone reaches it through the same public Nostr relays the friends feature uses. Rooms are no
  longer compatible with Metrolist clients. The session, bridge and UI above did not change: they talk to the new
  `RoomTransport` interface, which both `ListenTogetherClient` (metroserver, kept but unbound) and
  `peer/PeerRoomTransport` implement, and `ListenTogetherModule` binds the peer one.
  - `peer/RoomHub` is metroserver's room rules ported message for message (join/approve, playback with in-flight
    compensation, queue, suggestions, buffer barrier, kick/transfer, presence from pings, 15-minute seats). Pure
    and clock-injected; `RoomHubTest` drives it.
  - Wire: kind 21078 ephemeral events tagged `h` = a hash of the room code, NIP-44 encrypted with a key derived
    from the code (`SharedCodeSecret`). Each device has a fresh key per process, which is its user id. Frames are
    `{"v":1,"n":seq,"d":"u"|"d","to":[ids],"e":<MessageCodec envelope>}`: `u` goes to the hub (`to` = its id, empty
    for a join), `d` comes from it. `SequenceGate` restores each sender's order, waiting 400 ms on a gap.
  - The hub moves with the host role (`hub_moved` carries a gzipped `HubSnapshot`). The old hub decides the
    hand-over and numbers every frame before it first suspends, or a concurrent step overtakes it. The new host's
    own `host_changed` is held back until `hub_moved` has made it the hub; otherwise its session sends its first
    command to the old device, which drops it.
  - **Failover.** The hub sends a `state` beacon (gzipped snapshot) to members when the room changes, and at least
    every 60 s. If the hub is silent for 30 s, the first connected member in the snapshot's order takes over
    (`RoomHub.claim`, advancing the position by the silence); each next one waits 15 s more. Every take-over or
    hand-over raises `HubSnapshot.epoch`, and a claim wins by higher epoch, then smaller key, and only from a member.
    A host that comes back hears the new hub's beacon, steps down and asks for sync. Tests use short `Timing`.
  - `ListenTogetherSession` now sends through one ordered queue (`inOrder`). Each send used to be its own
    coroutine, so a track change and the play after it could arrive swapped; `capturedAtServerTime` is read when
    the command is issued, not when it goes out.
  - Tests: `peer/RoomHubTest` (10) and `peer/PeerRoomTest` (7, devices meeting through `LocalRelay` on localhost:
    join, follow, transfer, host leaves, suggestions, unknown code, host vanishes, host returns).
  - Settings: the server picker is replaced by a note on how rooms connect; the `lt_server_url` value is unread.
  - Not verified: public relays from a real device, rate limits on busy rooms, iOS.

- **Start radio keeps the song playing (2026-09-28).** `MediaPlayerHandler.startRadio()` (domain,
  `handler/StartRadio.kt`), used by the Now Playing sheet and both handlers' `toggleRadio`: when the seed is the song
  already playing, `MediaPlayerInterface.clearMediaItemsExceptCurrent()` drops every other queue item and the radio is
  loaded around it, instead of reloading the song from 0:00. Implemented in `CrossfadeExoPlayerAdapter` (refuses while
  crossfading or casting) and `MpvPlayerAdapter` (refuses while crossfading); a refusal falls back to the old reload.

- **Optimized build (2026-09-28).** `androidApp` has an `optimized` build type: `initWith(release)` (R8, shrinking),
  `applicationIdSuffix ".dev"` so it installs over the debug builds shipped before, signed with
  `.private-fork/test-signing.keystore` (the same key those debug builds used, so it updates in place). Sentry skips
  it. `SharedViewModel.checkOfficialBuild` accepts that key's certificate, or the anti-clone screen would block it.

- **Radio curation and "new songs" Start radio (2026-09-29).** `RadioCurator` (domain, `handler/RadioCurator.kt`,
  pure, `RadioCuratorTest`) sits between YouTube's radio pages and the queue, in `SongRepositoryImpl.curateRadio`,
  for all three radio sources. Measured anonymously on YouTube Music: a radio's continuation pages repeat most of what
  came before (49 rows each, of which 10, 11, then 4 were new), and one song arrives as several uploads with
  different videoIds.
  - `songKey()` = normalised title + first artist: strips bracketed upload words ("Official Video", "4K Remaster",
    "Live", "feat."…), a leading "Artist - " when it names the artist, and channel suffixes (VEVO, Official, Topic).
    Letters of any script are kept. Remixes and covers stay distinct.
  - `dropRepeats` removes what the queue holds (the handlers now pass `queued = listTracks` to `getContinueTrack` and
    `getRelatedData`) and repeats within a page; `capArtists` allows 2 per artist in any 8 places (moved down, not
    dropped); a page left with fewer than 15 useful songs is topped up from the radios of up to 2 new songs on it
    (`driftSeeds`, one request each, in parallel).
  - Start radio (`getRadioFromEndpoint(startRadio = true)` while the radio mix is New: the Now Playing sheet, the
    handlers' `toggleRadio`, and the playlist and artist Radio buttons) keeps only songs never started or liked (`DatabaseDao.getHeardSongs`: song rows
    with `totalPlayTime > 0 OR liked = 1`, which exists with local tracking off too), matched by id and by song key. It
    leans to new artists (`discovery ≥ 0.9`), wants 20 on the first page, and falls back to the least played known
    songs only when fewer than 10 new ones exist. The mode is carried in the queue's continuation string
    (`RadioContinuation`, `SMNEW:` prefix), so every later page is new songs too and the radio goes on from seeded
    radios when YouTube's chain ends. All of it reads history only while "Learn from my listening" is on.
- **App icon (2026-10-11).** A play button cut through by a sound wave: music that plays and carries, and two halves
  that make one (listening together). White (top `#FFFFFF` → bottom `#DCE7FF`) on an electric blue → violet gradient
  (`#4F8CFF` → `#2F55F5` → `#3B22CF`, (18,8) to (92,102)) with a white glow from the top left and a violet one in the
  bottom right. The glyph's two pieces are exact shapes (a rounded triangle, corner radius 6.8 in the 108 grid,
  intersected with the regions either side of a 4.2-wide sine band, amplitude 3.3, wavelength 22.5), generated with
  shapely and written as plain `M…L…Z` paths: Android does not anti-alias `<clip-path>` in vector drawables, so a cut
  made with clip paths would show jagged edges. Bounding box about 36…79 × 31…77, so it sits inside the 66-unit safe
  zone in every launcher mask. Where it is used:
  - launcher: `drawable/ic_launcher_together_{background,foreground,monochrome}.xml` (both `mipmap-anydpi-v26` files);
  - notification small icon (status bar, media controls, downloads) and Android Auto's attribution icon:
    `androidApp/res/drawable/mono.xml` and `monochrome.xml`, 24 dp white. The app's `mono.xml` overrides core media3's
    drawable of the same name at resource merge, so `SimpleMediaService` and `MusicDownloadService` pick it up with no
    core change;
  - Compose resources: `mono.xml` (the in-app logo, `#5B8CFF`, the glyph at the share of the canvas the old note had,
    since callers size it by the whole canvas), `monochrome.xml` (the badge on generated playlist and mood artwork),
    `app_icon.png` (Credits) and `circle_app_icon.png` (Desktop window, tray, mini player);
  - Desktop packaging: `composeApp/icon/circle_app_icon.{png,ico,icns}`, the .ico and .icns holding PNG entries.
  (Before: a play button sending out two sound waves, 2026-10-04; a seven-bar sound wave, 2026-09-29; upstream's note.)
- **Listen Together repairs lost messages (2026-09-29).** Nothing is re-sent; a guest notices what it missed:
  - every hub frame carries `"r"` = the room's revision; a guest whose session is behind for 1.5 s, whose
    `SequenceGate` gave up on a hole in the hub's frames, or whose connection just came back sends `request_sync`
    (at most one per 2 s);
  - on the hub's state beacon a guest compares the member list and host with what its session was told, and
    delivers the missing `user_joined` / `user_left` / `user_(dis|re)connected` / `host_changed` itself;
  - the room's own `RelayPool` gives up on a silent socket after 35 s (keepalive at 15 s) instead of 100 s.
  - `LocalRelay.drop` loses chosen events; `PeerRoomTest` loses every playback frame and a `user_joined` and checks
    the room still converges.
- **Playback recovers instead of stopping (2026-09-29).** Every player error used to end in a toast and a pause, and
  `play()` in the ERROR state did nothing, so the music stayed stopped until another song was picked.
  - Android (`CrossfadeExoPlayerAdapter` + `PlaybackRecovery`): a connection error (2001, 2002, 1003), or any error
    while offline, shows buffering and waits for the network (2, 4, 8, 16 s, then every 30 s, fresh URL from the 3rd
    try), then resumes the same song at the same position; up to 10 minutes, or until the user pauses or picks
    something else. Online and still failing after 5 attempts counts as the song's problem.
  - A song that fails with a fresh URL twice is skipped, not paused on (`PlayerConstants.ERROR_CODE_SKIPPED_UNPLAYABLE`
    → `ToastType.SkippedUnplayable`), at most 3 in a row. `play()` on a failed player reloads the song where it stopped.
  - Desktop (`MpvPlayerAdapter`): the same play-after-error and skipping, and its retry now resumes at the position
    instead of 0:00. It has no wait-for-network.
  - Not on a device. `isOnline()` uses plain null checks: release lint crashes on `?: return` locals in that file.
- **Radio mix: Familiar · Mix · New (2026-09-29).** `RadioMix` (domain, `handler/RadioMix.kt`, `RadioMixTest`) names
  three stops of the discovery slider (0, 0.5, 1), and `RadioMix.of` reads any slider value back as the nearest one
  (≥ 0.8 New, ≤ 0.2 Familiar). `RadioMixBar` (composeApp `ui/component/RadioMixBar.kt`) writes the same
  `radio_discovery` value, so every place it appears and Settings always agree:
  - last in the song ⋯ sheet, under Share;
  - at the bottom of both queues, pinned under the list (the Classic/M3E sheet: the list takes `weight(1f)`; the
    Apple Music queue: above its bottom controls, in its artwork colours), with `whilePlaying = true`: shown only while
    `RadioQueueTrim.appliesTo` says the queue is a real YouTube radio, and letting go of the slider calls
    `toggleRadio()`, which rebuilds the radio around the playing song without restarting it.
  - It is a slider (`RadioMixSlider`, also used by Settings' `DiscoverySlider`): Material's `Slider` with custom
    `track`/`thumb` slots, so drag, tap, keys and accessibility come from Material. A 36 dp rounded track filled with a
    tertiary→primary gradient up to a 4×48 dp handle with a 5 dp gap each side, History and AutoAwesome icons at the
    ends, a midpoint dot, and a `SegmentFrequentTick` haptic per step. 10 steps; commits are snapped to tenths
    (`snapRadioMix`), so 0.8 is the same float `RadioMix.startsWithNewOnly` compares against. `RadioMixHeader` names
    the position (`radioMixLabel`: Familiar ≤0.2, Mostly familiar 0.3, Mix 0.4–0.6, Mostly new 0.7, New ≥0.8).
  - Uses the value-based `Slider(thumb, track)` overload, the one Now Playing already depends on — see the
    `material3-expressive` pin note in `libs.versions.toml` before bumping Material 3.
  - The default is New (`RadioMix.DEFAULT_DISCOVERY = 1f`), so an untouched install still gets new songs from Start
    radio. `getRadioFromEndpoint(startRadio = true)` uses new-songs mode only while the mix is New; on Mix or
    Familiar, Start radio is an ordinary personalised radio.
- **Listen Together: direct links on the same network (2026-09-29).** A room no longer needs a relay when its
  devices share a network. `peer/DirectLinks` (commonMain interface; `SocketDirectLinks` in a `jvmShared` source set
  shared by Android and Desktop, declared with `applyDefaultHierarchyTemplate` in `listenTogether/build.gradle.kts`;
  iOS gets `NoDirectLinks`) carries the same signed, encrypted Nostr events as the relays, over plain TCP: `SMLT/1\n`
  greeting, then frames of a 4-byte length plus the event JSON, an empty frame as a heartbeat every 4 s, and a link
  silent for 12 s is dead.
  - The hub listens on a random port while it is the hub (`serve()`), and its addresses (`lanAddresses()`: up,
    non-loopback, non-link-local IPv4, container bridges and mobile-data interfaces left out, Wi-Fi/Ethernet first) ride
    on its `state` beacon and on the join acknowledgement it sends a joiner (`"l"`). Guests dial them and redial with
    1/2/4/8 s back-off; a hand-over or failover moves the listener to the new hub and re-points every guest.
  - `PeerRoomTransport.publish` sends each event both ways; the receiver drops the copy it already saw (last 4000
    event ids). Either path alone keeps the room going, so a relay outage on a shared Wi-Fi is not noticed at all.
    The room reports itself connected when a relay OR a direct link is up.
  - The room QR carries the host's addresses: `simpmusic://listen-together?code=X&lan=ip:port,ip:port`
    (`ListenTogetherViewModel.inviteLink`/`parseDirectHints`, at most 8, strict `a.b.c.d:port`). A guest that scans it
    dials before joining (`RoomTransport.hintDirect`) and waits up to 2 s for the link, so a room with no reachable
    relay can still be joined by scanning. A typed code has no hints and learns the addresses from the first frame.
  - `joinRoom` now always returns true: the answer (joined or "no such room") comes back as an event, and returning
    false when no relay was up turned a direct-only join into "Not connected".
  - `ListenTogetherSession` collects transport events with `CoroutineStart.UNDISPATCHED`: a transport that connects
    instantly (a direct link, or a local relay in tests) emitted `Connected` before the session was listening.
  - The room screen's connection line now says how it is reached (`routeText`: "Connected directly to the host", "N
    phones connected directly", "Relays 2 of 3", or no relay but direct still possible), replacing a placeholder.
  - Tests: `PeerRoomTest` (12: the 9 relay-only ones plus a room with no relay at all, a room that loses its relays
    mid-song, and duplicate delivery). Not verified on devices: Android's LAN behaviour, networks with client isolation
    (guest Wi-Fi), iOS.
- **Listen Together finds peers on the same network by itself (2026-09-29).** No QR code or relay needed on one Wi-Fi.
  `peer/LanDiscovery` (commonMain interface + `LanBeacon` wire format; `SocketLanDiscovery` in `jvmSharedMain`; iOS
  `NoLanDiscovery`) sends a UDP broadcast every 2 s to port 45797, to each interface's broadcast address and
  255.255.255.255: `{"m":"SMLT-D/1","t":<room tag>,"l":[hub endpoints],"h":host,"c":code?,"n":listeners}`. A room
  unheard for 7 s is forgotten.
  - The hub announces while it runs a room and serves direct links (`PeerRoomTransport.announceRoom`, on every tick
    and on any change). The tag is `SharedCodeSecret.tag`, so a guest who typed the code recognises its room without
    the code being broadcast. The code rides along only while the host allows "Show my rooms on this Wi-Fi"
    (`lt_visible_nearby`, on by default, in Listen Together settings; `RoomTransport.setVisibleNearby`).
  - A guest dials the hub as soon as it is heard (`onNearby`), also before joining, so a typed code joins with no relay.
    The hub's address lists from its frames (`frameEndpoints`) and from the network (`lanEndpoints`, which adds the
    address the beacon came from) are merged, and `SocketDirectLinks.dial` keeps an up link whose endpoint is still in
    the new list, so the two sources cannot make it hang up and redial.
  - After the host's phone vanishes, the member who takes over starts announcing and the others dial it, so a room
    with no relay survives failover on one Wi-Fi.
  - "Nearby on this Wi-Fi" on the Listen Together lobby lists rooms that carry a code; Join calls `joinByInvite`, and
    the host still approves. `RoomTransport.nearby` → `ListenTogetherRepository.nearbyRooms` (`NearbyListenRoom`).
  - Android: the Wi-Fi driver drops broadcasts without a `WifiManager.MulticastLock`, held only while listening or
    announcing, via `LanDiscoveryPlatform.holdBroadcastReceive`, set by `loadListenTogetherPlatform()` in core's
    `Loader.android.kt`; `CHANGE_WIFI_MULTICAST_STATE` is in the manifest (normal permission).
  - Trap: inside `DatagramSocket(null).apply { … }`, a bare `port` is the socket's own port (-1), not the class
    property. The first version bound nothing, and the loopback test is what caught it.
  - Tests: `LanDiscoveryTest` (beacon encoding, and one real UDP round trip on loopback) and three `PeerRoomTest`s on
    an in-memory `LocalLan`: typed code joins with no relay, nearby list and hiding it, and failover with no relay.
    Not verified on real phones or networks that block broadcast; iOS has none.
- **Radios lift the best songs (2026-09-29).** `RadioQuality` (domain, `handler/RadioQuality.kt`, `RadioQualityTest`
  on a real Queen radio page) ranks by what YouTube says about each song. A video row's byline reads
  "artist • 536M views • 3M likes" (a song row's reads "artist • album • year"), so `NextPage.fromPlaylistPanelVideoRenderer`
  now parses those into `SongItem.viewCount`/`likeCount` (`NextPage.parseCount`, English plus common localised
  suffixes; a bare number is a year and is ignored; `CountParseTest`). `Track.viewCount`/`likeCount` carry them,
  falling back to the music video's counts for a song (`counterpart`, logged-in only), and the audio-only swap keeps
  them.
  - `boosts()`: percentile of log views ±18 places, likes-per-view ±4, rows under 100K views another 10 back, and +5
    per other seeded radio that picked the song (at most 2; `curateRadio` counts `appearances` by `songKey`, without
    each seed radio's own first row). Added to `RadioPersonalizer.rank` as `boost`, so it also works with history off.
  - `hits()` = the most played quarter of the page (≥1M views); `weave()` pulls the next hit forward after
    `HIT_EVERY` = 4 songs without one. It runs last and keeps the artist cap at every place (`RadioCurator.fitsArtistCap`):
    run before the cap, an artist with many hits undid it. With new songs only, a known hit is never pulled forward.
  - `capArtists` now places each song at the first spot where its artist fits, in ranked order. It used to defer
    every extra song of a crowded artist to the end of the page, so Queen's biggest hits landed last on a Queen radio.
  - Rows with no numbers stay neutral, so an audio-only page with no music videos keeps YouTube's order.
- **Upcoming songs are looked up ahead of time (2026-09-29).** Both players already keep the next
  `StreamWarmer.PRELOADED` songs fully loaded (2, now 3 — see the caching entry below) (standby ExoPlayers on Android, paused mpv handles on Desktop). After
  those, `StreamWarmer` (domain) looks up the stream addresses of the next `AHEAD` songs (5, now 10), from `warmStreamsAhead()`
  at the end of each precache job in `CrossfadeExoPlayerAdapter` and `MpvPlayerAdapter`. It calls
  `StreamRepository.getStream`, which saves a `NewFormatEntity`; both players check that first, so a skip past the
  preloaded songs or a tap further down the queue skips the address lookup and signature solving. Songs whose saved
  address is good for 30 more minutes are left alone. Videos (watch-video on) get their video stream too.
  - Android: a preload that fails is retried after 5 s, up to 3 failures per song (`precacheFailures`), instead of
    waiting for the next track change.
  - Not verified on a device: how much faster skipping feels depends on the network and on YouTube's response times.
- **Moving a song in a shuffled queue moves only that song (2026-10-03, replaced by upstream 2026-10-04).** Fixed here
  first with a play-order branch inside `moveMediaItem`; upstream then shipped the same fix as
  `MediaPlayerInterface.moveShuffledItem` (both handlers' `swap`/`moveQueueItem` call it while shuffle is on). The
  merge took upstream's version on both players and dropped this copy's `QueueMoves`, so `moveMediaItem` is
  upstream's again (playlist positions, shuffle rebuilt).
- **No tracking (2026-10-03).** `isFullBuild=false` in `gradle.properties`: no Sentry (Android `crashlytics-empty`),
  no Google Play Services Cast SDK (`cast-empty`) and no Last.fm. Desktop's Sentry was not behind that flag, so it was
  removed by hand: the `Sentry.init` block, `machineId()`, the crash dialog's capture and `pushPlayerError`'s report
  in `DesktopApp.kt`/`CrashDialog.kt`, and `sentry-jvm` from `composeApp` and `desktopApp`. The BuildKonfig
  `sentryDsn` field is still generated but read by nothing. Left as they were because they are opt-in and off by
  default: "Send back listening data to Google" (`sendBackToGoogle`) and "Help build the lyrics database"
  (`helpBuildLyricsDatabase`). `SharedViewModel.checkOfficialBuild` makes no network call for this copy's key.
- **SoundCloud backup source (2026-10-03).** When YouTube gives no playable audio for a song (every extraction tier
  failed, or no audio format), the same recording plays from SoundCloud. Setting `soundcloud_backup`, on by default,
  under Content next to the quality rows.
  - `kotlinYtmusicScraper/.../soundcloud/`: `SoundCloud` (client, `YouTube.soundCloud`, shares the proxy) uses
    SoundCloud's public web API — `client_id` scraped from the `a-v2.sndcdn.com/assets/*.js` scripts soundcloud.com
    links (cached 6 h, refetched once on 401/403), `api-v2.soundcloud.com/search/tracks`, then the progressive
    transcoding's url `?track_authorization=` → a signed `cf-media.sndcdn.com/….128.mp3` (CloudFront, range requests
    work, extra query parameters are tolerated). Its life is read from the `Policy` parameter (base64 JSON with
    CloudFront's `-_~` substitutions); it was about 8 minutes when measured.
  - `SoundCloudMatcher` (pure, `SoundCloudMatcherTest`; `SoundCloudLiveTest` runs only with `SOUNDCLOUD_LIVE=1`)
    takes a candidate only when it streams in full (`policy != SNIP`, a non-snipped progressive `audio/mpeg`), is
    within 5 s of the song's length, carries no other-version word ("remix", "live", "sped"…) the song's title lacks,
    has the song's title once upload decorations and an "Artist - " side are removed, and names the artist in
    `publisher_metadata.artist`, the uploader or the title — as the whole name or its start, never merely
    contained: the first live run matched Queen to "Killer Queen Band Page", a tribute band, at the right length. Label releases on SoundCloud are mostly 30-second
    `SNIP` previews, so those songs simply have no backup; full-length matches are user re-uploads.
  - `StreamRepositoryImpl.getStream` is now a wrapper: upstream's body is `youTubeStream` unchanged (one
    `bestAudio` fallback added), and the backup runs only for playback (`!isDownloading && !isVideo && !muxed`). The
    title, artists and length come from the song's `SongEntity` (waited for up to 2 s, since the handlers save a song
    as it starts). The row is a normal `NewFormatEntity` with `itag = SOUNDCLOUD_BACKUP_ITAG` (0) and an expiry 30 s
    before the url's; within 15 minutes of YouTube's failure an expired backup is renewed straight from SoundCloud
    instead of asking YouTube again. `ExtractSource` shows "SoundCloud · backup (<uploader>)" in the info sheet.
  - Android: `Mp3Extractor` added (last) to the extractor list, which had no MP3 extractor at all; backup audio is
    cached under `soundcloud:<videoId>` (`DataSpec.keyedForSource`) so MP3 bytes never share a cache entry with
    YouTube's WebM/MP4 for the same song; `DownloadUtils` ignores a cached backup row. Desktop: mpv plays the url as is.
  - Not used, on purpose: Monochrome and Octave (lossless) stream TIDAL/Qobuz through shared paid accounts; ArtistGrid
    and unmusic host leaked unreleased songs; public Piped instances were all failing (`SignInConfirmNotBot`) and the
    one Invidious instance with its API on hides audio behind a bot challenge; soundcloak's docs ask not to be scraped.
  - Not verified on a device. The live test (search, match, resolve, a 206 range read, renew) passed from a cloud
    container on 2026-10-03, matching "Queen - Bohemian Rhapsody" (352 s, a re-upload) with a url valid for 473 s.
- **Hi-Fi sound (2026-10-03).** Setting `hifi_sound`, off by default, first row under Playback. While on:
  `StreamRepositoryImpl.bestAudio` takes the highest-bitrate audio YouTube returned (Opus over AAC at equal rate:
  774/141 at 256 kbps with Premium, 251 at about 160 kbps without), for playback and downloads, whatever the quality
  settings say; both handlers send a flat equalizer and `AudioEffects.NONE`, and Android's `mayBeNormalizeVolume`
  treats normalisation as off. The EQ, delay, reverb and normalise rows grey out with "Bypassed while Hi-Fi sound is
  on"; their stored values are kept. Nothing lossless exists on YouTube or SoundCloud. Separately, the ordinary
  quality path now falls back to `bestAudio` when neither the chosen itag nor its twin is there (a non-Premium
  account on "High"), instead of taking the last format with a url, which could be a video stream with no sound.
- **YouTube rate limits switch to the backup without a pause (2026-10-04).** `YouTubeHealth` (domain,
  `handler/YouTubeHealth.kt`, pure, clock-injected, `YouTubeHealthTest`) is a breaker held by `StreamRepositoryImpl`.
  - Opens at once on a rate limit: HTTP 429/403 from the player request (ktor `ResponseException`), or a playability
    reason with "not a bot" / "unusual traffic" / "too many requests". `YouTube.player` now throws
    `YouTubePlayabilityException(status, reason)` for a non-OK playability status instead of letting `newPipePlayer`
    return null into "No URL found"; `youTubeFailureOf()` (scraper, `extractor/YouTubeFailure.kt`) classifies.
    Cool-down 5 min, doubling per trip without a success in between, capped at 60 min; signals during one outage
    do not stack. "Sign in to confirm your age" is a song problem, not a rate limit — the first draft matched
    "confirm you" and would have read it as one.
  - Also opens when 3 different songs fail to extract inside 3 minutes; an unavailable/private song never counts.
  - While open, `getStream` goes to the SoundCloud backup first and only asks YouTube when the backup has no match;
    any YouTube success closes it.
  - `StreamRepository.reportStreamRejected(videoId)` (default no-op): both adapters call it on their source-error
    retry, right before `invalidateFormat`. If the refused stream was an unexpired YouTube one, that song prefers the
    backup for 10 minutes and it counts as a strike — asking YouTube again usually hands out another URL that the
    CDN refuses the same way. The retry already reloads at the saved position, so the song carries on from the
    backup where it stopped, with no toast. Not wired to the network-recovery path: an outage is not YouTube's fault.
  - Not done, on purpose: Monochrome-style "HiFi API" instances for lossless. They stream TIDAL/Qobuz through shared
    paid accounts. Lossless would need the user's own TIDAL or Qobuz subscription.
  - Not verified against a real rate limit or on a device.
- **The player shows which source is playing (2026-10-04).** A pill in the time row under the seek bar: "YouTube ·
  OPUS 160 kbps", "SoundCloud · MP3 128 kbps" or "Downloaded · OPUS" (`playbackSourceLabel` +
  `PlaybackSourcePill`, `ui/screen/player/content/PlaybackSourcePill.kt`; `NowPlayingContentState.playbackSourceLabel`).
  Classic and M3 Expressive show it where "Crossfading" appears, and hide it while crossfading; the Apple Music
  style's existing codec badge now carries the label. It is read off the song's format row, which the stream lookup
  rewrites when the source changes, so it follows a mid-song switch to the backup. "Downloaded" comes from
  `songEntity.downloadState`. The kbps is YouTube's nominal `bitrate`, not a measurement.
- **More songs cached ahead (2026-10-04).** `StreamWarmer.PRELOADED` 2 → 3 (fully prepared players on Android, paused
  mpv handles on Desktop) and `AHEAD` 5 → 10 (stream lookups). Android also caches the opening `UpcomingPrefetch.BYTES`
  (1.5 MiB, about 75 s at 160 kbps) of the `SONGS` = 5 songs after the preloaded ones (`media3/exoplayer/
  UpcomingPrefetch.kt`, from `prefetchAhead()` at the end of the precache job, so a queue change cancels it). It reads
  through its own copy of the player's resolving data source (a Koin single built with the same caches, proxy and
  resolver), so the URL, the SoundCloud backup and the cache key are the ones playback uses — reading is what fills
  `playerCache`. Songs already holding that many cached bytes and songs that will play as video are skipped. Data
  cost: up to ~7.5 MiB ahead of the preloaded songs, on any network.
- **Remaining tracking removed (2026-10-04).** On top of "No tracking":
  - "Send back listening data to Google" (`sendBackToGoogle`: `initPlayback`/`updateWatchTime` to YouTube's
    playback-tracking URLs) and "Help build the lyrics database" (uploads lyrics tagged with the song, plus contributor
    name/email) are gone from Settings, and `DataStoreManagerImpl` reports both as `FALSE` whatever an older install
    stored, so the existing gates in the handlers and `SharedViewModel` never open.
  - `YouTube.getSongInfo` no longer calls Return YouTube Dislike: it ran on every song change and sent each video id to
    returnyoutubedislikeapi.com. `viewCount`/`like`/`dislike` are now null.
  - SponsorBlock (off by default) uses the hash-prefix API: `/api/skipSegments/<first 4 hex of SHA-256(videoId)>`
    (okio) answers every video under that prefix, `HashedSkipSegments` picks ours. Checked live: a list of
    `{videoID, segments}`.
  - The per-song TIDAL metadata search (title + artist → BPM/key for AutoMix) runs only while crossfade and DJ mode
    are both on.
  - Still contacted, because they are the features themselves: the selected lyrics provider (SimpMusic lyrics by video
    id, LRCLIB/BetterLyrics by title), YouTube, SoundCloud when it backs a song up, GitHub/F-Droid for the update
    check, chart.simpmusic.org for charts, and Discord/Spotify/AI services only after the user signs in or adds a key.
- **Upstream merge (2026-10-04).** maxrave-dev/core gained 6 commits (live broadcasts over HLS with
  `LiveStreamRegistry`, per-app audio output selection, an AI "taste reading" from local history, Apple Music animated
  artist artwork, `moveShuffledItem`); upstream SimpMusic had none, so those features are in core but have no app UI
  until upstream adds it. Conflicts resolved: the handlers' `swap` and `moveMediaItem` are upstream's;
  `loadAndPlayTrackInternal` keeps this copy's `takePrecachedPlayer()` (it drops errored AND idle precaches, a
  superset of upstream's new error check); the precache loop takes both this copy's failure limit and upstream's
  "never precache a live broadcast"; `YouTube.player` runs upstream's live check before this copy's
  `YouTubePlayabilityException` (a live response is answered before anything needs an OK status);
  `UpcomingPrefetch` skips live broadcasts too.
- **Lossless from the Internet Archive (2026-10-04).** While Hi-Fi sound is on, `StreamRepositoryImpl.getStream`
  first asks archive.org for a FLAC file of the same recording (`archiveLossless`, playback only, before the YouTube
  and SoundCloud paths); no account or key. The user has a TIDAL subscription, but signing in needs TIDAL's app client
  credentials, and the session's auto-mode classifier refused decoding them from python-tidal twice ("Third-Party
  Attack", "Credential Exploration"); Monochrome-style public "HiFi API" instances (shared paid accounts) and torrents
  were declined.
  - `kotlinYtmusicScraper/.../archive/`: `InternetArchive` (`YouTube.internetArchive`, shares the proxy) runs
    `advancedsearch.php` twice — `title:("T") AND creator:("A") AND format:(Flac)`, then `creator:("A") AND
    format:(Flac) AND ("T")` for albums naming the song — reads up to 6 items' `/metadata/<id>` in parallel, and hands
    every FLAC file to the matcher. `ArchiveCandidates` (pure) reads archive.org's loose JSON: `creator`/`collection`
    are a string or a list, `length` is seconds or a clock, most files have no title of their own (a single-file item
    takes the item's title, otherwise the file name minus its track number), items in the `stems` collection are
    skipped, and the item title rides along as `context` so a clean file title inside "Live at Wembley" or "Boombox
    Demo" is still refused.
  - Matching moved to `matching/RecordingMatcher.kt` (`RecordingCandidate`), shared with `SoundCloudMatcher`, which
    now only adds SoundCloud's full-stream gate. Version words gained multitrack(s), stem(s), acapella, isolated,
    recreation, boombox.
  - The stream is `https://archive.org/download/<id>/<path>` (percent-encoded per segment; 302 to a data node, which
    answers range requests with `audio/flac`). The row is `itag = ARCHIVE_LOSSLESS_ITAG` (1), trusted for 6 h (the
    address itself does not expire). A miss, or a file the player refuses (`reportStreamRejected`), is not searched
    again for 6 h; the whole lookup gives up after 6 s so a slow archive.org cannot hold a song's start. Android caches it under
    `archive:<videoId>` (`otherSourceCacheKey`), downloads ignore it, and the source pill reads "Internet Archive ·
    FLAC <kbps>".
  - Coverage measured on ten well-known songs: items for Queen, the Beatles, Michael Jackson and Nirvana; none for
    Taylor Swift, Pink Floyd, Eagles or Miles Davis. Uploads are mostly users', some 24-bit/176.4 kHz (220 MB a song).
  - Tests: `ArchiveCandidatesTest` (real answer shapes); `InternetArchiveLiveTest` runs only with `ARCHIVE_LIVE=1`.
    Not verified on a device.
- **Streams keep their source; songs start at once; seamless upgrade to lossless (2026-10-10).** Three fixes to the
  Internet Archive feature above, plus a sources sheet.
  - **The "no sound" bug.** The player reads a song in 5 MiB chunks, and every chunk ran the resolver again, which
    read the song's single format row. When that row changed under a playing song, the next chunk came from another
    file. The 6 s archive timeout, a failed HEAD check or a lookup for the same song could each swap the row, so
    YouTube's WebM bytes landed in the middle of a FLAC stream, which the extractor cannot decode.
    - `PinnedResolvingDataSource` (media3, one per media period) remembers what its stream was resolved to
      (`StreamPin.Local`/`Remote(PlaybackStream)`), and later chunks only renew that same file.
    - `StreamResolver` holds the old resolver body. Past the first chunk a googlevideo `range=` parameter is
      dropped, because upstream never sent it there.
    - Cache keys now name the file: `archive:<id>:<fnv64(fileKey)>` and `soundcloud:<id>:…`
      (`otherSourceCacheKey(stream, mediaId)`).
  - **Archive matches no longer share the song's row.** They live in their own `NewFormatEntity` keyed
    `archive:<videoId>` (hit trusted 30 days, miss 6 h); `cpn` holds bits;channels;item. A legacy main-key archive row
    from the last build is ignored. `InternetArchive.findLossless` checks before accepting:
    - it reads the first 64 KiB of each candidate (`FlacHeader`: STREAMINFO after an optional ID3 tag);
    - it refuses non-FLAC, more than 2 channels, rates above 96 kHz (Android plays 16-bit/48 kHz anyway; 176.4 kHz
      streams at ~4.6 Mbps) and a real length more than 5 s off;
    - it skips `is_dark` / `access-restricted-item` items, `private` files and `.ffp` fingerprints;
    - it prefers CD quality over 24-bit/high-rate (`isHighResolution`), and works through `RecordingMatcher.ranked`.
  - **Instant start.** `getStream` never waits for archive.org any more.
    - A lossless file already found (`knownLossless`) starts at once; otherwise the search runs in the background
      (`searchLossless`, two at a time, 25 s budget).
    - `StreamWarmer` and the precache start searches for queued songs. Each precache waits up to 12 s for its song's
      search, so queued songs start on FLAC.
    - Handlers push queued tracks as `SongRef`s (`rememberSongs`), because the library only holds a song once it
      has started.
  - **What is playing.** The resolver publishes each new stream's `PlaybackSource` (`publishPlayingSource`), unless
    the media item URI marks it `sm_trial`/`sm_prefetch` (`StreamRequest`; `sm_source=<KIND>` asks for one source).
    The badge reads it, falling back to the format row. A music video's audio half always asks for YouTube.
  - **Seamless upgrade (Android, Hi-Fi on).** Once a song's lossless file is found mid-song, `scheduleUpgrade` →
    `SeamlessSourceSwitch` does the switch:
    - a second, muted player opens the FLAC 2 s behind;
    - both sinks are tapped (`TappingAudioSink` → `AnalysisTap`: mono, Blackman-sinc low-pass, about 8 kHz, every
      sample stamped in sink presentation time, plus the sink's own position readings);
    - `StreamAligner` (GCC-PHAT-0.8, 150–3500 Hz, three 3 s windows) must find one offset: strength ≥ 25,
      distinctness ≥ 2.5, spread ≤ 1 ms;
    - the muted player is seeked and nudged with Sonic speed (±5%) until both sinks are within 1.5 ms;
    - levels are matched (the quieter copy decides; ramps over seconds);
    - an 80 ms linear crossfade hands over.
    Anything else gives up and the song stays as it was; the next play starts on FLAC.
    - Measured on real audio: one master as FLAC and as its MP3 derivative lines up within 1 µs, strength 67–127.
      Two CD transfers of a 1975 recording drift 5.8 ms/s (0.58% speed) and are refused. So classic recordings often
      upgrade only on their next play.
    - After a switch the adapter reports positions on the song's original timeline (`currentTimelineOffsetMs`,
      `DelegatingForwardingPlayer.timelineOffsetMs`), so the seek bar, the session and synced lyrics do not jump.
      Reloads of the same song (`SongReload.SAME_SOURCE`: network recovery, stall, play-after-error) keep source and
      offset; a refused stream (`AFTER_REFUSAL`) reloads afresh.
    - Not with Hi-Fi off: volume normalisation lives on the old player's audio session.
  - **Sources sheet.** Tapping the source badge opens `PlaybackSourcesSheet`. It lists Internet Archive / YouTube /
    SoundCloud (and Downloaded) with quality and state from `StreamRepository.sourceOptions`, which starts the
    allowed searches. Tapping a row calls `MediaPlayerInterface.switchSource(kind)`:
    - Android tries the seamless switch, and reloads at the position when that is not possible;
    - Desktop always reloads at the position (mpv gives no PCM to align).
  - Tests: `StreamAlignerTest` (synthetic, and real recordings with `ALIGN_AUDIO_DIR` of raw mono f32 44.1 kHz files),
    `StreamRequestTest`, `FlacHeaderTest`, `OtherSourceCacheKeyTest`, new `ArchiveCandidatesTest` cases;
    `InternetArchiveLiveTest` (`ARCHIVE_LIVE=1`) now asserts the header was read.
  - Not verified on a device: the seamless switch itself (dual ExoPlayers, sink position accuracy, the 80 ms fade)
    has only been reasoned about and unit-tested in its parts.
- **Headphone noise control: Sennheiser MOMENTUM 4 (2026-10-10, Android).** (Huawei earbuds were added the same
  day; see the next entry for what changed in the shared model.) The player shows the connected
  MOMENTUM 4's noise control as a pill beside the source pill (Classic and M3E: in the time row, the source pill
  capped at 130 dp then; Apple Music: beside its codec badge): "ANC 80%", "Adaptive ANC", "Transparency" or
  "ANC off". Tapping it opens `HeadsetSheet` (composeApp `ui/screen/player/HeadsetControls.kt`): the four modes,
  the cancelling strength (ANC only), wind noise reduction (Off / Maximum / Automatic, hidden when off) and the
  battery.
  - Protocol, from two MIT projects verified on the headset (firmware 3.37.3 / 3.38.3):
    Tumult1337/momentum4-control and Zhengyang-Liu/m4-companion. Their captured bytes are the test vectors.
    - GAIA v3 frames over Bluetooth Classic RFCOMM, SDP service UUID `a2129ff3-081b-4c45-8afe-469d9c4842ec`:
      `FF 03 00 len vendor(2) command(2) payload`, Sennheiser vendor `0x0495`. The answer is command + `0x0100`,
      an error + `0x0180` (first byte the reason), a change notification + `0x0080`.
    - ANC on/off `0x1A04`/`0x1A05`; mode table `0x1A00`/`0x1A01` as (id, value) pairs: 1 anti-wind
      (0 off, 1 max, 2 auto), 2 comfort, 3 adaptive; level `0x1A02`/`0x1A03`, 0…100 with **0 the strongest**
      (the UI shows strength = 100 − level); Transparent Hearing `0x1804`/`0x1805`. Notifications are registered
      per feature with `0x0007` (13 ANC, 12 Transparent Hearing, 3 battery); without feature 12 the headset's own
      touch gesture is not reported.
    - Firmware side effects the plans respect: any `0x1A00` write (even unchanged) ends Transparent Hearing and
      sets the level to 0; Transparent Hearing on saves the level and sets 100, off restores it; ANC on ends
      Transparent Hearing at level 0. So anti-wind in ANC mode writes the level back afterwards, and in
      transparency turns Transparent Hearing back on.
  - New module `:headsetControl` (`core/service/headsetControl`, android + jvm for tests, registered in the
    private block of `settings.gradle.kts`): `gaia/Gaia.kt` (codec, reassembling reader), `momentum/NoiseControl.kt`
    (state, mode table, `NoiseControlPlan`: the writes from one state to another, pure), `momentum/Momentum4Session.kt`
    (one command in flight, answers matched by command, notifications folded into `status`, each change read
    before, written and read back; three unanswered commands close the channel), androidMain
    `RfcommHeadsetLink`. Tests: `GaiaCodecTest`, `Momentum4SessionTest` against `FakeMomentum4`, which
    reproduces the side effects above.
  - Domain: `HeadsetRepository` + `NoHeadsetRepository` (Desktop and iOS) and `data/model/headset/HeadsetState`.
    Data androidMain: `HeadsetRepositoryImpl`, bound by the new `loadHeadsetModule()` loader actual.
    - The headset is found through `AudioManager` outputs (A2DP, SCO, LE Audio), which need no permission: an
      output named "MOMENTUM 4" makes the pill offer "Allow" (`NEEDS_PERMISSION`). With `BLUETOOTH_CONNECT`
      (Android 12+; `BLUETOOTH` with maxSdk 30 below) the bonded device is matched by the output's address, or by
      name, or by advertising the service UUID (a renamed headset); a device matched only by the UUID that does
      not answer like a MOMENTUM 4 is left alone for the rest of the process.
    - The channel is open while `state` is collected (the player collects it with the lifecycle) and 2 minutes
      after; reconnects after 5, 15, 30, 60 s, or at once on an audio-output change or `retry()`. Slider moves
      are debounced 250 ms.
  - Not verified on a device: no MOMENTUM 4 here. The protocol layer is tested against captured bytes and a
    simulated headset; the Bluetooth discovery and connection on Android are untested. Other Sennheiser models
    are not supported. Sennheiser Smart Control holding the channel at the same time is untested; the failure
    text suggests closing it.
- **Huawei / Honor earbuds join the noise control (2026-10-10, Android).** FreeBuds, FreeClip, FreeLace and Honor
  Earbuds now use the same pill and sheet as the MOMENTUM 4. Exact model names come from OpenFreebuds'
  `DEVICE_TO_DRIVER_MAP` (melianmiko/OpenFreebuds, GPL-3.0 like this app), including FreeBuds Pro 4 and 6i:
  `huawei/HuaweiModels.kt` gives each its channel, whether it has ANC, its cancelling levels (Comfort / Normal /
  Ultra, plus Dynamic on newer ones), voice boost, per-bud battery, and FreeLace Pro's 2 s connect delay.
  - Unlisted names that still name a family (`freebuds|freeclip|freelace|freearc|honor earbuds|honor choice`) are
    guessed: a later "FreeBuds Pro" as the Pro 3, anything else as ANC on/off without levels. A guess whose ANC
    read gets no answer falls back to battery only. A listed name followed by more of a model name ("FreeBuds Pro 6")
    is not that model; one followed by a tag ("FreeBuds 5i (A1B2)") is.
  - Protocol (`huawei/HuaweiPacket.kt`, `huawei/HuaweiHeadset.kt`): `5A len(2) 00 command(2)` + TLV parameters +
    CRC-16/XMODEM; a packet is `len + 5` bytes. OpenFreebuds' own reader reads one byte short, so some of its
    captured answers miss the last CRC byte; this reader takes a packet with a wrong CRC when its parameters fill it
    exactly. Noise read `2B 2A` → parameter 1 `[level, mode]` (0 off, 1 ANC, 2 awareness), also sent unasked;
    older models send only `2B 03` and are re-read. Mode write `2B 04` parameter 1 `[mode, FF]`, `[00, 00]` for off
    (FreeBuddy and Gadgetbridge; OpenFreebuds always sends FF). A level write is `[mode, level]` in parameter 1
    (OpenFreebuds) or 2 (Gadgetbridge): parameter 1 goes first, parameter 2 when reading back shows no change, and
    the one that worked is kept. Battery `01 08` / unasked `01 27`: 1 = overall, 2 = left/right/case (0 = unknown),
    3 = a charging flag per part. A write answer may carry `7F` = result code, 100000 = done.
  - Connection: the standard Serial Port service UUID `00001101-…`, as FreeBuddy and Gadgetbridge open it on
    Android; if that fails, OpenFreebuds' fixed channel for the model through the hidden `createRfcommSocket(int)`
    (reflection; may be refused). After a failed session the other way goes first.
  - Shared model: `HeadsetSession` / `HeadsetReport` in `:headsetControl` (which now depends on `:domain`);
    `Momentum4Headset` adapts `Momentum4Session`, `HeadsetModels.recognise(name)` picks the kind. Domain
    `NoiseControl` gained `modes`, `level`/`levels` (`NoiseLevel`), and `strength`/`antiWind` became nullable;
    `HeadsetState.battery` (`HeadsetBattery`: overall, left, right, case, charging) replaced `batteryPercent`/`charging`;
    `HeadsetRepository.setLevel`. The sheet shows only the controls a model has; the pill shows "ANC Dynamic",
    "Voice boost", or the battery for earbuds without noise control.
  - Tests: `HuaweiPacketTest` (OpenFreebuds' captured packets, CRCs included), `HuaweiHeadsetTest` against
    `FakeHuaweiBuds` (modes, levels in either parameter, the earbuds' own button, battery, no-ANC and guessed
    models, a silent channel), and `Momentum4SessionTest.theAdapterSpeaksTheSharedModel`.
  - Not verified on a device: no Huawei earbuds here.
- **The developer's pop-ups, blog and start-up update prompt removed (2026-10-11).** Upstream counts app opens and
  shows, on Home: a "give a star / review" dialog (opens 10–50), a request to share saved lyrics (1, 15, 30…; it
  could never be satisfied here, since this copy reports `helpBuildLyricsDatabase` as off), a promo for the
  developer's blog (5) and a "kotlin-footguns" star request with a complaint about lost nights (6, 16…46). All four
  dialogs are deleted (`ReviewDialog`, `ShareSavedLyricsDialog`, `BlogPromoDialog`, `FootgunsStarDialog`) with their
  triggers in `HomeScreen` and hooks in `SharedViewModel`. Also gone:
  - the "log in to YouTube" warning on Home (it mentioned Piped, which nothing here uses), with the two `runBlocking`
    DataStore reads in `HomeViewModel.init` that fed it;
  - the developer-blog news: `RssFeedNotifyWork` (a daily job polling maxrave.dev's RSS and posting notifications),
    the Settings rows "Developer blog" and "Blog post notifications", and the credits page's blog button. Installed
    copies still had the job and its "Blog updates" channel, so `MainActivity` cancels the job and deletes the
    channel on every start; blog entries already saved are filtered out of the notification list;
  - the automatic update check on start (`SharedViewModel.shouldCheckForUpdate()` returns false; the Settings switch
    is gone). It reads the official SimpMusic releases, a different app from this build, and popped their release
    notes up. "Check for update" in Settings still works on demand.
  Kept on purpose: the author credit, the third-party licences, and the passive donation and "follow me" rows.
  Strings stay in `strings.xml` (and its Crowdin translations) so upstream syncs do not conflict.
- **Crash guards and a lost upgrade (2026-10-11).** The background scopes this copy added had no exception handler,
  so one failure would end the app: `StreamRepositoryImpl.scope` now logs failures, and a lossless search that
  throws counts as a miss instead of making `awaitLossless` throw. The Android adapter's `scheduleUpgrade` and
  `switchSource` bodies (`upgradeWhenFound`, `switchSourceNow`) and Desktop's `switchSource` catch and log; the
  headset watcher restarts after a failure, and `findTarget` treats a revoked Bluetooth permission as no headset.
  A seek used to cancel the pending lossless upgrade for the rest of the song; it now waits again from the new
  position.
- **Upstream 2.3.0 merged (2026-10-11).** 31 app and 12 core commits (queue order kept on append, synced playlist
  edits past the first page, Japanese romanization after a reinstall, seek bars while paused, the Apple Music player
  rework, Settings in grouped cards, Home's daily discover carousel, the App log screen, and more). Kept out, as before:
  the review, blog, footguns and share-lyrics dialogs, the log-in warning, the developer-blog rows and job, Desktop's
  Sentry (upstream added OS details and a machine id to it). New and left out: Home's launch banners. Their `promos`
  block still arrives with the remote config upstream already fetched for TIDAL, and `SharedViewModel` still caches it,
  but nothing draws a banner. Upstream replaced the Apple Music codec badge with a "kbps · kHz" line read from YouTube's
  format row; this copy keeps its source pill there instead, since that row says nothing while a lossless or SoundCloud
  copy plays. `toAudioCodecLabel` now lives in `PlaybackSourcePill.kt`, and the pill's text uses the `footer` style
  (upstream dropped `badge`). Merging into the work branch needed the merge commit's own resolutions (`git checkout
  <merge> -- <file>`): the work branch carries this copy's commits as different ids, so git re-raises every conflict.
- **Skipping ahead with Hi-Fi sound on (2026-10-11).** The Android preload waits up to 12 s per song for the lossless
  search, one song after another, and only then looked up the addresses of the songs after it. A skip made during
  those waits found neither a loaded player nor a looked-up address. Now the preload starts the searches side by side,
  and looks up the addresses of the preloaded songs and the next ten in a child job while it waits. With Hi-Fi off
  nothing waits, so the preloaded songs are not looked up twice.
- **Headset channel hardening (2026-10-11).** MOMENTUM 4: a battery read with no answer in time, or a
  notification registration the firmware refuses or ignores, ended the session, so every retry failed the same
  way and noise control never showed; both are logged and skipped now (tests in `Momentum4SessionTest`; the fake
  headset gained `unanswered` and `refusedFeatures`). The repository's activity flow gets `distinctUntilChanged`
  after its debounce as well: the player closed and reopened within the two-minute grace sent a second "active",
  which restarted the watcher and reopened a channel that was still open. `HeadsetRepositoryImpl.serve` subscribes its change collectors
  (`CoroutineStart.UNDISPATCHED`) before marking the channel connected, because the change flows replay nothing and a
  tap in that gap was dropped while the pill showed the change as pending. A session whose `run()` returns, which the
  interface says it never does, now counts as a closed channel instead of leaving the pill connected to nothing.
- **Tap to sound, then an upgrade that is not heard (2026-10-11).** For a song that has to be looked up:
  - `YouTube.player` used to send its WEB_REMIX player request and only then run the stream extraction, though
    neither needs the other. The extraction now starts first, in `extractionScope` (not a child: the extractor
    blocks and cannot be interrupted, so a child would make a refused or live video wait for it), and
    `newPipePlayer` awaits it.
  - PipePipe's tiers HEAD-check the URLs they return (`headCheckRandomStream`), so `newPipePlayer`'s own
    `is403Url` runs only for BravePipe's answer (`ExtractSource.of(id)` names the tier).
  - The cipher solver (YouTube's 1–2 MB player script, downloaded and compiled in QuickJS) is built 1.5 s after
    `YouTube` is created (`FaradayCipherEngine.prewarm`, `Extractor.prewarm`); it shares the decode lock, so a
    song arriving meanwhile waits for that build instead of starting a second one.
  - `StreamResolver.quickStart(videoId, waitedFor)`: when the lossless file is known but its opening is not
    cached, a song someone is waiting for (`StreamRequest.waitedFor`: no `sm_trial`, `sm_prefetch` or the new
    `sm_preload`) starts on a still-fresh YouTube address. Measured from a container: archive.org's first byte
    arrives 1.0–1.6 s after the request (TLS, a redirect to a storage node, TLS again). The seamless upgrade
    then moves the song onto the file. Preloads (`sm_preload`, set by the precache) and songs whose seamless
    move was refused (`UpgradeRefusals`, process memory) take the lossless file directly.
  - The upgrade is also scheduled after a crossfade cut short (`commitIncomingAsCurrentInternal`); a finished
    crossfade already did.
  - Loudness: a louder copy keeps the level the song was heard at until the song ends (`matchedLevel`, applied
    wherever the playing volume is set: the volume setter, focus gain and duck, a crossfade out, a same-source
    reload) instead of being raised over 10 s, and the old copy is lowered to a quieter one at no more than
    0.25 dB/s (4–24 s). `MIN_REMAINING_FOR_UPGRADE_MS` went from 60 to 90 s to leave room for that ramp.
  - Not measured on a phone: how much each of these saves depends on the network.
- **High-bitrate sources: whole songs, real releases, real sound (2026-10-11).**
  - **The "no sound / stops" bug.** `StreamResolver.open` capped every read at `CHUNK_LENGTH` (5 MiB).
    - YouTube's containers (WebM, MP4) know their own size, so a chunk's end throws EOF and the loader opens the
      next chunk.
    - `FlacExtractor` and `Mp3Extractor` take END_OF_INPUT as the song's end, and size their seek maps by the
      input length.
    - So an archive.org FLAC stopped after 5 MiB (about 46 s; 13 s behind a 3.5 MB embedded cover), an Audius
      song after about two minutes, and seeking past the first chunk was impossible.
    - Only YouTube is chunked now; other sources open one range from the requested position. A read that asked
      for less than a chunk (the prefetch) gets no more.
  - **Covers.** `FlacHeader.walk` follows the metadata blocks to the first audio frame, stepping over blocks
    longer than the 64 KiB probe with small range reads (`InternetArchive.audioStart`, at most 6 reads,
    16 MiB of metadata).
    - The offset rides on `ArchiveFile.audioOffset` / `PlaybackStream.audioOffset`, persisted in the archive
      row as `v2;bits;channels;audioOffset;origin`. Rows without `v2` are searched again.
    - `StreamResolver.openingCached` counts from it, and a prefetch of such a file asks for the cover plus its
      bytes (`UpcomingPrefetch` reads to the end of what was opened, at most 8 MiB).
    - Measured: Queen's archive file starts its audio at byte 3,502,611, and the live test checks for a FLAC
      frame sync there.
  - **Sound.** A file averaging under 100 kbps of audio per channel (measured past the cover) is refused as
    silence.
  - **Releases, not concerts.**
    - The searches add `mediatype:(audio)`, which drops the Live Music Archive's `etree` items.
    - `ArchiveCandidates` refuses:
      - items in the `etree`, `GratefulDead`, `78rpm`, `georgeblood`, `taperssection` and `roiocollection`
        collections (and a few radio/audiobook ones);
      - items with taper fields (`venue`, `taper`, `transferer`, `lineage`);
      - items with a show date (`yyyy-mm-dd`) in their identifier or title.
    - Item `subject` tags and the `source` note now count as context. `RecordingMatcher` gained concert words
      (concert, tour, festival, gig, soundboard, sbd, unplugged, rehearsal, session(s), outtake(s), alternate)
      and transfer words (vinyl, needledrop, shellac, cassette, 78rpm, acetate). These apply to SoundCloud and
      Audius too.
    - Live run on 2026-10-11: Queen still matches. Beatles and Nirvana no longer do; their only archive.org
      FLACs were a video upload (`mediatype:movies`), a tribute-band tape and live bootlegs. Grateful Dead and
      Phish (concert tapes only) match nothing.
- **Starting a tapped song sooner (2026-10-11).**
  - `StreamResolver.freshYouTube` HEAD-checked every saved address before opening it: a TLS handshake plus a
    round trip, about 0.2–0.5 s.
    - `StreamRepository.isRecentlyVerified/markVerified/forgetVerified` now trust an address found playable in
      the last 10 minutes on the same network. It is marked by `getStream`'s extraction, whose tiers HEAD-check,
      and by the resolver's own check.
    - Google's stream addresses are bound to the asking IP, so `media3/service/NetworkChangeWatcher` (a default
      network callback, created at Koin start) clears the memory when the network changes.
    - A stale one still fails into the normal error retry.
  - `SharedViewModel.loadMediaItemFromTrack` hands the song to the player right after inserting its row. The
    like-status read and the duration update come after.
- **Battery (2026-10-11).**
  - **Position tick.** `MediaServiceHandlerImpl.startProgressUpdate` published the position every 50 ms,
    screen off included. It now ticks every 50 ms while the screen is on, 250 ms off-screen with SponsorBlock
    on, and 1 s otherwise. A `SCREEN_ON/OFF` receiver, registered for the life of the process, keeps
    `screenOn` (do not unregister it in `release()`: the handler can be reused). The notification, lock screen
    and Android Auto read the session's own clock.
  - **Preload buffers.** `exoplayer/PausedBufferCap` wraps each player's `DefaultLoadControl`. It stops loading
    at 30 s while `playWhenReady` is false: preloaded players, and a paused song. Each preload used to fill the
    full 200 s, three songs per track change (about 25 MB each for lossless).
    - Every `DefaultLoadControl` method is forwarded by name, not through `by` delegation alone, so the
      per-player bookkeeping is never skipped.
  - **Battery Saver** (`PowerManager.isPowerSaveMode`, read at each use): one preloaded song instead of three,
    3 addresses looked up ahead instead of 10, no opening prefetch.
  - **Lyrics and canvas wait while no screen shows** (`SharedViewModel.setAppVisible`, set by a
    `LifecycleStartEffect` in `App`). They are fetched when the app comes back, through the existing
    null checks. This is a privacy gain too: a song played with the screen off is not sent to a lyrics or
    canvas provider unless the listener looks.
  - **Friends relays.** `FriendsSession` connects only while someone is on the list, or after the Friends page
    asks for the identity. `setForeground(false)` (from `FriendsInbox`'s `LifecycleStartEffect`) closes the
    sockets in the background. Messages are stored on the relays, so the next connect (`since` =
    `FRIEND_TTL` ago) delivers what was sent meanwhile. Tests: `theRelaysAreLeftAloneInTheBackground`, and
    `strangersCanAskButNotInvite` now calls `ensureIdentity()` after the restart.
- **Privacy: the upstream remote config is fetched only for AutoMix (2026-10-11).**
  `CommonRepositoryImpl` waited for nothing and fetched `remote-config.json` from the upstream developer's
  GitHub on every launch. Its only use here is TIDAL access for AutoMix; its promo block is never drawn. It is
  now fetched once crossfade and DJ mode are both on, and saved credentials keep working meanwhile.
- **Player cache keeps storage free (2026-10-11).** Settings → Storage → "Keep free storage": Off, 10, 15, 20
  (default), 25 or 30%. DataStore key `player_cache_keep_free_percent`.
  - `media3/cache/StorageAwareCacheEvictor` replaces `LeastRecentlyUsedCacheEvictor` for the player cache. It
    removes the least recently played audio when the cache is over "Limit player cache", or when free space
    (`StatFs` on the cache directory) is below the share.
  - `CacheTrim.bytesToFree` is pure and tested in `CacheTrimTest`. It never trims the free-space rule below
    `FLOOR_BYTES` (64 MiB), so the playing song and the next openings stay.
  - Both settings now apply without a restart. The size limit used to need one.
  - `followCacheLimits` in `Media3ServiceModule` re-checks every 15 minutes, for space other apps took. The
    download cache is not touched.
- **AI without a key (2026-10-11).**
  - **Taste card.** With no AI key, the "Your music taste" card is written on the phone by
    `domain/.../taste/OnDeviceTasteWriter`. It uses the same `TasteInput` an AI gets, picks from phrasings
    (a random variant per Regenerate), uses no figures and invents no genres. `OnDeviceTasteWriterTest`.
    `TasteProfile.onDevice` makes the card add "written on this phone".
  - **Playlist suggestions.** The ✨ panel worked only for playlists synced to a YouTube account (YouTube's
    own suggestions). Any other playlist with songs now gets on-device ones:
    - `LocalPlaylistRepositoryImpl.onDeviceSuggestions` takes 4 seeds spread over the playlist, a different
      slice per reload (`PlaylistSuggestions.seeds`);
    - it fetches their anonymous `RDAMVM` radios, the same request as starting a radio;
    - `PlaylistSuggestions.pick` leaves out the playlist's songs by id and `songKey`, takes the radios in
      turn, and allows at most 2 songs per artist. `PlaylistSuggestionsTest`.
    - Reload params `ondevice:<id>:<batch>`. Suggestions load when the panel opens, no longer on every visit.
  - Lyrics translation still needs a key: no on-device model is bundled.
- **Analytics' back arrow only where there is somewhere to go back to (2026-10-11).** Analytics became a tab
  (2026-08-16), but kept the back arrow from its days as a page under Library: from the tab bar it only jumped to
  Home. `AnalyticsScreen` now draws it only when the screen below is not the graph's start destination (Home):
  every tab is opened with `popUpTo(start)`, so a tab always sits right on Home, while a link opened from another
  screen keeps its arrow. System back is unchanged.
- **Auto backup on Android 8 and 9 (2026-10-11).** `MediaStore.Downloads` exists from Android 10; touching it
  below that throws `NoClassDefFoundError`, an Error `AutoBackupWorker`'s `catch (e: Exception)` does not see, so
  auto backup never ran there. Those versions write `Downloads/SimpMusic` through the File API (the app holds
  `WRITE_EXTERNAL_STORAGE` up to SDK 28). Found by `:androidApp:lintOptimized`, whose other three errors
  (`UseAppTint` in `widget_preview_playlists.xml`) are wrong for a widget layout, which cannot use AppCompat.
- **Listen Together: connects by itself, guests can control playback (2026-10-11).**
  - Opening the screen connects (`ListenTogetherViewModel.ensureConnected`). Create and Join no longer wait for
    "Connected"; they connect too. Leaving the screen with no room and no pending join disconnects again, but
    only if this screen opened the connection (`connectedHere`). `ListenTogetherSession.connect()` now does
    nothing while connected or connecting: a second call used to set Connecting over a live peer transport,
    which then reported nothing new, so the screen stayed on "Connecting" with Create and Join disabled.
  - **Shared control.** Four message types exist in peer rooms only (`Protocol.kt`):
    - `control`: guest → room, a `PlaybackActionPayload`;
    - `control_request`: room → host, `ControlRequestPayload`;
    - `set_room_settings`: host → room, `RoomSettingsPayload`;
    - `room_settings`: room → everyone, `RoomSettingsPayload`.
    `RoomState`/`SyncStatePayload` carry `guestControl` at field 101, outside metroproto's numbering.
  - **`RoomHub.control` never edits the room.** It checks membership, the room's `guestControl` flag and the action
    (play, pause, seek, skip, or change track with a track), then forwards the request to the host. The host's
    bridge (`carryOutGuestControl`) runs it on the host's own player, and the host's usual publishers send the
    result. One device keeps deciding what plays next, so its queue, radio and endless queue keep working.
  - The setting lives in `HubSnapshot.guestControl`, so it survives a host transfer. A new room takes it from
    `lt_guest_control` (on unless `FALSE`), sent right after `room_created`. The host flips it from a switch on
    the room screen, which also stores it. Settings → Listen Together has the same toggle for new rooms. The
    transport's beacon check (`reconcileMembers`) re-delivers a lost `room_settings`.
  - Guest side (`ListenTogetherPlaybackBridge`). A guest's action is sent only when it disagrees with the room,
    which is what keeps the guest's own applied commands from echoing back:
    - play/pause: when the intent differs from `room.isPlaying`;
    - seek: when the guest is more than 2 s from the room's live position, checked 400 ms after the jump;
    - a song picked anywhere: sent as `change_track`.
    While a request is pending (4 s; 8 s for a song pick), the room's older state is not applied over it. A pick
    the room has not taken after 8 s switches the guest to listening on their own. A song the player moved to by
    itself (last seen within 3 s of its end, `lastSeen`) is not a pick. A pause from a call or another app taking
    the audio is not sent either: `MediaPlayerInterface.pausedBySystem`, set by the Android adapter's focus
    listener.
  - Bugs fixed on the way:
    - **Queue changes moved guests' playheads.** A `sync_queue` or `queue_add` overwrote the session's
      `lastActionServerTime` (and `queue_add` its position, set to 0). Every queue change from the host (endless
      queue appending, a trim, an approved suggestion) made guests seek back to the last play command, or to
      0:00. Only play, pause, seek and change_track move the playhead now (`PLAYHEAD_ACTIONS`). A play's or a
      seek's time base is the room's `serverTime`, at which the hub already compensated the position.
    - **Approving a suggestion played it at once on every guest**: `queue_add`'s `trackInfo` became
      `currentTrack`.
    - **Joins, leaves and host transfers made guests jump to 0:00 and back**: `publishSnapshot` re-sent
      `change_track` for the song already playing. It now sends play/pause (and the queue) when the room is on
      that song.
    - **Guests restarted every next song a second in.** Their player reached it first, and the host's
      `change_track` then rebuilt the queue and reloaded it. `playTrack` now keeps the playing item
      (`clearMediaItemsExceptCurrent`) when it is the room's song, and also when only the queue changed.
    - **The room queue held the songs already played.** The host published its whole queue, so a guest's player
      lined those up after the current song. Only songs after the current one go out now (`upcoming()`, at most
      100).
    - **A song change could go out as a seek of the old song to 0:00.** Seeks are now confirmed 400 ms later,
      on the same song.
  - Tests: `RoomHubTest` (control refused, allowed, forwarded, kept across a transfer) and `PeerRoomTest`
    (control through the host; a queue change and a suggestion leave guests' playheads alone). The bridge has
    no automated test (it needs a player handler). Not tried on devices.
- **Audius as a second high-bitrate source; YouTube rips refused as lossless (2026-10-11).**
  - With Hi-Fi sound on, the background search (`StreamRepositoryImpl.searchArchive`) tries Audius after an
    archive.org miss: `kotlinYtmusicScraper/.../audius/` (`Audius`, `AudiusCandidates`, `Mp3Header`),
    `YouTube.audius`.
  - It uses Audius's public API (`api.audius.co/v1/tracks/search`, `/v1/tracks/{id}/stream`, `app_name=SimpMusic`,
    no key). Every request needs a User-Agent; Cloudflare answers 403 to Python's default one.
  - Only tracks the artist uploaded themselves count: the account's name or handle is the artist. They must be
    streamable and not gated, deleted or unlisted, with no `remix_of` tracks and no `cover_original_song_title`.
    `RecordingMatcher` then applies its usual checks, and the stream's first MP3 frame must read ≥ 256 kbps stereo.
  - Audius re-signs the stream on every request: 302 to a content node, 307 to signed storage, 206 with ranges.
    The stored URL is the API one and never expires.
  - The hit is a `SourceKind.AUDIUS` stream, persisted in the song's `archive:` row with `itag = AUDIUS_ITAG`
    (2); `cpn` holds `trackId|uploader`. Its cache key is `audius:<id>:<hash>`.
  - `SourceKind.isHighQuality` (archive or Audius) now stands in for "is the archive" wherever the upgrade path
    asked: the seek re-schedule, the refusal list, and `reportStreamRejected`.
  - The seamless upgrade takes the found copy's own kind, and skips a copy that ranks below what plays.
    `PlaybackSource.rank` puts Audius MP3 at 208, between YouTube's Opus 160 (160) and Premium's 256.
  - The sources sheet shows an Audius row only when there is a match.
  - Measured 2026-10-11: ODESZA "Say My Name" matched at 320 kbps / 48 kHz in 2.9 s. A rough check found 2 of
    14 well-known songs (ODESZA, Marshmello); Queen and Taylor Swift have nothing there. First byte takes 0.8
    to 2 s, so instant start relies on the opening cache as with archive.org.
  - **archive.org's original MP3s were left out on purpose.** The ones checked were mostly YouTube rips
    re-encoded at 250–330 kbps ("Eagles - Hotel California (Official Audio).mp3", a Bad Bunny file inside an
    Eagles item): a higher number, but worse than YouTube's own stream.
  - The same reasoning now applies to FLAC: `ArchiveCandidates.looksLikeRip` drops items and files named after
    a downloader or a YouTube upload ("y2mate", "Official Audio", "Lyric Video"…).
  - Tests: `AudiusCandidatesTest` and `Mp3HeaderTest` (real search rows); `AudiusLiveTest` with `AUDIUS_LIVE=1`;
    `ArchiveCandidatesTest.youTubeRipsAreNotLossless`.
- **Starting on the lossless file needs 1 MiB cached (2026-10-11).** `StreamResolver.OPENING_BYTES` went from
  256 KiB (about 2 s of CD FLAC) to 1 MiB (about 9 s). With archive.org's 1.0–1.6 s first byte, the old bar could
  run out right after the start, which is a stall. With less cached, a song someone is waiting for starts on
  YouTube and the seamless upgrade moves it. Preloaded songs and the 1.5 MiB upcoming prefetch still clear the
  bar and start on the file.
- **Player notification: Like first, then noise control or Shuffle (2026-10-11).**
  - The system's media controls (notification, lock screen, quick settings) show only the first two custom
    buttons beside previous / play / next, and some phones only one. So the order is the priority.
  - `SimpleMediaService.publishButtons` orders them:
    1. Like (the heart);
    2. the noise-control button (`service/HeadsetNotification.kt`), while headphones with noise control are
       connected;
    3. Shuffle;
    4. Repeat and Radio.
    Shuffle is therefore visible only without such headphones. Everything after the second shows where a host
    has more room (Android Auto, watches).
  - `MediaServiceHandlerImpl.toggleLike` now updates `controlState.isLiked` itself. Before, the heart refreshed
    only when the app's screen reported the change, so a tap in the notification with the app closed looked
    ignored.
  - The noise button's icon is the mode (`ic_noise_control_on` / `ic_noise_aware` / `ic_noise_control_off`,
    converted from the app's SimpIcons to vector XML). Its name uses the in-app pill's words: "ANC · 80%",
    "ANC · Comfort", "Adaptive ANC", "Transparency", "Voice boost", "ANC off".
  - Its session command (`noise_control`) is granted in `SimpleMediaSessionCallback.onConnect`, since Media3
    leaves a button off the notification unless its command is granted. It reaches the service through the
    callback's `onNoiseControl`, the same pattern as `toggleLike`. The constant lives in the media3 module, not
    in upstream's `MEDIA_CUSTOM_COMMAND`, so no upstream `when` grows a case.
  - **Switching from the notification.**
    - A tap moves to the next mode at once on screen (`pendingMode`). The headphones get it only after
      `HeadsetNotification.SETTLE_MS` (700 ms) without another tap (`HeadsetRepository.setMode(mode, settleMs)`).
      Mode requests are a conflated channel, so tapping from ANC to Off writes Off alone, never the modes in
      between.
    - The next mode is computed from the repository's own state, not the service's copy, which can lag a tap
      behind.
    - The notification is re-posted only when the button's icon or name changes. One switch reports several
      intermediate states, and Android drops a burst of notification updates, possibly including the last one.
    - While paused, the button stays live for its 60 s: it used to freeze as soon as playback stopped.
  - **No song pauses on a switch.**
    - The MOMENTUM 4 has its own "pause music in Transparent Hearing" setting (`0x1800`/`0x1801`, Smart
      Control's "automatic pause", read from Tumult1337/momentum4-control). With it on, the headset sends AVRCP
      pause when Transparent Hearing turns on, and play when it turns off.
    - `HeadsetRepository.isChangingNoiseControl()` is true while the app applies a change and for 3 s after
      (`MEDIA_KEYS_AFTER_CHANGE_MS`). Meanwhile `SimpleMediaSessionCallback.onMediaButtonEvent` consumes play,
      pause, play/pause, stop and headset-hook keys. `onPlayerCommandRequest` refuses `COMMAND_PLAY_PAUSE` from
      the Bluetooth stack's packages, for stacks that send a transport command instead of a key.
    - The headset's own setting is not changed, so its touch gesture still pauses as the listener set it.
  - **Fewer round trips.** Once both ANC and Transparent Hearing notifications are registered,
    `Momentum4Session.act` plans from the state those keep current, so a switch costs its writes and one read
    back instead of a read, writes and a read back. If the read back shows a stale start, it plans once more
    from what was read.
  - The service collects `HeadsetRepository.state` only while music plays, and until 60 s after it stops.
    Collecting is what keeps the headphones' control channel open, and the headphones' own app needs that
    channel back.
  - The in-app pill and the notification leave the strength out while a switch is under way, since it is still
    the old mode's (it read "ANC 0%" on the way out of Transparency).
  - Tests: `Momentum4SessionTest` (`aSwitchSendsItsWritesAndOneReadBack`,
    `aStaleStartIsPlannedAgainFromWhatWasRead`, `withoutNotificationsTheStateIsReadFirst`). Not tried on a
    device, including whether the headset's pause arrives as a key.
- **Home recommendations when signed out (2026-10-11).**
  - Signed out, YouTube Music's own Home is "Podcasts to get you started" and an artist picker
    (`musicTastebuilderShelfRenderer`), with no music: measured anonymously on 2026-10-11.
  - `ForYouRepository` (domain; `data/foryou/ForYouRepositoryImpl`, `forYouModule`) builds Quick picks, New for
    you and Listen again, and `HomeViewModel.refreshForYou` puts them first. Signed in, they are removed again.
  - The shelves come from radios (`next` on `RDAMVM<id>`, no account) of the songs played most in the last 30
    days, then of all time (up to 4 seeds). With no history at all, the first chart playlist seeds them
    instead: for the global chart, "Daily Top Music Videos". Its queue becomes Quick picks.
  - `ForYouShelves` (domain, pure, `ForYouShelvesTest`) decides what goes where:
    - the radios take turns;
    - seeds and songs heard in the last 3 h are left out;
    - "New for you" holds only songs never started or liked, matched by id and by `songKey`;
    - at most 2 songs per artist in a shelf.
  - Quick picks must carry the app's own `quick_picks` string: Home draws that shelf by its title.
  - Listen again gets `itemsPerColumn = 1` only so it stays a row of cards. A card shelf of songs only with no
    More page is otherwise drawn as the large hero carousel (`isSongCardShelf`), which New for you does use.
  - The repository is injected in `HomeViewModel` with `by inject()`, so upstream's `ViewModelModule` is
    untouched.
- **Podcasts tab: RSS feeds and YouTube channels (2026-10-12).** A nav tab (`BottomNavScreen.Podcasts`, ordinal 5,
  before Library in all three bars: `AppBottomNavigationBar`, `AppNavigationRail` in the same file, and both lists
  of the Android liquid-glass bar) opens `PodcastsScreen` (`PodcastsDestination`); a podcast opens
  `PodcastFeedScreen` (`PodcastFeedDestination(podcastId | feedUrl)`). One `PodcastFeedsViewModel` serves both.
  - **Adding.** One field takes an RSS feed, a podcast's web page (its `<link rel="alternate">` feed is followed),
    a YouTube channel (`/channel/UC…`, `@handle`, `/c/`, `/user/`: the id is read from the page's `externalId`)
    or a YouTube playlist (`list=`). `kotlinYtmusicScraper/.../podcast/`: `PodcastFeeds` (client,
    `YouTube.podcastFeeds`, shares the proxy), `FeedXml` (a forgiving hand-written XML reader: entities outside
    CDATA, unclosed `<br>`, DOCTYPEs; no new dependency), `FeedParser` (RSS 2.0 with iTunes tags, RSS 1.0,
    Atom; RFC 822 and ISO dates without a library), `YouTubeChannelPage`.
  - **YouTube channels are read through InnerTube, not their RSS feed.** `feeds/videos.xml` answered 404 for every
    channel on 2026-10-12 (Invidious #6074 reports the same) and never gives lengths. A WEB `browse` of the
    channel with `params=EgZ2aWRlb3PyBgQKAjoA` (Videos tab, no Shorts) or of `VL<playlist>` returns
    `lockupViewModel`s: `contentId`, title, `["989K views","3 weeks ago"]`, a length badge. Dates are therefore
    approximate (now − age); a refresh keeps the date first worked out. The RSS feed stays as the fallback, with
    Shorts dropped. Only the newest page (30 videos) is read; what was seen before stays.
  - **Storage** is JSON files under `fileDir()/podcasts/` (`feeds.json`, `episodes/<id>.json`, `progress.json`),
    written temp-file + atomic move: not Room (no schema version of this copy's own), not DataStore (back catalogues
    would be rewritten with every settings change). `PodcastFeedRepositoryImpl` (`data/podcast/`,
    `podcastFeedModule`) keeps at most 500 episodes a podcast, refreshes feeds older than an hour when the tab
    opens (4 at a time), and writes positions at most every 5 s.
  - **Playback.** A YouTube episode is its video id and plays like any video. An RSS episode is `pod_<hash>`
    (`FeedIds`): `StreamRepository.feedEpisodeStream` gives the enclosure as a `SourceKind.PODCAST` stream, which
    `StreamResolver` (Android, unchunked, cache key `podcast:<id>:<hash>`) and `MpvPlayerAdapter` (Desktop) check
    first, and `getStream` returns for downloads. `GenericMediaItem.isVideo()` / `MediaItem.isVideo()` are false for
    `pod_` ids, since `SongEntity.toTrack()` turns any non-544 artwork into a "video". No lossless search, lyrics
    provider, canvas or song-info lookup is ever asked about a followed podcast's episode (`isPodcastEpisode`
    in `StreamRepositoryImpl` and `SharedViewModel`), and `getRelatedData` refuses `pod_` ids.
  - **Resume.** `PodcastPlaybackTracker` (data, started from `App`) saves a followed episode's position every 5 s on
    the main thread, and on its next start seeks there once the length is known, unless it was left within 30 s of
    the end or 95% through (`EpisodeProgress.finished`), or the player already moved past 3 s.
  - **Recommendations** come from Apple's public directory (`itunes.apple.com/search?media=podcast`), which returns
    RSS feed addresses, so a suggestion can be followed in one tap or opened first (`preview`, kept in memory,
    playable). Search words come only from the followed feeds (`PodcastSuggestionPicker`: keywords, then the most
    specific categories, then the shows' names; shared words first), never from listening history; with nothing
    followed, six broad subjects. Two searches at a time, one retry after a 403/429 (Apple allows about 20 a
    minute), results cached 6 h.
  - Tests: `FeedParserTest`, `YouTubeChannelPageTest`, `PodcastSuggestionPickerTest`; `PodcastFeedsLiveTest`
    (`PODCAST_LIVE=1`: Darknet Diaries' feed, Lex Fridman's channel by handle, the directory) passed on 2026-10-12.
    Not tried on a device.
- **Hi-Fi sources can be turned off one by one (2026-10-12).** Under Hi-Fi sound in Settings → Playback: "Internet
  Archive" (`source_internet_archive`) and "Audius" (`source_audius`), both on by default. `StreamRepositoryImpl`
  skips a turned-off source in the background search, ignores a match already found from it (`knownLossless`), and
  remembers a miss (6 h) only when every source was asked, so turning one back on searches again. The sources sheet
  lists a turned-off source as off. YouTube is always on; the SoundCloud backup keeps its own switch.
