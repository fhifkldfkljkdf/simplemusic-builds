package com.maxrave.simpmusic.viewModel

import androidx.lifecycle.viewModelScope
import com.maxrave.common.Config
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.data.model.podcast.EpisodeProgress
import com.maxrave.domain.data.model.podcast.FeedEpisode
import com.maxrave.domain.data.model.podcast.FeedPodcast
import com.maxrave.domain.data.model.podcast.PodcastSuggestion
import com.maxrave.domain.data.model.searchResult.songs.Artist
import com.maxrave.domain.data.model.searchResult.songs.Thumbnail
import com.maxrave.domain.mediaservice.handler.PlaylistType
import com.maxrave.domain.mediaservice.handler.QueueData
import com.maxrave.domain.repository.PodcastFeedRepository
import com.maxrave.simpmusic.viewModel.base.BaseViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Private copy: the Podcasts tab and a podcast's page — followed feeds, their episodes, listening
 * positions, adding a feed by its address, and podcasts like the followed ones.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class PodcastFeedsViewModel(
    private val repository: PodcastFeedRepository,
) : BaseViewModel() {
    val podcasts: StateFlow<List<FeedPodcast>?> =
        repository.podcasts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val latest: StateFlow<List<FeedEpisode>> =
        repository.latestEpisodes(LATEST_COUNT).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val progress: StateFlow<Map<String, EpisodeProgress>> =
        repository.progress.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    sealed interface Suggestions {
        data object Loading : Suggestions

        data class Ready(
            val list: List<PodcastSuggestion>,
        ) : Suggestions

        data object Failed : Suggestions
    }

    private val _suggestions = MutableStateFlow<Suggestions>(Suggestions.Loading)
    val suggestions: StateFlow<Suggestions> = _suggestions.asStateFlow()

    private val _adding = MutableStateFlow<String?>(null)

    /** The address being added, while it is read. */
    val adding: StateFlow<String?> = _adding.asStateFlow()

    private val _addError = MutableStateFlow<String?>(null)
    val addError: StateFlow<String?> = _addError.asStateFlow()

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    private val openPodcast = MutableStateFlow<String?>(null)

    /** Episodes of the podcast whose page is open. */
    val episodes: StateFlow<List<FeedEpisode>> =
        openPodcast
            .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.episodes(id) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    sealed interface Page {
        data object Loading : Page

        data class Ready(
            val podcast: FeedPodcast,
            /** Followed: its episodes come from [episodes]. Looked at only: these are all there is. */
            val followed: Boolean,
            val previewEpisodes: List<FeedEpisode> = emptyList(),
        ) : Page

        data class Failed(
            val message: String,
        ) : Page
    }

    private val _page = MutableStateFlow<Page>(Page.Loading)

    /** The podcast whose page is open. */
    val page: StateFlow<Page> = _page.asStateFlow()

    private var opened = false

    /** The tab came on screen: feeds older than an hour are read again, and suggestions fetched. */
    fun openTab() {
        if (opened) return
        opened = true
        // Side by side: one slow feed must not hold the recommendations back.
        viewModelScope.launch { repository.refreshAll() }
        loadSuggestions()
    }

    /** Opens a followed podcast's page by [podcastId], or reads [feedUrl] to look at before following. */
    fun openPage(
        podcastId: String?,
        feedUrl: String?,
    ) {
        _page.value = Page.Loading
        viewModelScope.launch {
            val followed = podcastId?.let { id -> repository.podcasts.first().firstOrNull { it.id == id } }
            if (followed != null) {
                openPodcast.value = followed.id
                _page.value = Page.Ready(followed, followed = true)
                return@launch
            }
            if (feedUrl == null) {
                _page.value = Page.Failed("")
                return@launch
            }
            repository
                .preview(feedUrl)
                .onSuccess { (podcast, list) ->
                    val isFollowed = repository.podcasts.first().any { it.id == podcast.id }
                    openPodcast.value = podcast.id
                    _page.value = Page.Ready(podcast, followed = isFollowed, previewEpisodes = list)
                }.onFailure { _page.value = Page.Failed(it.message ?: it::class.simpleName.orEmpty()) }
        }
    }

    /** Follows the podcast whose page is open. */
    fun followOpen() {
        val ready = _page.value as? Page.Ready ?: return
        add(ready.podcast.feedUrl) { podcast ->
            openPodcast.value = podcast.id
            _page.value = Page.Ready(podcast, followed = true)
        }
    }

    fun unfollowOpen() {
        val ready = _page.value as? Page.Ready ?: return
        viewModelScope.launch {
            repository.remove(ready.podcast.id)
            _page.value = ready.copy(followed = false, previewEpisodes = ready.previewEpisodes.ifEmpty { episodes.value })
            loadSuggestions()
        }
    }

    fun loadSuggestions() {
        viewModelScope.launch {
            if (_suggestions.value !is Suggestions.Ready) _suggestions.value = Suggestions.Loading
            _suggestions.value =
                repository.suggestions().fold(
                    onSuccess = { Suggestions.Ready(it) },
                    onFailure = { Suggestions.Failed },
                )
        }
    }

    fun refresh() {
        if (_refreshing.value) return
        viewModelScope.launch {
            _refreshing.value = true
            try {
                repository.refreshAll(force = true)
            } finally {
                _refreshing.value = false
            }
        }
    }

    fun refresh(podcastId: String) {
        if (_refreshing.value) return
        viewModelScope.launch {
            _refreshing.value = true
            try {
                repository.refresh(podcastId)
            } finally {
                _refreshing.value = false
            }
        }
    }

    /** Follows what [input] points at; [onAdded] gets the podcast once its feed was read. */
    fun add(
        input: String,
        onAdded: (FeedPodcast) -> Unit = {},
    ) {
        val text = input.trim()
        if (text.isEmpty() || _adding.value != null) return
        _addError.value = null
        _adding.value = text
        viewModelScope.launch {
            repository
                .add(text)
                .onSuccess { podcast ->
                    _addError.value = null
                    onAdded(podcast)
                    loadSuggestions()
                }.onFailure { failure ->
                    log("Could not add $text: ${failure.message}")
                    _addError.value = failure.message ?: failure::class.simpleName
                }
            _adding.value = null
        }
    }

    fun clearAddError() {
        _addError.value = null
    }

    fun unfollow(podcastId: String) {
        viewModelScope.launch {
            repository.remove(podcastId)
            loadSuggestions()
        }
    }

    /** Plays [episodes] from [index]: the rest of the list follows in the order shown. */
    fun play(
        podcast: FeedPodcast,
        episodes: List<FeedEpisode>,
        index: Int,
    ) {
        val episode = episodes.getOrNull(index) ?: return
        val tracks = episodes.map { it.toTrack(podcast) }
        setQueueData(
            QueueData.Data(
                listTracks = tracks,
                firstPlayedTrack = tracks[index],
                playlistId = podcast.id,
                playlistName = "Podcast \"${podcast.title}\"",
                playlistType = PlaylistType.PLAYLIST,
                continuation = null,
            ),
        )
        log("Playing ${episode.title} from ${podcast.title}")
        loadMediaItem(tracks[index], Config.PLAYLIST_CLICK, index)
    }

    /** Plays one of the newest episodes, each with its own podcast. */
    fun playLatest(index: Int) {
        val list = latest.value
        val byId = podcasts.value.orEmpty().associateBy { it.id }
        val tracks = list.mapNotNull { episode -> byId[episode.podcastId]?.let { episode.toTrack(it) } }
        val first = list.getOrNull(index)?.let { episode -> byId[episode.podcastId]?.let { episode.toTrack(it) } } ?: return
        val start = tracks.indexOfFirst { it.videoId == first.videoId }.coerceAtLeast(0)
        setQueueData(
            QueueData.Data(
                listTracks = tracks,
                firstPlayedTrack = first,
                playlistId = null,
                playlistName = "New episodes",
                playlistType = PlaylistType.PLAYLIST,
                continuation = null,
            ),
        )
        loadMediaItem(first, Config.PLAYLIST_CLICK, start)
    }

    fun podcast(podcastId: String): FeedPodcast? = podcasts.value?.firstOrNull { it.id == podcastId }

    private companion object {
        const val LATEST_COUNT = 30
    }
}

/**
 * An episode as the player queues it. An RSS episode carries a square picture, which is what
 * marks it as audio; a YouTube video carries its own 16:9 thumbnail and plays like any video.
 */
fun FeedEpisode.toTrack(podcast: FeedPodcast): Track {
    val picture = imageUrl ?: podcast.imageUrl
    return Track(
        album = null,
        artists = listOf(Artist(id = podcast.youTubeChannelId, name = podcast.author ?: podcast.title)),
        duration = durationSeconds?.let(::clock),
        durationSeconds = durationSeconds,
        isAvailable = true,
        isExplicit = false,
        likeStatus = null,
        thumbnails =
            picture?.let {
                listOf(if (isYouTube) Thumbnail(height = 360, url = it, width = 480) else Thumbnail(height = 544, url = it, width = 544))
            },
        title = title,
        videoId = id,
        videoType = null,
        category = podcast.title,
        feedbackTokens = null,
        resultType = null,
    )
}

private fun clock(seconds: Int): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "$h:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}" else "$m:${s.toString().padStart(2, '0')}"
}
