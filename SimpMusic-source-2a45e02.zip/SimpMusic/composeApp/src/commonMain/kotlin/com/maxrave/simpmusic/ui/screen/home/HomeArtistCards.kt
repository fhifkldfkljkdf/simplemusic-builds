package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.data.model.home.HomeItem
import com.maxrave.domain.data.model.home.chart.ItemArtist
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.ui.HorizontalScrollBar
import com.maxrave.simpmusic.extension.getScreenSizeInfo
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.component.HomeSectionHeader
import com.maxrave.simpmusic.ui.component.rememberHolderPainter
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.navigation.destination.list.ArtistDestination
import com.maxrave.simpmusic.ui.theme.typo
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.new_to_you
import simpmusic.composeapp.generated.resources.you_might_like

/**
 * Private copy: one artist in Home's "Top artists" row — Spotify's shelf shape: a big circular photo
 * with the name underneath, no rank number. [subtitle] says why the artist is there: their subscriber
 * line, "New to you", or "You might like" for a related artist the listener has heard before.
 */
@Composable
fun HomeArtistCard(
    data: ItemArtist,
    imageSize: Dp,
    subtitle: String,
    onClick: () -> Unit,
) {
    val appShapes = LocalAppShapes.current
    val thumb = data.thumbnails.lastOrNull()?.url
    Column(
        modifier =
            Modifier
                .width(imageSize + 24.dp)
                .clip(appShapes.card)
                .clickable(onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AsyncImage(
            model =
                ImageRequest
                    .Builder(LocalPlatformContext.current)
                    .data(thumb)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .diskCacheKey(thumb)
                    .crossfade(550)
                    .build(),
            placeholder = rememberHolderPainter(),
            error = rememberHolderPainter(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier =
                Modifier
                    .size(imageSize)
                    .clip(CircleShape),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = data.title,
            style = typo().titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = subtitle,
            style = typo().bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/**
 * Private copy: Home's "Top artists" row, in the feed near the top. The listener's own artists
 * come first, then the genuinely new ones ("New to you"), then related artists they have met
 * ("You might like"); each is a big circular card, without the chart's rank numbers.
 */
@Composable
fun TopArtistsRow(
    data: HomeItem,
    navController: NavController,
) {
    val row = data.topArtists ?: return
    val listState = rememberLazyListState()
    val flingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyListState = listState))
    val isPortrait = getScreenSizeInfo().let { it.wDP < it.hDP }
    val imageSize = if (isPortrait) 132.dp else 160.dp
    Column {
        HomeSectionHeader(data = data, navController = navController, onPlayAll = {})
        LazyRow(
            state = listState,
            flingBehavior = flingBehavior,
        ) {
            itemsIndexed(
                row.artists,
                key = { index, artist -> artist.browseId + artist.title + index },
            ) { index, artist ->
                HomeArtistCard(
                    data = artist,
                    imageSize = imageSize,
                    subtitle =
                        when {
                            index < row.knownCount -> artist.subscribers
                            index < row.knownCount + row.newCount -> stringResource(Res.string.new_to_you)
                            else -> stringResource(Res.string.you_might_like)
                        },
                    onClick = {
                        navController.navigate(
                            ArtistDestination(
                                channelId = artist.browseId,
                            ),
                        )
                    },
                )
            }
        }
        if (getPlatform() == Platform.Desktop) {
            HorizontalScrollBar(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                scrollState = listState,
                flingBehavior = flingBehavior,
            )
        }
    }
}
