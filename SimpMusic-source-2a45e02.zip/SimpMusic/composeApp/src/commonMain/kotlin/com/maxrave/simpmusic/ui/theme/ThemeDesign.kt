package com.maxrave.simpmusic.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import com.maxrave.domain.manager.DataStoreManager

/**
 * Private copy: what a named app theme changes besides its palette — corner shapes, typeface,
 * chip style and the few Home/Navigation touches. The Spotify and Retro themes had some of this
 * already; this makes every theme carry a shape and type identity.
 */
enum class AppThemeFamily {
    DEFAULT,
    MATERIAL_YOU,
    SPOTIFY,
    APPLE_MUSIC,
    OCEAN,
    AMOLED,
    RETRO,
    CUSTOM,
}

/** How the filter chips are drawn: outlined (app default), filled, or square-filled. */
enum class AppChipStyle { OUTLINED, FILLED, SQUARE }

/** [Shape]s used by Home's cards, artwork and the navigation bar, per theme. */
data class AppShapes(
    val card: Shape,
    val cardSmall: Shape,
    val artwork: Shape,
    val artworkSmall: Shape,
    val hero: Shape,
    val chip: Shape,
    val navBar: Shape,
    val navIndicator: Shape,
    val searchButton: Shape,
)

val LocalAppThemeFamily = staticCompositionLocalOf { AppThemeFamily.DEFAULT }
val LocalAppShapes = staticCompositionLocalOf { defaultAppShapes() }
val LocalAppChipStyle = staticCompositionLocalOf { AppChipStyle.OUTLINED }

/** Whether the theme has a palette of its own, so Desktop's shell should take it instead of #121212. */
fun AppThemeFamily.usesThemedShell(): Boolean =
    this == AppThemeFamily.SPOTIFY ||
        this == AppThemeFamily.APPLE_MUSIC ||
        this == AppThemeFamily.OCEAN ||
        this == AppThemeFamily.AMOLED ||
        this == AppThemeFamily.RETRO

fun themeFamily(source: String): AppThemeFamily =
    when (source) {
        DataStoreManager.THEME_COLOR_SPOTIFY -> AppThemeFamily.SPOTIFY
        DataStoreManager.THEME_COLOR_APPLE_MUSIC -> AppThemeFamily.APPLE_MUSIC
        DataStoreManager.THEME_COLOR_OCEAN -> AppThemeFamily.OCEAN
        DataStoreManager.THEME_COLOR_AMOLED -> AppThemeFamily.AMOLED
        DataStoreManager.THEME_COLOR_RETRO -> AppThemeFamily.RETRO
        DataStoreManager.THEME_COLOR_WALLPAPER -> AppThemeFamily.MATERIAL_YOU
        DataStoreManager.THEME_COLOR_CUSTOM -> AppThemeFamily.CUSTOM
        else -> AppThemeFamily.DEFAULT
    }

fun defaultAppShapes(): AppShapes =
    AppShapes(
        card = RoundedCornerShape(8.dp),
        cardSmall = RoundedCornerShape(5.dp),
        artwork = RoundedCornerShape(10.dp),
        artworkSmall = RoundedCornerShape(8.dp),
        hero = RoundedCornerShape(28.dp),
        chip = CircleShape,
        navBar = RoundedCornerShape(32.dp),
        navIndicator = RoundedCornerShape(18.dp),
        searchButton = CircleShape,
    )

fun appShapesFor(family: AppThemeFamily): AppShapes =
    when (family) {
        AppThemeFamily.SPOTIFY ->
            defaultAppShapes().copy(
                card = RoundedCornerShape(8.dp),
                cardSmall = RoundedCornerShape(6.dp),
                artwork = RoundedCornerShape(10.dp),
                hero = RoundedCornerShape(20.dp),
            )
        AppThemeFamily.APPLE_MUSIC ->
            defaultAppShapes().copy(
                card = RoundedCornerShape(12.dp),
                cardSmall = RoundedCornerShape(8.dp),
                artwork = RoundedCornerShape(14.dp),
                artworkSmall = RoundedCornerShape(10.dp),
                hero = RoundedCornerShape(24.dp),
            )
        AppThemeFamily.OCEAN ->
            defaultAppShapes().copy(
                card = RoundedCornerShape(16.dp),
                cardSmall = RoundedCornerShape(10.dp),
                artwork = RoundedCornerShape(18.dp),
                artworkSmall = RoundedCornerShape(12.dp),
                hero = RoundedCornerShape(28.dp),
            )
        AppThemeFamily.AMOLED ->
            AppShapes(
                card = RoundedCornerShape(2.dp),
                cardSmall = RoundedCornerShape(2.dp),
                artwork = RoundedCornerShape(2.dp),
                artworkSmall = RoundedCornerShape(2.dp),
                hero = RoundedCornerShape(8.dp),
                chip = RoundedCornerShape(2.dp),
                navBar = RoundedCornerShape(6.dp),
                navIndicator = RoundedCornerShape(4.dp),
                searchButton = RoundedCornerShape(8.dp),
            )
        AppThemeFamily.RETRO ->
            AppShapes(
                card = RoundedCornerShape(0.dp),
                cardSmall = RoundedCornerShape(0.dp),
                artwork = RoundedCornerShape(0.dp),
                artworkSmall = RoundedCornerShape(0.dp),
                hero = RoundedCornerShape(0.dp),
                chip = RoundedCornerShape(2.dp),
                navBar = RoundedCornerShape(0.dp),
                navIndicator = RoundedCornerShape(0.dp),
                searchButton = RoundedCornerShape(0.dp),
            )
        else -> defaultAppShapes()
    }

fun chipStyleFor(family: AppThemeFamily): AppChipStyle =
    when (family) {
        AppThemeFamily.SPOTIFY, AppThemeFamily.APPLE_MUSIC, AppThemeFamily.OCEAN -> AppChipStyle.FILLED
        AppThemeFamily.AMOLED, AppThemeFamily.RETRO -> AppChipStyle.SQUARE
        else -> AppChipStyle.OUTLINED
    }

val AppleShapes =
    Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(24.dp),
        extraLarge = RoundedCornerShape(28.dp),
    )

val OceanShapes =
    Shapes(
        extraSmall = RoundedCornerShape(10.dp),
        small = RoundedCornerShape(14.dp),
        medium = RoundedCornerShape(18.dp),
        large = RoundedCornerShape(26.dp),
        extraLarge = RoundedCornerShape(32.dp),
    )

val AmoledShapes =
    Shapes(
        extraSmall = RoundedCornerShape(2.dp),
        small = RoundedCornerShape(4.dp),
        medium = RoundedCornerShape(6.dp),
        large = RoundedCornerShape(10.dp),
        extraLarge = RoundedCornerShape(14.dp),
    )

/**
 * [base] with every style set in [family] — used for Apple/Ocean/AMOLED (system sans) and Retro
 * (VT323). [scale] lifts the sizes for a face with a small x-height, keeping the layout's rhythm.
 */
fun typographyWithFamily(
    base: Typography,
    family: FontFamily,
    scale: Float = 1f,
): Typography {
    fun androidx.compose.ui.text.TextStyle.withFamily(): androidx.compose.ui.text.TextStyle =
        copy(
            fontFamily = family,
            fontSize = if (fontSize.isSpecified) fontSize * scale else fontSize,
            lineHeight = if (lineHeight.isSpecified) lineHeight * scale else lineHeight,
        )
    return Typography(
        displayLarge = base.displayLarge.withFamily(),
        displayMedium = base.displayMedium.withFamily(),
        displaySmall = base.displaySmall.withFamily(),
        headlineLarge = base.headlineLarge.withFamily(),
        headlineMedium = base.headlineMedium.withFamily(),
        headlineSmall = base.headlineSmall.withFamily(),
        titleLarge = base.titleLarge.withFamily(),
        titleMedium = base.titleMedium.withFamily(),
        titleSmall = base.titleSmall.withFamily(),
        bodyLarge = base.bodyLarge.withFamily(),
        bodyMedium = base.bodyMedium.withFamily(),
        bodySmall = base.bodySmall.withFamily(),
        labelLarge = base.labelLarge.withFamily(),
        labelMedium = base.labelMedium.withFamily(),
        labelSmall = base.labelSmall.withFamily(),
    )
}
