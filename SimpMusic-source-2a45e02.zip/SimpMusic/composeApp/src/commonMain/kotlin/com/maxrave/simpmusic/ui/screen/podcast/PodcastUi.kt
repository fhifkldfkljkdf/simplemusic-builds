package com.maxrave.simpmusic.ui.screen.podcast

import com.maxrave.simpmusic.ui.component.ThemedIcon
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.maxrave.domain.data.model.podcast.EpisodeProgress
import com.maxrave.domain.data.model.podcast.FeedEpisode
import com.maxrave.simpmusic.ui.component.rememberHolderPainter
import com.maxrave.simpmusic.ui.icon.Add
import com.maxrave.simpmusic.ui.icon.CheckCircle
import com.maxrave.simpmusic.ui.icon.PlayArrow
import com.maxrave.simpmusic.ui.icon.Search
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.screen.home.analytics.formatChartDay
import com.maxrave.simpmusic.ui.theme.typo
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import org.jetbrains.compose.resources.pluralStringResource
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.podcasts_add
import simpmusic.composeapp.generated.resources.podcasts_add_hint
import simpmusic.composeapp.generated.resources.podcasts_days_ago
import simpmusic.composeapp.generated.resources.podcasts_hours
import simpmusic.composeapp.generated.resources.podcasts_left
import simpmusic.composeapp.generated.resources.podcasts_minutes
import simpmusic.composeapp.generated.resources.podcasts_played
import simpmusic.composeapp.generated.resources.podcasts_search_hint
import simpmusic.composeapp.generated.resources.podcasts_today
import simpmusic.composeapp.generated.resources.podcasts_yesterday
import kotlin.time.Clock
import kotlin.time.Instant

internal val PodcastArtShape = RoundedCornerShape(10.dp)

@Composable
internal fun SectionHeader(
    text: String,
    modifier: Modifier = Modifier,
) {
    Text(
        text = text,
        style = typo().titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

@Composable
internal fun MutedText(
    text: String,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
) {
    Text(
        text = text,
        style = typo().bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier,
    )
}

@Composable
internal fun Artwork(
    url: String?,
    size: Dp,
    modifier: Modifier = Modifier,
) {
    AsyncImage(
        model = url,
        contentDescription = null,
        placeholder = rememberHolderPainter(),
        error = rememberHolderPainter(),
        contentScale = ContentScale.Crop,
        modifier =
            modifier
                .size(size)
                .clip(PodcastArtShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest),
    )
}

/**
 * Private copy: the one bar at the top of the Podcasts tab. A name searches Apple's directory as it
 * is typed; an address - an RSS feed, a podcast page, a YouTube channel or playlist - turns the lens
 * into a +, and tapping it follows that address. One field instead of two means no guessing which of
 * them a pasted link belongs in.
 */
@Composable
internal fun PodcastBar(
    adding: Boolean,
    searching: Boolean,
    onQueryChange: (String) -> Unit,
    onAdd: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var text by rememberSaveable { mutableStateOf("") }
    val address = looksLikeAddress(text)
    val submit = {
        if (text.isNotBlank() && !adding) {
            onAdd(text)
            text = ""
        }
    }
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        BasicTextField(
            value = text,
            onValueChange = { typed ->
                text = typed
                // A pasted address is not a search term: don't ask the directory about it.
                onQueryChange(if (looksLikeAddress(typed)) "" else typed)
            },
            singleLine = true,
            textStyle = typo().bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions =
                KeyboardOptions(
                    keyboardType = if (address) KeyboardType.Uri else KeyboardType.Text,
                    imeAction = if (address) ImeAction.Go else ImeAction.Search,
                ),
            keyboardActions = KeyboardActions(onGo = { submit() }),
            modifier =
                Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.10f)),
            decorationBox = { inner ->
                Box(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) MutedText(stringResource(Res.string.podcasts_search_hint), maxLines = 1)
                    inner()
                }
            },
        )
        Box(
            modifier =
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (address) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f),
                    ).clickable(enabled = address && !adding) { submit() },
            contentAlignment = Alignment.Center,
        ) {
            when {
                adding -> CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                address ->
                    ThemedIcon(
                        SimpIcons.Add,
                        contentDescription = stringResource(Res.string.podcasts_add),
                        tint = MaterialTheme.colorScheme.onPrimary,
                    )

                searching -> CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                else -> ThemedIcon(SimpIcons.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/**
 * Whether [text] is an address to follow rather than a name to search for. The shapes
 * `PodcastFeeds.resolve` accepts: anything with a scheme, a YouTube link or handle, or a bare host
 * such as `feeds.example.com/rss`. Only these turn the lens into a +, so a search for a name is
 * never mistaken for a link.
 */
internal fun looksLikeAddress(text: String): Boolean {
    val trimmed = text.trim()
    if (trimmed.isEmpty()) return false
    val lower = trimmed.lowercase()
    if (lower.startsWith("http://") || lower.startsWith("https://")) return true
    if (YOUTUBE_LINK.containsMatchIn(lower)) return true
    if (YOUTUBE_HANDLE.matches(trimmed)) return true
    return HOST_AND_PATH.matches(trimmed)
}

private val YOUTUBE_LINK = Regex("""(^|\.)(youtube\.com|youtu\.be)/""")
private val YOUTUBE_HANDLE = Regex("""^@[A-Za-z0-9._-]{3,}$""")
private val HOST_AND_PATH = Regex("""^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}([/?#]\S*)?$""")

/** One directory search result: tap to follow it. */
@Composable
internal fun PodcastSearchResultRow(
    title: String,
    author: String?,
    imageUrl: String?,
    onClick: () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AsyncImage(
            model = imageUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(44.dp).clip(PodcastArtShape),
        )
        Column(Modifier.weight(1f)) {
            Text(title, style = typo().bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!author.isNullOrBlank()) MutedText(author, maxLines = 1)
        }
    }
}

/** One episode: picture, title, podcast and date, how far it was listened to. */
@Composable
internal fun EpisodeRow(
    episode: FeedEpisode,
    podcastTitle: String?,
    progress: EpisodeProgress?,
    playing: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clickable { onClick() }
                .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(episode.imageUrl, 56.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                text = episode.title,
                style = typo().labelMedium,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            MutedText(episodeLine(episode, podcastTitle, progress), maxLines = 1)
            if (progress != null && !progress.finished && progress.positionMs > 0) {
                LinearProgressIndicator(
                    progress = { progress.fraction },
                    modifier = Modifier.fillMaxWidth(0.6f).height(3.dp).clip(CircleShape),
                    drawStopIndicator = {},
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        ThemedIcon(
            imageVector = if (progress?.finished == true) SimpIcons.CheckCircle else SimpIcons.PlayArrow,
            contentDescription = null,
            tint = if (progress?.finished == true) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.size(22.dp),
        )
    }
}

@Composable
private fun episodeLine(
    episode: FeedEpisode,
    podcastTitle: String?,
    progress: EpisodeProgress?,
): String {
    val parts = ArrayList<String>()
    podcastTitle?.let(parts::add)
    episode.publishedAtMs?.let { parts += publishedLabel(it) }
    when {
        progress?.finished == true -> parts += stringResource(Res.string.podcasts_played)
        progress != null && progress.positionMs > 0 && progress.durationMs > 0 ->
            parts += stringResource(Res.string.podcasts_left, lengthLabel(((progress.durationMs - progress.positionMs) / 1000).toInt()))
        episode.durationSeconds != null && episode.durationSeconds!! > 0 -> parts += lengthLabel(episode.durationSeconds!!)
    }
    return parts.joinToString(" · ")
}

@Composable
internal fun lengthLabel(seconds: Int): String {
    val hours = seconds / 3600
    val minutes = (seconds % 3600) / 60
    return when {
        hours > 0 && minutes > 0 -> stringResource(Res.string.podcasts_hours, hours) + " " + stringResource(Res.string.podcasts_minutes, minutes)
        hours > 0 -> stringResource(Res.string.podcasts_hours, hours)
        else -> stringResource(Res.string.podcasts_minutes, minutes.coerceAtLeast(1))
    }
}

@Composable
internal fun publishedLabel(epochMs: Long): String {
    val zone = TimeZone.currentSystemDefault()
    val day = Instant.fromEpochMilliseconds(epochMs).toLocalDateTime(zone).date
    val today = Clock.System.now().toLocalDateTime(zone).date
    val days = (today.toEpochDays() - day.toEpochDays()).toInt()
    return when {
        days <= 0 -> stringResource(Res.string.podcasts_today)
        days == 1 -> stringResource(Res.string.podcasts_yesterday)
        days < 7 -> pluralStringResource(Res.plurals.podcasts_days_ago, days, days)
        else -> formatChartDay(day)
    }
}
