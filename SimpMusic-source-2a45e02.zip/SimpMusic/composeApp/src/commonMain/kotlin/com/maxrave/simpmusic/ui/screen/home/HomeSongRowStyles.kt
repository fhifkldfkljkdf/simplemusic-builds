package com.maxrave.simpmusic.ui.screen.home

import com.maxrave.simpmusic.ui.component.ThemedIcon
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.data.model.home.Content
import com.maxrave.domain.data.model.home.HomeItem
import com.maxrave.domain.utils.connectArtists
import com.maxrave.domain.utils.toListName
import com.maxrave.domain.utils.toSongEntity
import com.maxrave.domain.utils.toTrack
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.ui.HorizontalScrollBar
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.component.HomeContentCard
import com.maxrave.simpmusic.ui.component.HomeItemVideo
import com.maxrave.simpmusic.ui.component.HomeSectionHeader
import com.maxrave.simpmusic.ui.component.NowPlayingBottomSheet
import com.maxrave.simpmusic.ui.component.playRadio
import com.maxrave.simpmusic.ui.component.rememberHolderPainter
import com.maxrave.simpmusic.ui.icon.PlayArrow
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.HomeViewModel

/**
 * Private copy: the three layouts of Home's app-built song rows, so "Because you played", "More like"
 * and "… for you" do not all read as the same row. Each row type keeps its own [HomeShelfStyle].
 */

private const val TOP_LIST_SIZE = 5

/**
 * "Because you played <song>": one full-width feature card for the song itself, over the radio's
 * songs in the ordinary card row.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeatureSongRow(
    data: HomeItem,
    navController: NavController,
    viewModel: HomeViewModel,
) {
    var sheetTrack by remember { mutableStateOf<Track?>(null) }
    sheetTrack?.let { track ->
        NowPlayingBottomSheet(
            onDismiss = { sheetTrack = null },
            song = track.toSongEntity(),
            navController = navController,
        )
    }
    val listState = rememberLazyListState()
    val flingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyListState = listState))
    Column {
        HomeSectionHeader(data = data, navController = navController, onPlayAll = {})
        data.feature?.let { feature ->
            FeatureCard(
                data = feature,
                onClick = { feature.playRadio(viewModel) },
                onLongClick = { sheetTrack = feature.toTrack() },
            )
        }
        LazyRow(
            state = listState,
            flingBehavior = flingBehavior,
        ) {
            items(data.contents) { content ->
                if (content != null) {
                    HomeContentCard(
                        temp = content,
                        navController = navController,
                        viewModel = viewModel,
                        onLongClick = { sheetTrack = it.toTrack() },
                    )
                }
            }
        }
        if (getPlatform() == Platform.Desktop) {
            HorizontalScrollBar(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                scrollState = listState,
                flingBehavior = flingBehavior,
            )
        }
    }
}

/**
 * "More like <artist>": one row of wide 16:9 cards, so the row reads as video-like artwork rather
 * than the square covers the other rows use.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WideSongRow(
    data: HomeItem,
    navController: NavController,
    viewModel: HomeViewModel,
) {
    var sheetTrack by remember { mutableStateOf<Track?>(null) }
    sheetTrack?.let { track ->
        NowPlayingBottomSheet(
            onDismiss = { sheetTrack = null },
            song = track.toSongEntity(),
            navController = navController,
        )
    }
    val listState = rememberLazyListState()
    val flingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyListState = listState))
    Column {
        HomeSectionHeader(data = data, navController = navController, onPlayAll = {})
        LazyRow(
            state = listState,
            flingBehavior = flingBehavior,
        ) {
            items(data.contents) { content ->
                if (content != null) {
                    HomeItemVideo(
                        onClick = { content.playRadio(viewModel) },
                        onLongClick = { sheetTrack = content.toTrack() },
                        data = content,
                        onPlay = { content.playRadio(viewModel) },
                    )
                }
            }
        }
        if (getPlatform() == Platform.Desktop) {
            HorizontalScrollBar(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                scrollState = listState,
                flingBehavior = flingBehavior,
            )
        }
    }
}

/**
 * "<Genre> for you": a compact numbered Top 5 list, the one vertical layout on Home, so a genre's
 * row is short to scan instead of another carousel.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TopSongsListRow(
    data: HomeItem,
    navController: NavController,
    viewModel: HomeViewModel,
) {
    var sheetTrack by remember { mutableStateOf<Track?>(null) }
    sheetTrack?.let { track ->
        NowPlayingBottomSheet(
            onDismiss = { sheetTrack = null },
            song = track.toSongEntity(),
            navController = navController,
        )
    }
    Column {
        HomeSectionHeader(data = data, navController = navController, onPlayAll = {})
        data.contents.filterNotNull().take(TOP_LIST_SIZE).forEachIndexed { index, content ->
            TopSongRow(
                rank = index + 1,
                data = content,
                onClick = { content.playRadio(viewModel) },
                onLongClick = { sheetTrack = content.toTrack() },
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FeatureCard(
    data: Content,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val appShapes = LocalAppShapes.current
    val thumb = data.thumbnails.lastOrNull()?.url
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(appShapes.hero)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick,
                ),
    ) {
        AsyncImage(
            model =
                ImageRequest
                    .Builder(LocalPlatformContext.current)
                    .data(thumb)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .diskCacheKey(thumb)
                    .crossfade(550)
                    .build(),
            placeholder = rememberHolderPainter(isVideo = true),
            error = rememberHolderPainter(isVideo = true),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f)),
                    ),
                ),
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 20.dp, end = 84.dp, bottom = 18.dp),
        ) {
            Text(
                text = data.title,
                style = typo().titleLarge,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = data.artists.toListName().connectArtists(),
                style = typo().bodyMedium,
                color = Color.White.copy(alpha = 0.82f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(
            modifier =
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            ThemedIcon(
                imageVector = SimpIcons.PlayArrow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(30.dp),
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TopSongRow(
    rank: Int,
    data: Content,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val appShapes = LocalAppShapes.current
    val thumb = data.thumbnails.lastOrNull()?.url
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(appShapes.card)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick,
                ).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = rank.toString(),
            style = typo().titleLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier.width(32.dp),
        )
        AsyncImage(
            model =
                ImageRequest
                    .Builder(LocalPlatformContext.current)
                    .data(thumb)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .diskCacheKey(thumb)
                    .crossfade(550)
                    .build(),
            placeholder = rememberHolderPainter(),
            error = rememberHolderPainter(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier =
                Modifier
                    .size(48.dp)
                    .clip(appShapes.artworkSmall),
        )
        Column(
            Modifier
                .padding(start = 12.dp)
                .weight(1f),
        ) {
            Text(
                text = data.title,
                style = typo().titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = data.artists.toListName().connectArtists(),
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
