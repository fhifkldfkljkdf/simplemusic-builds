package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.data.model.home.Content
import com.maxrave.simpmusic.ui.component.playRadio
import com.maxrave.simpmusic.ui.component.rememberHolderPainter
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.HomeViewModel

/**
 * Private copy: Spotify's Home opening grid — six recently played / favourite songs as two-column
 * tiles. Only shown by the Spotify theme; the rest of Home keeps the app's own layout.
 */
@Composable
fun SpotifyQuickAccessGrid(
    items: List<Content>,
    nowPlayingId: String?,
    viewModel: HomeViewModel,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { content ->
                    SpotifyQuickTile(
                        content = content,
                        playing = content.videoId != null && content.videoId == nowPlayingId,
                        viewModel = viewModel,
                        modifier = Modifier.weight(1f),
                    )
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SpotifyQuickTile(
    content: Content,
    playing: Boolean,
    viewModel: HomeViewModel,
    modifier: Modifier = Modifier,
) {
    val appShapes = LocalAppShapes.current
    val thumb = content.thumbnails.lastOrNull()?.url
    Row(
        modifier =
            modifier
                .height(56.dp)
                .clip(appShapes.card)
                .background(MaterialTheme.colorScheme.surfaceContainer)
                .clickable { content.playRadio(viewModel) }
                .padding(end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model =
                ImageRequest
                    .Builder(LocalPlatformContext.current)
                    .data(thumb)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .diskCacheKey(thumb)
                    .crossfade(550)
                    .build(),
            placeholder = rememberHolderPainter(),
            error = rememberHolderPainter(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier =
                Modifier
                    .size(56.dp)
                    .clip(appShapes.artworkSmall),
        )
        Text(
            text = content.title,
            style = typo().titleSmall,
            // Spotify marks the current track in green; the rest stay white. inversePrimary is the
            // bright green on dark and the readable dark green on light.
            color = if (playing) MaterialTheme.colorScheme.inversePrimary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier =
                Modifier
                    .padding(start = 10.dp)
                    .fillMaxWidth(),
        )
    }
}
