package com.maxrave.simpmusic.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily

/** The Retro Pixel theme's icons are sampled from this grid, then scaled up with no smoothing. */
private const val PIXEL_GRID = 12

/**
 * Private copy: every icon under the Retro Pixel theme is drawn as a coarse pixel grid instead of
 * a smooth vector, the way an 8-bit icon set would look. Other themes get the normal Material icon.
 * The pixel grid is cached per vector; tinting and scaling stay at draw time.
 */
@Composable
fun ThemedIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    if (LocalAppThemeFamily.current == AppThemeFamily.RETRO) {
        PixelIcon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    } else {
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    }
}

@Composable
private fun PixelIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier,
    tint: Color,
) {
    val painter = rememberVectorPainter(imageVector)
    val pixelated = remember(painter) {
        val grid = PIXEL_GRID
        val bitmap = ImageBitmap(grid, grid)
        CanvasDrawScope().draw(
            density = Density(1f),
            layoutDirection = LayoutDirection.Ltr,
            canvas = Canvas(bitmap),
            size = Size(grid.toFloat(), grid.toFloat()),
        ) {
            with(painter) {
                draw(Size(grid.toFloat(), grid.toFloat()))
            }
        }
        bitmap
    }
    // Material's Icon only applies its 24dp default when the caller gave no size of its own.
    val defaultSize = if (modifier == Modifier) Modifier.size(24.dp) else Modifier
    Image(
        bitmap = pixelated,
        contentDescription = contentDescription,
        modifier = modifier.then(defaultSize),
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.tint(tint),
        filterQuality = FilterQuality.None,
    )
}
