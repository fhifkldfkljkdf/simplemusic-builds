package com.maxrave.simpmusic.ui.screen.home

import com.maxrave.simpmusic.ui.component.ThemedIcon
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.maxrave.domain.data.model.friends.Friend
import com.maxrave.domain.data.model.friends.FriendsState
import com.maxrave.domain.repository.FriendsRepository
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.shareUrl
import com.maxrave.simpmusic.expect.ui.RoomQrScannerSheet
import com.maxrave.simpmusic.expect.ui.layerBackdrop
import com.maxrave.simpmusic.expect.ui.rememberBackdrop
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.component.EndOfPage
import com.maxrave.simpmusic.ui.component.LiquidGlassIconButton
import com.maxrave.simpmusic.ui.component.QrCodeImage
import com.maxrave.simpmusic.ui.icon.ArrowBackIosNew
import com.maxrave.simpmusic.ui.icon.Check
import com.maxrave.simpmusic.ui.icon.ContentCopy
import com.maxrave.simpmusic.ui.icon.Delete
import com.maxrave.simpmusic.ui.icon.PersonAdd
import com.maxrave.simpmusic.ui.icon.QrCodeScanner
import com.maxrave.simpmusic.ui.icon.Share
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.navigation.destination.home.ListenTogetherDestination
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.FriendsViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.cancel
import simpmusic.composeapp.generated.resources.friends_accept
import simpmusic.composeapp.generated.resources.friends_add
import simpmusic.composeapp.generated.resources.friends_add_body
import simpmusic.composeapp.generated.resources.friends_add_button
import simpmusic.composeapp.generated.resources.friends_add_hint
import simpmusic.composeapp.generated.resources.friends_add_title
import simpmusic.composeapp.generated.resources.friends_copied
import simpmusic.composeapp.generated.resources.friends_copy_link
import simpmusic.composeapp.generated.resources.friends_decline
import simpmusic.composeapp.generated.resources.friends_empty
import simpmusic.composeapp.generated.resources.friends_in_room_hint
import simpmusic.composeapp.generated.resources.friends_invite
import simpmusic.composeapp.generated.resources.friends_invite_body
import simpmusic.composeapp.generated.resources.friends_invite_entry
import simpmusic.composeapp.generated.resources.friends_invite_title
import simpmusic.composeapp.generated.resources.friends_invited
import simpmusic.composeapp.generated.resources.friends_join
import simpmusic.composeapp.generated.resources.friends_list
import simpmusic.composeapp.generated.resources.friends_my_code
import simpmusic.composeapp.generated.resources.friends_my_code_desc
import simpmusic.composeapp.generated.resources.friends_name_needed
import simpmusic.composeapp.generated.resources.friends_not_now
import simpmusic.composeapp.generated.resources.friends_notice_added
import simpmusic.composeapp.generated.resources.friends_notice_added_offline
import simpmusic.composeapp.generated.resources.friends_notice_already
import simpmusic.composeapp.generated.resources.friends_notice_invalid
import simpmusic.composeapp.generated.resources.friends_notice_invite_failed
import simpmusic.composeapp.generated.resources.friends_notice_self
import simpmusic.composeapp.generated.resources.friends_privacy
import simpmusic.composeapp.generated.resources.friends_relays
import simpmusic.composeapp.generated.resources.friends_relays_none
import simpmusic.composeapp.generated.resources.friends_remove
import simpmusic.composeapp.generated.resources.friends_remove_confirm
import simpmusic.composeapp.generated.resources.friends_request_body
import simpmusic.composeapp.generated.resources.friends_request_desc
import simpmusic.composeapp.generated.resources.friends_request_title
import simpmusic.composeapp.generated.resources.friends_requests
import simpmusic.composeapp.generated.resources.friends_scan
import simpmusic.composeapp.generated.resources.friends_scan_hint
import simpmusic.composeapp.generated.resources.friends_scan_not_a_friend
import simpmusic.composeapp.generated.resources.friends_share_link
import simpmusic.composeapp.generated.resources.friends_share_text
import simpmusic.composeapp.generated.resources.friends_title
import simpmusic.composeapp.generated.resources.friends_unavailable
import simpmusic.composeapp.generated.resources.friends_waiting
import simpmusic.composeapp.generated.resources.lt_display_name

private val CARD = RoundedCornerShape(24.dp)
private val ROW = RoundedCornerShape(18.dp)
private val BACK_STRIP = 56.dp
private const val COPIED_MS = 1800L

/**
 * Friends: your own code, adding someone else's, requests, and the list — with an Invite button on
 * each friend while [roomCode] is set. Drawn in the Listen Together page's language (the same card,
 * row and pill shapes) since it is reached from there and leads back there.
 */
@Composable
fun FriendsScreen(
    navController: NavController,
    innerPadding: PaddingValues,
    roomCode: String? = null,
    addCode: String? = null,
    viewModel: FriendsViewModel = koinViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val notice by viewModel.notice.collectAsStateWithLifecycle()
    val invited by viewModel.invited.collectAsStateWithLifecycle()
    val sending by viewModel.sending.collectAsStateWithLifecycle()
    val adding by viewModel.adding.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { viewModel.open() }

    // A friend link opened from outside the app; asked about once, even across a rotation.
    var offered by rememberSaveable(addCode) { mutableStateOf(addCode?.takeIf(viewModel::isFriendCode)) }
    var scanning by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<Friend?>(null) }

    val bg = MaterialTheme.colorScheme.background
    val backdrop = rememberBackdrop(bg)

    Box(Modifier.fillMaxSize().background(bg)) {
        Box(Modifier.matchParentSize().layerBackdrop(backdrop)) {
            Box(Modifier.matchParentSize().background(bg))
        }
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(innerPadding)
                    .padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(
                modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth().animateContentSize(),
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Spacer(Modifier.height(BACK_STRIP))
                Text(
                    text = stringResource(Res.string.friends_title),
                    style = typo().titleLarge.copy(fontSize = 32.sp, lineHeight = 36.sp),
                    color = MaterialTheme.colorScheme.onBackground,
                )
                if (!state.available) {
                    Muted(stringResource(Res.string.friends_unavailable))
                } else {
                    RelayLine(state)
                    if (roomCode != null) {
                        Card(tint = MaterialTheme.colorScheme.primary) {
                            Text(
                                stringResource(Res.string.friends_in_room_hint, roomCode),
                                style = typo().bodyMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(16.dp),
                            )
                        }
                    }
                    notice?.let { current ->
                        Card(tint = MaterialTheme.colorScheme.tertiary) {
                            Text(
                                text = noticeText(current),
                                style = typo().bodyMedium,
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.fillMaxWidth().clickable { viewModel.clearNotice() }.padding(16.dp),
                            )
                        }
                    }

                    AnimatedVisibility(visible = state.requests.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Header(stringResource(Res.string.friends_requests), state.requests.size)
                            state.requests.forEach { request ->
                                PersonRow(name = request.name, subtitle = stringResource(Res.string.friends_request_desc)) {
                                    Pill(stringResource(Res.string.friends_decline)) { viewModel.decline(request.publicKey) }
                                    Pill(stringResource(Res.string.friends_accept), filled = true) { viewModel.accept(request.publicKey) }
                                }
                            }
                        }
                    }

                    Header(stringResource(Res.string.friends_list), state.friends.size)
                    if (state.friends.isEmpty()) {
                        Muted(stringResource(Res.string.friends_empty))
                    }
                    state.friends.forEach { friend ->
                        PersonRow(
                            name = friend.name,
                            subtitle = if (friend.confirmed) null else stringResource(Res.string.friends_waiting),
                        ) {
                            if (roomCode != null) {
                                val done = friend.publicKey in invited
                                Pill(
                                    text = stringResource(if (done) Res.string.friends_invited else Res.string.friends_invite),
                                    filled = !done,
                                    enabled = !done && friend.publicKey !in sending,
                                ) { viewModel.invite(friend.publicKey, roomCode) }
                            }
                            Glyph(SimpIcons.Delete, stringResource(Res.string.friends_remove)) { removing = friend }
                        }
                    }

                    AddFriend(
                        adding = adding,
                        onAdd = viewModel::addFriend,
                        onScan = { scanning = true }.takeIf { getPlatform() == Platform.Android },
                    )

                    MyCode(state, onNameChange = viewModel::setMyName)

                    Muted(stringResource(Res.string.friends_privacy))
                }
                EndOfPage()
            }
        }

        LiquidGlassIconButton(
            backdrop = backdrop,
            imageVector = SimpIcons.ArrowBackIosNew,
            tint = MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(24.dp),
            modifier =
                Modifier
                    .align(Alignment.TopStart)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(start = 12.dp, top = 8.dp)
                    .size(48.dp),
            onClick = { navController.navigateUp() },
        )
    }

    if (scanning) {
        RoomQrScannerSheet(
            onScanned = viewModel::onScanned,
            onDismiss = { scanning = false },
            title = stringResource(Res.string.friends_scan),
            hint = stringResource(Res.string.friends_scan_hint),
            rejectedHint = stringResource(Res.string.friends_scan_not_a_friend),
        )
    }
    removing?.let { friend ->
        AlertDialog(
            onDismissRequest = { removing = null },
            text = { Text(stringResource(Res.string.friends_remove_confirm, friend.name), style = typo().bodyMedium) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.remove(friend.publicKey)
                    removing = null
                }) { Text(stringResource(Res.string.friends_remove), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { removing = null }) { Text(stringResource(Res.string.cancel)) } },
        )
    }
    offered?.let { code ->
        AlertDialog(
            onDismissRequest = { offered = null },
            title = { Text(stringResource(Res.string.friends_add_title), style = typo().titleMedium) },
            text = { Text(stringResource(Res.string.friends_add_body), style = typo().bodyMedium) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.addFriend(code)
                    offered = null
                }) { Text(stringResource(Res.string.friends_add_button)) }
            },
            dismissButton = { TextButton(onClick = { offered = null }) { Text(stringResource(Res.string.cancel)) } },
        )
    }
}

/**
 * Incoming invites and friend requests, over whatever screen is open. Placed once, in App.kt, since
 * an invitation is to listen now and is no use waiting for the Friends page to be opened.
 */
@Composable
fun FriendsInbox(
    navController: NavController,
    repository: FriendsRepository = koinInject(),
) {
    // The repository rather than a ViewModel: this sits above navigation, where Desktop has no
    // ViewModelStoreOwner of its own to scope one to.
    LaunchedEffect(repository) { repository.start() }
    // Private copy: connected to the relays only while the app is on screen; see setForeground.
    LifecycleStartEffect(repository) {
        repository.setForeground(true)
        onStopOrDispose { repository.setForeground(false) }
    }
    val scope = rememberCoroutineScope()
    val state by repository.state.collectAsStateWithLifecycle()
    val invite = state.invites.firstOrNull()
    val request = state.requests.firstOrNull()
    when {
        invite != null ->
            AlertDialog(
                onDismissRequest = {},
                title = { Text(stringResource(Res.string.friends_invite_title), style = typo().titleMedium) },
                text = { Text(stringResource(Res.string.friends_invite_body, invite.from.name), style = typo().bodyMedium) },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch { repository.dismissInvite(invite.id) }
                        navController.navigate(ListenTogetherDestination(joinCode = invite.roomCode))
                    }) { Text(stringResource(Res.string.friends_join)) }
                },
                dismissButton = {
                    TextButton(onClick = { scope.launch { repository.dismissInvite(invite.id) } }) {
                        Text(stringResource(Res.string.friends_not_now))
                    }
                },
            )

        request != null ->
            AlertDialog(
                onDismissRequest = {},
                title = { Text(stringResource(Res.string.friends_request_title), style = typo().titleMedium) },
                text = { Text(stringResource(Res.string.friends_request_body, request.name), style = typo().bodyMedium) },
                confirmButton = {
                    TextButton(onClick = { scope.launch { repository.acceptRequest(request.publicKey) } }) {
                        Text(stringResource(Res.string.friends_accept))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { scope.launch { repository.declineRequest(request.publicKey) } }) {
                        Text(stringResource(Res.string.friends_decline))
                    }
                },
            )
    }
}

@Composable
private fun noticeText(notice: FriendsViewModel.Notice): String =
    when (notice) {
        is FriendsViewModel.Notice.Added ->
            stringResource(if (notice.delivered) Res.string.friends_notice_added else Res.string.friends_notice_added_offline, notice.name)
        is FriendsViewModel.Notice.AlreadyFriends -> stringResource(Res.string.friends_notice_already, notice.name)
        FriendsViewModel.Notice.NotAFriendCode -> stringResource(Res.string.friends_notice_invalid)
        FriendsViewModel.Notice.ThatIsYou -> stringResource(Res.string.friends_notice_self)
        is FriendsViewModel.Notice.InviteFailed -> stringResource(Res.string.friends_notice_invite_failed, notice.name)
    }

@Composable
private fun RelayLine(state: FriendsState) {
    val connected = state.relaysConnected > 0
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant),
        )
        Muted(
            if (connected) {
                stringResource(Res.string.friends_relays, state.relaysConnected, state.relaysTotal)
            } else {
                stringResource(Res.string.friends_relays_none)
            },
        )
    }
}

@Composable
private fun AddFriend(
    adding: Boolean,
    onAdd: (String) -> Unit,
    onScan: (() -> Unit)?,
) {
    var text by rememberSaveable { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Header(stringResource(Res.string.friends_add))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(
                value = text,
                onValueChange = { text = it },
                placeholder = stringResource(Res.string.friends_add_hint),
                modifier = Modifier.weight(1f),
            )
            Pill(stringResource(Res.string.friends_add_button), filled = true, enabled = text.isNotBlank() && !adding) {
                onAdd(text)
                text = ""
            }
        }
        onScan?.let { scan -> OutlineAction(stringResource(Res.string.friends_scan), SimpIcons.QrCodeScanner, onClick = scan) }
    }
}

@Composable
private fun MyCode(
    state: FriendsState,
    onNameChange: (String) -> Unit,
) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(COPIED_MS)
            copied = false
        }
    }
    // Local while typing, saved on every change: the name is shared with Listen Together.
    var name by remember(state.myName.isEmpty()) { mutableStateOf(state.myName) }
    val shareTitle = stringResource(Res.string.friends_share_link)
    Card {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                stringResource(Res.string.friends_my_code),
                style = typo().titleSmall,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth(),
            )
            Muted(stringResource(Res.string.friends_my_code_desc), Modifier.fillMaxWidth())
            if (state.myName.isBlank()) {
                Muted(stringResource(Res.string.friends_name_needed), Modifier.fillMaxWidth())
            }
            Field(
                value = name,
                onValueChange = {
                    name = it.take(32)
                    onNameChange(name)
                },
                placeholder = stringResource(Res.string.lt_display_name),
                modifier = Modifier.fillMaxWidth(),
            )
            val link = state.myLink
            if (link != null && state.myName.isNotBlank()) {
                QrCodeImage(text = link, modifier = Modifier.size(220.dp))
                val shareText = stringResource(Res.string.friends_share_text, link)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlineAction(
                        text = stringResource(if (copied) Res.string.friends_copied else Res.string.friends_copy_link),
                        icon = if (copied) SimpIcons.Check else SimpIcons.ContentCopy,
                        modifier = Modifier.weight(1f),
                    ) {
                        clipboard.setText(AnnotatedString(link))
                        copied = true
                    }
                    OutlineAction(stringResource(Res.string.friends_share_link), SimpIcons.Share, Modifier.weight(1f)) {
                        shareUrl(title = shareTitle, url = shareText)
                    }
                }
            }
        }
    }
}

// ───────────────────────────── pieces ─────────────────────────────

@Composable
private fun Card(
    tint: Color? = null,
    content: @Composable () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(CARD)
                .background(tint?.copy(alpha = 0.07f) ?: MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.06f))
                .border(1.dp, tint?.copy(alpha = 0.22f) ?: MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f), CARD),
    ) { content() }
}

@Composable
private fun Header(
    title: String,
    count: Int? = null,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, style = typo().titleSmall, color = MaterialTheme.colorScheme.onBackground)
        if (count != null) {
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f))
                    .padding(horizontal = 8.dp, vertical = 1.dp),
            ) {
                Text("$count", style = typo().labelSmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun Muted(
    text: String,
    modifier: Modifier = Modifier,
) {
    Text(text, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)
}

@Composable
private fun PersonRow(
    name: String,
    subtitle: String?,
    actions: @Composable () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(ROW)
                .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.06f))
                .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(name.trim().firstOrNull()?.uppercase() ?: "?", style = typo().titleSmall, color = MaterialTheme.colorScheme.onPrimary)
        }
        Column(Modifier.weight(1f)) {
            Text(name, style = typo().bodyMedium, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
            subtitle?.let { Muted(it) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { actions() }
    }
}

@Composable
private fun Pill(
    text: String,
    filled: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .height(36.dp)
                .clip(CircleShape)
                .then(
                    if (filled && enabled) {
                        Modifier.background(MaterialTheme.colorScheme.primary)
                    } else {
                        Modifier.border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f), CircleShape)
                    },
                ).clickable(enabled = enabled) { onClick() }
                .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            style = typo().labelMedium,
            color = if (filled && enabled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Glyph(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f))
                .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        ThemedIcon(icon, contentDescription = description, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun OutlineAction(
    text: String,
    icon: ImageVector,
    modifier: Modifier = Modifier.fillMaxWidth(),
    onClick: () -> Unit,
) {
    Row(
        modifier =
            modifier
                .height(48.dp)
                .clip(CircleShape)
                .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f), CircleShape)
                .clickable { onClick() }
                .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        ThemedIcon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = typo().labelLarge, color = MaterialTheme.colorScheme.onBackground, maxLines = 1)
    }
}

@Composable
private fun Field(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = typo().bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground),
        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
        modifier =
            modifier
                .height(50.dp)
                .clip(ROW)
                .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)),
        decorationBox = { inner ->
            Box(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) Muted(placeholder)
                inner()
            }
        },
    )
}

/** For the Listen Together page: the row that opens Friends. */
@Composable
internal fun FriendsEntryRow(
    inRoom: Boolean,
    pendingRequests: Int,
    onClick: () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(CircleShape)
                .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f), CircleShape)
                .clickable { onClick() }
                .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        ThemedIcon(SimpIcons.PersonAdd, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            stringResource(if (inRoom) Res.string.friends_invite_entry else Res.string.friends_title),
            style = typo().titleSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (pendingRequests > 0) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 8.dp, vertical = 1.dp),
            ) {
                Text("$pendingRequests", style = typo().labelSmall, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}
