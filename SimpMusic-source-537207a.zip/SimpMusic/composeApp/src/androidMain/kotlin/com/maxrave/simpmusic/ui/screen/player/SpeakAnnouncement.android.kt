package com.maxrave.simpmusic.ui.screen.player

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import com.maxrave.logger.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.koin.mp.KoinPlatform.getKoin
import java.util.Locale

private const val TAG = "SpeakAnnouncement"
private const val UTTERANCE_ID = "simpmusic-announcement"

/**
 * One TextToSpeech engine for the whole process: creating one is slow, and a value spoken seconds
 * after the slider was released is worse than one not spoken at all.
 */
private object Speaker {
    private val lock = Any()
    private var engine: TextToSpeech? = null
    private var starting = false
    private var ready = false

    // The value to say once init finishes; the newest one wins, since only the last matters.
    private var pending: String? = null

    // null until something is known: the package probe or an init result sets it.
    private val availability = MutableStateFlow<Boolean?>(null)
    private var probed = false

    /** Whether an announcement can be heard; the first call looks for an engine, cheaply. */
    fun state(): StateFlow<Boolean?> {
        synchronized(lock) {
            if (!probed) {
                probed = true
                probe()
            }
        }
        return availability
    }

    /**
     * Asks the package manager whether any text-to-speech service is installed, without creating an
     * engine: enough to tell a phone with none from one that will speak. A later init refines it.
     */
    @Suppress("DEPRECATION")
    private fun probe() {
        try {
            val context = getKoin().get<Context>()
            // An app targeting API 30+ only sees other apps' services its manifest asks for: the
            // TTS_SERVICE intent in <queries>. Without it this list is empty even when one exists.
            val services =
                context.packageManager.queryIntentServices(
                    Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE),
                    0,
                )
            val anyInstalled = services?.isNotEmpty() == true
            availability.value = anyInstalled
            if (!anyInstalled) Logger.w(TAG, "No text to speech engine is installed")
        } catch (t: Throwable) {
            availability.value = false
            Logger.e(TAG, "Could not look for a text to speech engine: ${t.message}", t)
        }
    }

    fun speak(text: String) {
        try {
            synchronized(lock) {
                pending = text
                if (!ready) {
                    start()
                    return
                }
                speakPending()
            }
        } catch (t: Throwable) {
            availability.value = false
            Logger.e(TAG, "Could not speak announcement: ${t.message}", t)
        }
    }

    private fun start() {
        if (starting) return
        starting = true
        try {
            val context = getKoin().get<Context>()
            val created = TextToSpeech(context.applicationContext, ::onInit)
            engine = created
        } catch (t: Throwable) {
            starting = false
            pending = null
            availability.value = false
            Logger.e(TAG, "Could not create the text to speech engine: ${t.message}", t)
        }
    }

    @Suppress("DEPRECATION")
    private fun onInit(status: Int) {
        synchronized(lock) {
            starting = false
            val tts = engine
            if (status != TextToSpeech.SUCCESS || tts == null) {
                pending = null
                availability.value = false
                Logger.w(TAG, "Text to speech is unavailable (status $status)")
                // Release the dead engine, so a later call can try a fresh one.
                runCatching { tts?.shutdown() }
                engine = null
                return
            }
            try {
                val language = tts.setLanguage(Locale.getDefault())
                val defaultUsable =
                    language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED
                if (!defaultUsable) {
                    // No voice data for the phone's language: English is the fallback the
                    // announcement is written in, and without that there is nothing to hear.
                    val fallback = tts.setLanguage(Locale.US)
                    if (fallback == TextToSpeech.LANG_MISSING_DATA || fallback == TextToSpeech.LANG_NOT_SUPPORTED) {
                        pending = null
                        ready = false
                        availability.value = false
                        Logger.w(TAG, "Text to speech has no voice data for this language")
                        runCatching { tts.shutdown() }
                        engine = null
                        return
                    }
                }
                // Accessibility speech: the engine takes transient audio focus that may duck, so
                // the music dips under the announcement instead of stopping.
                tts.setAudioAttributes(
                    AudioAttributes
                        .Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                ready = true
                availability.value = true
                speakPending()
            } catch (t: Throwable) {
                availability.value = false
                Logger.e(TAG, "Could not set up text to speech: ${t.message}", t)
            }
        }
    }

    private fun speakPending() {
        val tts = engine ?: return
        val text = pending ?: return
        pending = null
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }
}

actual fun speakAnnouncement(text: String) {
    Speaker.speak(text)
}

actual fun speechAvailability(): StateFlow<Boolean?> = Speaker.state()
