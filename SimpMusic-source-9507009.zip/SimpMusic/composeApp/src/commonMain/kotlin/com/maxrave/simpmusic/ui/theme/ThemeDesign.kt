package com.maxrave.simpmusic.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.unit.sp
import com.maxrave.domain.manager.DataStoreManager
import kotlin.math.sqrt

/**
 * Private copy: what a named app theme changes besides its palette — corner shapes, typeface,
 * chip style and the few Home/Navigation touches. The Spotify and Retro themes had some of this
 * already; this makes every theme carry a shape and type identity.
 */
enum class AppThemeFamily {
    DEFAULT,
    MATERIAL_YOU,
    SPOTIFY,
    APPLE_MUSIC,
    OCEAN,
    AMOLED,
    RETRO,
    CUSTOM,
}

/** How the filter chips are drawn: outlined (app default), filled, or square-filled. */
enum class AppChipStyle { OUTLINED, FILLED, SQUARE }

/** [Shape]s used by Home's cards, artwork and the navigation bar, per theme. */
data class AppShapes(
    val card: Shape,
    val cardSmall: Shape,
    val artwork: Shape,
    val artworkSmall: Shape,
    val hero: Shape,
    val chip: Shape,
    val navBar: Shape,
    val navIndicator: Shape,
    val searchButton: Shape,
    val pill: Shape = CircleShape,
    val avatar: Shape = CircleShape,
)

/**
 * A round corner rasterised into stair steps — Retro Pixel's answer to a rounded corner.
 * [step] is roughly the size of one step. Each corner follows a quarter-circle arc rather than a
 * straight diagonal, so it still reads as round. Steps are snapped to whole device pixels, so the
 * stairs stay hard instead of picking up an anti-aliased slope.
 */
class PixelCornerShape private constructor(
    cStart: CornerSize,
    cEnd: CornerSize,
    cBottomEnd: CornerSize,
    cBottomStart: CornerSize,
    private val stepsHint: Int,
) : CornerBasedShape(cStart, cEnd, cBottomEnd, cBottomStart) {
    /** The common case: the same corner on all four sides. */
    constructor(corner: Dp, step: Dp = 3.dp) : this(
        cStart = CornerSize(corner),
        cEnd = CornerSize(corner),
        cBottomEnd = CornerSize(corner),
        cBottomStart = CornerSize(corner),
        stepsHint = ((corner.value / step.value) + 0.5f).toInt().coerceIn(1, 32),
    )

    override fun createOutline(
        size: Size,
        topStart: Float,
        topEnd: Float,
        bottomEnd: Float,
        bottomStart: Float,
        layoutDirection: LayoutDirection,
    ): Outline =
        stairOutline(
            size = size,
            topStart = topStart,
            topEnd = topEnd,
            bottomEnd = bottomEnd,
            bottomStart = bottomStart,
            steps = stepsHint,
        )

    /** Honors every corner it is given, instead of quietly returning the original shape. */
    override fun copy(
        topStart: CornerSize,
        topEnd: CornerSize,
        bottomEnd: CornerSize,
        bottomStart: CornerSize,
    ): CornerBasedShape = PixelCornerShape(topStart, topEnd, bottomEnd, bottomStart, stepsHint)
}

/** Whole-pixel coordinate, so a stair edge lands on the pixel grid instead of between two. */
private fun Float.snapPx(): Float = kotlin.math.round(this)

@Suppress("LongParameterList")
private fun stairOutline(
    size: Size,
    topStart: Float,
    topEnd: Float,
    bottomEnd: Float,
    bottomStart: Float,
    steps: Int,
): Outline {
    val width = size.width
    val height = size.height
    if (width <= 0f || height <= 0f) return Outline.Generic(Path())
    val maxCorner = minOf(width, height) / 2f
    val cTL = topStart.coerceIn(0f, maxCorner)
    val cTR = topEnd.coerceIn(0f, maxCorner)
    val cBR = bottomEnd.coerceIn(0f, maxCorner)
    val cBL = bottomStart.coerceIn(0f, maxCorner)
    val stepCount = steps.coerceIn(1, 32)

    val path =
        Path().apply {
            moveTo(cTL, 0f)
            lineTo(width - cTR, 0f)

            // Top-right: equal-height rows, each row's x taken from the middle of the arc.
            if (cTR > 0f) {
                val steps = stepCount
                val row = cTR / steps
                for (i in 0 until steps) {
                    val yTop = i * row
                    val yBottom = yTop + row
                    val yMid = yTop + row / 2f
                    val dx = sqrt((cTR * cTR - (cTR - yMid) * (cTR - yMid)).coerceAtLeast(0f))
                    val x = (width - cTR + dx).snapPx()
                    lineTo(x, yTop.snapPx())
                    lineTo(x, yBottom.snapPx())
                }
                lineTo(width, cTR)
            }
            lineTo(width, height - cBR)

            // Bottom-right: the mirror of the top-right, walking down to the bottom edge.
            if (cBR > 0f) {
                val steps = stepCount
                val row = cBR / steps
                for (i in 0 until steps) {
                    val yTop = height - cBR + i * row
                    val yBottom = yTop + row
                    val yMid = yTop + row / 2f
                    val dy = yMid - (height - cBR)
                    val dx = sqrt((cBR * cBR - dy * dy).coerceAtLeast(0f))
                    val x = (width - cBR + dx).snapPx()
                    lineTo(x, yTop.snapPx())
                    lineTo(x, yBottom.snapPx())
                }
            }
            lineTo(cBL, height)

            // Bottom-left: the mirror of the top-left, walking up to the left edge.
            if (cBL > 0f) {
                val steps = stepCount
                val row = cBL / steps
                for (i in 0 until steps) {
                    val yBottom = height - i * row
                    val yTop = yBottom - row
                    val yMid = yTop + row / 2f
                    val dy = yMid - (height - cBL)
                    val dx = sqrt((cBL * cBL - dy * dy).coerceAtLeast(0f))
                    val x = (cBL - dx).snapPx()
                    lineTo(x, yBottom.snapPx())
                    lineTo(x, yTop.snapPx())
                }
                lineTo(0f, height - cBL)
            }
            lineTo(0f, cTL)

            // Top-left: the mirror of the bottom-right, walking up to the top edge.
            if (cTL > 0f) {
                val steps = stepCount
                val row = cTL / steps
                for (i in 0 until steps) {
                    val yBottom = cTL - i * row
                    val yTop = yBottom - row
                    val yMid = yTop + row / 2f
                    val dx = sqrt((cTL * cTL - (cTL - yMid) * (cTL - yMid)).coerceAtLeast(0f))
                    val x = (cTL - dx).snapPx()
                    lineTo(x, yBottom.snapPx())
                    lineTo(x, yTop.snapPx())
                }
            }
            close()
        }
    return Outline.Generic(path)
}

/**
 * A hard, offset "pixel" shadow plus an optional equally hard border: no blur, no tint, no
 * elevation. Retro Pixel's stand-in for Material elevation, drawn behind the component.
 */
@Suppress("LongParameterList")
fun Modifier.pixelShadow(
    shape: Shape,
    shadowColor: Color = Color(0xFF07070D),
    borderColor: Color? = null,
    borderWidth: Dp = 2.dp,
    offset: Dp = 3.dp,
): Modifier =
    drawBehind {
        val path =
            when (val outline = shape.createOutline(size, layoutDirection, this)) {
                is Outline.Generic -> outline.path
                is Outline.Rounded -> Path().apply { addRoundRect(outline.roundRect) }
                is Outline.Rectangle -> Path().apply { addRect(outline.rect) }
            }
        translate(left = offset.toPx(), top = offset.toPx()) {
            drawPath(path = path, color = shadowColor)
        }
        if (borderColor != null && borderWidth > 0.dp) {
            drawPath(path = path, color = borderColor, style = Stroke(width = borderWidth.toPx()))
        }
    }

/** A card/artwork corner for the active theme: stepped under Retro, a normal arc elsewhere. */
@Composable
fun appCorner(radius: Dp): Shape =
    if (LocalAppThemeFamily.current == AppThemeFamily.RETRO) {
        PixelCornerShape(corner = radius, step = if (radius <= 8.dp) 2.dp else 4.dp)
    } else {
        RoundedCornerShape(radius)
    }

val LocalAppThemeFamily = staticCompositionLocalOf { AppThemeFamily.DEFAULT }
val LocalAppShapes = staticCompositionLocalOf { defaultAppShapes() }
val LocalAppChipStyle = staticCompositionLocalOf { AppChipStyle.OUTLINED }

/** Whether the theme has a palette of its own, so Desktop's shell should take it instead of #121212. */
fun AppThemeFamily.usesThemedShell(): Boolean =
    this == AppThemeFamily.SPOTIFY ||
        this == AppThemeFamily.APPLE_MUSIC ||
        this == AppThemeFamily.OCEAN ||
        this == AppThemeFamily.AMOLED ||
        this == AppThemeFamily.RETRO

fun themeFamily(source: String): AppThemeFamily =
    when (source) {
        DataStoreManager.THEME_COLOR_SPOTIFY -> AppThemeFamily.SPOTIFY
        DataStoreManager.THEME_COLOR_APPLE_MUSIC -> AppThemeFamily.APPLE_MUSIC
        DataStoreManager.THEME_COLOR_OCEAN -> AppThemeFamily.OCEAN
        DataStoreManager.THEME_COLOR_AMOLED -> AppThemeFamily.AMOLED
        DataStoreManager.THEME_COLOR_RETRO -> AppThemeFamily.RETRO
        DataStoreManager.THEME_COLOR_WALLPAPER -> AppThemeFamily.MATERIAL_YOU
        DataStoreManager.THEME_COLOR_CUSTOM -> AppThemeFamily.CUSTOM
        else -> AppThemeFamily.DEFAULT
    }

fun defaultAppShapes(): AppShapes =
    AppShapes(
        card = RoundedCornerShape(8.dp),
        cardSmall = RoundedCornerShape(5.dp),
        artwork = RoundedCornerShape(10.dp),
        artworkSmall = RoundedCornerShape(8.dp),
        hero = RoundedCornerShape(28.dp),
        chip = CircleShape,
        navBar = RoundedCornerShape(32.dp),
        navIndicator = RoundedCornerShape(18.dp),
        searchButton = CircleShape,
    )

fun appShapesFor(family: AppThemeFamily): AppShapes =
    when (family) {
        AppThemeFamily.SPOTIFY ->
            defaultAppShapes().copy(
                card = RoundedCornerShape(8.dp),
                cardSmall = RoundedCornerShape(6.dp),
                artwork = RoundedCornerShape(10.dp),
                hero = RoundedCornerShape(20.dp),
            )
        AppThemeFamily.APPLE_MUSIC ->
            defaultAppShapes().copy(
                card = RoundedCornerShape(12.dp),
                cardSmall = RoundedCornerShape(8.dp),
                artwork = RoundedCornerShape(14.dp),
                artworkSmall = RoundedCornerShape(10.dp),
                hero = RoundedCornerShape(24.dp),
            )
        AppThemeFamily.OCEAN ->
            defaultAppShapes().copy(
                card = RoundedCornerShape(16.dp),
                cardSmall = RoundedCornerShape(10.dp),
                artwork = RoundedCornerShape(18.dp),
                artworkSmall = RoundedCornerShape(12.dp),
                hero = RoundedCornerShape(28.dp),
            )
        AppThemeFamily.AMOLED ->
            AppShapes(
                card = RoundedCornerShape(2.dp),
                cardSmall = RoundedCornerShape(2.dp),
                artwork = RoundedCornerShape(2.dp),
                artworkSmall = RoundedCornerShape(2.dp),
                hero = RoundedCornerShape(8.dp),
                chip = RoundedCornerShape(2.dp),
                navBar = RoundedCornerShape(6.dp),
                navIndicator = RoundedCornerShape(4.dp),
                searchButton = RoundedCornerShape(8.dp),
            )
        AppThemeFamily.RETRO ->
            AppShapes(
                card = PixelCornerShape(corner = 8.dp, step = 2.dp),
                cardSmall = PixelCornerShape(corner = 4.dp, step = 2.dp),
                artwork = PixelCornerShape(corner = 8.dp, step = 2.dp),
                artworkSmall = PixelCornerShape(corner = 4.dp, step = 2.dp),
                hero = PixelCornerShape(corner = 16.dp, step = 4.dp),
                chip = PixelCornerShape(corner = 4.dp, step = 2.dp),
                navBar = PixelCornerShape(corner = 12.dp, step = 4.dp),
                navIndicator = PixelCornerShape(corner = 8.dp, step = 4.dp),
                searchButton = PixelCornerShape(corner = 8.dp, step = 4.dp),
                pill = PixelCornerShape(corner = 8.dp, step = 4.dp),
                avatar = PixelCornerShape(corner = 8.dp, step = 4.dp),
            )
        else -> defaultAppShapes()
    }

fun chipStyleFor(family: AppThemeFamily): AppChipStyle =
    when (family) {
        AppThemeFamily.SPOTIFY, AppThemeFamily.APPLE_MUSIC, AppThemeFamily.OCEAN -> AppChipStyle.FILLED
        AppThemeFamily.AMOLED, AppThemeFamily.RETRO -> AppChipStyle.SQUARE
        else -> AppChipStyle.OUTLINED
    }

val AppleShapes =
    Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(24.dp),
        extraLarge = RoundedCornerShape(28.dp),
    )

val OceanShapes =
    Shapes(
        extraSmall = RoundedCornerShape(10.dp),
        small = RoundedCornerShape(14.dp),
        medium = RoundedCornerShape(18.dp),
        large = RoundedCornerShape(26.dp),
        extraLarge = RoundedCornerShape(32.dp),
    )

val AmoledShapes =
    Shapes(
        extraSmall = RoundedCornerShape(2.dp),
        small = RoundedCornerShape(4.dp),
        medium = RoundedCornerShape(6.dp),
        large = RoundedCornerShape(10.dp),
        extraLarge = RoundedCornerShape(14.dp),
    )

/**
 * [base] with every style set in [family] — used for Apple/Ocean/AMOLED (system sans) and Retro
 * (VT323). [scale] lifts the sizes for a face with a small x-height, keeping the layout's rhythm.
 */
fun typographyWithFamily(
    base: Typography,
    family: FontFamily,
    scale: Float = 1f,
): Typography {
    fun androidx.compose.ui.text.TextStyle.withFamily(): androidx.compose.ui.text.TextStyle =
        copy(
            fontFamily = family,
            fontSize = if (fontSize.isSpecified) fontSize * scale else fontSize,
            lineHeight = if (lineHeight.isSpecified) lineHeight * scale else lineHeight,
        )
    return Typography(
        displayLarge = base.displayLarge.withFamily(),
        displayMedium = base.displayMedium.withFamily(),
        displaySmall = base.displaySmall.withFamily(),
        headlineLarge = base.headlineLarge.withFamily(),
        headlineMedium = base.headlineMedium.withFamily(),
        headlineSmall = base.headlineSmall.withFamily(),
        titleLarge = base.titleLarge.withFamily(),
        titleMedium = base.titleMedium.withFamily(),
        titleSmall = base.titleSmall.withFamily(),
        bodyLarge = base.bodyLarge.withFamily(),
        bodyMedium = base.bodyMedium.withFamily(),
        bodySmall = base.bodySmall.withFamily(),
        labelLarge = base.labelLarge.withFamily(),
        labelMedium = base.labelMedium.withFamily(),
        labelSmall = base.labelSmall.withFamily(),
    )
}

/**
 * Retro's own ramp: VT323 has a small x-height and a single weight, so it needs larger, even sizes
 * and must never be asked for a bold it does not have (a synthesised bold smears its 1px stems).
 * Sizes are plain sp values rather than a multiplier so every style lands on an even number;
 * line-height is set explicitly for the same reason.
 */
fun retroTypography(
    base: Typography,
    family: FontFamily,
): Typography {
    fun TextStyle.retro(size: TextUnit): TextStyle =
        copy(
            fontFamily = family,
            fontSize = size,
            fontWeight = FontWeight.Normal,
            lineHeight = size * 1.15f,
            letterSpacing = 0.sp,
        )
    return Typography(
        displayLarge = base.displayLarge.retro(22.sp),
        displayMedium = base.displayMedium.retro(24.sp),
        displaySmall = base.displaySmall.retro(24.sp),
        headlineLarge = base.headlineLarge.retro(26.sp),
        headlineMedium = base.headlineMedium.retro(22.sp),
        headlineSmall = base.headlineSmall.retro(20.sp),
        titleLarge = base.titleLarge.retro(24.sp),
        titleMedium = base.titleMedium.retro(18.sp),
        titleSmall = base.titleSmall.retro(14.sp),
        bodyLarge = base.bodyLarge.retro(20.sp),
        bodyMedium = base.bodyMedium.retro(16.sp),
        bodySmall = base.bodySmall.retro(14.sp),
        labelLarge = base.labelLarge.retro(18.sp),
        labelMedium = base.labelMedium.retro(16.sp),
        labelSmall = base.labelSmall.retro(14.sp),
    )
}
