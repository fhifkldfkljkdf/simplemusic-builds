package com.maxrave.media3.exoplayer

import androidx.media3.common.PlaybackException
import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackRecoveryTest {
    @Test
    fun aLostConnectionIsWaitedOut() {
        listOf(
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
            PlaybackException.ERROR_CODE_TIMEOUT,
        ).forEach { assertEquals(PlaybackRecovery.Kind.NETWORK, PlaybackRecovery.kindOf(it)) }
    }

    @Test
    fun aSongThatWillNotPlayIsRetriedThenSkipped() {
        listOf(
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
            // A stream URL that could not be resolved arrives as a bare IOException.
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
        ).forEach { assertEquals(PlaybackRecovery.Kind.SONG, PlaybackRecovery.kindOf(it)) }
    }

    @Test
    fun retriesBackOffToHalfAMinute() {
        assertEquals(listOf(2_000L, 4_000L, 8_000L, 16_000L, 30_000L, 30_000L), (1..6).map(PlaybackRecovery::backoffMs))
    }
}
