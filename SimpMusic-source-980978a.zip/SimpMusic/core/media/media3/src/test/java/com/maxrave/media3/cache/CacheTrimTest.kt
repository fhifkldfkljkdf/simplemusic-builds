package com.maxrave.media3.cache

import org.junit.Assert.assertEquals
import org.junit.Test

class CacheTrimTest {
    private val gib = 1024L * 1024 * 1024
    private val mib = 1024L * 1024

    @Test
    fun nothingToDoWithRoomToSpare() {
        // 64 GB phone, 30 GB free, keep 20% (12.8 GB) free: the cache keeps everything.
        assertEquals(0L, CacheTrim.bytesToFree(2 * gib, 5 * mib, maxBytes = -1, keepFreePercent = 20, availableBytes = 30 * gib, totalBytes = 64 * gib))
    }

    @Test
    fun givesBackWhatIsMissingFromTheFreeShare() {
        // 100 GB phone, 19 GB free, keep 20%: 1 GB short, plus the 5 MiB about to be written.
        val total = 100L * 1000 * 1000 * 1000
        val free = 19L * 1000 * 1000 * 1000
        val need = CacheTrim.bytesToFree(4 * gib, 5 * mib, maxBytes = -1, keepFreePercent = 20, availableBytes = free, totalBytes = total)
        assertEquals(total / 100 * 20 - (free - 5 * mib), need)
    }

    @Test
    fun keepsTheNewestAudioEvenOnAFullPhone() {
        // Far short of the free share: the cache drops to its floor, never below.
        val need = CacheTrim.bytesToFree(500 * mib, 0, maxBytes = -1, keepFreePercent = 30, availableBytes = 1 * gib, totalBytes = 64 * gib)
        assertEquals(500 * mib - CacheTrim.FLOOR_BYTES, need)
        // Already at the floor: nothing more.
        assertEquals(0L, CacheTrim.bytesToFree(CacheTrim.FLOOR_BYTES, 0, -1, 30, 1 * gib, 64 * gib))
    }

    @Test
    fun theSizeLimitStillApplies() {
        // 1000 MB limit, 990 MB cached, 20 MB coming: 10 MB go, whatever the free space.
        assertEquals(10 * mib, CacheTrim.bytesToFree(990 * mib, 20 * mib, maxBytes = 1000 * mib, keepFreePercent = 0, availableBytes = 0, totalBytes = 0))
        // Both rules: the larger need wins, here the free share, down to the floor.
        val need = CacheTrim.bytesToFree(990 * mib, 20 * mib, maxBytes = 1000 * mib, keepFreePercent = 20, availableBytes = 10 * gib, totalBytes = 64 * gib)
        assertEquals(990 * mib - CacheTrim.FLOOR_BYTES, need)
    }

    @Test
    fun unknownStorageTurnsTheFreeShareOff() {
        assertEquals(0L, CacheTrim.bytesToFree(4 * gib, 5 * mib, maxBytes = -1, keepFreePercent = 20, availableBytes = 0, totalBytes = 0))
    }
}
