package com.maxrave.media3.upgrade

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * [StreamAligner] through [AnalysisTap], the way the player uses them: two copies decoded at
 * different rates, fed in buffers stamped with presentation times from unrelated clocks.
 */
class StreamAlignerTest {
    /** A music-like signal that can be evaluated at any time: notes, chords and noisy hits. */
    private class Song(
        seed: Int,
    ) {
        private class Partial(
            val start: Double,
            val length: Double,
            val hz: Double,
            val amp: Double,
            val phase: Double,
            val decay: Double,
        )

        private val partials: List<Partial>

        /** Partials by the tenth of a second they start in, so [at] only looks at nearby ones. */
        private val byBin: Array<List<Partial>>

        init {
            val random = Random(seed)
            val list = ArrayList<Partial>()
            var t = 0.0
            while (t < 40.0) {
                // A chord of three notes, each with three harmonics.
                repeat(3) {
                    val f0 = 110.0 * Math.pow(2.0, random.nextInt(0, 36) / 12.0)
                    for (h in 1..3) {
                        list += Partial(t, 0.5, f0 * h, 0.12 / h, random.nextDouble(0.0, 2 * PI), 2.0)
                    }
                }
                // A hit: many short partials spread over the spectrum.
                if (random.nextBoolean()) {
                    repeat(10) {
                        list += Partial(t, 0.15, random.nextDouble(200.0, 7000.0), 0.03, random.nextDouble(0.0, 2 * PI), 30.0)
                    }
                }
                t += random.nextDouble(0.18, 0.4)
            }
            partials = list
            val bins = Array(410) { ArrayList<Partial>() }
            for (p in list) bins[(p.start * 10).toInt().coerceIn(0, 409)] += p
            byBin = Array(410) { bins[it] }
        }

        fun at(t: Double): Double {
            var v = 0.0
            val bin = (t * 10).toInt()
            // No partial lasts longer than 0.5 s, so it started at most five bins back.
            for (b in (bin - 5).coerceAtLeast(0)..bin.coerceAtMost(409)) for (p in byBin[b]) {
                val local = t - p.start
                if (local < 0 || local > p.length) continue
                v += p.amp * exp(-p.decay * local) * sin(2 * PI * p.hz * local + p.phase)
            }
            return v
        }
    }

    /** Plays [content] (seconds of song at each output second) into a tap, stereo PCM16. */
    private fun tapOf(
        rate: Int,
        seconds: Double,
        firstPtsUs: Long,
        content: (Double) -> Double,
    ): AnalysisTap {
        val tap = AnalysisTap()
        tap.configure(AnalysisTap.ENCODING_PCM_16BIT, rate, 2)
        tap.arm()
        val frames = (rate * seconds).toInt()
        val block = 1024
        var frame = 0
        while (frame < frames) {
            val n = minOf(block, frames - frame)
            val buffer = ByteBuffer.allocate(n * 4).order(ByteOrder.nativeOrder())
            for (i in 0 until n) {
                val s = (content((frame + i).toDouble() / rate) * 16000).toInt().coerceIn(-32768, 32767).toShort()
                buffer.putShort(s)
                buffer.putShort(s)
            }
            buffer.flip()
            tap.feed(buffer, firstPtsUs + frame * 1_000_000L / rate)
            frame += n
        }
        return tap
    }

    private fun alignTaps(
        reference: AnalysisTap,
        candidate: AnalysisTap,
    ): StreamAligner.Alignment? {
        val refSpan = reference.span()!!
        val candSpan = candidate.span()!!
        val refCount = ((refSpan.last - refSpan.first) * StreamAligner.RATE / 1_000_000L).toInt() - 2
        val ref = reference.window(refSpan.first, refCount, StreamAligner.RATE)!!
        val windowSamples = StreamAligner.WINDOW_SECONDS * StreamAligner.RATE
        val windows =
            StreamAligner.windowStarts(candSpan.first, candSpan.last, 3).map { start ->
                candidate.window(start, windowSamples, StreamAligner.RATE)!! to start
            }
        return StreamAligner.align(ref, refSpan.first, windows)
    }

    @Test
    fun findsTheOffsetBetweenTwoRatesAndClocks() {
        val song = Song(7)
        // The reference has played 24 s from song time 4 s; its clock starts at a renderer offset.
        val referencePts = 1_000_000_000_000L + 4_000_000L
        val reference = tapOf(44_100, 24.0, referencePts) { t -> song.at(4.0 + t) }
        // The candidate runs on an unrelated clock, starts at song time 14.2345 s and is 3 dB quieter.
        val gain = Math.pow(10.0, -3.0 / 20)
        val candidatePts = 500_000_000_000L
        val candidateStartSongTime = 14.2345
        val candidate =
            tapOf(48_000, 9.0, candidatePts) { t -> gain * song.at(candidateStartSongTime + t) }
        val alignment = alignTaps(reference, candidate)
        assertNotNull("no alignment found", alignment)
        // Candidate pts p holds song time 14.2345 + (p - candidatePts); reference pts q holds
        // 4 + (q - referencePts). The same song time: p - q = candidatePts - referencePts - 10.2345 s.
        val expectedUs = candidatePts - referencePts - 10_234_500L
        assertEquals(expectedUs.toDouble(), alignment!!.offsetUs.toDouble(), 300.0)
        assertEquals(3.0, alignment.gainDb, 0.5)
    }

    @Test
    fun refusesADifferentRecording() {
        val reference = tapOf(44_100, 24.0, 0L) { t -> Song(1).at(t) }
        val candidate = tapOf(44_100, 9.0, 0L) { t -> Song(2).at(t + 5) }
        assertNull(alignTaps(reference, candidate))
    }

    @Test
    fun refusesACopyRunningAtAnotherSpeed() {
        val song = Song(3)
        val reference = tapOf(44_100, 24.0, 0L) { t -> song.at(t) }
        // 0.3% fast: a different tape transfer of the same recording.
        val candidate = tapOf(44_100, 9.0, 0L) { t -> song.at((8.0 + t) * 1.003) }
        assertNull(alignTaps(reference, candidate))
    }

    @Test
    fun positionIsCarriedForwardToTheMomentAsked() {
        val tap = AnalysisTap()
        tap.configure(AnalysisTap.ENCODING_PCM_16BIT, 48_000, 2)
        tap.arm()
        for (i in 0 until 10) tap.recordPosition(1_000_000L + i * 10_000L, 5_000_000L + i * 10_000L)
        assertEquals(1_200_000L, tap.positionAt(5_200_000L))
        // A jump among the readings (a seek): no answer rather than an average.
        tap.recordPosition(9_000_000L, 5_100_000L)
        assertNull(tap.positionAt(5_200_000L))
    }

    /**
     * Real recordings, when `ALIGN_AUDIO_DIR` names a folder of raw mono float32 44.1 kHz files
     * (not checked in: they are commercial music). Expected outcomes are the measurements in
     * [StreamAligner]'s documentation.
     */
    @Test
    fun realRecordings() {
        val dir = System.getenv("ALIGN_AUDIO_DIR")?.let(::File)
        assumeTrue(dir != null && dir.isDirectory)
        fun load(name: String): FloatArray {
            val bytes = File(dir, name).readBytes()
            val fb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
            return FloatArray(fb.remaining()).also { fb.get(it) }
        }

        fun tapFrom(
            pcm: FloatArray,
            fromSeconds: Double,
            seconds: Double,
        ): AnalysisTap =
            tapOf(44_100, seconds, (fromSeconds * 1_000_000).toLong()) { t ->
                val i = ((fromSeconds + t) * 44_100).toInt()
                if (i in pcm.indices) pcm[i] * 2.0 else 0.0
            }
        val flac = load("queen2_flac.f32")
        val mp3 = load("queen2_mp3.f32")
        val otherTransfer = load("queen_flac.f32")
        // Same master, two codecs: aligned at offset 0.
        val same = alignTaps(tapFrom(flac, 4.0, 24.0), tapFrom(mp3, 12.0, 9.0))
        println("same master: $same")
        assertNotNull(same)
        assertEquals(0.0, same!!.offsetUs.toDouble(), 500.0)
        // Another transfer, 0.58% apart: refused.
        assertNull(alignTaps(tapFrom(otherTransfer, 2.0, 30.0), tapFrom(flac, 10.0, 9.0)))
    }
}
