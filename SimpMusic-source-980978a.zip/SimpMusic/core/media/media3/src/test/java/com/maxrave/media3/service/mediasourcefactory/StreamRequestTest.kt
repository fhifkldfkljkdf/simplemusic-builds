package com.maxrave.media3.service.mediasourcefactory

import com.maxrave.domain.data.player.SourceKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamRequestTest {
    @Test
    fun aPlainSongAsksForNothing() {
        assertEquals("dQw4w9WgXcQ", StreamRequest.uri("dQw4w9WgXcQ"))
        val parsed = StreamRequest.parse("dQw4w9WgXcQ")
        assertEquals(null, parsed.kind)
        assertTrue(parsed.publishes)
    }

    @Test
    fun roundTrips() {
        val uri = StreamRequest.uri("abc", SourceKind.INTERNET_ARCHIVE, trial = true)
        val parsed = StreamRequest.parse(uri)
        assertEquals(SourceKind.INTERNET_ARCHIVE, parsed.kind)
        assertTrue(parsed.trial)
        assertFalse(parsed.publishes)
        assertFalse(StreamRequest.parse(StreamRequest.uri("abc", prefetch = true)).publishes)
    }

    @Test
    fun ignoresWhatItDoesNotKnow() {
        assertEquals(StreamRequest.Parsed(), StreamRequest.parse("abc?sm_source=NOPE&other=1"))
        assertEquals(StreamRequest.Parsed(), StreamRequest.parse(null))
    }

    @Test
    fun onlyAPlainPlayIsWaitedFor() {
        // The song a listener tapped takes the quickest copy; a preload, a prefetch or the second
        // player of a seamless upgrade takes the best one.
        assertTrue(StreamRequest.parse("abc").waitedFor)
        val preload = StreamRequest.parse(StreamRequest.uri("abc", preload = true))
        assertTrue(preload.preload)
        assertFalse(preload.waitedFor)
        // A preloaded player becomes the one heard when its turn comes, so it still names its source.
        assertTrue(preload.publishes)
        assertFalse(StreamRequest.parse(StreamRequest.uri("abc", prefetch = true)).waitedFor)
        assertFalse(StreamRequest.parse(StreamRequest.uri("abc", SourceKind.INTERNET_ARCHIVE, trial = true)).waitedFor)
    }
}
