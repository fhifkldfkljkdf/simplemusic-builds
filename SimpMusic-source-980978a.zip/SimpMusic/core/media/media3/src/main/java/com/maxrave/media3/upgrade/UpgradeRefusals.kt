package com.maxrave.media3.upgrade

/**
 * Songs whose lossless copy could not be brought in seamlessly mid-song: a different master that
 * drifts, a level too far apart. Private copy.
 *
 * A song someone is waiting for usually starts on the quickest copy and moves onto the lossless
 * file while it plays (StreamResolver); for these songs that move will not happen, so they start
 * on the lossless file instead, a second later but in full quality from the first note. Only for
 * this run of the app: the next search may find a different file.
 */
internal object UpgradeRefusals {
    private const val MAX_SONGS = 500

    private val songs = LinkedHashSet<String>()

    @Synchronized
    fun add(videoId: String) {
        songs.remove(videoId)
        songs.add(videoId)
        while (songs.size > MAX_SONGS) songs.remove(songs.first())
    }

    @Synchronized
    fun contains(videoId: String): Boolean = videoId in songs
}
