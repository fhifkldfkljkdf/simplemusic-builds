package com.maxrave.media3.upgrade

import com.maxrave.media3.audio.Fft
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Finds where one copy of a song sits against another, so playback can move from one to the other
 * mid-song with nothing to hear. Pure; private copy.
 *
 * The method is GCC-PHAT (generalised cross-correlation with phase transform) on mono audio at
 * [RATE] Hz, band-limited to [LOW_HZ]–[HIGH_HZ]. Whitening the cross-spectrum makes the peak sharp
 * and makes it ignore what two releases of one recording differ in — equalisation, level, the
 * codec — while still being decided by the waveform itself, which no other recording shares.
 *
 * Measured on real audio (2026-10-10) before any threshold here was picked:
 * - one master as FLAC and as its MP3 derivative: every 3 s window at the same offset, strength
 *   57–121, distinctness 4.7–17;
 * - two CD transfers of one 1975 recording: offsets drifting by 5.8 ms per second (the transfers
 *   run 0.58% apart), strength ≤ 12, distinctness ≤ 1.4;
 * - a re-upload of unknown origin against a CD: no consistent offset at all.
 * So [align] wants every window strong ([MIN_STRENGTH]), distinct ([MIN_DISTINCTNESS]) and agreeing
 * to within [MAX_SPREAD_US]. Two copies that run at different speeds cannot be swapped without the
 * listener hearing it, and are refused here rather than half-fixed later.
 */
object StreamAligner {
    const val RATE = 8000
    const val WINDOW_SECONDS = 3
    const val LOW_HZ = 150.0
    const val HIGH_HZ = 3500.0

    /** Partial whitening: fully whitened (1.0) lets noise-only bins count as much as music. */
    private const val PHAT_EXPONENT = 0.8

    const val MIN_STRENGTH = 25.0
    const val MIN_DISTINCTNESS = 2.5
    const val MAX_SPREAD_US = 1_000L

    /** Peaks closer than this to the best one belong to it, not to a rival offset. */
    private const val PEAK_HALF_WIDTH = 24

    /** Where one window of the candidate matched inside the reference. */
    data class Match(
        /** Candidate time minus reference time, for the same moment of the song. */
        val offsetUs: Double,
        /** Peak height against the correlation's RMS. */
        val strength: Double,
        /** Peak height against the best peak elsewhere. */
        val distinctness: Double,
    )

    data class Alignment(
        /** Candidate presentation time = reference presentation time + this, for the same sound. */
        val offsetUs: Long,
        /** How much louder the reference is than the candidate. */
        val gainDb: Double,
        val matches: List<Match>,
    )

    /**
     * Where [window], which starts at [windowStartUs] in the candidate's time, sits inside
     * [reference], which starts at [referenceStartUs] in the reference's time. Both at [RATE] Hz.
     * Null when the reference is not longer than the window.
     */
    fun locate(
        reference: FloatArray,
        referenceStartUs: Long,
        window: FloatArray,
        windowStartUs: Long,
    ): Match? {
        if (reference.size <= window.size || window.size < RATE / 2) return null
        var n = 1
        while (n < reference.size + window.size) n = n shl 1
        val fft = Fft(n)

        val refRe = DoubleArray(n)
        val refIm = DoubleArray(n)
        val refMean = reference.average()
        for (i in reference.indices) refRe[i] = reference[i] - refMean
        fft.forward(refRe, refIm)

        val winRe = DoubleArray(n)
        val winIm = DoubleArray(n)
        val winMean = window.average()
        val last = window.size - 1
        for (i in window.indices) {
            val hann = 0.5 - 0.5 * cos(2 * PI * i / last)
            winRe[i] = (window[i] - winMean) * hann
        }
        fft.forward(winRe, winIm)

        // Cross-spectrum R · conj(W), whitened and band-limited, back into refRe/refIm.
        for (k in 0 until n) {
            val bin = if (k <= n / 2) k else n - k
            val hz = bin.toDouble() * RATE / n
            if (hz < LOW_HZ || hz > HIGH_HZ) {
                refRe[k] = 0.0
                refIm[k] = 0.0
                continue
            }
            val re = refRe[k] * winRe[k] + refIm[k] * winIm[k]
            val im = refIm[k] * winRe[k] - refRe[k] * winIm[k]
            val magnitude = sqrt(re * re + im * im)
            val scale = if (magnitude > 1e-12) 1.0 / magnitude.pow(PHAT_EXPONENT) else 0.0
            refRe[k] = re * scale
            refIm[k] = im * scale
        }
        fft.inverse(refRe, refIm)

        // Lag k = the window starting at reference sample k.
        val lags = reference.size - window.size + 1
        var best = 0
        var sumSquares = 0.0
        for (k in 0 until lags) {
            val v = refRe[k]
            sumSquares += v * v
            if (v > refRe[best]) best = k
        }
        val peak = refRe[best]
        if (peak <= 0.0) return null
        val rms = sqrt(sumSquares / lags)
        var rival = 0.0
        for (k in 0 until lags) {
            if (abs(k - best) <= PEAK_HALF_WIDTH) continue
            if (refRe[k] > rival) rival = refRe[k]
        }
        // Parabolic interpolation around the peak, for a fraction of a sample.
        var fraction = 0.0
        if (best in 1 until lags - 1) {
            val a = refRe[best - 1]
            val b = refRe[best]
            val c = refRe[best + 1]
            val denominator = a - 2 * b + c
            if (denominator != 0.0) fraction = (0.5 * (a - c) / denominator).coerceIn(-0.5, 0.5)
        }
        val matchedReferenceUs = referenceStartUs + (best + fraction) * 1_000_000.0 / RATE
        return Match(
            offsetUs = windowStartUs - matchedReferenceUs,
            strength = if (rms > 0) peak / rms else 0.0,
            distinctness = if (rival > 0) peak / rival else Double.POSITIVE_INFINITY,
        )
    }

    /**
     * One offset that explains every window, or null. [windows] are candidate windows with their
     * start times; [reference] covers the stretch of the reference they are searched in.
     */
    fun align(
        reference: FloatArray,
        referenceStartUs: Long,
        windows: List<Pair<FloatArray, Long>>,
    ): Alignment? {
        if (windows.size < 2) return null
        val matches = windows.map { (window, startUs) -> locate(reference, referenceStartUs, window, startUs) ?: return null }
        if (matches.any { it.strength < MIN_STRENGTH || it.distinctness < MIN_DISTINCTNESS }) return null
        val offsets = matches.map { it.offsetUs }
        if (offsets.max() - offsets.min() > MAX_SPREAD_US) return null
        val offsetUs = offsets.sorted()[offsets.size / 2]

        // Level: the same moments of both, compared by RMS.
        var refEnergy = 0.0
        var candEnergy = 0.0
        for ((window, startUs) in windows) {
            val referenceIndex = ((startUs - offsetUs - referenceStartUs) * RATE / 1_000_000.0).toInt()
            if (referenceIndex < 0 || referenceIndex + window.size > reference.size) continue
            for (i in window.indices) {
                val r = reference[referenceIndex + i].toDouble()
                val c = window[i].toDouble()
                refEnergy += r * r
                candEnergy += c * c
            }
        }
        val gainDb = if (refEnergy > 0 && candEnergy > 0) 10 * log10(refEnergy / candEnergy) else 0.0
        return Alignment(offsetUs.toLong(), gainDb, matches)
    }

    /** Window start times spread evenly over [firstUs]..[lastUs] for [count] windows. */
    fun windowStarts(
        firstUs: Long,
        lastUs: Long,
        count: Int,
    ): List<Long> {
        val windowUs = WINDOW_SECONDS * 1_000_000L
        val usable = lastUs - windowUs - firstUs
        if (usable < 0 || count < 1) return emptyList()
        if (count == 1) return listOf(firstUs)
        return List(count) { i -> firstUs + usable * i / max(1, count - 1) }
    }
}
