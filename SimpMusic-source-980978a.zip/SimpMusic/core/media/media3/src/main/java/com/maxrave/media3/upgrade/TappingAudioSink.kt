package com.maxrave.media3.upgrade

import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import java.nio.ByteBuffer

/**
 * Lets an [AnalysisTap] listen in on a player's audio sink. Private copy.
 *
 * Two things pass through here that nothing else in the player exposes: the decoded PCM with its
 * presentation time ([handleBuffer]), before any effect touches it, and the sink's own estimate of
 * what is coming out of the speaker right now ([getCurrentPositionUs]), which is what lets two
 * players be lined up to the millisecond. Both stay in the sink's time base; the tap never needs
 * to know how that relates to the player's position.
 *
 * Unarmed, it costs one volatile read per buffer.
 */
@UnstableApi
class TappingAudioSink(
    sink: AudioSink,
    private val tap: AnalysisTap,
) : ForwardingAudioSink(sink) {
    // The renderer hands the same buffer back until the sink has taken all of it; tap it once.
    private var lastBuffer: ByteBuffer? = null
    private var lastPresentationTimeUs = Long.MIN_VALUE

    override fun configure(config: AudioSink.AudioSinkConfig) {
        val format = config.format
        if (MimeTypes.AUDIO_RAW == format.sampleMimeType) {
            tap.configure(
                pcmEncoding =
                    when (format.pcmEncoding) {
                        C.ENCODING_PCM_16BIT -> AnalysisTap.ENCODING_PCM_16BIT
                        C.ENCODING_PCM_FLOAT -> AnalysisTap.ENCODING_PCM_FLOAT
                        else -> -1
                    },
                sampleRate = format.sampleRate,
                channelCount = format.channelCount,
            )
        }
        super.configure(config)
    }

    override fun handleBuffer(
        buffer: ByteBuffer,
        presentationTimeUs: Long,
        encodedAccessUnitCount: Int,
    ): Boolean {
        if (tap.armed && (buffer !== lastBuffer || presentationTimeUs != lastPresentationTimeUs)) {
            lastBuffer = buffer
            lastPresentationTimeUs = presentationTimeUs
            tap.feed(buffer, presentationTimeUs)
        }
        return super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
    }

    override fun getCurrentPositionUs(sourceEnded: Boolean): Long {
        val position = super.getCurrentPositionUs(sourceEnded)
        if (tap.armed && position != AudioSink.CURRENT_POSITION_NOT_SET) {
            tap.recordPosition(position, SystemClock.elapsedRealtimeNanos() / 1000)
        }
        return position
    }

    override fun flush() {
        lastBuffer = null
        lastPresentationTimeUs = Long.MIN_VALUE
        tap.flush()
        super.flush()
    }

    override fun reset() {
        lastBuffer = null
        lastPresentationTimeUs = Long.MIN_VALUE
        tap.flush()
        super.reset()
    }
}
