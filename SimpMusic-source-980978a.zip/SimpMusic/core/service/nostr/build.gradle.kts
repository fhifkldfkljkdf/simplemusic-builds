@file:OptIn(ExperimentalKotlinGradlePluginApi::class)

import com.android.build.gradle.internal.tasks.CompileArtProfileTask
import org.jetbrains.kotlin.gradle.ExperimentalKotlinGradlePluginApi
import org.jetbrains.kotlin.gradle.plugin.KotlinPlatformType

plugins {
    alias(libs.plugins.kotlin.multiplatform)
    alias(libs.plugins.android.kotlin.multiplatform.library)
    alias(libs.plugins.android.lint)
    alias(libs.plugins.kotlin.serialization)
}

// PipePipeExtractor already ships this exact artifact in the APK and the Desktop jar, so the
// curve arithmetic costs no size. Kept out of the version catalog, which upstream owns.
val bouncyCastle = "org.bouncycastle:bcprov-jdk18on:1.85"

kotlin {
    android {
        namespace = "org.simpmusic.nostr"
        compileSdk = 37
        minSdk = 26
    }

    iosArm64()
    iosSimulatorArm64()

    jvm()

    // Android and Desktop share one implementation of the curve (BouncyCastle), in `jvmSharedMain`.
    // iOS gets a stub: the whole protocol layer is common code, only the curve is not.
    applyDefaultHierarchyTemplate {
        common {
            group("jvmShared") {
                withCompilations {
                    it.platformType == KotlinPlatformType.jvm || it.platformType == KotlinPlatformType.androidJvm
                }
            }
        }
    }

    sourceSets {
        commonMain {
            dependencies {
                implementation(libs.kotlin.stdlib)
                implementation(libs.kotlinx.serialization.json)
                // SHA-256 and HMAC-SHA256 on every target.
                implementation(libs.okio)
                // Transport: ktorExt carries `api(ktor-client-core)` and the per-platform engine.
                implementation(projects.ktorExt)
                implementation(libs.ktor.client.websockets)
                // Logger.
                implementation(projects.common)
            }
        }

        getByName("jvmSharedMain") {
            dependencies {
                implementation(bouncyCastle)
            }
        }

        commonTest {
            dependencies {
                implementation(libs.kotlin.test)
            }
        }

        jvmTest {
            dependencies {
                // A relay of our own for the round-trip tests; the public ones are not reachable from CI.
                implementation(libs.ktor.server.core)
                implementation(libs.ktor.server.cio)
                implementation("io.ktor:ktor-server-websockets:${libs.versions.ktor.get()}")
            }
        }
    }
}

tasks.withType<CompileArtProfileTask> {
    enabled = false
}
