package org.simpmusic.nostr

/** No curve implementation on iOS yet; the friends feature stays hidden there. */
internal actual object Secp256k1 {
    actual val isSupported: Boolean = false

    actual fun isValidSecretKey(secretKey: ByteArray): Boolean = false

    actual fun publicKey(secretKey: ByteArray): ByteArray = unsupported()

    actual fun signSchnorr(
        message: ByteArray,
        secretKey: ByteArray,
        auxRand: ByteArray,
    ): ByteArray = unsupported()

    actual fun verifySchnorr(
        message: ByteArray,
        publicKey: ByteArray,
        signature: ByteArray,
    ): Boolean = false

    actual fun sharedSecretX(
        secretKey: ByteArray,
        publicKey: ByteArray,
    ): ByteArray = unsupported()

    actual fun randomBytes(size: Int): ByteArray = unsupported()

    private fun unsupported(): Nothing = throw UnsupportedOperationException("Nostr keys are not supported on iOS yet")
}
