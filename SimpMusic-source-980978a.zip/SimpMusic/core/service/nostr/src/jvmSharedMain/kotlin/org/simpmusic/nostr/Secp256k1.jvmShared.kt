package org.simpmusic.nostr

import org.bouncycastle.crypto.ec.CustomNamedCurves
import org.bouncycastle.math.ec.ECAlgorithms
import org.bouncycastle.math.ec.ECPoint
import org.bouncycastle.math.ec.FixedPointCombMultiplier
import java.math.BigInteger
import java.security.SecureRandom

/**
 * BIP-340 written out step by step over BouncyCastle's secp256k1 arithmetic, using the lightweight
 * API only — no JCA provider is registered, which on Android would clash with the platform's own.
 * Checked against the BIP's official vectors in `Bip340Test`.
 */
internal actual object Secp256k1 {
    private val params = CustomNamedCurves.getByName("secp256k1")
    private val curve = params.curve
    private val g: ECPoint = params.g
    private val n: BigInteger = params.n
    private val p: BigInteger = curve.field.characteristic
    private val multiplier = FixedPointCombMultiplier()
    private val random = SecureRandom()

    actual val isSupported: Boolean = true

    actual fun isValidSecretKey(secretKey: ByteArray): Boolean {
        if (secretKey.size != 32) return false
        val d = BigInteger(1, secretKey)
        return d.signum() > 0 && d < n
    }

    actual fun publicKey(secretKey: ByteArray): ByteArray {
        require(isValidSecretKey(secretKey)) { "Secret key out of range" }
        return multiplier.multiply(g, BigInteger(1, secretKey)).normalize().x32()
    }

    actual fun signSchnorr(
        message: ByteArray,
        secretKey: ByteArray,
        auxRand: ByteArray,
    ): ByteArray {
        require(isValidSecretKey(secretKey)) { "Secret key out of range" }
        require(auxRand.size == 32) { "aux_rand must be 32 bytes" }
        val d0 = BigInteger(1, secretKey)
        val point = multiplier.multiply(g, d0).normalize()
        val d = if (point.hasEvenY()) d0 else n - d0
        val px = point.x32()
        val t = d.to32().xor(taggedHash("BIP0340/aux", auxRand))
        val k0 = BigInteger(1, taggedHash("BIP0340/nonce", t + px + message)).mod(n)
        check(k0.signum() != 0) { "Nonce is zero" }
        val r = multiplier.multiply(g, k0).normalize()
        val k = if (r.hasEvenY()) k0 else n - k0
        val rx = r.x32()
        val e = BigInteger(1, taggedHash("BIP0340/challenge", rx + px + message)).mod(n)
        val signature = rx + k.add(e.multiply(d)).mod(n).to32()
        // BIP-340 recommends this: it turns a fault in the arithmetic into an error instead of a
        // signature that leaks the key.
        check(verifySchnorr(message, px, signature)) { "Produced an invalid signature" }
        return signature
    }

    actual fun verifySchnorr(
        message: ByteArray,
        publicKey: ByteArray,
        signature: ByteArray,
    ): Boolean {
        if (publicKey.size != 32 || signature.size != 64) return false
        val point = liftX(publicKey) ?: return false
        val rBytes = signature.copyOfRange(0, 32)
        val r = BigInteger(1, rBytes)
        val s = BigInteger(1, signature.copyOfRange(32, 64))
        if (r >= p || s >= n) return false
        val e = BigInteger(1, taggedHash("BIP0340/challenge", rBytes + publicKey + message)).mod(n)
        // R = s·G − e·P
        val candidate = ECAlgorithms.sumOfTwoMultiplies(g, s, point, n.subtract(e).mod(n)).normalize()
        if (candidate.isInfinity || !candidate.hasEvenY()) return false
        return candidate.affineXCoord.toBigInteger() == r
    }

    actual fun sharedSecretX(
        secretKey: ByteArray,
        publicKey: ByteArray,
    ): ByteArray {
        require(isValidSecretKey(secretKey)) { "Secret key out of range" }
        val point = requireNotNull(liftX(publicKey)) { "Public key is not on the curve" }
        val shared = point.multiply(BigInteger(1, secretKey)).normalize()
        require(!shared.isInfinity) { "Shared point at infinity" }
        return shared.x32()
    }

    actual fun randomBytes(size: Int): ByteArray = ByteArray(size).also(random::nextBytes)

    /**
     * The point with x coordinate [x] and an even y, or null when there is none. A compressed
     * encoding with prefix 02 means exactly that, and BouncyCastle rejects x ≥ p and x with no
     * square root on its own.
     */
    private fun liftX(x: ByteArray): ECPoint? {
        if (x.size != 32) return null
        return try {
            curve.decodePoint(byteArrayOf(2) + x)
        } catch (_: IllegalArgumentException) {
            null
        }
    }

    private fun ECPoint.hasEvenY(): Boolean = !affineYCoord.testBitZero()

    private fun ECPoint.x32(): ByteArray = affineXCoord.toBigInteger().to32()

    private fun BigInteger.to32(): ByteArray {
        val raw = toByteArray()
        return when {
            raw.size == 32 -> raw
            raw.size > 32 -> raw.copyOfRange(raw.size - 32, raw.size)
            else -> ByteArray(32 - raw.size) + raw
        }
    }

    private fun ByteArray.xor(other: ByteArray): ByteArray = ByteArray(size) { (this[it].toInt() xor other[it].toInt()).toByte() }
}
