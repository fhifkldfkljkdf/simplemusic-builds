package org.simpmusic.nostr.friends

import com.maxrave.logger.Logger
import io.ktor.http.encodeURLParameter
import io.ktor.http.parseQueryString
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.simpmusic.nostr.Nip19
import org.simpmusic.nostr.Nip44
import org.simpmusic.nostr.NostrEvent
import org.simpmusic.nostr.NostrFilter
import org.simpmusic.nostr.NostrKeys
import org.simpmusic.nostr.RelayPool
import kotlin.coroutines.CoroutineContext
import kotlin.time.Duration
import kotlin.time.Duration.Companion.days
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

/** Where a session keeps its key, friend list and bookkeeping. Plain strings, so any store will do. */
interface FriendsStorage {
    suspend fun read(key: String): String?

    suspend fun write(
        key: String,
        value: String,
    )

    companion object {
        const val IDENTITY = "identity"
        const val FRIENDS = "friends"
        const val HANDLED = "handled"
        const val NAME = "name"
    }
}

@Serializable
data class FriendEntry(
    val publicKey: String,
    val name: String,
    /** They told us we are on their list too. */
    val confirmed: Boolean = false,
    /** Our "we added you" message reached a relay; until then it is re-sent on every connect. */
    val announced: Boolean = false,
)

data class PendingRequest(
    val publicKey: String,
    val name: String,
    val sentAt: Long,
)

data class Invite(
    val id: String,
    val publicKey: String,
    val roomCode: String,
    val sentAt: Long,
)

data class FriendsSnapshot(
    val available: Boolean,
    val publicKey: String? = null,
    val link: String? = null,
    val name: String = "",
    val friends: List<FriendEntry> = emptyList(),
    val requests: List<PendingRequest> = emptyList(),
    val invites: List<Invite> = emptyList(),
    val relaysConnected: Int = 0,
    val relaysTotal: Int = 0,
)

sealed interface AddResult {
    data class Added(
        val friend: FriendEntry,
        val delivered: Boolean,
    ) : AddResult

    data class AlreadyFriends(
        val friend: FriendEntry,
    ) : AddResult

    data object Invalid : AddResult

    data object Self : AddResult
}

/**
 * SimpMusic's friend protocol, carried over Nostr.
 *
 * Every message is an addressable app-data event (kind 30078, NIP-78) whose content is NIP-44
 * encrypted to one recipient and whose `d` tag is `simpmusic:<type>:<recipient>`, so a newer message
 * of the same type to the same person replaces the older one on every relay. Two types:
 *
 * - `friend` — "you are on my list". To someone not on ours it is a friend request; from someone
 *   already on ours it confirms them. Adding a friend sends it, and so does accepting a request,
 *   which is what makes a single scan enough for both sides.
 * - `invite` — a Listen Together room code. Only read from confirmed-or-not friends on our list, and
 *   only for [INVITE_TTL]: an invitation is to listen now, not whenever the app is next opened.
 *
 * Relays see who writes to whom and when, but not names or room codes, and cannot forge a message:
 * events are signed, and a message that does not decrypt with the pair's shared key is dropped.
 */
class FriendsSession(
    private val storage: FriendsStorage,
    relayUrls: List<String> = DEFAULT_RELAYS,
    userAgent: String = "SimpMusic",
    private val clock: () -> Long = RelayPool::nowSeconds,
    dispatcher: CoroutineContext = Dispatchers.Default,
) : CoroutineScope {
    override val coroutineContext: CoroutineContext = SupervisorJob() + dispatcher

    private val pool = RelayPool(relayUrls, userAgent, dispatcher)
    private val lock = Mutex()
    private val json = Json { ignoreUnknownKeys = true }

    private var keys: NostrKeys? = null
    private var friends: List<FriendEntry> = emptyList()
    private var requests: List<PendingRequest> = emptyList()
    private var invites: List<Invite> = emptyList()
    private var name: String = ""

    /** `<type>:<publicKey>` → created_at of the newest message of that type already dealt with. */
    private var handled: Map<String, Long> = emptyMap()

    private val _state = MutableStateFlow(FriendsSnapshot(available = NostrKeys.isSupported, relaysTotal = relayUrls.size))
    val state: StateFlow<FriendsSnapshot> = _state.asStateFlow()

    private val loaded = CompletableDeferred<Unit>()

    // `lazy` is the one-time guard: start() is called from several places and threads.
    private val startup: Job by lazy {
        launch { pool.events.collect { onEvent(it) } }
        launch {
            pool.connectedCount.collect { count ->
                _state.update { it.copy(relaysConnected = count) }
                if (count > 0) announcePending()
            }
        }
        launch { pruneInvitesForever() }
        launch {
            lock.withLock {
                keys = storage.read(FriendsStorage.IDENTITY)?.let(NostrKeys::fromSecretKeyHex)
                friends = storage.read(FriendsStorage.FRIENDS)?.let { runCatching { json.decodeFromString<List<FriendEntry>>(it) }.getOrNull() }.orEmpty()
                handled = storage.read(FriendsStorage.HANDLED)?.let { runCatching { json.decodeFromString<Map<String, Long>>(it) }.getOrNull() }.orEmpty()
                name = storage.read(FriendsStorage.NAME).orEmpty()
                publish()
                // With nobody on the list there is nobody to hear from: the relays are left alone
                // until the Friends page asks for the identity (someone may be scanning our code).
                keys?.takeIf { friends.isNotEmpty() }?.let(::listen)
            }
            loaded.complete(Unit)
        }
    }

    fun start() {
        if (NostrKeys.isSupported) startup
    }

    private suspend fun awaitLoaded() {
        start()
        loaded.await()
    }

    fun release() {
        pool.release()
        cancel()
    }

    suspend fun ensureIdentity() {
        awaitLoaded()
        lock.withLock {
            keys?.let {
                if (!subscribed) listen(it)
                return
            }
            val created = NostrKeys.generate()
            storage.write(FriendsStorage.IDENTITY, created.secretKeyHex())
            keys = created
            publish()
            listen(created)
        }
    }

    suspend fun setMyName(value: String) {
        val clean = cleanName(value)
        awaitLoaded()
        lock.withLock {
            name = clean
            storage.write(FriendsStorage.NAME, clean)
            publish()
        }
    }

    /**
     * `(publicKey, name)` from a friend code, or null. Accepts our link in either spelling (Desktop
     * rewrites `simpmusic://friend?…` to `https://simpmusic.org/app/friend?…` before the app sees
     * it), `nostr:npub…` and a bare npub.
     */
    fun parseFriendCode(text: String): Pair<String, String?>? {
        val trimmed = text.trim()
        if (trimmed.contains("friend?", ignoreCase = true)) {
            val params = parseQueryString(trimmed.substringAfter('?'))
            val publicKey = params["npub"]?.let(Nip19::decodeNpub) ?: return null
            return publicKey to params["name"]?.let(::cleanName)?.ifBlank { null }
        }
        return Nip19.decodeNpub(trimmed.removePrefix("nostr:"))?.let { it to null }
    }

    suspend fun addFriend(code: String): AddResult {
        val (publicKey, codeName) = parseFriendCode(code) ?: return AddResult.Invalid
        ensureIdentity()
        val friend =
            lock.withLock {
                if (publicKey == keys?.publicKeyHex) return AddResult.Self
                friends.firstOrNull { it.publicKey == publicKey }?.let { return AddResult.AlreadyFriends(it) }
                // They added us first and their request is waiting: this scan answers it.
                val request = requests.firstOrNull { it.publicKey == publicKey }
                val entry =
                    FriendEntry(
                        publicKey = publicKey,
                        name = codeName ?: request?.name ?: DEFAULT_NAME,
                        confirmed = request != null,
                    )
                if (request != null) {
                    requests = requests - request
                    markHandled(TYPE_FRIEND, publicKey, request.sentAt)
                }
                friends = friends + entry
                saveFriends()
                publish()
                entry
            }
        val delivered = announce(friend.publicKey)
        return AddResult.Added(friends.firstOrNull { it.publicKey == publicKey } ?: friend, delivered)
    }

    suspend fun acceptRequest(publicKey: String) {
        awaitLoaded()
        lock.withLock {
            val request = requests.firstOrNull { it.publicKey == publicKey } ?: return
            requests = requests - request
            markHandled(TYPE_FRIEND, publicKey, request.sentAt)
            if (friends.none { it.publicKey == publicKey }) {
                friends = friends + FriendEntry(publicKey, request.name, confirmed = true)
            }
            saveFriends()
            publish()
        }
        announce(publicKey)
    }

    suspend fun declineRequest(publicKey: String) {
        awaitLoaded()
        lock.withLock {
            val request = requests.firstOrNull { it.publicKey == publicKey } ?: return
            requests = requests - request
            markHandled(TYPE_FRIEND, publicKey, request.sentAt)
            publish()
        }
    }

    suspend fun removeFriend(publicKey: String) {
        awaitLoaded()
        lock.withLock {
            friends = friends.filterNot { it.publicKey == publicKey }
            invites = invites.filterNot { it.publicKey == publicKey }
            saveFriends()
            publish()
        }
    }

    /** Sends [roomCode] to each friend in [publicKeys]; answers those whose invite reached a relay. */
    suspend fun invite(
        publicKeys: Collection<String>,
        roomCode: String,
    ): Set<String> {
        awaitLoaded()
        val targets = lock.withLock { friends.filter { it.publicKey in publicKeys }.map { it.publicKey } }
        val body =
            buildJsonObject {
                put("room", roomCode)
            }
        return targets.filter { send(it, TYPE_INVITE, body, INVITE_TTL) }.toSet()
    }

    suspend fun dismissInvite(id: String) {
        awaitLoaded()
        lock.withLock {
            val invite = invites.firstOrNull { it.id == id } ?: return
            invites = invites - invite
            markHandled(TYPE_INVITE, invite.publicKey, invite.sentAt)
            publish()
        }
    }

    /** Subscribed to messages for us; the relays are then connected whenever the app is in front. */
    @Volatile
    private var subscribed = false

    @Volatile
    private var foreground = true

    /**
     * The app went to the background ([on] false) or came back. In the background nothing would
     * show an invite, and three open sockets with their keep-alives wake the radio all through a
     * long listen; the messages wait on the relays (they are stored, not streamed) and arrive on
     * the next connect, which asks for everything since [FRIEND_TTL] ago.
     */
    fun setForeground(on: Boolean) {
        foreground = on
        if (!on) {
            pool.stop()
        } else if (subscribed) {
            pool.start()
        }
    }

    private fun listen(keys: NostrKeys) {
        subscribed = true
        pool.subscribe(
            SUBSCRIPTION,
            listOf(
                NostrFilter(
                    kinds = listOf(KIND),
                    tags = mapOf('p' to listOf(keys.publicKeyHex)),
                    since = clock() - FRIEND_TTL.inWholeSeconds,
                ),
            ),
        )
        if (foreground) pool.start()
    }

    /** Tells [publicKey] they are on our list. Records whether it got out, so a failure is retried. */
    private suspend fun announce(publicKey: String): Boolean {
        val delivered = send(publicKey, TYPE_FRIEND, buildJsonObject { }, FRIEND_TTL)
        lock.withLock {
            friends = friends.map { if (it.publicKey == publicKey) it.copy(announced = it.announced || delivered) else it }
            saveFriends()
            publish()
        }
        return delivered
    }

    private suspend fun announcePending() {
        val pending = lock.withLock { friends.filterNot { it.announced }.map { it.publicKey } }
        pending.forEach { announce(it) }
    }

    private suspend fun send(
        to: String,
        type: String,
        body: JsonObject,
        ttl: Duration,
    ): Boolean {
        val sender = lock.withLock { keys } ?: return false
        // Read fresh: the name is shared with Listen Together, which can change it at any time.
        val myName = cleanName(storage.read(FriendsStorage.NAME).orEmpty())
        val message =
            buildJsonObject {
                put("v", VERSION)
                put("t", type)
                put("name", myName)
                body.forEach { (key, value) -> put(key, value) }
            }
        val now = clock()
        val event =
            try {
                NostrEvent.create(
                    sender,
                    createdAt = now,
                    kind = KIND,
                    tags =
                        listOf(
                            listOf("d", "$D_PREFIX:$type:$to"),
                            listOf("p", to),
                            listOf("expiration", (now + ttl.inWholeSeconds).toString()),
                        ),
                    content = Nip44.encrypt(message.toString(), sender.conversationKeyWith(to)),
                )
            } catch (e: Exception) {
                Logger.w(TAG, "Could not build a $type message: ${e.message}")
                return false
            }
        val result = pool.publish(event)
        if (result.accepted == 0) Logger.w(TAG, "No relay took a $type message (${result.attempted} tried) ${result.rejections}")
        return result.accepted > 0
    }

    private suspend fun onEvent(event: NostrEvent) {
        val me = lock.withLock { keys } ?: return
        if (event.pubkey == me.publicKeyHex || event.tagValue("p") != me.publicKeyHex) return
        val type =
            when (event.tagValue("d")) {
                "$D_PREFIX:$TYPE_FRIEND:${me.publicKeyHex}" -> TYPE_FRIEND
                "$D_PREFIX:$TYPE_INVITE:${me.publicKeyHex}" -> TYPE_INVITE
                else -> return
            }
        val now = clock()
        val expiration = event.tagValue("expiration")?.toLongOrNull()
        if (expiration != null && expiration < now) return
        val message =
            try {
                json.parseToJsonElement(Nip44.decrypt(event.content, me.conversationKeyWith(event.pubkey))).jsonObject
            } catch (e: Exception) {
                Logger.w(TAG, "Dropped a message that does not decrypt: ${e.message}")
                return
            }
        if (message["v"]?.jsonPrimitive?.intOrNull != VERSION || message["t"]?.jsonPrimitive?.contentOrNull != type) return
        val senderName = cleanName(message["name"]?.jsonPrimitive?.contentOrNull.orEmpty())
        lock.withLock {
            if (event.createdAt <= (handled["$type:${event.pubkey}"] ?: 0)) return
            val friend = friends.firstOrNull { it.publicKey == event.pubkey }
            when (type) {
                TYPE_FRIEND ->
                    if (friend != null) {
                        updateFriend(friend.copy(confirmed = true, name = senderName.ifBlank { friend.name }))
                        markHandled(type, event.pubkey, event.createdAt)
                    } else {
                        requests = requests.filterNot { it.publicKey == event.pubkey } +
                            PendingRequest(event.pubkey, senderName.ifBlank { DEFAULT_NAME }, event.createdAt)
                    }

                TYPE_INVITE -> {
                    val room = message["room"]?.jsonPrimitive?.contentOrNull?.trim().orEmpty()
                    if (friend == null || !ROOM_CODE.matches(room) || now - event.createdAt > INVITE_TTL.inWholeSeconds) return
                    // Only someone who has us on their list sends invites: that confirms them too.
                    if (!friend.confirmed) updateFriend(friend.copy(confirmed = true))
                    invites = invites.filterNot { it.publicKey == event.pubkey } + Invite(event.id, event.pubkey, room, event.createdAt)
                }
            }
            publish()
        }
    }

    private suspend fun pruneInvitesForever() {
        while (true) {
            delay(30.seconds)
            lock.withLock {
                val fresh = invites.filter { clock() - it.sentAt <= INVITE_TTL.inWholeSeconds }
                if (fresh.size != invites.size) {
                    invites = fresh
                    publish()
                }
            }
        }
    }

    // Everything below runs with [lock] held.

    private suspend fun updateFriend(entry: FriendEntry) {
        friends = friends.map { if (it.publicKey == entry.publicKey) entry else it }
        saveFriends()
    }

    private suspend fun markHandled(
        type: String,
        publicKey: String,
        createdAt: Long,
    ) {
        val horizon = clock() - FRIEND_TTL.inWholeSeconds - 1.days.inWholeSeconds
        handled = (handled + ("$type:$publicKey" to createdAt)).filterValues { it >= horizon }
        storage.write(FriendsStorage.HANDLED, json.encodeToString(handled))
    }

    private suspend fun saveFriends() = storage.write(FriendsStorage.FRIENDS, json.encodeToString(friends))

    private fun publish() {
        val me = keys
        _state.update {
            it.copy(
                publicKey = me?.publicKeyHex,
                link = me?.let { k -> friendLink(k.publicKeyHex, name) },
                name = name,
                friends = friends,
                requests = requests,
                invites = invites,
            )
        }
    }

    companion object {
        private const val TAG = "Friends"
        const val KIND = 30078
        const val VERSION = 1
        const val D_PREFIX = "simpmusic"
        const val TYPE_FRIEND = "friend"
        const val TYPE_INVITE = "invite"
        const val LINK_PREFIX = "simpmusic://friend?"
        const val DEFAULT_NAME = "Friend"
        private const val SUBSCRIPTION = "simpmusic-inbox"
        private const val MAX_NAME_LENGTH = 32

        val INVITE_TTL: Duration = 30.minutes
        val FRIEND_TTL: Duration = 7.days

        /** Listen Together room codes: letters and digits, the way the server issues them. */
        private val ROOM_CODE = Regex("[A-Za-z0-9]{4,16}")

        /** Public relays that take app-data events from anyone. Three, so one being down changes nothing. */
        val DEFAULT_RELAYS =
            listOf(
                "wss://relay.damus.io",
                "wss://nos.lol",
                "wss://relay.primal.net",
            )

        fun friendLink(
            publicKeyHex: String,
            name: String,
        ): String =
            buildString {
                append(LINK_PREFIX).append("npub=").append(Nip19.npub(publicKeyHex))
                if (name.isNotBlank()) append("&name=").append(name.encodeURLParameter())
            }

        /** Names come from other people's devices: no control characters, bounded length. */
        fun cleanName(value: String): String = value.filterNot { it.isISOControl() }.trim().take(MAX_NAME_LENGTH)
    }
}
