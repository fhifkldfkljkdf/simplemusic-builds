package org.simpmusic.nostr

import com.maxrave.ktorext.getEngine
import com.maxrave.logger.Logger
import io.ktor.client.HttpClient
import io.ktor.client.plugins.UserAgent
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.plugins.websocket.webSocketSession
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlin.concurrent.Volatile
import kotlin.coroutines.CoroutineContext
import kotlin.time.Clock
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlin.time.ExperimentalTime
import kotlin.time.TimeSource

/** How a [RelayPool.publish] went: how many relays stored the event, out of how many were asked. */
data class PublishResult(
    val accepted: Int,
    val attempted: Int,
    val rejections: List<String> = emptyList(),
)

/**
 * One connection to each of [relayUrls] (NIP-01 over WebSocket), kept open and re-opened with
 * backoff for as long as the pool runs.
 *
 * Subscriptions are the pool's, not a connection's: every relay that connects — or reconnects —
 * is sent all of them, so a caller subscribes once. [events] carries each event once however many
 * relays deliver it, and only after its id and signature check out: a relay can drop events, but
 * it cannot invent or alter one.
 */
class RelayPool(
    val relayUrls: List<String>,
    userAgent: String = "SimpMusic",
    dispatcher: CoroutineContext = Dispatchers.Default,
    /** A connection quiet this long is asked for a reply (see [keepAlive]). */
    private val keepAliveInterval: Duration = 45.seconds,
    /** A connection quiet this long is given up and re-opened. Rooms want this short. */
    private val deadAfter: Duration = 100.seconds,
) : CoroutineScope {
    override val coroutineContext: CoroutineContext = SupervisorJob() + dispatcher

    private val client =
        HttpClient(getEngine()) {
            install(UserAgent) { agent = userAgent }
            install(WebSockets)
        }

    private val sessions = MutableStateFlow<Map<String, DefaultClientWebSocketSession>>(emptyMap())

    /** How many relays are connected right now. */
    val connectedCount: StateFlow<Int> = sessions.map { it.size }.stateIn(this, SharingStarted.Eagerly, 0)

    private val subscriptions = MutableStateFlow<Map<String, List<NostrFilter>>>(emptyMap())

    private val _events = MutableSharedFlow<NostrEvent>(extraBufferCapacity = 256)
    val events: SharedFlow<NostrEvent> = _events.asSharedFlow()

    private data class Ack(
        val eventId: String,
        val relay: String,
        val accepted: Boolean,
        val message: String,
    )

    private val acks = MutableSharedFlow<Ack>(extraBufferCapacity = 256)

    private val seenLock = Mutex()
    private val seen = LinkedHashSet<String>()

    private var relayJobs: List<Job> = emptyList()

    val isRunning: Boolean get() = relayJobs.any { it.isActive }

    /** Connects to every relay. Does nothing while already running. */
    fun start() {
        if (isRunning) return
        relayJobs = relayUrls.map { url -> launch { runRelay(url) } }
    }

    /** Closes every connection. Subscriptions are kept for the next [start]. */
    fun stop() {
        relayJobs.forEach { it.cancel() }
        relayJobs = emptyList()
    }

    /** Stops for good and releases the HTTP client. */
    fun release() {
        stop()
        runCatching { client.close() }
        cancel()
    }

    /** Adds or replaces subscription [id], on every relay now and on every relay that connects later. */
    fun subscribe(
        id: String,
        filters: List<NostrFilter>,
    ) {
        subscriptions.update { it + (id to filters) }
        val message = reqMessage(id, filters)
        sessions.value.values.forEach { session -> launch { runCatching { session.sendJson(message) } } }
    }

    fun unsubscribe(id: String) {
        subscriptions.update { it - id }
        val message = JsonArray(listOf(JsonPrimitive("CLOSE"), JsonPrimitive(id)))
        sessions.value.values.forEach { session -> launch { runCatching { session.sendJson(message) } } }
    }

    /**
     * Sends [event] to every connected relay and waits for their answers. When none is connected it
     * first waits for one, within the same [timeout].
     */
    suspend fun publish(
        event: NostrEvent,
        timeout: Duration = 10.seconds,
    ): PublishResult {
        val targets = withTimeoutOrNull(timeout) { sessions.first { it.isNotEmpty() } } ?: return PublishResult(0, 0)
        val message = JsonArray(listOf(JsonPrimitive("EVENT"), event.toJson()))
        return coroutineScope {
            val inbox = Channel<Ack>(Channel.UNLIMITED)
            // Subscribed before the first send, so an answer cannot arrive before anyone listens.
            val collector =
                launch(start = CoroutineStart.UNDISPATCHED) {
                    acks.collect { if (it.eventId == event.id) inbox.send(it) }
                }
            val sent = targets.filter { (_, session) -> runCatching { session.sendJson(message) }.isSuccess }.keys
            val answers = mutableMapOf<String, Ack>()
            withTimeoutOrNull(timeout) {
                while (!answers.keys.containsAll(sent)) {
                    val ack = inbox.receive()
                    if (ack.relay in sent) answers[ack.relay] = ack
                }
            }
            collector.cancel()
            PublishResult(
                accepted = answers.values.count { it.accepted },
                attempted = targets.size,
                rejections = answers.values.filterNot { it.accepted }.map { "${it.relay}: ${it.message}" },
            )
        }
    }

    private class Liveness {
        @Volatile var lastInboundMs: Long = 0
    }

    private suspend fun runRelay(url: String) {
        var failures = 0
        while (true) {
            try {
                val session = client.webSocketSession(url)
                failures = 0
                Logger.i(TAG, "Connected to $url")
                try {
                    sessions.update { it + (url to session) }
                    subscriptions.value.forEach { (id, filters) -> session.sendJson(reqMessage(id, filters)) }
                    val liveness = Liveness().apply { lastInboundMs = nowMs() }
                    coroutineScope {
                        val watchdog = launch { keepAlive(session, liveness) }
                        for (frame in session.incoming) {
                            liveness.lastInboundMs = nowMs()
                            if (frame is Frame.Text) handle(url, frame.readText())
                        }
                        watchdog.cancel()
                    }
                } finally {
                    sessions.update { current -> if (current[url] === session) current - url else current }
                    withContext(NonCancellable) { runCatching { withTimeoutOrNull(2.seconds) { session.close() } } }
                }
                Logger.w(TAG, "$url closed the connection")
            } catch (e: Exception) {
                // A cancelled session surfaces here as a CancellationException too; only a
                // cancelled pool ends the loop.
                currentCoroutineContext().ensureActive()
                Logger.w(TAG, "$url: ${e.message ?: e::class.simpleName}")
            }
            failures++
            delay(backoff(failures))
        }
    }

    /**
     * A socket whose network vanished can look open for many minutes. Relays answer any REQ with at
     * least an EOSE, so a quiet connection is sent a REQ that matches nothing, and one that stays
     * silent after that is dropped and re-opened.
     */
    private suspend fun keepAlive(
        session: DefaultClientWebSocketSession,
        liveness: Liveness,
    ) {
        while (true) {
            delay(keepAliveInterval)
            val silentMs = nowMs() - liveness.lastInboundMs
            if (silentMs >= deadAfter.inWholeMilliseconds) {
                Logger.w(TAG, "No answer for ${silentMs / 1000}s, reconnecting")
                session.cancel()
                return
            }
            if (silentMs >= keepAliveInterval.inWholeMilliseconds) {
                runCatching { session.sendJson(KEEPALIVE_REQ) }
            }
        }
    }

    private suspend fun handle(
        url: String,
        text: String,
    ) {
        val message = runCatching { Json.parseToJsonElement(text).jsonArray }.getOrNull() ?: return
        when (message.getOrNull(0)?.string()) {
            "EVENT" -> {
                val subscription = message.getOrNull(1)?.string() ?: return
                val filters = subscriptions.value[subscription] ?: return
                val event = (message.getOrNull(2) as? JsonObject)?.let(NostrEvent::fromJson) ?: return
                if (filters.none { it.matches(event) }) return
                if (seenLock.withLock { event.id in seen }) return
                if (!event.isValid()) {
                    Logger.w(TAG, "$url sent an event with a bad id or signature")
                    return
                }
                val fresh =
                    seenLock.withLock {
                        seen.add(event.id).also {
                            if (seen.size > SEEN_LIMIT) seen.remove(seen.first())
                        }
                    }
                if (fresh) _events.emit(event)
            }

            "OK" -> {
                val id = message.getOrNull(1)?.string() ?: return
                val accepted = (message.getOrNull(2) as? JsonPrimitive)?.booleanOrNull ?: return
                acks.emit(Ack(id, url, accepted, message.getOrNull(3)?.string().orEmpty()))
            }

            "CLOSED" -> Logger.w(TAG, "$url closed ${message.getOrNull(1)?.string()}: ${message.getOrNull(2)?.string()}")
            "NOTICE" -> Logger.w(TAG, "$url: ${message.getOrNull(1)?.string()}")
            else -> Unit
        }
    }

    private fun JsonElement.string(): String? = (this as? JsonPrimitive)?.contentOrNull

    private suspend fun DefaultClientWebSocketSession.sendJson(json: JsonElement) = send(Frame.Text(json.toString()))

    private fun reqMessage(
        id: String,
        filters: List<NostrFilter>,
    ): JsonArray = JsonArray(listOf(JsonPrimitive("REQ"), JsonPrimitive(id)) + filters.map { it.toJson() })

    companion object {
        private const val TAG = "NostrRelayPool"
        private const val SEEN_LIMIT = 2000
        private val MONOTONIC = TimeSource.Monotonic.markNow()

        private val KEEPALIVE_REQ =
            JsonArray(
                listOf(
                    JsonPrimitive("REQ"),
                    JsonPrimitive("keepalive"),
                    NostrFilter(ids = listOf("0".repeat(64)), limit = 1).toJson(),
                ),
            )

        private fun nowMs(): Long = MONOTONIC.elapsedNow().inWholeMilliseconds

        /** 2 s, 4 s, 8 s … capped at 32 s. */
        internal fun backoff(failures: Int): Duration = (1L shl failures.coerceIn(1, 5)).seconds.coerceAtMost(60.seconds)

        @OptIn(ExperimentalTime::class)
        fun nowSeconds(): Long = Clock.System.now().epochSeconds
    }
}
