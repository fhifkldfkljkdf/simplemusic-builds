package org.simpmusic.nostr

/**
 * Bech32 (BIP-173, not Bech32m), which NIP-19 uses for `npub` and `nsec`. Only the bare key forms
 * are supported; the TLV forms (`nprofile`, `nevent`) are not needed here.
 */
object Bech32 {
    private const val CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    private val GENERATOR = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)

    fun encode(
        hrp: String,
        data: ByteArray,
    ): String {
        val values = convertBits(data.map { it.toInt() and 0xff }, 8, 5, pad = true)!!
        val checksum = checksum(hrp, values)
        return buildString {
            append(hrp).append('1')
            (values + checksum).forEach { append(CHARSET[it]) }
        }
    }

    /** `(hrp, data)`, or null when [text] is not valid Bech32. */
    fun decode(text: String): Pair<String, ByteArray>? {
        if (text.length > 1000) return null
        if (text != text.lowercase() && text != text.uppercase()) return null
        val lower = text.lowercase()
        val separator = lower.lastIndexOf('1')
        if (separator < 1 || separator + 7 > lower.length) return null
        val hrp = lower.substring(0, separator)
        if (hrp.any { it.code !in 33..126 }) return null
        val values = lower.substring(separator + 1).map { CHARSET.indexOf(it).takeIf { i -> i >= 0 } ?: return null }
        if (polymod(hrpExpand(hrp) + values) != 1) return null
        val bytes = convertBits(values.dropLast(6), 5, 8, pad = false) ?: return null
        return hrp to ByteArray(bytes.size) { bytes[it].toByte() }
    }

    private fun checksum(
        hrp: String,
        values: List<Int>,
    ): List<Int> {
        val mod = polymod(hrpExpand(hrp) + values + List(6) { 0 }) xor 1
        return List(6) { (mod ushr (5 * (5 - it))) and 31 }
    }

    private fun polymod(values: List<Int>): Int {
        var chk = 1
        for (v in values) {
            val top = chk ushr 25
            chk = ((chk and 0x1ffffff) shl 5) xor v
            for (i in 0 until 5) if ((top ushr i) and 1 == 1) chk = chk xor GENERATOR[i]
        }
        return chk
    }

    private fun hrpExpand(hrp: String): List<Int> = hrp.map { it.code ushr 5 } + 0 + hrp.map { it.code and 31 }

    private fun convertBits(
        data: List<Int>,
        from: Int,
        to: Int,
        pad: Boolean,
    ): List<Int>? {
        var acc = 0
        var bits = 0
        val out = ArrayList<Int>()
        val maxv = (1 shl to) - 1
        for (value in data) {
            if (value < 0 || value ushr from != 0) return null
            acc = (acc shl from) or value
            bits += from
            while (bits >= to) {
                bits -= to
                out += (acc ushr bits) and maxv
            }
        }
        if (pad) {
            if (bits > 0) out += (acc shl (to - bits)) and maxv
        } else if (bits >= from || ((acc shl (to - bits)) and maxv) != 0) {
            return null
        }
        return out
    }
}

/** NIP-19 key encodings. */
object Nip19 {
    fun npub(publicKeyHex: String): String = Bech32.encode("npub", requireNotNull(publicKeyHex.hexToBytesOrNull()))

    /** The hex public key inside an `npub`, or null for anything else. */
    fun decodeNpub(npub: String): String? {
        val (hrp, data) = Bech32.decode(npub.trim()) ?: return null
        return if (hrp == "npub" && data.size == 32) data.toHex() else null
    }
}
