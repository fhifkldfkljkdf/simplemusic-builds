package org.simpmusic.nostr

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put

/** A Nostr identity: a secp256k1 secret key and the x-only public key relays know it by. */
class NostrKeys private constructor(
    private val secretKey: ByteArray,
) {
    val publicKey: ByteArray = Secp256k1.publicKey(secretKey)
    val publicKeyHex: String = publicKey.toHex()
    val npub: String get() = Nip19.npub(publicKeyHex)

    /** For storing the identity. Never send this anywhere. */
    fun secretKeyHex(): String = secretKey.toHex()

    fun sign(message: ByteArray): ByteArray = Secp256k1.signSchnorr(message, secretKey, Secp256k1.randomBytes(32))

    /** The NIP-44 conversation key with [otherPublicKeyHex]; the same one the other side derives. */
    fun conversationKeyWith(otherPublicKeyHex: String): ByteArray =
        Nip44.conversationKey(secretKey, requireNotNull(otherPublicKeyHex.hexToBytesOrNull()) { "Not a hex key" })

    companion object {
        val isSupported: Boolean get() = Secp256k1.isSupported

        fun generate(): NostrKeys {
            while (true) {
                val candidate = Secp256k1.randomBytes(32)
                if (Secp256k1.isValidSecretKey(candidate)) return NostrKeys(candidate)
            }
        }

        fun fromSecretKeyHex(hex: String): NostrKeys? {
            val bytes = hex.trim().hexToBytesOrNull() ?: return null
            return if (Secp256k1.isValidSecretKey(bytes)) NostrKeys(bytes) else null
        }
    }
}

/**
 * A NIP-01 event. [id] is the sha256 of [serializeForId]'s output and [sig] a BIP-340 signature of
 * that id by [pubkey]; [isValid] checks both, which is what makes the author of an event something a
 * relay cannot forge.
 */
data class NostrEvent(
    val id: String,
    val pubkey: String,
    val createdAt: Long,
    val kind: Int,
    val tags: List<List<String>>,
    val content: String,
    val sig: String,
) {
    fun tagValue(name: String): String? = tags.firstOrNull { it.size >= 2 && it[0] == name }?.get(1)

    fun isValid(): Boolean {
        if (!pubkey.isHex32() || !id.isHex32() || sig.length != 128) return false
        if (computeId(pubkey, createdAt, kind, tags, content) != id) return false
        val signature = sig.hexToBytesOrNull() ?: return false
        return Secp256k1.verifySchnorr(id.hexToBytesOrNull()!!, pubkey.hexToBytesOrNull()!!, signature)
    }

    fun toJson(): JsonObject =
        buildJsonObject {
            put("id", id)
            put("pubkey", pubkey)
            put("created_at", createdAt)
            put("kind", kind)
            put("tags", buildJsonArray { tags.forEach { tag -> add(JsonArray(tag.map(::JsonPrimitive))) } })
            put("content", content)
            put("sig", sig)
        }

    companion object {
        fun create(
            keys: NostrKeys,
            createdAt: Long,
            kind: Int,
            tags: List<List<String>>,
            content: String,
        ): NostrEvent {
            val id = computeId(keys.publicKeyHex, createdAt, kind, tags, content)
            val sig = keys.sign(id.hexToBytesOrNull()!!).toHex()
            return NostrEvent(id, keys.publicKeyHex, createdAt, kind, tags, content, sig)
        }

        fun computeId(
            pubkey: String,
            createdAt: Long,
            kind: Int,
            tags: List<List<String>>,
            content: String,
        ): String = sha256(serializeForId(pubkey, createdAt, kind, tags, content).encodeToByteArray()).toHex()

        /**
         * `[0,<pubkey>,<created_at>,<kind>,<tags>,<content>]` with no whitespace and NIP-01's own
         * escaping. That is deliberately not a general JSON encoder: NIP-01 escapes exactly seven
         * characters and writes every other one — other control characters included — verbatim,
         * and an id computed any other way is rejected by relays.
         */
        fun serializeForId(
            pubkey: String,
            createdAt: Long,
            kind: Int,
            tags: List<List<String>>,
            content: String,
        ): String =
            buildString {
                append("[0,")
                appendQuoted(pubkey)
                append(',').append(createdAt).append(',').append(kind).append(",[")
                tags.forEachIndexed { i, tag ->
                    if (i > 0) append(',')
                    append('[')
                    tag.forEachIndexed { j, value ->
                        if (j > 0) append(',')
                        appendQuoted(value)
                    }
                    append(']')
                }
                append("],")
                appendQuoted(content)
                append(']')
            }

        private fun StringBuilder.appendQuoted(value: String) {
            append('"')
            for (c in value) {
                when (c) {
                    '\n' -> append("\\n")
                    '"' -> append("\\\"")
                    '\\' -> append("\\\\")
                    '\r' -> append("\\r")
                    '\t' -> append("\\t")
                    '\b' -> append("\\b")
                    '\u000c' -> append("\\f")
                    else -> append(c)
                }
            }
            append('"')
        }

        /** Null for anything that is not shaped like an event. Does not check [isValid]. */
        fun fromJson(json: JsonObject): NostrEvent? =
            try {
                NostrEvent(
                    id = json["id"]!!.jsonPrimitive.contentOrNull!!,
                    pubkey = json["pubkey"]!!.jsonPrimitive.contentOrNull!!,
                    createdAt = json["created_at"]!!.jsonPrimitive.long,
                    kind = json["kind"]!!.jsonPrimitive.int,
                    tags =
                        json["tags"]!!.jsonArray.map { tag ->
                            tag.jsonArray.map { it.jsonPrimitive.contentOrNull!! }
                        },
                    content = json["content"]!!.jsonPrimitive.contentOrNull!!,
                    sig = json["sig"]!!.jsonPrimitive.contentOrNull!!,
                )
            } catch (_: Exception) {
                null
            }
    }
}

/** A NIP-01 subscription filter. Tag filters are keyed by the letter, without the `#`. */
data class NostrFilter(
    val ids: List<String>? = null,
    val authors: List<String>? = null,
    val kinds: List<Int>? = null,
    val tags: Map<Char, List<String>> = emptyMap(),
    val since: Long? = null,
    val until: Long? = null,
    val limit: Int? = null,
) {
    fun toJson(): JsonObject =
        buildJsonObject {
            ids?.let { put("ids", JsonArray(it.map(::JsonPrimitive))) }
            authors?.let { put("authors", JsonArray(it.map(::JsonPrimitive))) }
            kinds?.let { put("kinds", JsonArray(it.map(::JsonPrimitive))) }
            tags.forEach { (letter, values) -> put("#$letter", JsonArray(values.map(::JsonPrimitive))) }
            since?.let { put("since", it) }
            until?.let { put("until", it) }
            limit?.let { put("limit", it) }
        }

    fun matches(event: NostrEvent): Boolean {
        if (ids != null && event.id !in ids) return false
        if (authors != null && event.pubkey !in authors) return false
        if (kinds != null && event.kind !in kinds) return false
        if (since != null && event.createdAt < since) return false
        if (until != null && event.createdAt > until) return false
        return tags.all { (letter, values) ->
            event.tags.any { it.size >= 2 && it[0] == letter.toString() && it[1] in values }
        }
    }

    companion object {
        fun fromJson(json: JsonObject): NostrFilter =
            NostrFilter(
                ids = json["ids"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull },
                authors = json["authors"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull },
                kinds = json["kinds"]?.jsonArray?.mapNotNull { it.jsonPrimitive.intOrNull },
                tags =
                    json
                        .filterKeys { it.length == 2 && it[0] == '#' }
                        .map { (key, value) -> key[1] to value.jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull } }
                        .toMap(),
                since = json["since"]?.jsonPrimitive?.longOrNull,
                until = json["until"]?.jsonPrimitive?.longOrNull,
                limit = json["limit"]?.jsonPrimitive?.intOrNull,
            )
    }
}
