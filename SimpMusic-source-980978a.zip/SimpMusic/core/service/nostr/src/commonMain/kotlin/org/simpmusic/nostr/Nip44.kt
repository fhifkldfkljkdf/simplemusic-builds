package org.simpmusic.nostr

import kotlin.io.encoding.Base64

class Nip44Exception(
    message: String,
) : Exception(message)

/**
 * NIP-44 version 2: the encryption Nostr clients use for direct messages. Only the two people in a
 * conversation can read it; relays see a base64 blob whose length is rounded up (padding hides the
 * exact size of short messages).
 *
 * Follows the spec's pseudocode line for line and is checked against its official vectors
 * (`nip44.vectors.json`, sha256 269ed0f6…) in `Nip44Test`.
 */
object Nip44 {
    private const val VERSION: Byte = 2
    private val SALT = "nip44-v2".encodeToByteArray()

    const val MIN_PLAINTEXT_SIZE = 1
    const val MAX_PLAINTEXT_SIZE = 65535

    /** Same for both directions: `conversationKey(a, B) == conversationKey(b, A)`. */
    fun conversationKey(
        secretKey: ByteArray,
        publicKey: ByteArray,
    ): ByteArray = hmacSha256(SALT, Secp256k1.sharedSecretX(secretKey, publicKey))

    fun encrypt(
        plaintext: String,
        conversationKey: ByteArray,
        nonce: ByteArray = Secp256k1.randomBytes(32),
    ): String {
        require(conversationKey.size == 32) { "Conversation key must be 32 bytes" }
        require(nonce.size == 32) { "Nonce must be 32 bytes" }
        val keys = messageKeys(conversationKey, nonce)
        val ciphertext = ChaCha20.xor(keys.chachaKey, keys.chachaNonce, pad(plaintext))
        val mac = hmacAad(keys.hmacKey, ciphertext, nonce)
        return Base64.Default.encode(byteArrayOf(VERSION) + nonce + ciphertext + mac)
    }

    fun decrypt(
        payload: String,
        conversationKey: ByteArray,
    ): String {
        require(conversationKey.size == 32) { "Conversation key must be 32 bytes" }
        if (payload.isEmpty() || payload[0] == '#') throw Nip44Exception("Unknown version")
        if (payload.length !in 132..87472) throw Nip44Exception("Invalid payload size")
        val data =
            try {
                Base64.Default.decode(payload)
            } catch (_: IllegalArgumentException) {
                throw Nip44Exception("Invalid base64")
            }
        if (data.size !in 99..65603) throw Nip44Exception("Invalid data size")
        if (data[0] != VERSION) throw Nip44Exception("Unknown version ${data[0]}")
        val nonce = data.copyOfRange(1, 33)
        val ciphertext = data.copyOfRange(33, data.size - 32)
        val mac = data.copyOfRange(data.size - 32, data.size)
        val keys = messageKeys(conversationKey, nonce)
        if (!constantTimeEquals(hmacAad(keys.hmacKey, ciphertext, nonce), mac)) throw Nip44Exception("Invalid MAC")
        return unpad(ChaCha20.xor(keys.chachaKey, keys.chachaNonce, ciphertext))
    }

    fun calcPaddedLen(unpaddedLen: Int): Int {
        require(unpaddedLen > 0) { "Length must be positive" }
        if (unpaddedLen <= 32) return 32
        // 1 << (floor(log2(unpaddedLen - 1)) + 1)
        val nextPower = 1 shl (32 - (unpaddedLen - 1).countLeadingZeroBits())
        val chunk = if (nextPower <= 256) 32 else nextPower / 8
        return chunk * ((unpaddedLen - 1) / chunk + 1)
    }

    internal class MessageKeys(
        val chachaKey: ByteArray,
        val chachaNonce: ByteArray,
        val hmacKey: ByteArray,
    )

    /** HKDF-expand(conversationKey, info = nonce, L = 76), split 32 / 12 / 32. */
    internal fun messageKeys(
        conversationKey: ByteArray,
        nonce: ByteArray,
    ): MessageKeys {
        var block = ByteArray(0)
        var okm = ByteArray(0)
        var counter = 1
        while (okm.size < 76) {
            block = hmacSha256(conversationKey, block + nonce + byteArrayOf(counter.toByte()))
            okm += block
            counter++
        }
        return MessageKeys(okm.copyOfRange(0, 32), okm.copyOfRange(32, 44), okm.copyOfRange(44, 76))
    }

    private fun pad(plaintext: String): ByteArray {
        val unpadded = plaintext.encodeToByteArray()
        if (unpadded.size !in MIN_PLAINTEXT_SIZE..MAX_PLAINTEXT_SIZE) throw Nip44Exception("Invalid plaintext length ${unpadded.size}")
        val prefix = byteArrayOf((unpadded.size ushr 8).toByte(), unpadded.size.toByte())
        return prefix + unpadded + ByteArray(calcPaddedLen(unpadded.size) - unpadded.size)
    }

    private fun unpad(padded: ByteArray): String {
        if (padded.size < 2) throw Nip44Exception("Invalid padding")
        val length = ((padded[0].toInt() and 0xff) shl 8) or (padded[1].toInt() and 0xff)
        if (length == 0 || 2 + length > padded.size || padded.size != 2 + calcPaddedLen(length)) {
            throw Nip44Exception("Invalid padding")
        }
        return padded.copyOfRange(2, 2 + length).decodeToString(throwOnInvalidSequence = true)
    }

    private fun hmacAad(
        key: ByteArray,
        message: ByteArray,
        aad: ByteArray,
    ): ByteArray {
        require(aad.size == 32) { "AAD must be 32 bytes" }
        return hmacSha256(key, aad + message)
    }
}

/**
 * ChaCha20 as RFC 8439 defines it (96-bit nonce, 32-bit block counter), which is what NIP-44 means
 * by "chacha20" — the bare stream cipher, with its own HMAC instead of Poly1305. Plain Kotlin so it
 * runs on every target; checked against the RFC's section 2.4.2 vector in `Nip44Test`.
 */
internal object ChaCha20 {
    fun xor(
        key: ByteArray,
        nonce: ByteArray,
        data: ByteArray,
        initialCounter: Int = 0,
    ): ByteArray {
        require(key.size == 32 && nonce.size == 12)
        val state = IntArray(16)
        state[0] = 0x61707865
        state[1] = 0x3320646e
        state[2] = 0x79622d32
        state[3] = 0x6b206574
        for (i in 0 until 8) state[4 + i] = key.intLe(4 * i)
        for (i in 0 until 3) state[13 + i] = nonce.intLe(4 * i)
        val out = ByteArray(data.size)
        val working = IntArray(16)
        var counter = initialCounter
        var offset = 0
        while (offset < data.size) {
            state[12] = counter
            state.copyInto(working)
            repeat(10) {
                quarter(working, 0, 4, 8, 12)
                quarter(working, 1, 5, 9, 13)
                quarter(working, 2, 6, 10, 14)
                quarter(working, 3, 7, 11, 15)
                quarter(working, 0, 5, 10, 15)
                quarter(working, 1, 6, 11, 12)
                quarter(working, 2, 7, 8, 13)
                quarter(working, 3, 4, 9, 14)
            }
            val n = minOf(64, data.size - offset)
            for (i in 0 until n) {
                val word = working[i / 4] + state[i / 4]
                val keyByte = (word ushr (8 * (i % 4))).toByte()
                out[offset + i] = (data[offset + i].toInt() xor keyByte.toInt()).toByte()
            }
            offset += n
            counter++
        }
        return out
    }

    private fun quarter(
        x: IntArray,
        a: Int,
        b: Int,
        c: Int,
        d: Int,
    ) {
        x[a] += x[b]
        x[d] = (x[d] xor x[a]).rotateLeft(16)
        x[c] += x[d]
        x[b] = (x[b] xor x[c]).rotateLeft(12)
        x[a] += x[b]
        x[d] = (x[d] xor x[a]).rotateLeft(8)
        x[c] += x[d]
        x[b] = (x[b] xor x[c]).rotateLeft(7)
    }

    private fun ByteArray.intLe(at: Int): Int =
        (this[at].toInt() and 0xff) or
            ((this[at + 1].toInt() and 0xff) shl 8) or
            ((this[at + 2].toInt() and 0xff) shl 16) or
            ((this[at + 3].toInt() and 0xff) shl 24)
}
