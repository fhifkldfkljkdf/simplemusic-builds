package org.simpmusic.nostr

import okio.ByteString.Companion.toByteString

/**
 * The elliptic-curve half of Nostr: BIP-340 Schnorr signatures and the x-only ECDH that NIP-44
 * derives its keys from, all on secp256k1. Keys and signatures are raw bytes — 32-byte secret keys,
 * 32-byte x-only public keys, 64-byte signatures.
 *
 * Android and Desktop share one implementation (`jvmSharedMain`, BouncyCastle); iOS has none yet and
 * reports [isSupported] false, so the layers above can hide the feature instead of failing.
 */
internal expect object Secp256k1 {
    val isSupported: Boolean

    /** Whether [secretKey] is 32 bytes and in 1 until n. */
    fun isValidSecretKey(secretKey: ByteArray): Boolean

    /** The x-only public key of [secretKey]. */
    fun publicKey(secretKey: ByteArray): ByteArray

    fun signSchnorr(
        message: ByteArray,
        secretKey: ByteArray,
        auxRand: ByteArray,
    ): ByteArray

    fun verifySchnorr(
        message: ByteArray,
        publicKey: ByteArray,
        signature: ByteArray,
    ): Boolean

    /**
     * The x coordinate of `secretKey · lift_x(publicKey)`, unhashed — what NIP-44 feeds into HKDF.
     * Throws [IllegalArgumentException] for a secret key out of range or a public key off the curve.
     */
    fun sharedSecretX(
        secretKey: ByteArray,
        publicKey: ByteArray,
    ): ByteArray

    fun randomBytes(size: Int): ByteArray
}

internal fun sha256(data: ByteArray): ByteArray = data.toByteString().sha256().toByteArray()

internal fun hmacSha256(
    key: ByteArray,
    data: ByteArray,
): ByteArray = data.toByteString().hmacSha256(key.toByteString()).toByteArray()

/** Bytes from the platform's secure random source (the same one keys are made from). */
fun secureRandomBytes(size: Int): ByteArray = Secp256k1.randomBytes(size)

/**
 * A secret every member of a group derives from one shared code, for groups that meet through
 * relays without exchanging keys first (a Listen Together room and its code).
 *
 * [conversationKey] feeds [Nip44.encrypt]/[Nip44.decrypt] directly; [tag] is what relays filter
 * on. Both are one-way from the code, and the tag uses a different label, so a relay that sees the
 * tag learns nothing that decrypts anything.
 */
class SharedCodeSecret(
    code: String,
    label: String,
) {
    val conversationKey: ByteArray = hmacSha256("$label/key/v1".encodeToByteArray(), code.encodeToByteArray())
    val tag: String = sha256("$label/tag/v1:$code".encodeToByteArray()).toHex().take(32)
}

/** BIP-340's tagged hash: `sha256(sha256(tag) || sha256(tag) || data)`. */
internal fun taggedHash(
    tag: String,
    data: ByteArray,
): ByteArray {
    val tagHash = sha256(tag.encodeToByteArray())
    return sha256(tagHash + tagHash + data)
}

/** Compares in time independent of where the arrays first differ. */
internal fun constantTimeEquals(
    a: ByteArray,
    b: ByteArray,
): Boolean {
    if (a.size != b.size) return false
    var diff = 0
    for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
    return diff == 0
}

private const val HEX = "0123456789abcdef"

fun ByteArray.toHex(): String {
    val out = StringBuilder(size * 2)
    for (b in this) {
        val v = b.toInt() and 0xff
        out.append(HEX[v ushr 4]).append(HEX[v and 0x0f])
    }
    return out.toString()
}

/** Lower- or upper-case hex to bytes; null for odd length or any other character. */
fun String.hexToBytesOrNull(): ByteArray? {
    if (length % 2 != 0) return null
    val out = ByteArray(length / 2)
    for (i in out.indices) {
        val hi = this[2 * i].digitToIntOrNull(16) ?: return null
        val lo = this[2 * i + 1].digitToIntOrNull(16) ?: return null
        out[i] = ((hi shl 4) or lo).toByte()
    }
    return out
}

/** A 64-character hex string: the shape of a Nostr public key, event id or secret key. */
internal fun String.isHex32(): Boolean = length == 64 && all { it in '0'..'9' || it in 'a'..'f' }
