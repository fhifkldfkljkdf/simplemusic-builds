package org.simpmusic.nostr.friends

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.simpmusic.nostr.Nip19
import org.simpmusic.nostr.Nip44
import org.simpmusic.nostr.NostrEvent
import org.simpmusic.nostr.NostrKeys
import org.simpmusic.nostr.RelayPool
import org.simpmusic.nostr.TestRelay
import java.util.concurrent.ConcurrentHashMap
import kotlin.test.AfterTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

private class MemoryStorage : FriendsStorage {
    val values = ConcurrentHashMap<String, String>()

    override suspend fun read(key: String): String? = values[key]

    override suspend fun write(
        key: String,
        value: String,
    ) {
        values[key] = value
    }
}

/**
 * Two (sometimes three) devices, each with its own key and storage, talking through a relay on
 * localhost — the whole path a real friend request and invite takes, minus the public internet.
 */
class FriendsSessionTest {
    private val relay = TestRelay().also { it.start() }
    private val sessions = mutableListOf<FriendsSession>()

    @AfterTest
    fun tearDown() {
        sessions.forEach { it.release() }
        relay.stop()
    }

    private fun device(
        storage: MemoryStorage = MemoryStorage(),
        clock: () -> Long = RelayPool::nowSeconds,
    ) = FriendsSession(storage, listOf(relay.url), clock = clock).also(sessions::add)

    private suspend fun FriendsSession.named(name: String): FriendsSession {
        setMyName(name)
        ensureIdentity()
        state.first { it.relaysConnected == 1 }
        return this
    }

    private val FriendsSession.key get() = state.value.publicKey!!
    private val FriendsSession.link get() = state.value.link!!

    @Test
    fun oneScanMakesFriendsOnBothSidesAndAnInviteArrives() =
        runBlocking {
            withTimeout(30.seconds) {
                val bobStorage = MemoryStorage()
                val alice = device().named("Alice")
                val bob = device(bobStorage).named("Bob Å")

                // Alice scans Bob's code.
                val added = assertIs<AddResult.Added>(alice.addFriend(bob.link))
                assertEquals("Bob Å", added.friend.name)
                assertFalse(added.friend.confirmed)
                assertTrue(added.delivered)

                // Bob sees a request from Alice, by name, and accepts it.
                val request = bob.state.first { it.requests.isNotEmpty() }.requests.single()
                assertEquals(alice.key, request.publicKey)
                assertEquals("Alice", request.name)
                bob.acceptRequest(alice.key)
                assertEquals(listOf(FriendEntry(alice.key, "Alice", confirmed = true, announced = true)), bob.state.value.friends)

                // Bob's acceptance confirms him on Alice's side.
                alice.state.first { s -> s.friends.single().confirmed }

                // Alice invites Bob into a room.
                assertEquals(setOf(bob.key), alice.invite(listOf(bob.key), "ABC123"))
                val invite = bob.state.first { it.invites.isNotEmpty() }.invites.single()
                assertEquals("ABC123", invite.roomCode)
                assertEquals(alice.key, invite.publicKey)

                // Dealt with means dealt with, across a restart too.
                bob.dismissInvite(invite.id)
                assertTrue(bob.state.value.invites.isEmpty())
                bob.release()
                val bobAgain = device(bobStorage)
                bobAgain.start()
                bobAgain.state.first { it.relaysConnected == 1 }
                assertEquals(listOf("Alice"), bobAgain.state.value.friends.map { it.name })
                assertNull(withTimeoutOrNull(700.milliseconds) { bobAgain.state.first { it.invites.isNotEmpty() || it.requests.isNotEmpty() } })
            }
        }

    @Test
    fun strangersCanAskButNotInvite() =
        runBlocking {
            withTimeout(30.seconds) {
                val bobStorage = MemoryStorage()
                val bob = device(bobStorage).named("Bob")
                val carol = device().named("Carol")

                // Carol adds Bob; Bob has not added her, so her invite is not shown.
                carol.addFriend(bob.link)
                bob.state.first { it.requests.isNotEmpty() }
                carol.invite(listOf(bob.key), "ROOM42")
                assertNull(withTimeoutOrNull(700.milliseconds) { bob.state.first { it.invites.isNotEmpty() } })

                // A declined request stays declined after a restart.
                bob.declineRequest(carol.key)
                bob.release()
                val bobAgain = device(bobStorage)
                bobAgain.start()
                // Bob has nobody on his list, so the relays wait until the Friends page asks.
                assertNull(withTimeoutOrNull(500.milliseconds) { bobAgain.state.first { it.relaysConnected > 0 } })
                bobAgain.ensureIdentity()
                bobAgain.state.first { it.relaysConnected == 1 }
                assertNull(withTimeoutOrNull(700.milliseconds) { bobAgain.state.first { it.requests.isNotEmpty() } })
            }
        }

    @Test
    fun theRelaysAreLeftAloneInTheBackground() =
        runBlocking {
            withTimeout(30.seconds) {
                val alice = device().named("Alice")
                val bob = device().named("Bob")
                alice.addFriend(bob.link)
                bob.state.first { it.requests.isNotEmpty() }
                bob.acceptRequest(alice.key)
                // In the background: no sockets, and a message sent meanwhile waits on the relay.
                bob.setForeground(false)
                bob.state.first { it.relaysConnected == 0 }
                alice.invite(listOf(bob.key), "ROOM77")
                assertNull(withTimeoutOrNull(700.milliseconds) { bob.state.first { it.invites.isNotEmpty() } })
                // Back on screen: connected again, and the invite arrives.
                bob.setForeground(true)
                assertEquals("ROOM77", bob.state.first { it.invites.isNotEmpty() }.invites.first().roomCode)
            }
        }

    @Test
    fun anOldInviteIsIgnored() =
        runBlocking {
            withTimeout(30.seconds) {
                val alice = device(clock = { RelayPool.nowSeconds() - 31.minutes.inWholeSeconds }).named("Alice")
                val bob = device().named("Bob")
                alice.addFriend(bob.link)
                bob.addFriend(alice.link)
                alice.invite(listOf(bob.key), "LATE01")
                assertNull(withTimeoutOrNull(700.milliseconds) { bob.state.first { it.invites.isNotEmpty() } })
            }
        }

    @Test
    fun aMessageThatDoesNotDecryptIsDropped() =
        runBlocking {
            withTimeout(30.seconds) {
                val bob = device().named("Bob")
                val mallory = NostrKeys.generate()
                val stranger = NostrKeys.generate()
                // Signed by Mallory, addressed to Bob, but encrypted to someone else.
                val body =
                    buildJsonObject {
                        put("v", 1)
                        put("t", "friend")
                        put("name", "Mallory")
                    }
                val now = RelayPool.nowSeconds()
                val event =
                    NostrEvent.create(
                        mallory,
                        now,
                        FriendsSession.KIND,
                        listOf(listOf("d", "simpmusic:friend:${bob.key}"), listOf("p", bob.key)),
                        Nip44.encrypt(body.toString(), mallory.conversationKeyWith(stranger.publicKeyHex)),
                    )
                val pool = RelayPool(listOf(relay.url)).apply { start() }
                try {
                    assertEquals(1, pool.publish(event).accepted)
                } finally {
                    pool.release()
                }
                assertNull(withTimeoutOrNull(700.milliseconds) { bob.state.first { it.requests.isNotEmpty() } })
            }
        }

    @Test
    fun friendCodesParse() =
        runBlocking {
            val session = device()
            val key = NostrKeys.generate().publicKeyHex
            val npub = Nip19.npub(key)
            assertEquals(key to "Zoë & co", session.parseFriendCode(FriendsSession.friendLink(key, "Zoë & co")))
            assertEquals(key to null, session.parseFriendCode(FriendsSession.friendLink(key, "")))
            assertEquals(key to null, session.parseFriendCode(npub))
            assertEquals(key to "Ann", session.parseFriendCode("https://simpmusic.org/app/friend?npub=$npub&name=Ann"))
            assertEquals(key to null, session.parseFriendCode("nostr:$npub"))
            assertNull(session.parseFriendCode("simpmusic://listen-together?code=ABC123"))
            assertNull(session.parseFriendCode("hello"))
            assertIs<AddResult.Invalid>(session.addFriend("hello"))
            session.ensureIdentity()
            assertIs<AddResult.Self>(session.addFriend(session.link))
            assertNotNull(session.state.value.link)
            Unit
        }
}
