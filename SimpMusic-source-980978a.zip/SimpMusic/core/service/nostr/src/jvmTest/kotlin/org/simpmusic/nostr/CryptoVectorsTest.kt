package org.simpmusic.nostr

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

private fun resource(name: String): String =
    requireNotNull(CryptoVectorsTest::class.java.classLoader.getResource(name)) { "missing $name" }.readText()

private fun String.hex(): ByteArray = requireNotNull(hexToBytesOrNull()) { "bad hex $this" }

private val JsonObject.text get() = { key: String -> this[key]!!.jsonPrimitive.content }

class CryptoVectorsTest {
    /** bitcoin/bips bip-0340/test-vectors.csv, every row. */
    @Test
    fun bip340OfficialVectors() {
        val rows = resource("bip340.csv").lines().drop(1).filter { it.isNotBlank() }
        assertEquals(19, rows.size)
        for (row in rows) {
            val c = row.split(',')
            val (index, secret, public, aux, message, signature, result) = c
            val expected = result == "TRUE"
            if (secret.isNotEmpty()) {
                assertEquals(public.lowercase(), Secp256k1.publicKey(secret.hex()).toHex(), "pubkey #$index")
                assertEquals(signature.lowercase(), Secp256k1.signSchnorr(message.hex(), secret.hex(), aux.hex()).toHex(), "sign #$index")
            }
            assertEquals(expected, Secp256k1.verifySchnorr(message.hex(), public.hex(), signature.hex()), "verify #$index (${c.getOrNull(7)})")
        }
    }

    private operator fun <T> List<T>.component6() = this[5]

    private operator fun <T> List<T>.component7() = this[6]

    private val nip44 = Json.parseToJsonElement(resource("nip44.vectors.json")).jsonObject["v2"]!!.jsonObject
    private val valid = nip44["valid"]!!.jsonObject
    private val invalid = nip44["invalid"]!!.jsonObject

    @Test
    fun nip44VectorFileIsTheOfficialOne() {
        assertEquals("269ed0f69e4c192512cc779e78c555090cebc7c785b609e338a62afc3ce25040", sha256(resource("nip44.vectors.json").encodeToByteArray()).toHex())
    }

    @Test
    fun nip44ConversationKeys() {
        for (v in valid["get_conversation_key"]!!.jsonArray.map { it.jsonObject }) {
            val t = v.text
            assertEquals(t("conversation_key"), Nip44.conversationKey(t("sec1").hex(), t("pub2").hex()).toHex())
        }
        for (v in invalid["get_conversation_key"]!!.jsonArray.map { it.jsonObject }) {
            val t = v.text
            assertFailsWith<IllegalArgumentException>(t("note")) { Nip44.conversationKey(t("sec1").hex(), t("pub2").hex()) }
        }
    }

    @Test
    fun nip44MessageKeys() {
        val block = valid["get_message_keys"]!!.jsonObject
        val conversationKey = block["conversation_key"]!!.jsonPrimitive.content.hex()
        for (k in block["keys"]!!.jsonArray.map { it.jsonObject }) {
            val t = k.text
            val keys = Nip44.messageKeys(conversationKey, t("nonce").hex())
            assertEquals(t("chacha_key"), keys.chachaKey.toHex())
            assertEquals(t("chacha_nonce"), keys.chachaNonce.toHex())
            assertEquals(t("hmac_key"), keys.hmacKey.toHex())
        }
    }

    @Test
    fun nip44PaddedLengths() {
        for (pair in valid["calc_padded_len"]!!.jsonArray.map { it.jsonArray }) {
            assertEquals(pair[1].jsonPrimitive.int, Nip44.calcPaddedLen(pair[0].jsonPrimitive.int), "len ${pair[0]}")
        }
    }

    @Test
    fun nip44EncryptDecrypt() {
        for (v in valid["encrypt_decrypt"]!!.jsonArray.map { it.jsonObject }) {
            val t = v.text
            val key = Nip44.conversationKey(t("sec1").hex(), Secp256k1.publicKey(t("sec2").hex()))
            assertEquals(t("conversation_key"), key.toHex())
            // Symmetric: the other side derives the same key.
            assertEquals(t("conversation_key"), Nip44.conversationKey(t("sec2").hex(), Secp256k1.publicKey(t("sec1").hex())).toHex())
            assertEquals(t("payload"), Nip44.encrypt(t("plaintext"), key, t("nonce").hex()))
            assertEquals(t("plaintext"), Nip44.decrypt(t("payload"), key))
        }
    }

    @Test
    fun nip44LongMessages() {
        for (v in valid["encrypt_decrypt_long_msg"]!!.jsonArray.map { it.jsonObject }) {
            val t = v.text
            val plaintext = t("pattern").repeat(v["repeat"]!!.jsonPrimitive.int)
            assertEquals(t("plaintext_sha256"), sha256(plaintext.encodeToByteArray()).toHex())
            val payload = Nip44.encrypt(plaintext, t("conversation_key").hex(), t("nonce").hex())
            assertEquals(t("payload_sha256"), sha256(payload.encodeToByteArray()).toHex())
            assertEquals(plaintext, Nip44.decrypt(payload, t("conversation_key").hex()))
        }
    }

    @Test
    fun nip44RejectsBadInput() {
        val key = ByteArray(32) { 1 }
        for (length in invalid["encrypt_msg_lengths"]!!.jsonArray.map { it.jsonPrimitive.int }) {
            assertFailsWith<Nip44Exception>("length $length") { Nip44.encrypt("a".repeat(length), key) }
        }
        for (v in invalid["decrypt"]!!.jsonArray.map { it.jsonObject }) {
            val t = v.text
            assertFailsWith<Nip44Exception>(t("note")) { Nip44.decrypt(t("payload"), t("conversation_key").hex()) }
        }
    }

    /** RFC 8439 section 2.4.2. */
    @Test
    fun chacha20Rfc8439() {
        val key = (0 until 32).map { it.toByte() }.toByteArray()
        val nonce = "000000000000004a00000000".hex()
        val plaintext =
            "Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it."
        val expected =
            "6e2e359a2568f98041ba0728dd0d6981e97e7aec1d4360c20a27afccfd9fae0bf91b65c5524733ab8f593dabcd62b3571639d624e65152ab8f530c359f0861d807ca0dbf500d6a6156a38e088a22b65e52bc514d16ccf806818ce91ab77937365af90bbf74a35be6b40b8eedf2785e42874d"
        assertEquals(expected, ChaCha20.xor(key, nonce, plaintext.encodeToByteArray(), initialCounter = 1).toHex())
    }

    /** NIP-19's own example. */
    @Test
    fun npubRoundTrip() {
        val hex = "3bf0c63fcb93463407af97a5e5ee64fa883d107ef9e558472c4eb9aaaefa459d"
        val npub = "npub180cvv07tjdrrgpa0j7j7tmnyl2yr6yr7l8j4s3evf6u64th6gkwsyjh6w6"
        assertEquals(npub, Nip19.npub(hex))
        assertEquals(hex, Nip19.decodeNpub(npub))
        assertEquals(hex, Nip19.decodeNpub(npub.uppercase()))
        assertNull(Nip19.decodeNpub(npub.dropLast(1) + "7"), "bad checksum")
        assertNull(Nip19.decodeNpub("nsec" + npub.drop(4)), "wrong prefix")
        assertNull(Nip19.decodeNpub("not a key"))
    }

    /** Signed by other clients (go-nostr's own fixtures), so ids and signatures are not just self-consistent. */
    @Test
    fun realEventsVerify() {
        val events = resource("real_events.jsonl").lines().filter { it.isNotBlank() }
        assertEquals(2, events.size)
        for (line in events) {
            val event = assertNotNull(NostrEvent.fromJson(Json.parseToJsonElement(line).jsonObject))
            assertTrue(event.isValid(), "event ${event.id}")
            assertFalse(event.copy(content = event.content + " ").isValid(), "tampered content")
            assertFalse(event.copy(createdAt = event.createdAt + 1).isValid(), "tampered time")
        }
    }

    @Test
    fun ownEventsVerifyAndSurviveJson() {
        val keys = NostrKeys.generate()
        val event =
            NostrEvent.create(
                keys,
                createdAt = 1_700_000_000,
                kind = 30078,
                tags = listOf(listOf("d", "x"), listOf("p", keys.publicKeyHex)),
                content = "line\nbreak \"quoted\" \\ tab\t \u0001 ünïcödé",
            )
        assertTrue(event.isValid())
        val parsed = assertNotNull(NostrEvent.fromJson(Json.parseToJsonElement(event.toJson().toString()).jsonObject))
        assertEquals(event, parsed)
        assertTrue(parsed.isValid())
        assertFalse(event.copy(pubkey = NostrKeys.generate().publicKeyHex).isValid(), "someone else's key")
        assertEquals(keys.publicKeyHex, NostrKeys.fromSecretKeyHex(keys.secretKeyHex())!!.publicKeyHex)
    }

    @Test
    fun filtersMatchLikeARelay() {
        val keys = NostrKeys.generate()
        val event = NostrEvent.create(keys, 100, 30078, listOf(listOf("p", "abc")), "")
        assertTrue(NostrFilter(kinds = listOf(30078), tags = mapOf('p' to listOf("abc"))).matches(event))
        assertFalse(NostrFilter(kinds = listOf(1)).matches(event))
        assertFalse(NostrFilter(tags = mapOf('p' to listOf("other"))).matches(event))
        assertFalse(NostrFilter(since = 101).matches(event))
        val roundTrip = NostrFilter.fromJson(NostrFilter(kinds = listOf(1), tags = mapOf('p' to listOf("a")), since = 5).toJson())
        assertEquals(NostrFilter(kinds = listOf(1), tags = mapOf('p' to listOf("a")), since = 5), roundTrip)
    }
}
