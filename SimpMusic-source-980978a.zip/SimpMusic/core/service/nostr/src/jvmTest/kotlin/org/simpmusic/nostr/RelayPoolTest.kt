package org.simpmusic.nostr

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.test.AfterTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

class RelayPoolTest {
    private val relays = mutableListOf<TestRelay>()
    private val pools = mutableListOf<RelayPool>()

    @AfterTest
    fun tearDown() {
        pools.forEach { it.release() }
        relays.forEach { it.stop() }
    }

    private fun relay(port: Int = TestRelay.freePort()) = TestRelay(port).also { it.start() }.also(relays::add)

    private fun pool(vararg relay: TestRelay) = RelayPool(relay.map { it.url }).also(pools::add)

    private fun inbox(
        scope: CoroutineScope,
        pool: RelayPool,
    ): Channel<NostrEvent> {
        val channel = Channel<NostrEvent>(Channel.UNLIMITED)
        scope.launch(start = CoroutineStart.UNDISPATCHED) { pool.events.collect { channel.send(it) } }
        return channel
    }

    private fun note(
        from: NostrKeys,
        to: NostrKeys,
        content: String = "hi",
    ) = NostrEvent.create(from, RelayPool.nowSeconds(), 30078, listOf(listOf("d", "test:${to.publicKeyHex}"), listOf("p", to.publicKeyHex)), content)

    private fun inboxFilter(keys: NostrKeys) = listOf(NostrFilter(kinds = listOf(30078), tags = mapOf('p' to listOf(keys.publicKeyHex))))

    @Test
    fun anEventReachesItsRecipientLive() =
        runBlocking {
            withTimeout(20.seconds) {
                val relay = relay()
                val alice = NostrKeys.generate()
                val bob = NostrKeys.generate()
                val sender = pool(relay).apply { start() }
                val receiver = pool(relay).apply { subscribe("in", inboxFilter(bob)) }
                val received = inbox(this, receiver)
                receiver.start()
                receiver.connectedCount.first { it == 1 }
                while (relay.subscriptionCount < 1) delay(20)

                val event = note(alice, bob)
                val result = sender.publish(event)
                assertEquals(PublishResult(accepted = 1, attempted = 1), result)
                assertEquals(event, received.receive())
                coroutineContext.cancelChildren()
            }
        }

    @Test
    fun eventsSentWhileOfflineArriveOnConnect() =
        runBlocking {
            withTimeout(20.seconds) {
                val relay = relay()
                val alice = NostrKeys.generate()
                val bob = NostrKeys.generate()
                val event = note(alice, bob)
                assertEquals(1, pool(relay).apply { start() }.publish(event).accepted)

                val receiver = pool(relay).apply { subscribe("in", inboxFilter(bob)) }
                val received = inbox(this, receiver)
                receiver.start()
                assertEquals(event, received.receive())
                coroutineContext.cancelChildren()
            }
        }

    @Test
    fun forgedEventsAreDroppedAndOthersStillArrive() =
        runBlocking {
            withTimeout(20.seconds) {
                val relay = relay()
                val alice = NostrKeys.generate()
                val bob = NostrKeys.generate()
                val receiver = pool(relay).apply { subscribe("in", inboxFilter(bob)) }
                val received = inbox(this, receiver)
                receiver.start()
                while (relay.subscriptionCount < 1) delay(20)

                val real = note(alice, bob, "real")
                val forged = real.copy(content = "forged")
                relay.inject(forged.toJson())
                relay.inject(real.copy(sig = "00".repeat(64)).toJson())
                pool(relay).apply { start() }.publish(real)
                assertEquals(real, received.receive())
                assertNull(withTimeoutOrNull(500.milliseconds) { received.receive() })
                coroutineContext.cancelChildren()
            }
        }

    @Test
    fun anEventOnTwoRelaysArrivesOnce() =
        runBlocking {
            withTimeout(20.seconds) {
                val one = relay()
                val two = relay()
                val alice = NostrKeys.generate()
                val bob = NostrKeys.generate()
                val receiver = pool(one, two).apply { subscribe("in", inboxFilter(bob)) }
                val received = inbox(this, receiver)
                receiver.start()
                receiver.connectedCount.first { it == 2 }

                val event = note(alice, bob)
                val sender = pool(one, two).apply { start() }
                sender.connectedCount.first { it == 2 }
                assertEquals(2, sender.publish(event).accepted)
                assertEquals(event, received.receive())
                assertNull(withTimeoutOrNull(700.milliseconds) { received.receive() })
                coroutineContext.cancelChildren()
            }
        }

    @Test
    fun aRejectionIsReported() =
        runBlocking {
            withTimeout(20.seconds) {
                val relay = relay().apply { rejectKinds = setOf(30078) }
                val result = pool(relay).apply { start() }.publish(note(NostrKeys.generate(), NostrKeys.generate()))
                assertEquals(0, result.accepted)
                assertEquals(1, result.attempted)
                assertTrue(result.rejections.single().contains("blocked"), result.rejections.toString())
            }
        }

    @Test
    fun publishingWithNoRelayGivesUp() =
        runBlocking {
            val closed = TestRelay()
            val result = pool(closed).apply { start() }.publish(note(NostrKeys.generate(), NostrKeys.generate()), timeout = 1.seconds)
            assertEquals(PublishResult(0, 0), result)
        }

    @Test
    fun aRestartedRelayGetsTheSubscriptionAgain() =
        runBlocking {
            withTimeout(30.seconds) {
                val port = TestRelay.freePort()
                val relay = relay(port)
                val alice = NostrKeys.generate()
                val bob = NostrKeys.generate()
                val receiver = pool(relay).apply { subscribe("in", inboxFilter(bob)) }
                val received = inbox(this, receiver)
                receiver.start()
                receiver.connectedCount.first { it == 1 }

                relay.stop()
                receiver.connectedCount.first { it == 0 }
                val restarted = relay(port)
                receiver.connectedCount.first { it == 1 }
                while (restarted.subscriptionCount < 1) delay(20)

                val event = note(alice, bob)
                assertEquals(1, pool(restarted).apply { start() }.publish(event).accepted)
                assertEquals(event, received.receive())
                coroutineContext.cancelChildren()
            }
        }
}
