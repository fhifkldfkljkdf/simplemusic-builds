package org.simpmusic.nostr

import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.engine.EmbeddedServer
import io.ktor.server.engine.embeddedServer
import io.ktor.server.routing.routing
import io.ktor.server.websocket.DefaultWebSocketServerSession
import io.ktor.server.websocket.WebSockets
import io.ktor.server.websocket.webSocket
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import java.net.ServerSocket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * A NIP-01 relay small enough to read in one sitting: stores events (replacing addressable ones),
 * answers REQ with stored matches then EOSE, pushes new matches live, and says OK or not to every
 * EVENT. It checks ids and signatures the way public relays do, which is what makes the tests below
 * worth something: an event our client builds wrongly is refused here as it would be there.
 */
internal class TestRelay(
    val port: Int = freePort(),
) {
    val url = "ws://127.0.0.1:$port"
    val stored = CopyOnWriteArrayList<NostrEvent>()
    var rejectKinds: Set<Int> = emptySet()
    private val clients = ConcurrentHashMap<DefaultWebSocketServerSession, ConcurrentHashMap<String, List<NostrFilter>>>()
    private var server: EmbeddedServer<*, *>? = null

    fun start() {
        server =
            embeddedServer(CIO, port = port, host = "127.0.0.1") {
                install(WebSockets)
                routing {
                    webSocket("/") {
                        val subs = ConcurrentHashMap<String, List<NostrFilter>>()
                        clients[this] = subs
                        try {
                            for (frame in incoming) {
                                if (frame is Frame.Text) handle(this, subs, frame.readText())
                            }
                        } finally {
                            clients.remove(this)
                        }
                    }
                }
            }.start(wait = false)
    }

    fun stop() {
        server?.stop(0, 500)
        server = null
    }

    val subscriptionCount: Int get() = clients.values.sumOf { subs -> subs.keys.count { it != "keepalive" } }

    /** Pushes [event] to every open subscription, unchecked — the way a hostile relay would. */
    suspend fun inject(event: JsonObject) {
        for ((session, subs) in clients) {
            for (id in subs.keys) session.sendJson(JsonArray(listOf(JsonPrimitive("EVENT"), JsonPrimitive(id), event)))
        }
    }

    private suspend fun handle(
        session: DefaultWebSocketServerSession,
        subs: MutableMap<String, List<NostrFilter>>,
        text: String,
    ) {
        val message = Json.parseToJsonElement(text).jsonArray
        when (message[0].jsonPrimitive.content) {
            "EVENT" -> {
                val event = NostrEvent.fromJson(message[1] as JsonObject)
                val id = event?.id ?: ""
                val verdict =
                    when {
                        event == null || !event.isValid() -> "invalid: bad id or signature"
                        event.kind in rejectKinds -> "blocked: kind not accepted"
                        else -> null
                    }
                session.sendJson(JsonArray(listOf(JsonPrimitive("OK"), JsonPrimitive(id), JsonPrimitive(verdict == null), JsonPrimitive(verdict ?: ""))))
                if (event == null || verdict != null) return
                if (event.kind in 30000..39999) {
                    stored.removeIf { it.pubkey == event.pubkey && it.kind == event.kind && it.tagValue("d") == event.tagValue("d") }
                }
                stored += event
                for ((other, otherSubs) in clients) {
                    for ((subId, filters) in otherSubs) {
                        if (filters.any { it.matches(event) }) other.sendJson(eventMessage(subId, event))
                    }
                }
            }

            "REQ" -> {
                val subId = message[1].jsonPrimitive.content
                val filters = message.drop(2).map { NostrFilter.fromJson(it as JsonObject) }
                subs[subId] = filters
                stored.filter { e -> filters.any { it.matches(e) } }.forEach { session.sendJson(eventMessage(subId, it)) }
                session.sendJson(JsonArray(listOf(JsonPrimitive("EOSE"), JsonPrimitive(subId))))
            }

            "CLOSE" -> subs.remove(message[1].jsonPrimitive.content)
        }
    }

    private fun eventMessage(
        subId: String,
        event: NostrEvent,
    ) = JsonArray(listOf(JsonPrimitive("EVENT"), JsonPrimitive(subId), event.toJson()))

    private suspend fun DefaultWebSocketServerSession.sendJson(json: JsonElement) = send(Frame.Text(json.toString()))

    companion object {
        fun freePort(): Int = ServerSocket(0).use { it.localPort }
    }
}
