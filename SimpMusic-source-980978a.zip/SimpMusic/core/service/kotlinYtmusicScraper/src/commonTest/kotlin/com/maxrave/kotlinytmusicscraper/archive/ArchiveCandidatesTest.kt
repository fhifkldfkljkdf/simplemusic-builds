package com.maxrave.kotlinytmusicscraper.archive

import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher
import kotlinx.serialization.json.Json
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** Shapes taken from real archive.org answers on 2026-10-04, trimmed to the fields read. */
class ArchiveCandidatesTest {
    private fun json(text: String) = Json.parseToJsonElement(text)

    private val queenItem =
        json(
            """
            {"metadata":{"title":"Bohemian Rhapsody","creator":"Queen","collection":["opensource_audio"]},
             "files":[
              {"name":"1)bohemian rhapsody-queen.flac","format":"Flac","length":"358.46","size":"35790113"},
              {"name":"2) i'm in love with my car-queen.flac","format":"Flac","length":"190.57","size":"22599890"},
              {"name":"1)bohemian rhapsody-queen.mp3","format":"VBR MP3","length":"358.46"}
             ]}
            """,
        )

    @Test
    fun picksTheSongsFileOutOfAnItem() {
        val candidates = ArchiveCandidates.candidates("bohemian-rhapsody-by-queen", queenItem)
        assertEquals(2, candidates.size)
        val picked = RecordingMatcher.pick(candidates, "Bohemian Rhapsody", listOf("Queen"), 355)
        assertEquals("1)bohemian rhapsody-queen.flac", picked?.name)
        assertEquals(798_752, picked?.bitrateBps)
    }

    @Test
    fun concertTapesAreNotTheRelease() {
        // A Live Music Archive tape, as such items read: its own mediatype, taper fields, a show date.
        val tape =
            json(
                """
                {"metadata":{"title":"Grateful Dead Live at Barton Hall on 1977-05-08","creator":"Grateful Dead",
                  "mediatype":"etree","collection":["GratefulDead","etree"],"venue":"Barton Hall",
                  "source":"SBD > Reel > DAT","taper":"Betty Cantor-Jackson"},
                 "files":[{"name":"gd77-05-08d2t01.flac","title":"Scarlet Begonias","format":"Flac","length":"578.2","size":"60000000"}]}
                """,
            )
        assertEquals(emptyList(), ArchiveCandidates.candidates("gd1977-05-08", tape))
        // Filed as plain audio, but a taper still signed it.
        val signed =
            json(
                """
                {"metadata":{"title":"Scarlet Begonias","creator":"Grateful Dead","mediatype":"audio","lineage":"Mics > DAT > FLAC"},
                 "files":[{"name":"Scarlet Begonias.flac","format":"Flac","length":"578.2","size":"60000000"}]}
                """,
            )
        assertEquals(emptyList(), ArchiveCandidates.candidates("scarlet-begonias", signed))
        // A bootleg filed under a show date, no taper fields at all.
        val dated =
            json(
                """
                {"metadata":{"title":"Nirvana - 1992-06-27 Ruissalo, Turku, Finland","creator":"Nirvana","mediatype":"audio"},
                 "files":[{"name":"05 Smells Like Teen Spirit.flac","format":"Flac","length":"301.0","size":"30000000"}]}
                """,
            )
        assertEquals(emptyList(), ArchiveCandidates.candidates("Nirvana_1992-06-27", dated))
        // Tagged as a concert: the song's own title passes, the item's tags do not.
        val tagged =
            json(
                """
                {"metadata":{"title":"Queen at Wembley","creator":"Queen","subject":"queen;concert;1986"},
                 "files":[{"name":"Bohemian Rhapsody.flac","format":"Flac","length":"358.46","size":"35790113"}]}
                """,
            )
        val candidates = ArchiveCandidates.candidates("queen-wembley", tagged)
        assertNull(RecordingMatcher.pick(candidates, "Bohemian Rhapsody", listOf("Queen"), 355))
    }

    @Test
    fun recordTransfersAreNotTheDigitalRelease() {
        val vinyl =
            json(
                """
                {"metadata":{"title":"A Night at the Opera","creator":"Queen","source":"Vinyl LP, Technics SL-1200, 24/96"},
                 "files":[{"name":"11 Bohemian Rhapsody.flac","format":"Flac","length":"358.46","size":"35790113"}]}
                """,
            )
        assertNull(RecordingMatcher.pick(ArchiveCandidates.candidates("opera-vinyl", vinyl), "Bohemian Rhapsody", listOf("Queen"), 355))
        val seventyEight =
            json(
                """
                {"metadata":{"title":"In The Mood","creator":"Glenn Miller","collection":["78rpm","georgeblood"]},
                 "files":[{"name":"In The Mood.flac","format":"Flac","length":"215.0","size":"20000000"}]}
                """,
            )
        assertEquals(emptyList(), ArchiveCandidates.candidates("78_in-the-mood", seventyEight))
    }

    @Test
    fun aSessionTakeIsAnotherRecording() {
        val item =
            json(
                """
                {"metadata":{"title":"The BBC Sessions","creator":"Queen"},
                 "files":[{"name":"Keep Yourself Alive.flac","format":"Flac","length":"228.0","size":"25000000"}]}
                """,
            )
        assertNull(RecordingMatcher.pick(ArchiveCandidates.candidates("queen-bbc", item), "Keep Yourself Alive", listOf("Queen"), 228))
    }

    @Test
    fun youTubeRipsAreNotLossless() {
        val ripItem =
            json(
                """
                {"metadata":{"title":"Eagles - Hotel California (Official Audio)","creator":"Eagles"},
                 "files":[{"name":"Hotel California.flac","format":"Flac","length":"391.37","size":"41000000"}]}
                """,
            )
        assertEquals(emptyList(), ArchiveCandidates.candidates("hotel-california-official-audio", ripItem), "the item says where it came from")
        val ripFile =
            json(
                """
                {"metadata":{"title":"Queen collection","creator":"Queen"},
                 "files":[
                  {"name":"y2mate.com - Queen Bohemian Rhapsody.flac","format":"Flac","length":"358.46","size":"35790113"},
                  {"name":"02 Bohemian Rhapsody.flac","format":"Flac","length":"358.46","size":"35790113"}
                 ]}
                """,
            )
        assertEquals(listOf("02 Bohemian Rhapsody.flac"), ArchiveCandidates.candidates("queen-collection", ripFile).map { it.item.name })
    }

    @Test
    fun aSingleFileItemIsTitledAfterTheItem() {
        val item =
            json(
                """
                {"metadata":{"title":"Billie Jean (Single Version) - 24bit / 176.4kHz","creator":"Michael Jackson"},
                 "files":[{"name":"Billie Jean (Single Version).flac","format":"Flac","length":"293.8","size":"223845176"}]}
                """,
            )
        val picked = RecordingMatcher.pick(ArchiveCandidates.candidates("billie-jean-single-version", item), "Billie Jean", listOf("Michael Jackson"), 294)
        assertEquals("Billie Jean (Single Version).flac", picked?.name)
    }

    @Test
    fun aDemoIsRefusedEvenWhenTheFileTitleIsClean() {
        val item =
            json(
                """
                {"metadata":{"title":"Nirvana- \"Smells like teen spirit\" Boombox Demo Full Cut","creator":"Nirvana"},
                 "files":[{"name":"inbound.flac","format":"Flac","title":"Smells Like Teen Spirit","creator":"Nirvana","length":"301.2"}]}
                """,
            )
        assertNull(RecordingMatcher.pick(ArchiveCandidates.candidates("inbound", item), "Smells Like Teen Spirit", listOf("Nirvana"), 301))
    }

    @Test
    fun aLiveAlbumIsRefused() {
        val item =
            json(
                """
                {"metadata":{"title":"Queen Live at Wembley 1986","creator":"Queen"},
                 "files":[{"name":"05 Bohemian Rhapsody.flac","format":"Flac","length":"355.0"}]}
                """,
            )
        assertNull(RecordingMatcher.pick(ArchiveCandidates.candidates("wembley", item), "Bohemian Rhapsody", listOf("Queen"), 355))
    }

    @Test
    fun stemsAreNeverCandidates() {
        val search =
            json(
                """
                {"response":{"numFound":2,"docs":[
                  {"identifier":"BRMultitrack","collection":["stems","folksoundomy"]},
                  {"identifier":"bohemian-rhapsody-by-queen","collection":"opensource_audio"}]}}
                """,
            )
        assertEquals(listOf("bohemian-rhapsody-by-queen"), ArchiveCandidates.identifiers(search))
        val stemItem = json("""{"metadata":{"title":"x","collection":["stems"]},"files":[{"name":"a.flac","format":"Flac","length":"355"}]}""")
        assertEquals(0, ArchiveCandidates.candidates("BRMultitrack", stemItem).size)
    }

    @Test
    fun lengthsAndFileNamesAreRead() {
        assertEquals(358_460L, ArchiveCandidates.lengthMs("358.46"))
        assertEquals(358_000L, ArchiveCandidates.lengthMs("5:58"))
        assertEquals(3_723_000L, ArchiveCandidates.lengthMs("1:02:03"))
        assertNull(ArchiveCandidates.lengthMs("unknown"))
        assertEquals("Time", ArchiveCandidates.titleFromFileName("Dark Side/03 - Time.flac"))
        assertEquals("bohemian rhapsody-queen", ArchiveCandidates.titleFromFileName("1)bohemian rhapsody-queen.flac"))
        assertEquals("Let It Be", ArchiveCandidates.titleFromFileName("06_Let_It_Be.flac"))
    }

    @Test
    fun pathsAreEncodedSegmentBySegment() {
        assertEquals(
            "billie-jean-single-version/Billie%20Jean%20%28Single%20Version%29.flac",
            InternetArchive.encodePath("billie-jean-single-version/Billie Jean (Single Version).flac"),
        )
        assertEquals("a/b%C3%A9.flac", InternetArchive.encodePath("a/bé.flac"))
    }

    @Test
    fun skipsItemsArchiveOrgWillNotServe() {
        val restricted =
            json(
                """
                {"metadata":{"title":"Night at the Opera","creator":"Queen","access-restricted-item":"true"},
                 "files":[{"name":"01.flac","format":"Flac","length":"358.4","size":"35790113"}]}
                """,
            )
        assertEquals(0, ArchiveCandidates.candidates("restricted", restricted).size)
        val dark =
            json(
                """
                {"is_dark":true,"metadata":{"title":"x","creator":"Queen"},
                 "files":[{"name":"01.flac","format":"Flac","length":"358.4","size":"35790113"}]}
                """,
            )
        assertEquals(0, ArchiveCandidates.candidates("dark", dark).size)
    }

    @Test
    fun onlyRealFlacFilesThatAreNotPrivate() {
        val item =
            json(
                """
                {"metadata":{"title":"Album","creator":"Queen"},
                 "files":[
                  {"name":"01 Song.flac","format":"Flac","length":"200.0","size":"20000000"},
                  {"name":"02 Song.flac","format":"Flac","length":"200.0","size":"20000000","private":"true"},
                  {"name":"album.ffp","format":"Flac FingerPrint"}
                 ]}
                """,
            )
        assertEquals(listOf("01 Song.flac"), ArchiveCandidates.candidates("album", item).map { it.item.name })
    }

    @Test
    fun rankedListsEveryMatchBestFirst() {
        val candidates = ArchiveCandidates.candidates("bohemian-rhapsody-by-queen", queenItem)
        val ranked = RecordingMatcher.ranked(candidates, "Bohemian Rhapsody", listOf("Queen"), 355)
        assertEquals(listOf("1)bohemian rhapsody-queen.flac"), ranked.map { it.name })
        assertEquals(emptyList(), RecordingMatcher.ranked(candidates, "Somebody to Love", listOf("Queen"), 296).map { it.name })
    }

    @Test
    fun highResolutionIsToldApart() {
        val cd = ArchiveFile("a", "a.flac", 355_000, 35_000_000)
        val hiRes = ArchiveFile("b", "b.flac", 293_800, 223_845_176)
        assertEquals(false, cd.isHighResolution)
        assertEquals(true, hiRes.isHighResolution)
        assertEquals(true, cd.copy(flac = FlacInfo(96_000, 2, 24, 0)).isHighResolution)
    }
}
