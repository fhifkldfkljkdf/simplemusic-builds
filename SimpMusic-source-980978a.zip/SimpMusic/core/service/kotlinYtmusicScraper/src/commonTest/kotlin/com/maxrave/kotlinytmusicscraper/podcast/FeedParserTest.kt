package com.maxrave.kotlinytmusicscraper.podcast

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class FeedParserTest {
    // Cut from https://darknetdiaries.com/feedfree.xml (2026-10-11), the episode order kept.
    private val darknet =
        """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss xmlns:atom="http://www.w3.org/2005/Atom" xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd" version="2.0">
        <channel>
        	<title>Darknet Diaries Plus</title>
        	<link>https://darknetdiaries.com/plus</link>
        	<atom:link href="https://darknetdiaries.com/feedfree.xml" rel="self" type="application/rss+xml" />
        	<itunes:author>Jack Rhysider</itunes:author>
        	<itunes:keywords>infosec, security, hacking, privacy</itunes:keywords>
        	<description>This is the ad free and bonus episode feed of Darknet Diaries.</description>
        	<itunes:category text="Technology" />
        	<itunes:category text="Society &amp; Culture"><itunes:category text="Documentary" /></itunes:category>
        	<itunes:image href="https://darknetdiaries.com/imgs/darknet-diaries-plus.jpg" />
        	<item>
        	  <guid isPermaLink="false">prx_7057_31515d19-94aa-45ed-ad93-0dd844309049</guid>
        	  <title>Bonus 12: Sebastien</title>
        	  <pubDate>Tue, 26 May 2026 05:00:00 -0000</pubDate>
        	  <link>https://darknetdiaries.com</link>
        	  <description>
        	    <![CDATA[<p>This is the story of Sebastien Vachon-Desjardins.</p><p>Second &amp; last.</p>]]>
        	  </description>
        	  <enclosure url="https://dovetail.prxu.org/7057/31515d19/darknet-diaries-b12-sebastien.mp3" type="audio/mpeg" length="31010379"/>
        	  <itunes:duration>00:42:13</itunes:duration>
        	</item>
        	<item>
        	  <guid isPermaLink="false">older</guid>
        	  <title>Bonus 11</title>
        	  <pubDate>Tue, 12 May 2026 05:00:00 GMT</pubDate>
        	  <enclosure url="https://example.org/b11.mp3" type="audio/mpeg" length="1"/>
        	  <itunes:duration>2533</itunes:duration>
        	</item>
        </channel>
        </rss>
        """.trimIndent()

    @Test
    fun readsAPodcastFeed() {
        val feed = assertNotNull(FeedParser.parse(darknet))
        assertEquals("Darknet Diaries Plus", feed.title)
        assertEquals("Jack Rhysider", feed.author)
        assertEquals("https://darknetdiaries.com/imgs/darknet-diaries-plus.jpg", feed.imageUrl)
        assertEquals(listOf("Technology", "Society & Culture", "Documentary"), feed.categories)
        assertEquals(listOf("infosec", "security", "hacking", "privacy"), feed.keywords)
        assertEquals(2, feed.episodes.size)
        val newest = feed.episodes.first()
        assertEquals("Bonus 12: Sebastien", newest.title)
        assertEquals("prx_7057_31515d19-94aa-45ed-ad93-0dd844309049", newest.guid)
        assertEquals("https://dovetail.prxu.org/7057/31515d19/darknet-diaries-b12-sebastien.mp3", newest.audioUrl)
        assertEquals(42 * 60 + 13, newest.durationSeconds)
        assertEquals(1779771600000L, newest.publishedAtMs) // 2026-05-26T05:00:00Z
        assertEquals("This is the story of Sebastien Vachon-Desjardins.\nSecond & last.", newest.description)
        assertEquals(2533, feed.episodes[1].durationSeconds)
    }

    @Test
    fun episodesComeNewestFirstWhateverTheFeedOrder() {
        val reversed =
            darknet
                .replace("Bonus 12: Sebastien", "TMP")
                .replace("<title>Bonus 11</title>", "<title>Bonus 12: Sebastien</title>")
                .replace("<title>TMP</title>", "<title>Bonus 11</title>")
                .replace("Tue, 26 May 2026", "Tue, 01 Jan 2026")
        val feed = assertNotNull(FeedParser.parse(reversed))
        assertEquals("Bonus 12: Sebastien", feed.episodes.first().title)
    }

    // Cut from https://www.youtube.com/feeds/videos.xml?channel_id=UCSHZKyawb77ixDdsGog4iWA (2026-10-11).
    private val youTube =
        """
        <?xml version="1.0" encoding="UTF-8"?>
        <feed xmlns:yt="http://www.youtube.com/xml/schemas/2015" xmlns:media="http://search.yahoo.com/mrss/" xmlns="http://www.w3.org/2005/Atom">
         <link rel="self" href="http://www.youtube.com/feeds/videos.xml?channel_id=UCSHZKyawb77ixDdsGog4iWA"/>
         <id>yt:channel:SHZKyawb77ixDdsGog4iWA</id>
         <yt:channelId>SHZKyawb77ixDdsGog4iWA</yt:channelId>
         <title>Lex Fridman</title>
         <link rel="alternate" href="https://www.youtube.com/channel/UCSHZKyawb77ixDdsGog4iWA"/>
         <author><name>Lex Fridman</name><uri>https://www.youtube.com/channel/UCSHZKyawb77ixDdsGog4iWA</uri></author>
         <entry>
          <id>yt:video:s7d2d8FhevU</id>
          <yt:videoId>s7d2d8FhevU</yt:videoId>
          <title>Psychiatry, Freud &amp; Jung | Lex Fridman Podcast #502</title>
          <link rel="alternate" href="https://www.youtube.com/watch?v=s7d2d8FhevU"/>
          <published>2026-09-17T00:34:47+00:00</published>
          <media:group>
           <media:thumbnail url="https://i4.ytimg.com/vi/s7d2d8FhevU/hqdefault.jpg" width="480" height="360"/>
           <media:description>Andrew Scull is a historian of psychiatry.
        Thank you for listening</media:description>
          </media:group>
         </entry>
         <entry>
          <yt:videoId>abcdefghijk</yt:videoId>
          <title>A clip</title>
          <link rel="alternate" href="https://www.youtube.com/shorts/abcdefghijk"/>
          <published>2026-09-18T00:00:00+00:00</published>
         </entry>
        </feed>
        """.trimIndent()

    @Test
    fun readsAYouTubeChannelFeed() {
        val feed = assertNotNull(FeedParser.parse(youTube))
        assertEquals("Lex Fridman", feed.title)
        assertEquals("UCSHZKyawb77ixDdsGog4iWA", feed.youTubeChannelId)
        // The Short is left out.
        val episode = feed.episodes.single()
        assertEquals("s7d2d8FhevU", episode.youTubeVideoId)
        assertNull(episode.audioUrl)
        assertEquals("Psychiatry, Freud & Jung | Lex Fridman Podcast #502", episode.title)
        assertEquals(1789605287000L, episode.publishedAtMs) // 2026-09-17T00:34:47Z
        assertEquals("https://i4.ytimg.com/vi/s7d2d8FhevU/hqdefault.jpg", episode.imageUrl)
        assertEquals(episode.imageUrl, feed.imageUrl)
    }

    @Test
    fun sloppyFeedsStillRead() {
        val sloppy =
            """
            <!DOCTYPE rss [ <!ENTITY nbsp "&#160;"> ]>
            <rss><channel><title>Caf&eacute;&nbsp;Talk</title>
            <item><title>One &amp; two & three</title><description><p>Line<br>break</description>
            <enclosure url='https://x.example/1.m4a' type=audio/x-m4a /></item>
            <item><title>No audio</title></item>
            </channel></rss>
            """.trimIndent()
        val feed = assertNotNull(FeedParser.parse(sloppy))
        assertEquals("Café Talk", feed.title)
        val episode = feed.episodes.single()
        assertEquals("One & two & three", episode.title)
        assertEquals("https://x.example/1.m4a", episode.audioUrl)
        assertEquals("audio/x-m4a", episode.audioType)
        assertEquals("Line\nbreak", episode.description)
    }

    @Test
    fun notAFeedIsNull() {
        assertNull(FeedParser.parse("<html><head><title>x</title></head><body>hi</body></html>"))
        assertNull(FeedParser.parse("not xml at all"))
    }

    @Test
    fun datesAndDurations() {
        assertEquals(0L, FeedParser.parseDate("Thu, 01 Jan 1970 00:00:00 GMT"))
        assertEquals(3_600_000L, FeedParser.parseDate("Thu, 01 Jan 1970 00:00:00 -0100"))
        assertEquals(8 * 3_600_000L, FeedParser.parseDate("1 Jan 70 00:00 PST"))
        assertEquals(0L, FeedParser.parseDate("1970-01-01T00:00:00Z"))
        assertEquals(-7_200_000L, FeedParser.parseDate("1970-01-01T00:00:00+02:00"))
        assertEquals(951_782_400_000L, FeedParser.parseDate("2000-02-29")) // a leap day
        assertNull(FeedParser.parseDate("yesterday"))
        assertEquals(3723, FeedParser.parseDuration("1:02:03"))
        assertEquals(3723, FeedParser.parseDuration("62:03"))
        assertEquals(3723, FeedParser.parseDuration("3723.6"))
        assertNull(FeedParser.parseDuration("about an hour"))
    }

    @Test
    fun aWebPageNamesItsFeed() {
        val page = """<html><head><link rel="alternate" type="application/rss+xml" title="RSS" href="/feed/podcast/"></head></html>"""
        assertEquals("https://example.org/feed/podcast/", PodcastFeeds.feedLinkIn(page, "https://example.org/show/"))
        assertNull(PodcastFeeds.feedLinkIn("<html></html>", "https://example.org/"))
    }

    @Test
    fun youTubeVideoIds() {
        assertEquals("s7d2d8FhevU", FeedParser.youTubeVideoIdOf("https://www.youtube.com/watch?v=s7d2d8FhevU"))
        assertEquals("abcdefghijk", FeedParser.youTubeVideoIdOf("https://www.youtube.com/shorts/abcdefghijk"))
        assertTrue(FeedParser.youTubeVideoIdOf("https://example.org/") == null)
    }
}
