package com.maxrave.kotlinytmusicscraper.pages

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** Byline counts as radio rows state them (the English ones are from a real Queen radio). */
class CountParseTest {
    @Test
    fun englishCounts() {
        assertEquals(2_100_000_000L, NextPage.parseCount("2.1B views"))
        assertEquals(536_000_000L, NextPage.parseCount("536M views"))
        assertEquals(704_000L, NextPage.parseCount("704K likes"))
        assertEquals(164L, NextPage.parseCount("164 likes"))
        assertEquals(1_234_567L, NextPage.parseCount("1,234,567 views"))
    }

    @Test
    fun localisedCounts() {
        assertEquals(536_000_000L, NextPage.parseCount("536 Tr lượt xem"))
        assertEquals(2_100_000_000L, NextPage.parseCount("2,1 Mrd. Aufrufe"))
        assertEquals(12_000L, NextPage.parseCount("12 N lượt thích"))
    }

    @Test
    fun aYearOrAnAlbumIsNotACount() {
        assertNull(NextPage.parseCount("1975"))
        assertNull(NextPage.parseCount("A Night At The Opera"))
    }
}
