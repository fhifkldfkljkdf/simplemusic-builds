package com.maxrave.kotlinytmusicscraper.podcast

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class YouTubeChannelPageTest {
    // The shape of a WEB `browse` answer for a channel's Videos tab (Lex Fridman, 2026-10-12), cut down.
    private val channel =
        """
        {"metadata":{"channelMetadataRenderer":{"title":"Lex Fridman","description":"Lex Fridman Podcast and other videos.",
          "externalId":"UCSHZKyawb77ixDdsGog4iWA","channelUrl":"https://www.youtube.com/channel/UCSHZKyawb77ixDdsGog4iWA",
          "keywords":"\"lex fridman\" podcast AI",
          "avatar":{"thumbnails":[{"url":"https://yt3.googleusercontent.com/avatar=s900"}]}}},
         "contents":{"twoColumnBrowseResultsRenderer":{"tabs":[{"tabRenderer":{"selected":true,"content":{"richGridRenderer":{"contents":[
          {"richItemRenderer":{"content":{"lockupViewModel":{"contentId":"s7d2d8FhevU","contentType":"LOCKUP_CONTENT_TYPE_VIDEO",
            "contentImage":{"thumbnailViewModel":{"overlays":[{"thumbnailBottomOverlayViewModel":{"badges":[{"thumbnailBadgeViewModel":{"text":"3:36:56"}}]}}]}},
            "metadata":{"lockupMetadataViewModel":{"title":{"content":"Psychiatry | Lex Fridman Podcast #502"},
              "metadata":{"contentMetadataViewModel":{"metadataRows":[{"metadataParts":[{"text":{"content":"989K views"}},{"text":{"content":"3 weeks ago"}}]}]}}}}}}}},
          {"richItemRenderer":{"content":{"lockupViewModel":{"contentId":"UPCOMING123","contentType":"LOCKUP_CONTENT_TYPE_VIDEO",
            "metadata":{"lockupMetadataViewModel":{"title":{"content":"Premieres soon"}}}}}}},
          {"continuationItemRenderer":{"continuationEndpoint":{"continuationCommand":{"token":"NEXT","request":"CONTINUATION_REQUEST_TYPE_BROWSE"}}}}
         ]}}}}]}}}
        """.trimIndent()

    @Test
    fun readsAChannelsVideos() {
        val now = 1_800_000_000_000L
        val feed = YouTubeChannelPage.parse(Json.parseToJsonElement(channel).jsonObject, now, null)!!
        assertEquals("Lex Fridman", feed.title)
        assertEquals("UCSHZKyawb77ixDdsGog4iWA", feed.youTubeChannelId)
        assertEquals("https://yt3.googleusercontent.com/avatar=s900", feed.imageUrl)
        assertEquals(listOf("lex fridman", "podcast"), feed.keywords)
        val episode = feed.episodes.single()
        assertEquals("s7d2d8FhevU", episode.youTubeVideoId)
        assertEquals(3 * 3600 + 36 * 60 + 56, episode.durationSeconds)
        assertEquals(now - 21 * 86_400_000L, episode.publishedAtMs)
        assertEquals("https://i.ytimg.com/vi/s7d2d8FhevU/hqdefault.jpg", episode.imageUrl)
        assertNull(episode.audioUrl)
        assertEquals("NEXT", YouTubeChannelPage.continuation(Json.parseToJsonElement(channel)))
    }

    @Test
    fun ages() {
        assertEquals(2 * 86_400_000L, YouTubeChannelPage.ageMs("Streamed 2 days ago"))
        assertEquals(3_600_000L, YouTubeChannelPage.ageMs("1 hour ago"))
        assertNull(YouTubeChannelPage.ageMs("989K views"))
    }
}
