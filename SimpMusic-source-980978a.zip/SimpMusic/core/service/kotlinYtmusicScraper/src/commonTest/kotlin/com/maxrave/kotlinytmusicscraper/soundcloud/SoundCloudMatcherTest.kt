package com.maxrave.kotlinytmusicscraper.soundcloud

import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

class SoundCloudMatcherTest {
    private fun mp3(snipped: Boolean = false) =
        SoundCloudTranscoding(
            url = "https://api-v2.soundcloud.com/media/x/progressive",
            snipped = snipped,
            format = SoundCloudTranscodingFormat(protocol = "progressive", mimeType = "audio/mpeg"),
        )

    private fun hls() =
        SoundCloudTranscoding(
            url = "https://api-v2.soundcloud.com/media/x/hls",
            snipped = false,
            format = SoundCloudTranscodingFormat(protocol = "hls", mimeType = "audio/mpeg"),
        )

    private fun track(
        id: Long,
        title: String,
        seconds: Long,
        user: String,
        policy: String = "MONETIZE",
        publisher: String? = null,
        transcodings: List<SoundCloudTranscoding> = listOf(hls(), mp3(snipped = policy == "SNIP")),
    ) = SoundCloudTrack(
        id = id,
        title = title,
        duration = seconds * 1000,
        policy = policy,
        streamable = true,
        user = SoundCloudUser(user),
        publisherMetadata = publisher?.let { SoundCloudPublisher(it) },
        media = SoundCloudMedia(transcodings),
        trackAuthorization = "auth",
    )

    /** The first ten results SoundCloud gave for "Queen Bohemian Rhapsody" on 2026-10-03. */
    private val bohemianRhapsody =
        listOf(
            track(253166273, "Bohemian Rhapsody", 30, "Queen", policy = "SNIP", publisher = "Queen"),
            track(115417954, "Queen - Bohemian Rhapsody", 352, "rizky.rilos"),
            track(2371717559, "Bohemian Rhapsody", 30, "Queen", policy = "SNIP", publisher = "Queen"),
            track(79703451, "Bohemian Rhapsody - LIVE QUEEN", 320, "Live Queen"),
            track(160332992, "Queen - Bohemian Rhapsody - ReMastered (M. Bazoli Studio Works)", 366, "Matheus Bazoli"),
            track(291350835, "Queen - Bohemian Rhapsody", 373, "Rock Story", publisher = "Various Artists"),
            track(513332091, "Bohemian Rhapsody (Live Aid)", 30, "Queen", policy = "SNIP", publisher = "Queen"),
            track(789649912, "Bohemian Rhapsody - QUEEN (Mama)", 347, "Pop Music Stream", publisher = "Pop Music Stream"),
            track(1727264841, "Queen - Bohemian Rhapsody (Yann Muller Remix)", 173, "Yann Muller", policy = "ALLOW"),
        )

    @Test
    fun picksTheFullLengthUploadOverPreviewsLiveTakesAndRemixes() {
        val picked = SoundCloudMatcher.pick(bohemianRhapsody, "Bohemian Rhapsody", listOf("Queen"), 355)
        assertEquals(115417954, picked?.first?.id)
        assertEquals("progressive", picked?.second?.format?.protocol)
    }

    /** Live search on 2026-10-03 matched this before the artist check was tightened. */
    @Test
    fun aTributeBandIsNotTheArtist() {
        val tribute = track(15192971, "Bohemian Rhapsody", 356, "Killer Queen Band Page")
        assertEquals(
            115417954,
            SoundCloudMatcher.pick(listOf(tribute) + bohemianRhapsody, "Bohemian Rhapsody", listOf("Queen"), 355)?.first?.id,
        )
        assertNull(SoundCloudMatcher.pick(listOf(tribute), "Bohemian Rhapsody", listOf("Queen"), 355))
        val inTitle = track(1, "Killer Queen - Bohemian Rhapsody", 355, "someone")
        assertNull(SoundCloudMatcher.pick(listOf(inTitle), "Bohemian Rhapsody", listOf("Queen"), 355))
    }

    @Test
    fun aPreviewIsNeverPlayedEvenWhenItIsTheOnlyResult() {
        val previews = bohemianRhapsody.filter { it.policy == "SNIP" }
        assertNull(SoundCloudMatcher.pick(previews, "Bohemian Rhapsody", listOf("Queen"), 30))
    }

    @Test
    fun anotherVersionIsRefusedEvenAtTheRightLength() {
        val remix = listOf(track(1, "Blinding Lights (Remix)", 200, "The Weeknd"))
        assertNull(SoundCloudMatcher.pick(remix, "Blinding Lights", listOf("The Weeknd"), 200))
        val sped = listOf(track(2, "Blinding Lights - sped up", 200, "The Weeknd"))
        assertNull(SoundCloudMatcher.pick(sped, "Blinding Lights", listOf("The Weeknd"), 200))
    }

    @Test
    fun aVersionWordInTheSongsOwnTitleIsAllowed() {
        val live = listOf(track(1, "Hotel California (Live)", 430, "Eagles"))
        assertEquals(1L, SoundCloudMatcher.pick(live, "Hotel California (Live)", listOf("Eagles"), 432)?.first?.id)
    }

    @Test
    fun theLengthMustAgree() {
        val long = listOf(track(1, "Queen - Bohemian Rhapsody", 361, "someone"))
        assertNull(SoundCloudMatcher.pick(long, "Bohemian Rhapsody", listOf("Queen"), 355))
        val close = listOf(track(1, "Queen - Bohemian Rhapsody", 359, "someone"))
        assertEquals(1L, SoundCloudMatcher.pick(close, "Bohemian Rhapsody", listOf("Queen"), 355)?.first?.id)
    }

    @Test
    fun theArtistMustAppearSomewhere() {
        val anonymous = listOf(track(1, "Bohemian Rhapsody", 355, "random uploader"))
        assertNull(SoundCloudMatcher.pick(anonymous, "Bohemian Rhapsody", listOf("Queen"), 355))
        val byField = listOf(track(2, "Bohemian Rhapsody", 355, "QueenOfficial"))
        assertEquals(2L, SoundCloudMatcher.pick(byField, "Bohemian Rhapsody", listOf("Queen"), 355)?.first?.id)
        val titleFirst = listOf(track(3, "Bohemian Rhapsody - Queen", 355, "random uploader"))
        assertEquals(3L, SoundCloudMatcher.pick(titleFirst, "Bohemian Rhapsody", listOf("Queen"), 355)?.first?.id)
    }

    @Test
    fun uploadDecorationsAreIgnoredOnBothSides() {
        val upload = listOf(track(1, "Queen - Bohemian Rhapsody (Official Video Remastered)", 355, "someone"))
        assertEquals(1L, SoundCloudMatcher.pick(upload, "Bohemian Rhapsody - Remastered 2011", listOf("Queen"), 355)?.first?.id)
        assertEquals("bohemianrhapsody", SoundCloudMatcher.titleKey("Bohemian Rhapsody - Remastered 2011"))
        assertEquals("song", SoundCloudMatcher.titleKey("Song (feat. Someone)"))
        assertEquals("song", SoundCloudMatcher.titleKey("Song [M/V]"))
    }

    @Test
    fun theBestMatchWins() {
        val tracks =
            listOf(
                track(1, "Queen - Bohemian Rhapsody Mama", 355, "someone"),
                track(2, "Queen - Bohemian Rhapsody", 354, "someone"),
                track(3, "Bohemian Rhapsody", 355, "Queen Vevo"),
            )
        assertEquals(3L, SoundCloudMatcher.pick(tracks, "Bohemian Rhapsody", listOf("Queen"), 355)?.first?.id)
    }

    @Test
    fun anUnknownLengthNeedsAnExactTitleAndANamedArtist() {
        val loose = listOf(track(1, "Queen - Bohemian Rhapsody", 352, "rizky.rilos"))
        assertNull(SoundCloudMatcher.pick(loose, "Bohemian Rhapsody", listOf("Queen"), 0))
        val exact = listOf(track(2, "Bohemian Rhapsody", 352, "Queen"))
        assertEquals(2L, SoundCloudMatcher.pick(exact, "Bohemian Rhapsody", listOf("Queen"), 0)?.first?.id)
    }

    @Test
    fun anyScriptMatches() {
        val tracks = listOf(track(1, "Sơn Tùng M-TP - Chúng Ta Của Hiện Tại", 301, "fan"))
        assertEquals(1L, SoundCloudMatcher.pick(tracks, "Chúng Ta Của Hiện Tại", listOf("Sơn Tùng M-TP"), 302)?.first?.id)
    }

    @Test
    fun onlyAProgressiveMp3IsPlayable() {
        val hlsOnly = listOf(track(1, "Bohemian Rhapsody", 355, "Queen", transcodings = listOf(hls())))
        assertNull(SoundCloudMatcher.pick(hlsOnly, "Bohemian Rhapsody", listOf("Queen"), 355))
    }

    @Test
    fun theQueryIsArtistThenCleanTitle() {
        assertEquals("Queen Bohemian Rhapsody", SoundCloudMatcher.query("Bohemian Rhapsody (Official Video)", listOf("Queen")))
        assertEquals("Song", SoundCloudMatcher.query("Song (feat. X)", emptyList()))
    }

    @OptIn(ExperimentalEncodingApi::class, ExperimentalTime::class)
    @Test
    fun theUrlsLifeIsReadFromItsPolicy() {
        val expiry = Clock.System.now().epochSeconds + 480
        val policy =
            """{"Statement":[{"Resource":"*://cf-media.sndcdn.com/a.128.mp3*","Condition":{"DateLessThan":{"AWS:EpochTime":$expiry}}}]}"""
        val encoded = Base64.Default.encode(policy.encodeToByteArray()).replace('+', '-').replace('=', '_').replace('/', '~')
        val life = SoundCloud.validForSeconds("https://cf-media.sndcdn.com/a.128.mp3?Policy=$encoded&Signature=x&Key-Pair-Id=y")
        assertTrue(life in 470..480, "life was $life")
        assertEquals(300L, SoundCloud.validForSeconds("https://cf-media.sndcdn.com/a.128.mp3"))
    }
}
