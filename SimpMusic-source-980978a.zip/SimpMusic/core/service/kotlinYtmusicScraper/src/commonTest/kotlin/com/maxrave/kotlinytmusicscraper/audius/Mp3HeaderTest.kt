package com.maxrave.kotlinytmusicscraper.audius

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class Mp3HeaderTest {
    private fun bytes(vararg values: Int) = ByteArray(values.size) { values[it].toByte() }

    @Test
    fun readsTheFirstFrameAfterAnId3Tag() {
        // ID3v2.4 with a 5-byte body (syncsafe size), then MPEG-1 Layer III, 320 kbps, 44.1 kHz, joint stereo.
        val file = bytes(0x49, 0x44, 0x33, 4, 0, 0, 0, 0, 0, 5, 1, 2, 3, 4, 5, 0xFF, 0xFB, 0xE0, 0x64, 0, 0)
        assertEquals(Mp3Info(bitrateBps = 320_000, sampleRate = 44_100, channels = 2), Mp3Header.parse(file))
    }

    @Test
    fun readsMpeg2AndMono() {
        // MPEG-2 Layer III, 64 kbps, 22.05 kHz, mono.
        assertEquals(Mp3Info(64_000, 22_050, 1), Mp3Header.parse(bytes(0, 0, 0xFF, 0xF3, 0x80, 0xC0)))
    }

    @Test
    fun refusesWhatIsNotLayerThree() {
        assertNull(Mp3Header.parse(bytes(0xFF, 0xFD, 0xE0, 0x64)), "Layer II")
        assertNull(Mp3Header.parse(bytes(0x66, 0x4C, 0x61, 0x43, 0, 0, 0, 0x22)), "a FLAC file")
        assertNull(Mp3Header.parse(bytes(0xFF, 0xFB, 0xF0, 0x64)), "a bad bitrate index")
    }
}
