package com.maxrave.kotlinytmusicscraper.archive

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class FlacHeaderTest {
    /** "fLaC", then a STREAMINFO block header and its 34 bytes, as an encoder writes them. */
    private fun flac(
        sampleRate: Int,
        channels: Int,
        bits: Int,
        totalSamples: Long,
    ): ByteArray {
        val info = ByteArray(34)
        // Block sizes and frame sizes, which the parser skips.
        info[0] = 0x10
        info[2] = 0x10
        // 20 bits rate, 3 bits channels-1, 5 bits bits-1, 36 bits total samples.
        val packed =
            (sampleRate.toLong() shl 44) or ((channels - 1).toLong() shl 41) or ((bits - 1).toLong() shl 36) or totalSamples
        for (i in 0 until 8) info[10 + i] = (packed ushr (56 - 8 * i)).toByte()
        return "fLaC".encodeToByteArray() + byteArrayOf(0x00, 0x00, 0x00, 34) + info
    }

    @Test
    fun readsCdQuality() {
        // 354.86 s at 44.1 kHz: the Queen file the live test matched.
        val info = FlacHeader.parse(flac(44_100, 2, 16, 15_649_032))
        assertEquals(FlacInfo(44_100, 2, 16, 15_649_032, metadataStart = 4), info)
        assertEquals(354_853L, info?.durationMs)
    }

    @Test
    fun readsHighResolutionAndSurround() {
        assertEquals(FlacInfo(176_400, 2, 24, 0, metadataStart = 4), FlacHeader.parse(flac(176_400, 2, 24, 0)))
        assertEquals(6, FlacHeader.parse(flac(48_000, 6, 24, 1000))?.channels)
    }

    @Test
    fun skipsAnId3TagInFront() {
        // ID3v2.4 header with a syncsafe size of 300 bytes, then the tag body.
        val id3 = byteArrayOf('I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte(), 4, 0, 0, 0, 0, 2, 44) + ByteArray(300)
        assertEquals(48_000, FlacHeader.parse(id3 + flac(48_000, 2, 16, 48_000))?.sampleRate)
    }

    @Test
    fun refusesWhatIsNotFlac() {
        assertNull(FlacHeader.parse("<html><body>Item not available</body></html>".encodeToByteArray()))
        assertNull(FlacHeader.parse(ByteArray(0)))
        // An MP3 renamed .flac.
        assertNull(FlacHeader.parse(byteArrayOf(0xFF.toByte(), 0xFB.toByte(), 0x90.toByte(), 0x64) + ByteArray(60)))
    }

    @Test
    fun stepsOverALargeCoverToTheAudio() {
        // fLaC, STREAMINFO (34 bytes), then a 3.46 MB PICTURE marked last: the audio starts after it.
        val head = ByteArray(4 + 4 + 34 + 4)
        "fLaC".encodeToByteArray().copyInto(head)
        head[4] = 0x00 // STREAMINFO, not last
        head[7] = 34
        val picture = 3_460_000
        head[42] = (0x80 or 6).toByte() // PICTURE, last
        head[43] = (picture shr 16).toByte()
        head[44] = (picture shr 8).toByte()
        head[45] = picture.toByte()
        val walk = FlacHeader.walk(head, 0, 4)
        assertEquals(46L + picture, walk.audioOffset)
    }

    @Test
    fun aBlockPastTheProbeAsksForTheNextHeader() {
        // STREAMINFO, then a 5 MB PADDING block that is not the last one: the walk needs the header after it.
        val head = ByteArray(4 + 4 + 34 + 4)
        "fLaC".encodeToByteArray().copyInto(head)
        head[7] = 34
        val padding = 5_000_000
        head[42] = 1
        head[43] = (padding shr 16).toByte()
        head[44] = (padding shr 8).toByte()
        head[45] = padding.toByte()
        val first = FlacHeader.walk(head, 0, 4)
        assertEquals(null, first.audioOffset)
        val next = first.nextHeader
        assertEquals(46L + padding, next)
        // The read at that header: a last VORBIS_COMMENT of 100 bytes.
        val more = byteArrayOf((0x80 or 4).toByte(), 0, 0, 100)
        assertEquals(next + 104, FlacHeader.walk(more, next, next).audioOffset)
    }
}
