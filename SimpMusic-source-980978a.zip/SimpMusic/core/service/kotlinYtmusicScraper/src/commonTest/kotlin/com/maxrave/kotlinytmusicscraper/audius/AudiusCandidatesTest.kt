package com.maxrave.kotlinytmusicscraper.audius

import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher
import kotlinx.serialization.json.Json
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class AudiusCandidatesTest {
    // Rows as /v1/tracks/search answered on 2026-10-11 (trimmed to the fields read), plus made-up
    // ones for the cases a live search did not happen to show.
    private val search =
        Json.parseToJsonElement(
            """
            {"data":[
             {"id":"pzRN5","title":"Odesza - Say My Name (SENZA Remix)","duration":192,"is_streamable":true,"is_stream_gated":false,"stream_conditions":null,"access":{"stream":true,"download":true},"is_delete":false,"is_available":true,"is_unlisted":false,"remix_of":{"tracks":[]},"cover_original_song_title":null,"album_backlink":null,"user":{"name":"SENZA","handle":"officialsenza","is_verified":false,"is_deactivated":false,"is_available":true}},
             {"id":"K7vE9","title":"Say My Name (feat. Zyra)","duration":263,"is_streamable":true,"is_stream_gated":false,"stream_conditions":null,"access":{"stream":true,"download":true},"is_delete":false,"is_available":true,"is_unlisted":false,"remix_of":{"tracks":[]},"cover_original_song_title":null,"album_backlink":{"permalink":"/odesza/album/in-return-76861","playlist_id":76861,"playlist_name":"In Return"},"user":{"name":"ODESZA","handle":"odesza","is_verified":true,"is_deactivated":false,"is_available":true}},
             {"id":"gated","title":"Say My Name (feat. Zyra)","duration":263,"is_streamable":true,"is_stream_gated":true,"stream_conditions":{"usdc_purchase":{"price":100}},"access":{"stream":false,"download":false},"user":{"name":"ODESZA","handle":"odesza"}},
             {"id":"remix","title":"Say My Name (feat. Zyra)","duration":263,"is_streamable":true,"remix_of":{"tracks":[{"parent_track_id":"K7vE9"}]},"user":{"name":"ODESZA","handle":"odesza"}},
             {"id":"cover","title":"Say My Name (feat. Zyra)","duration":263,"is_streamable":true,"cover_original_song_title":"Say My Name","user":{"name":"ODESZA","handle":"odesza"}},
             {"id":"gone","title":"Say My Name (feat. Zyra)","duration":263,"is_streamable":true,"user":{"name":"ODESZA","handle":"odesza","is_deactivated":true}},
             {"id":"fan","title":"ODESZA - Say My Name (feat. Zyra)","duration":263,"is_streamable":true,"user":{"name":"bestmusic4u","handle":"bestmusic4u"}}
            ]}
            """.trimIndent(),
        )

    @Test
    fun onlyTheArtistsOwnFullUploadsAreCandidates() {
        val ids = AudiusCandidates.candidates(search, listOf("ODESZA")).map { it.item.id }
        assertEquals(listOf("K7vE9"), ids, "no remixer, no gate, no remix or cover flag, no closed account, no fan re-upload")
        val official = AudiusCandidates.candidates(search, listOf("ODESZA")).single()
        assertEquals(263_000, official.durationMs)
        assertEquals("In Return", official.context)
        assertEquals("ODESZA", official.item.uploader)
    }

    @Test
    fun theSameRecordingIsPickedAndAnotherLengthIsNot() {
        val candidates = AudiusCandidates.candidates(search, listOf("ODESZA"))
        assertEquals("K7vE9", RecordingMatcher.pick(candidates, "Say My Name (feat. Zyra)", listOf("ODESZA"), 262)?.id)
        assertNull(RecordingMatcher.pick(candidates, "Say My Name (feat. Zyra)", listOf("ODESZA"), 240), "a radio edit is another take")
        assertEquals(emptyList(), AudiusCandidates.candidates(search, emptyList()), "an artist is needed to know whose upload it is")
    }
}
