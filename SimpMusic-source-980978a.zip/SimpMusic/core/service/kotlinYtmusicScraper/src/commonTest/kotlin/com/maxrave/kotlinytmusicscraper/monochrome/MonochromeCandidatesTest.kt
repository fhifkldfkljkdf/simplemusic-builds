package com.maxrave.kotlinytmusicscraper.monochrome

import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher
import kotlinx.serialization.json.Json
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class MonochromeCandidatesTest {
    // Rows as tracks.monochrome.st/search/tracks answered on 2026-10-13 (trimmed to the fields read),
    // plus a made-up one for the case a live search did not happen to show.
    private val search =
        Json.parseToJsonElement(
            """
            {"tracks":[
             {"id":"156929735690203136","trackId":"156929735690203136","title":"Bohemian Rhapsody","artistNames":["Queen","Freddie Mercury","The London Horn Sound","Geoffrey Simon"],"playable":true,"duration":381066,"isrc":"GBATS0910183","recordingId":"157193870508036096"},
             {"id":"171616448614424576","trackId":"171616448614424576","title":"Bohemian Rhapsody","artistNames":["Rockabye Baby!"],"playable":true,"duration":274280,"isrc":"USEWC0882101","recordingId":"188059379637948416"},
             {"id":"live","trackId":"live","title":"Bohemian Rhapsody (Live Aid)","artistNames":["Queen"],"playable":true,"duration":381066,"isrc":null,"recordingId":"live"},
             {"id":"gone","trackId":"gone","title":"Bohemian Rhapsody","artistNames":["Queen"],"playable":false,"duration":381066,"isrc":null,"recordingId":"gone"}
            ]}
            """.trimIndent(),
        )

    @Test
    fun unplayableRowsAreDropped() {
        val ids = MonochromeCandidates.candidates(search).map { it.item.id }
        assertEquals(listOf("156929735690203136", "171616448614424576", "live"), ids)
    }

    @Test
    fun theSameRecordingIsPickedAndAnotherLengthIsNot() {
        val candidates = MonochromeCandidates.candidates(search)
        assertEquals("156929735690203136", RecordingMatcher.pick(candidates, "Bohemian Rhapsody", listOf("Queen"), 381)?.id)
        assertEquals("Queen", MonochromeCandidates.candidates(search).first().item.artists.first())
        assertNull(RecordingMatcher.pick(candidates, "Bohemian Rhapsody", listOf("Queen"), 240), "a different length is another take")
        assertNull(RecordingMatcher.pick(candidates, "Bohemian Rhapsody", listOf("Someone Else"), 381), "the artist must match")
    }
}
