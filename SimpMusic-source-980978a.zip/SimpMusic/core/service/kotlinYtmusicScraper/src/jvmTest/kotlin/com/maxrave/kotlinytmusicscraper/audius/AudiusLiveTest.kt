package com.maxrave.kotlinytmusicscraper.audius

import kotlinx.coroutines.runBlocking
import java.net.HttpURLConnection
import java.net.URI
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** Talks to Audius, so it only runs with AUDIUS_LIVE=1: search, match, read the stream's first frame, then a range read. */
class AudiusLiveTest {
    @Test
    fun findsAndFetchesAnArtistsOwnUpload(): Unit =
        runBlocking {
            if (System.getenv("AUDIUS_LIVE") != "1") return@runBlocking
            val audius = Audius()
            val started = System.currentTimeMillis()
            val track = audius.findStream("Say My Name (feat. Zyra)", listOf("ODESZA"), 263).getOrThrow()
            println("Matched ${track.id} \"${track.title}\" by ${track.uploader}, ${track.mp3} in ${System.currentTimeMillis() - started} ms")
            assertTrue((track.mp3?.bitrateBps ?: 0) >= Audius.MIN_BITRATE_BPS, "first frame not read: ${track.mp3}")
            val connection = URI(audius.streamUrl(track.id)).toURL().openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Range", "bytes=0-1023")
            assertEquals(206, connection.responseCode)
            assertTrue(connection.contentType.startsWith("audio/mpeg"), connection.contentType)
            val missing = audius.findStream("Bohemian Rhapsody", listOf("Queen"), 355)
            println("Queen: ${missing.exceptionOrNull()?.message}")
        }
}
