package com.maxrave.kotlinytmusicscraper.archive

import kotlinx.coroutines.runBlocking
import java.net.HttpURLConnection
import java.net.URI
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** Talks to archive.org, so it only runs with ARCHIVE_LIVE=1: search, match, then a range read. */
class InternetArchiveLiveTest {
    @Test
    fun findsAndFetchesALosslessFile(): Unit =
        runBlocking {
            if (System.getenv("ARCHIVE_LIVE") != "1") return@runBlocking
            val archive = InternetArchive()
            val started = System.currentTimeMillis()
            val file = archive.findLossless("Bohemian Rhapsody", listOf("Queen"), 355).getOrThrow()
            val url = archive.streamUrl(file)
            println("Matched ${file.identifier}/${file.name}, ${file.bitrateBps} bps, ${file.flac}, audio from byte ${file.audioOffset} in ${System.currentTimeMillis() - started} ms: $url")
            // The audio really starts where the walk said: a FLAC frame begins with the sync code 0xFFF8/0xFFF9.
            val frame = URI(url).toURL().openConnection() as HttpURLConnection
            frame.instanceFollowRedirects = true
            frame.setRequestProperty("Range", "bytes=${file.audioOffset}-${file.audioOffset + 1}")
            val sync = frame.inputStream.use { it.readNBytes(2) }
            assertTrue(sync.size == 2 && sync[0] == 0xFF.toByte() && (sync[1].toInt() and 0xFE) == 0xF8, "no frame at ${file.audioOffset}")
            // The file was read before it was accepted: its own header says what it is.
            val flac = file.flac
            assertTrue(flac != null && flac.channels <= 2 && flac.sampleRate > 0, "header not read: $flac")
            val connection = URI(url).toURL().openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Range", "bytes=0-1023")
            assertEquals(206, connection.responseCode)
            assertTrue(connection.contentType.startsWith("audio/flac"), connection.contentType)
            val missing = archive.findLossless("Shake It Off", listOf("Taylor Swift"), 219)
            println("Taylor Swift: ${missing.exceptionOrNull()?.message}")
            for ((title, artist, seconds) in listOf(
                Triple("Billie Jean", "Michael Jackson", 294L),
                Triple("Come Together", "The Beatles", 260L),
                Triple("Smells Like Teen Spirit", "Nirvana", 301L),
                // Mostly concert tapes on archive.org: nothing should be found, or a studio file.
                Triple("Scarlet Begonias", "Grateful Dead", 259L),
                Triple("Tweezer", "Phish", 500L),
            )) {
                val t0 = System.currentTimeMillis()
                val found = archive.findLossless(title, listOf(artist), seconds)
                println("$title: ${found.getOrNull()?.let { "${it.identifier}/${it.name} ${it.flac}" } ?: found.exceptionOrNull()?.message} (${System.currentTimeMillis() - t0} ms)")
            }
        }
}
