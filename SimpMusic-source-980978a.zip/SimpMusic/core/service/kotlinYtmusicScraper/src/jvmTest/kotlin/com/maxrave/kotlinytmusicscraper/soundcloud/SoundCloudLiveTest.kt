package com.maxrave.kotlinytmusicscraper.soundcloud

import kotlinx.coroutines.runBlocking
import java.net.HttpURLConnection
import java.net.URI
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * Talks to soundcloud.com, so it only runs with SOUNDCLOUD_LIVE=1: search, match, resolve, then
 * fetch the first bytes of the audio the way the players do (a range request).
 */
class SoundCloudLiveTest {
    @Test
    fun findsAndFetchesAFullLengthUpload(): Unit =
        runBlocking {
            if (System.getenv("SOUNDCLOUD_LIVE") != "1") return@runBlocking
            val soundCloud = SoundCloud()
            val stream = soundCloud.findStream("Bohemian Rhapsody", listOf("Queen"), 355).getOrThrow()
            println("Matched ${stream.trackId} \"${stream.title}\" by ${stream.uploader}, valid ${stream.validForSeconds}s")
            assertTrue(stream.durationMs in 350_000..360_000)
            assertTrue(stream.validForSeconds > 60)
            val connection = URI(stream.url).toURL().openConnection() as HttpURLConnection
            connection.setRequestProperty("Range", "bytes=0-1023")
            assertEquals(206, connection.responseCode)
            assertTrue(connection.contentType.startsWith("audio/mpeg"))
            val renewed = soundCloud.renew(stream).getOrThrow()
            assertTrue(renewed.url.contains("sndcdn.com"))
        }
}
