package com.maxrave.kotlinytmusicscraper.podcast

import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/** Reads real feeds, so it only runs with PODCAST_LIVE=1: an RSS podcast, a YouTube handle, Apple's directory. */
class PodcastFeedsLiveTest {
    @Test
    fun readsRealFeeds(): Unit =
        runBlocking {
            if (System.getenv("PODCAST_LIVE") != "1") return@runBlocking
            val feeds = PodcastFeeds()

            val rss = feeds.resolve("https://darknetdiaries.com/feedfree.xml").getOrThrow()
            val (url, darknet) = feeds.fetch(rss.feedUrl).getOrThrow()
            println("$url: ${darknet.title}, ${darknet.episodes.size} episodes, newest \"${darknet.episodes.first().title}\"")
            assertTrue(darknet.episodes.size > 10)
            assertNotNull(darknet.episodes.first().audioUrl)
            assertNotNull(darknet.episodes.first().publishedAtMs)

            val handle = feeds.resolve("https://www.youtube.com/@lexfridman").getOrThrow()
            assertEquals("UCSHZKyawb77ixDdsGog4iWA", handle.youTubeChannelId)
            val (_, lex) = feeds.fetch(handle.feedUrl).getOrThrow()
            println("${lex.title}: ${lex.episodes.size} videos, newest ${lex.episodes.first().youTubeVideoId} (${lex.episodes.first().durationSeconds} s)")
            assertTrue(lex.episodes.all { it.youTubeVideoId != null })
            assertTrue(lex.episodes.any { it.durationSeconds != null })

            val found = feeds.searchDirectory("infosec", 10).getOrThrow()
            println("Directory: " + found.joinToString { it.title })
            assertTrue(found.isNotEmpty())
            assertTrue(found.all { it.feedUrl.startsWith("http") })
        }
}
