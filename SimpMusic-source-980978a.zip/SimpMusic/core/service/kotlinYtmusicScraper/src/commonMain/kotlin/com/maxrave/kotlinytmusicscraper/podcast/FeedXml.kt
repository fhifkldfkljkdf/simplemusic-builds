package com.maxrave.kotlinytmusicscraper.podcast

/** One element of a feed as [FeedXml] read it: the tag name as written (namespace prefix kept). */
class FeedElement(
    val name: String,
    val attributes: Map<String, String>,
) {
    val children = ArrayList<FeedElement>()

    // Text and child elements in document order, for [deepText].
    private val parts = ArrayList<Any>()

    internal fun appendText(text: CharSequence) {
        if (text.isNotEmpty()) parts.add(text.toString())
    }

    internal fun addChild(child: FeedElement) {
        children.add(child)
        parts.add(child)
    }

    /** The element's own text, without its children's, trimmed. */
    val text: String get() = parts.filterIsInstance<String>().joinToString("").trim()

    /**
     * The text of the element and everything inside it, in order: tolerates HTML that was not
     * wrapped in CDATA. Line breaks and block elements become new lines.
     */
    fun deepText(): String {
        if (children.isEmpty()) return text
        val out = StringBuilder()
        collect(out)
        return out.toString().trim()
    }

    private fun collect(out: StringBuilder) {
        for (part in parts) {
            when (part) {
                is String -> out.append(part)
                is FeedElement -> {
                    if (part.name.equals("br", ignoreCase = true)) {
                        out.append('\n')
                        continue
                    }
                    val block = part.name.lowercase() in BLOCKS
                    if (block) out.append('\n')
                    part.collect(out)
                    if (block) out.append('\n')
                }
            }
        }
    }

    fun child(name: String): FeedElement? = children.firstOrNull { it.name.equals(name, ignoreCase = true) }

    fun all(name: String): List<FeedElement> = children.filter { it.name.equals(name, ignoreCase = true) }

    fun childText(name: String): String? = child(name)?.deepText()?.takeIf { it.isNotEmpty() }

    fun attribute(name: String): String? = attributes.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value?.takeIf { it.isNotBlank() }

    private companion object {
        val BLOCKS = setOf("p", "div", "li", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "blockquote")
    }
}

/**
 * A forgiving XML reader for podcast feeds.
 *
 * Feeds in the wild carry HTML entities outside CDATA (`&nbsp;`), stray ampersands, unclosed `<br>`
 * tags inside descriptions and DOCTYPEs; a strict parser refuses the whole feed over any one of
 * them. This reads elements, attributes, text and CDATA, decodes the entities feeds actually use,
 * and closes unmatched tags at the nearest open element of the same name.
 */
object FeedXml {
    fun parse(text: String): FeedElement {
        val root = FeedElement("#document", emptyMap())
        val stack = ArrayList<FeedElement>().apply { add(root) }
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]
            if (c != '<') {
                val end = text.indexOf('<', i).let { if (it < 0) n else it }
                stack.last().appendText(decodeEntities(text, i, end))
                i = end
                continue
            }
            when {
                text.startsWith("<!--", i) -> i = skipPast(text, i + 4, "-->")
                text.startsWith("<![CDATA[", i, ignoreCase = true) -> {
                    val end = text.indexOf("]]>", i + 9).let { if (it < 0) n else it }
                    stack.last().appendText(text.substring(i + 9, end))
                    i = minOf(n, end + 3)
                }
                text.startsWith("<?", i) -> i = skipPast(text, i + 2, "?>")
                text.startsWith("<!", i) -> i = skipDeclaration(text, i + 2)
                text.startsWith("</", i) -> {
                    val end = text.indexOf('>', i).let { if (it < 0) n else it }
                    val name = text.substring(i + 2, end).trim()
                    val open = stack.indexOfLast { it.name.equals(name, ignoreCase = true) }
                    // A closing tag nothing opened is ignored; one that skips open elements closes them too.
                    if (open > 0) while (stack.size > open) stack.removeAt(stack.size - 1)
                    i = minOf(n, end + 1)
                }
                else -> {
                    val tag = readStartTag(text, i)
                    if (tag == null) {
                        // A bare "<" in text, as in "a < b".
                        stack.last().appendText("<")
                        i++
                    } else {
                        stack.last().addChild(tag.element)
                        if (!tag.selfClosing && !tag.element.name.lowercase().let { it in VOID_HTML }) stack.add(tag.element)
                        i = tag.end
                    }
                }
            }
        }
        return root
    }

    private class StartTag(
        val element: FeedElement,
        val selfClosing: Boolean,
        val end: Int,
    )

    private fun readStartTag(
        text: String,
        start: Int,
    ): StartTag? {
        val n = text.length
        var i = start + 1
        if (i >= n || !(text[i].isLetter() || text[i] == '_')) return null
        val nameStart = i
        while (i < n && !text[i].isWhitespace() && text[i] != '>' && text[i] != '/') i++
        val name = text.substring(nameStart, i)
        val attributes = LinkedHashMap<String, String>()
        var selfClosing = false
        while (i < n) {
            while (i < n && text[i].isWhitespace()) i++
            if (i >= n) break
            when (text[i]) {
                '>' -> return StartTag(FeedElement(name, attributes), selfClosing, i + 1)
                '/' -> {
                    selfClosing = true
                    i++
                    continue
                }
            }
            selfClosing = false
            val attrStart = i
            while (i < n && !text[i].isWhitespace() && text[i] != '=' && text[i] != '>' && text[i] != '/') i++
            val attrName = text.substring(attrStart, i)
            while (i < n && text[i].isWhitespace()) i++
            if (i < n && text[i] == '=') {
                i++
                while (i < n && text[i].isWhitespace()) i++
                val value: String
                if (i < n && (text[i] == '"' || text[i] == '\'')) {
                    val quote = text[i]
                    val end = text.indexOf(quote, i + 1).let { if (it < 0) n else it }
                    value = decodeEntities(text, i + 1, end)
                    i = minOf(n, end + 1)
                } else {
                    val valueStart = i
                    while (i < n && !text[i].isWhitespace() && text[i] != '>') i++
                    value = decodeEntities(text, valueStart, i)
                }
                if (attrName.isNotEmpty()) attributes[attrName] = value
            } else if (attrName.isNotEmpty()) {
                attributes[attrName] = ""
            } else {
                i++
            }
        }
        return StartTag(FeedElement(name, attributes), selfClosing, n)
    }

    private fun skipPast(
        text: String,
        from: Int,
        end: String,
    ): Int = text.indexOf(end, from).let { if (it < 0) text.length else it + end.length }

    /** A DOCTYPE, possibly with an internal subset in brackets. */
    private fun skipDeclaration(
        text: String,
        from: Int,
    ): Int {
        var depth = 0
        var i = from
        while (i < text.length) {
            when (text[i]) {
                '[' -> depth++
                ']' -> depth--
                '>' -> if (depth <= 0) return i + 1
            }
            i++
        }
        return text.length
    }

    fun decodeEntities(text: String): String = decodeEntities(text, 0, text.length)

    private fun decodeEntities(
        text: String,
        start: Int,
        end: Int,
    ): String {
        val amp = text.indexOf('&', start)
        if (amp < 0 || amp >= end) return text.substring(start, end)
        val out = StringBuilder(end - start)
        var i = start
        while (i < end) {
            val c = text[i]
            if (c != '&') {
                out.append(c)
                i++
                continue
            }
            val semi = text.indexOf(';', i + 1)
            if (semi < 0 || semi >= end || semi - i > 12) {
                out.append(c)
                i++
                continue
            }
            val entity = text.substring(i + 1, semi)
            val decoded =
                when {
                    entity.startsWith("#x") || entity.startsWith("#X") -> entity.substring(2).toIntOrNull(16)?.let(::codePoint)
                    entity.startsWith("#") -> entity.substring(1).toIntOrNull()?.let(::codePoint)
                    else -> NAMED[entity] ?: NAMED[entity.lowercase()]
                }
            if (decoded == null) {
                out.append(c)
                i++
            } else {
                out.append(decoded)
                i = semi + 1
            }
        }
        return out.toString()
    }

    private fun codePoint(value: Int): String? =
        when {
            value <= 0 || value > 0x10FFFF -> null
            value < 0x10000 -> value.toChar().toString()
            else -> {
                val v = value - 0x10000
                charArrayOf((0xD800 + (v shr 10)).toChar(), (0xDC00 + (v and 0x3FF)).toChar()).concatToString()
            }
        }

    /** HTML elements that never have a closing tag; inside a description they must not swallow what follows. */
    private val VOID_HTML = setOf("br", "hr", "img", "meta", "input", "wbr", "source")

    private val NAMED =
        mapOf(
            "amp" to "&",
            "lt" to "<",
            "gt" to ">",
            "quot" to "\"",
            "apos" to "'",
            "nbsp" to " ",
            "hellip" to "…",
            "mdash" to "—",
            "ndash" to "–",
            "lsquo" to "‘",
            "rsquo" to "’",
            "ldquo" to "“",
            "rdquo" to "”",
            "laquo" to "«",
            "raquo" to "»",
            "bull" to "•",
            "middot" to "·",
            "copy" to "©",
            "reg" to "®",
            "trade" to "™",
            "deg" to "°",
            "eacute" to "é",
            "egrave" to "è",
            "aacute" to "á",
            "agrave" to "à",
            "iacute" to "í",
            "oacute" to "ó",
            "uacute" to "ú",
            "ntilde" to "ñ",
            "ccedil" to "ç",
            "auml" to "ä",
            "ouml" to "ö",
            "uuml" to "ü",
            "szlig" to "ß",
            "euro" to "€",
            "pound" to "£",
        )
}
