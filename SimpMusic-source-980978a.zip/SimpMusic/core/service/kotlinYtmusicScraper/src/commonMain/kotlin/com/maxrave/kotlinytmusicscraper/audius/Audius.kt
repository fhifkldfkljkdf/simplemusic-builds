package com.maxrave.kotlinytmusicscraper.audius

import com.maxrave.kotlinytmusicscraper.archive.InternetArchive
import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher
import com.maxrave.ktorext.getEngine
import com.maxrave.logger.Logger
import io.ktor.client.HttpClient
import io.ktor.client.engine.ProxyConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.utils.io.readRemaining
import kotlinx.io.readByteArray
import kotlinx.serialization.json.Json

/**
 * Audius as a high-bitrate source: music its artists upload themselves, streamed as 320 kbps MP3
 * through Audius's public API. No account and no key; requests name the app (`app_name`), as the
 * API asks.
 *
 * Coverage is narrow — mostly electronic, hip-hop and independent artists who publish there — so
 * this is tried after the Internet Archive's FLAC and before YouTube, and only with Hi-Fi sound on.
 * Every candidate is the artist's own upload ([AudiusCandidates]) and the same recording
 * ([RecordingMatcher]), and the stream is read before it is used: a file that is not MP3 at
 * [MIN_BITRATE_BPS] or more is not worth leaving YouTube for. Measured 2026-10-11: ODESZA's
 * "Say My Name" and deadmau5's "Ghosts N Stuff" stream at 320 kbps CBR; the first byte arrives
 * 0.8 to 2 s after the request (two redirects, to a content node and then to signed storage).
 */
class Audius {
    private val json = Json { ignoreUnknownKeys = true }

    var proxy: ProxyConfig? = null
        set(value) {
            if (field == value) return
            field = value
            client.close()
            client = createClient()
        }

    private var client = createClient()

    private fun createClient() =
        HttpClient(getEngine()) {
            expectSuccess = true
            install(HttpTimeout) {
                requestTimeoutMillis = REQUEST_TIMEOUT_MS
                connectTimeoutMillis = REQUEST_TIMEOUT_MS
            }
            if (proxy != null) {
                engine {
                    proxy = this@Audius.proxy
                }
            }
        }

    /** The artist's own upload of the song at a high bitrate, or a failure when there is none. */
    suspend fun findStream(
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): Result<AudiusTrack> =
        runCatching {
            val query = RecordingMatcher.query(title, artists)
            require(query.isNotBlank()) { "Nothing to search for" }
            val body =
                client
                    .get(SEARCH_URL) {
                        header("User-Agent", USER_AGENT)
                        parameter("query", query)
                        parameter("app_name", APP_NAME)
                    }.bodyAsText()
            val candidates = AudiusCandidates.candidates(json.parseToJsonElement(body), artists)
            for (track in RecordingMatcher.ranked(candidates, title, artists, durationSeconds).take(MAX_PROBES)) {
                val checked = check(track) ?: continue
                Logger.d(TAG, "Matched \"$title\" to Audius ${track.id} \"${track.title}\" by ${track.uploader} (${checked.mp3})")
                return@runCatching checked
            }
            error("No Audius upload by the artist matches \"$title\"")
        }

    /** [track] with its first frame read, or null when the stream is not MP3 at a high enough bitrate. */
    private suspend fun check(track: AudiusTrack): AudiusTrack? {
        val head =
            runCatching {
                client
                    .prepareGet(streamUrl(track.id)) {
                        header("User-Agent", USER_AGENT)
                        header("Range", "bytes=0-${Mp3Header.PROBE_BYTES - 1}")
                    }.execute { response ->
                        response.bodyAsChannel().readRemaining(Mp3Header.PROBE_BYTES.toLong()).readByteArray()
                    }
            }.getOrElse {
                Logger.d(TAG, "Audius ${track.id} could not be read: ${it.message}")
                return null
            }
        val info = Mp3Header.parse(head)
        if (info == null || info.bitrateBps < MIN_BITRATE_BPS || info.channels != 2) {
            Logger.d(TAG, "Audius ${track.id} is $info; not used")
            return null
        }
        return track.copy(mp3 = info)
    }

    /** The track's stream; Audius redirects it to wherever the file is served from, freshly signed each time. */
    fun streamUrl(trackId: String): String = "$API_URL/v1/tracks/${InternetArchive.encodePath(trackId)}/stream?app_name=$APP_NAME"

    companion object {
        private const val TAG = "Audius"
        private const val API_URL = "https://api.audius.co"
        private const val SEARCH_URL = "$API_URL/v1/tracks/search"
        private const val APP_NAME = "SimpMusic"
        private const val USER_AGENT = "SimpMusic (private build)"
        private const val REQUEST_TIMEOUT_MS = 8_000L
        private const val MAX_PROBES = 2

        /** Above YouTube's best without Premium (Opus at about 160 kbps). */
        const val MIN_BITRATE_BPS = 256_000

        /** Whether [url] is an Audius stream address made by [streamUrl]. */
        fun isStreamUrl(url: String): Boolean = url.startsWith("$API_URL/v1/tracks/") && url.contains("/stream")
    }
}
