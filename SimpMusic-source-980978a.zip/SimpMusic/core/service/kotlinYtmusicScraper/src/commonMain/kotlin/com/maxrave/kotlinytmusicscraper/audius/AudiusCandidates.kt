package com.maxrave.kotlinytmusicscraper.audius

import com.maxrave.domain.mediaservice.handler.RadioCurator
import com.maxrave.kotlinytmusicscraper.matching.RecordingCandidate
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/** A track on Audius that can stand in for a song. */
data class AudiusTrack(
    val id: String,
    val title: String,
    /** The account that uploaded it: the artist, for every track this source uses. */
    val uploader: String,
    val durationMs: Long?,
    /** What its first frame says; filled in once the stream has been checked. */
    val mp3: Mp3Info? = null,
)

/**
 * Turns Audius search results into match candidates. Pure, so the rules can be tested against real
 * answers.
 *
 * Audius is mostly remixes, edits and fan uploads, so this is stricter than the shared matcher:
 * only tracks the artist uploaded themselves (the account's name or handle is the artist's), not
 * gated or hidden, and not marked as a remix or a cover. A fan's upload is often a copy of a lower
 * quality file, which would make a 320 kbps stream 320 kbps in name only.
 */
object AudiusCandidates {
    fun candidates(
        search: JsonElement,
        artists: List<String>,
    ): List<RecordingCandidate<AudiusTrack>> {
        val wanted = artists.map(RadioCurator::artistKey).filter { it.isNotEmpty() }
        if (wanted.isEmpty()) return emptyList()
        val rows = (search as? JsonObject)?.get("data") ?: return emptyList()
        return runCatching { rows.jsonArray }.getOrNull().orEmpty().mapNotNull { row ->
            val track = row as? JsonObject ?: return@mapNotNull null
            if (!playableByAnyone(track)) return@mapNotNull null
            val user = track["user"] as? JsonObject ?: return@mapNotNull null
            if (bool(user["is_deactivated"]) == true || bool(user["is_available"]) == false) return@mapNotNull null
            val name = text(user["name"]).orEmpty()
            val handle = text(user["handle"]).orEmpty()
            if (wanted.none { want -> listOf(name, handle).map(RadioCurator::artistKey).any { sameArtist(want, it) } }) return@mapNotNull null
            val id = text(track["id"]) ?: return@mapNotNull null
            val title = text(track["title"]) ?: return@mapNotNull null
            val durationMs = (track["duration"] as? JsonPrimitive)?.longOrNull?.times(1000)
            val album = (track["album_backlink"] as? JsonObject)?.let { text(it["playlist_name"]) }.orEmpty()
            RecordingCandidate(
                item = AudiusTrack(id = id, title = title, uploader = name.ifBlank { handle }, durationMs = durationMs),
                title = title,
                artistFields = listOf(name, handle),
                durationMs = durationMs,
                context = album,
            )
        }
    }

    /** Streams in full to anyone: no gate, not deleted or hidden, and not a remix or a cover of another track. */
    private fun playableByAnyone(track: JsonObject): Boolean {
        if (bool(track["is_streamable"]) != true) return false
        if (bool(track["is_stream_gated"]) == true) return false
        if (track["stream_conditions"].let { it != null && it != JsonNull }) return false
        if ((track["access"] as? JsonObject)?.let { bool(it["stream"]) } == false) return false
        if (bool(track["is_delete"]) == true || bool(track["is_available"]) == false) return false
        if (bool(track["is_unlisted"]) == true) return false
        val remixOf = track["remix_of"] as? JsonObject
        if (remixOf != null && runCatching { remixOf["tracks"]?.jsonArray?.isNotEmpty() }.getOrNull() == true) return false
        if (!text(track["cover_original_song_title"]).isNullOrBlank()) return false
        return true
    }

    /** The same name, or one only adding words after it ("ODESZA" and "odesza"; "deadmau5" and "deadmau5 official"). */
    private fun sameArtist(
        want: String,
        field: String,
    ): Boolean = field.isNotEmpty() && (want == field || (minOf(want.length, field.length) >= 4 && (field.startsWith(want) || want.startsWith(field))))

    private fun text(element: JsonElement?): String? = (element as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull?.trim()?.takeIf { it.isNotEmpty() }

    private fun bool(element: JsonElement?): Boolean? = (element as? JsonPrimitive)?.booleanOrNull
}
