package com.maxrave.kotlinytmusicscraper.archive

/** What a FLAC file's STREAMINFO says about it. */
data class FlacInfo(
    val sampleRate: Int,
    val channels: Int,
    val bitsPerSample: Int,
    /** 0 when the encoder did not know it. */
    val totalSamples: Long,
    /** Where the first metadata block (STREAMINFO) starts, after any ID3 tag and "fLaC". */
    val metadataStart: Int = 0,
) {
    val durationMs: Long? get() = if (totalSamples > 0 && sampleRate > 0) totalSamples * 1000 / sampleRate else null
}

/**
 * Reads the head of a FLAC file. Pure, so it can be tested on bytes. Private copy.
 *
 * Used to check an archive.org file before it is played: archive.org's own metadata says a file is
 * "Flac" and gives a length, but not how many channels it has or its sample rate, and the length is
 * whatever the uploader's tool wrote. The first few kilobytes answer all of it, and fetching them
 * also proves the file can be downloaded at all.
 */
object FlacHeader {
    /** Bytes to fetch: enough for an ID3v2 tag with a small cover picture, then STREAMINFO. */
    const val PROBE_BYTES = 65_536

    fun parse(bytes: ByteArray): FlacInfo? {
        var at = 0
        // Some rippers put an ID3v2 tag in front, which FLAC tolerates. Its size is "syncsafe":
        // four bytes of seven bits each, after the ten-byte header.
        if (bytes.size >= 10 && bytes[0] == 'I'.code.toByte() && bytes[1] == 'D'.code.toByte() && bytes[2] == '3'.code.toByte()) {
            val size = (bytes[6].toInt() and 0x7F shl 21) or (bytes[7].toInt() and 0x7F shl 14) or
                (bytes[8].toInt() and 0x7F shl 7) or (bytes[9].toInt() and 0x7F)
            val footer = if (bytes[5].toInt() and 0x10 != 0) 10 else 0
            at = 10 + size + footer
        }
        if (bytes.size < at + 4 + 4 + 34) return null
        if (bytes[at] != 'f'.code.toByte() || bytes[at + 1] != 'L'.code.toByte() ||
            bytes[at + 2] != 'a'.code.toByte() || bytes[at + 3] != 'C'.code.toByte()
        ) {
            return null
        }
        at += 4
        val metadataStart = at
        // The first metadata block must be STREAMINFO (type 0), 34 bytes long.
        val type = bytes[at].toInt() and 0x7F
        val length = (u(bytes[at + 1]) shl 16) or (u(bytes[at + 2]) shl 8) or u(bytes[at + 3])
        if (type != 0 || length < 34) return null
        at += 4
        // Bytes 10..17 of STREAMINFO: 20 bits sample rate, 3 bits channels-1, 5 bits bits-1,
        // 36 bits total samples.
        var bits = 0L
        for (i in 0 until 8) bits = (bits shl 8) or u(bytes[at + 10 + i]).toLong()
        val sampleRate = (bits ushr 44).toInt()
        val channels = ((bits ushr 41) and 0x7).toInt() + 1
        val bitsPerSample = ((bits ushr 36) and 0x1F).toInt() + 1
        val totalSamples = bits and 0xFFFFFFFFFL
        if (sampleRate <= 0) return null
        return FlacInfo(sampleRate, channels, bitsPerSample, totalSamples, metadataStart)
    }

    /** How far [walk] got: where the audio starts, or the next block header it still has to read. */
    data class MetadataWalk(
        /** The first audio frame's position in the file; null until the last metadata block is seen. */
        val audioOffset: Long?,
        /** The block header to read next, while [audioOffset] is null. */
        val nextHeader: Long,
    )

    /**
     * Follows the metadata blocks from the header at file position [header] through [bytes], which
     * hold the file from position [bytesOffset]. Each header says its block's length and whether it
     * is the last, so a block too long for [bytes] — an embedded cover of several megabytes — is
     * stepped over, and the walk carries on with a read at [MetadataWalk.nextHeader].
     */
    fun walk(
        bytes: ByteArray,
        bytesOffset: Long,
        header: Long,
    ): MetadataWalk {
        var at = header
        while (true) {
            val i = at - bytesOffset
            if (i < 0 || i + 4 > bytes.size) return MetadataWalk(null, at)
            val index = i.toInt()
            val last = bytes[index].toInt() and 0x80 != 0
            val length = (u(bytes[index + 1]) shl 16) or (u(bytes[index + 2]) shl 8) or u(bytes[index + 3])
            at += 4 + length
            if (last) return MetadataWalk(at, at)
        }
    }

    private fun u(b: Byte): Int = b.toInt() and 0xFF
}
