package com.maxrave.kotlinytmusicscraper.extractor

import com.maxrave.domain.mediaservice.handler.YouTubeHealth
import io.ktor.client.plugins.ResponseException

/** YouTube answered the player request but would not play the video, and said why. */
class YouTubePlayabilityException(
    val status: String,
    val reason: String?,
) : RuntimeException("YouTube playability $status: $reason")

/** What a failed [com.maxrave.kotlinytmusicscraper.YouTube.player] call says about YouTube itself. */
fun youTubeFailureOf(error: Throwable): YouTubeHealth.Failure =
    when (error) {
        is ResponseException -> YouTubeHealth.classify(error.response.status.value, null, null)
        is YouTubePlayabilityException -> YouTubeHealth.classify(null, error.status, error.reason)
        else -> YouTubeHealth.classify(null, null, null)
    }
