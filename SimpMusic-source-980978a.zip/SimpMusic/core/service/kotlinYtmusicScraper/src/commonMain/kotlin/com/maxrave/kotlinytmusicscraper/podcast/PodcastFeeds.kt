package com.maxrave.kotlinytmusicscraper.podcast

import com.maxrave.ktorext.getEngine
import com.maxrave.logger.Logger
import io.ktor.client.HttpClient
import io.ktor.client.engine.ProxyConfig
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.prepareGet
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.content.TextContent
import io.ktor.utils.io.readRemaining
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.io.readByteArray
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlin.time.Clock

/** A podcast in Apple's public directory, which lists every RSS podcast submitted to Apple Podcasts. */
data class DirectoryPodcast(
    val title: String,
    val author: String?,
    val feedUrl: String,
    val imageUrl: String?,
    val genres: List<String>,
)

/** Where an address the user typed leads: the feed to read, and the YouTube channel or playlist it stands for. */
data class FeedAddress(
    val feedUrl: String,
    val youTubeChannelId: String? = null,
    val youTubePlaylistId: String? = null,
)

/**
 * Podcast feeds: RSS and Atom read from the address the user added, and YouTube channels and
 * playlists through YouTube's own public feeds (`/feeds/videos.xml`, the newest 15 videos, no
 * account and no key). Recommendations come from Apple's public podcast directory, searched by
 * category words only — nothing that identifies the listener is sent.
 */
class PodcastFeeds {
    private val json = Json { ignoreUnknownKeys = true }

    var proxy: ProxyConfig? = null
        set(value) {
            if (field == value) return
            field = value
            client.close()
            client = createClient()
        }

    private var client = createClient()

    private fun createClient() =
        HttpClient(getEngine()) {
            expectSuccess = true
            install(HttpTimeout) {
                requestTimeoutMillis = REQUEST_TIMEOUT_MS
                connectTimeoutMillis = CONNECT_TIMEOUT_MS
            }
            if (proxy != null) {
                engine {
                    proxy = this@PodcastFeeds.proxy
                }
            }
        }

    /** The feed behind what the user typed: a feed address, a podcast's web page, or a YouTube channel, handle or playlist. */
    suspend fun resolve(input: String): Result<FeedAddress> =
        runCatching {
            val text = input.trim()
            require(text.isNotEmpty()) { "Nothing to add" }
            youTubeAddress(text)?.let { return@runCatching it }
            val url = if (text.contains("://")) text else "https://$text"
            require(url.startsWith("http://") || url.startsWith("https://")) { "Not a web address" }
            FeedAddress(url)
        }

    private suspend fun youTubeAddress(text: String): FeedAddress? {
        val handle = Regex("""^@([A-Za-z0-9._-]{3,})$""").find(text)?.groupValues?.get(1)
        val lower = text.lowercase()
        val isYouTube = handle != null || Regex("""^(https?://)?([a-z]+\.)?(youtube\.com|youtu\.be)/""").containsMatchIn(lower)
        if (!isYouTube) return null
        Regex("""[?&]list=([A-Za-z0-9_-]+)""").find(text)?.groupValues?.get(1)?.let { list ->
            return FeedAddress(YOUTUBE_FEED + "playlist_id=" + list, youTubePlaylistId = list)
        }
        Regex("""/channel/(UC[A-Za-z0-9_-]{22})""").find(text)?.groupValues?.get(1)?.let { id ->
            return FeedAddress(YOUTUBE_FEED + "channel_id=" + id, youTubeChannelId = id)
        }
        // A handle, /c/ or /user/ page: the channel id is written into the page itself.
        val page =
            when {
                handle != null -> "https://www.youtube.com/@$handle"
                text.contains("://") -> text
                else -> "https://$text"
            }
        val html =
            client
                .get(page) {
                    header("User-Agent", BROWSER_USER_AGENT)
                    // Skips the cookie consent page served in the EU instead of the channel.
                    header("Cookie", "SOCS=CAI")
                    header("Accept-Language", "en")
                }.bodyAsText()
        val id =
            Regex(""""externalId":"(UC[A-Za-z0-9_-]{22})"""").find(html)?.groupValues?.get(1)
                ?: Regex("""<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[A-Za-z0-9_-]{22})"""").find(html)?.groupValues?.get(1)
                ?: Regex(""""browseId":"(UC[A-Za-z0-9_-]{22})"""").find(html)?.groupValues?.get(1)
                ?: error("No YouTube channel at $page")
        return FeedAddress(YOUTUBE_FEED + "channel_id=" + id, youTubeChannelId = id)
    }

    /**
     * The feed at [url]. A podcast's web page that names its feed (`<link rel="alternate"
     * type="application/rss+xml">`) is followed once to that feed.
     */
    suspend fun fetch(url: String): Result<Pair<String, ParsedFeed>> =
        runCatching {
            // A YouTube channel or playlist: read from YouTube's own web API first. Its RSS feed
            // answers 404 for every channel at times, and never gives lengths.
            youTubeTarget(url)?.let { (channelId, playlistId) ->
                youTubePage(channelId, playlistId)
                    .onSuccess { return@runCatching url to it }
                    .onFailure { if (it is CancellationException) throw it else Logger.w(TAG, "YouTube page for $url failed (${it.message}); trying its feed") }
            }
            val body = download(url)
            FeedParser.parse(body)?.let { return@runCatching url to it }
            val linked = feedLinkIn(body, url) ?: error("No podcast feed at $url")
            Logger.d(TAG, "$url is a web page; its feed is $linked")
            val feed = FeedParser.parse(download(linked)) ?: error("No podcast feed at $linked")
            linked to feed
        }

    /** The channel id or playlist id a YouTube feed address names. */
    private fun youTubeTarget(url: String): Pair<String?, String?>? {
        if (!url.startsWith(YOUTUBE_FEED)) return null
        val channel = Regex("""[?&]channel_id=(UC[A-Za-z0-9_-]{22})""").find(url)?.groupValues?.get(1)
        val playlist = Regex("""[?&]playlist_id=([A-Za-z0-9_-]+)""").find(url)?.groupValues?.get(1)
        return if (channel == null && playlist == null) null else channel to playlist
    }

    private suspend fun youTubePage(
        channelId: String?,
        playlistId: String?,
    ): Result<ParsedFeed> =
        runCatching {
            val request =
                buildJsonObject {
                    put(
                        "context",
                        buildJsonObject {
                            put(
                                "client",
                                buildJsonObject {
                                    put("clientName", "WEB")
                                    put("clientVersion", WEB_CLIENT_VERSION)
                                    put("hl", "en")
                                    put("gl", "US")
                                },
                            )
                        },
                    )
                    if (channelId != null) {
                        put("browseId", channelId)
                        put("params", YouTubeChannelPage.VIDEOS_TAB_PARAMS)
                    } else {
                        put("browseId", "VL$playlistId")
                    }
                }
            val text =
                client
                    .post(INNERTUBE_BROWSE) {
                        header("User-Agent", BROWSER_USER_AGENT)
                        setBody(TextContent(request.toString(), ContentType.Application.Json))
                    }.bodyAsText()
            val feed =
                YouTubeChannelPage.parse(json.parseToJsonElement(text).jsonObject, Clock.System.now().toEpochMilliseconds(), channelId)
                    ?: error("Not a channel or playlist page")
            require(feed.episodes.isNotEmpty()) { "No videos on the page" }
            feed
        }

    private suspend fun download(url: String): String =
        client
            .prepareGet(url) {
                header("User-Agent", FEED_USER_AGENT)
                header("Accept", "application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.9, */*;q=0.5")
            }.execute { response ->
                response.bodyAsChannel().readRemaining(MAX_FEED_BYTES).readByteArray()
            }.decodeToString()

    /** Apple's directory, searched for [term]: podcasts whose feeds can be added directly. */
    suspend fun searchDirectory(
        term: String,
        limit: Int = 25,
    ): Result<List<DirectoryPodcast>> =
        runCatching {
            suspend fun ask() =
                client
                    .get(DIRECTORY_URL) {
                        header("User-Agent", FEED_USER_AGENT)
                        parameter("media", "podcast")
                        parameter("entity", "podcast")
                        parameter("term", term)
                        parameter("limit", limit)
                    }.bodyAsText()
            // Apple limits the directory to about 20 searches a minute per address and answers
            // 403 (sometimes 429) past it; one later try is usually enough.
            val body =
                try {
                    ask()
                } catch (e: ClientRequestException) {
                    if (e.response.status.value != 403 && e.response.status.value != 429) throw e
                    delay(DIRECTORY_RETRY_MS)
                    ask()
                }
            directoryResults(json.parseToJsonElement(body).jsonObject)
        }

    companion object {
        private const val TAG = "PodcastFeeds"
        private const val YOUTUBE_FEED = "https://www.youtube.com/feeds/videos.xml?"
        private const val DIRECTORY_URL = "https://itunes.apple.com/search"
        private const val INNERTUBE_BROWSE = "https://www.youtube.com/youtubei/v1/browse?prettyPrint=false"
        private const val WEB_CLIENT_VERSION = "2.20250312.04.00"
        private const val DIRECTORY_RETRY_MS = 3_000L
        private const val FEED_USER_AGENT = "SimpMusic (private build) podcast reader"
        private const val BROWSER_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36"
        private const val REQUEST_TIMEOUT_MS = 30_000L
        private const val CONNECT_TIMEOUT_MS = 10_000L

        /** Feeds of thousands of episodes run to tens of megabytes; past this the rest is not read. */
        private const val MAX_FEED_BYTES = 16L * 1024 * 1024

        fun directoryResults(answer: JsonObject): List<DirectoryPodcast> =
            (answer["results"] as? JsonArray).orEmpty().mapNotNull { element ->
                val row = element as? JsonObject ?: return@mapNotNull null
                fun text(key: String) = row[key]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                val feedUrl = text("feedUrl") ?: return@mapNotNull null
                val title = text("collectionName") ?: text("trackName") ?: return@mapNotNull null
                DirectoryPodcast(
                    title = title,
                    author = text("artistName"),
                    feedUrl = feedUrl,
                    imageUrl = text("artworkUrl600") ?: text("artworkUrl100"),
                    genres =
                        runCatching { row["genres"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull } }
                            .getOrNull()
                            .orEmpty()
                            .filter { it != "Podcasts" },
                )
            }

        /** The feed a web page names in its head, made absolute against [pageUrl]. */
        fun feedLinkIn(
            html: String,
            pageUrl: String,
        ): String? {
            val tags = Regex("""<link\b[^>]*>""", RegexOption.IGNORE_CASE).findAll(html).map { it.value }
            val feed =
                tags.firstOrNull { tag ->
                    tag.contains("alternate", ignoreCase = true) &&
                        (tag.contains("application/rss+xml", ignoreCase = true) || tag.contains("application/atom+xml", ignoreCase = true))
                } ?: return null
            val href = Regex("""href\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(feed)?.groupValues?.get(1) ?: return null
            val decoded = FeedXml.decodeEntities(href)
            return when {
                decoded.startsWith("http://") || decoded.startsWith("https://") -> decoded
                decoded.startsWith("//") -> pageUrl.substringBefore("//") + decoded
                decoded.startsWith("/") -> Regex("""^https?://[^/]+""").find(pageUrl)?.value?.plus(decoded)
                else -> pageUrl.substringBeforeLast('/') + "/" + decoded
            }
        }
    }
}
