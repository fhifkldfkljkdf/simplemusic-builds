package com.maxrave.kotlinytmusicscraper.models.sponsorblock

import kotlinx.serialization.Serializable

/** One video's entry in SponsorBlock's hash-prefix answer (`/api/skipSegments/<prefix>`). */
@Serializable
data class HashedSkipSegments(
    val videoID: String,
    val segments: List<SkipSegments> = emptyList(),
)
