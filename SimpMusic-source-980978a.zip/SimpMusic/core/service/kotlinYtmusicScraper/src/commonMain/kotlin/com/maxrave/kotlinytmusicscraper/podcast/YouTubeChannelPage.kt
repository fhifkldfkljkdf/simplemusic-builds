package com.maxrave.kotlinytmusicscraper.podcast

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/**
 * A YouTube channel's Videos tab, or a playlist, as YouTube's own web app receives it (InnerTube
 * `browse`, WEB client, `hl=en`). Used instead of the channel's RSS feed, which YouTube answers
 * with 404 for every channel at times (measured 2026-10-12; Invidious issue #6074 reports the
 * same), and which carries no lengths.
 *
 * Every video is a `lockupViewModel` (`contentId`, title, a metadata row such as
 * `["989K views", "3 weeks ago"]`, and a length badge such as `3:36:56`). The age is all the page
 * says about when a video came out, so [ParsedEpisode.publishedAtMs] is approximate: now minus
 * the age.
 */
object YouTubeChannelPage {
    /** The channel's Videos tab, newest first. */
    const val VIDEOS_TAB_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"

    fun parse(
        answer: JsonObject,
        nowMs: Long,
        channelId: String?,
    ): ParsedFeed? {
        val channel = (answer["metadata"] as? JsonObject)?.obj("channelMetadataRenderer")
        val playlistHeader = (answer["header"] as? JsonObject)?.obj("playlistHeaderRenderer")
        val title =
            channel?.text("title")
                ?: playlistHeader?.obj("title")?.text("simpleText")
                ?: (answer["metadata"] as? JsonObject)?.obj("playlistMetadataRenderer")?.text("title")
                ?: return null
        val owner =
            playlistHeader
                ?.obj("ownerText")
                ?.array("runs")
                ?.firstOrNull()
                ?.let { (it as? JsonObject)?.text("text") }
        val episodes =
            lockups(answer)
                .mapNotNull { episode(it, nowMs) }
                .distinctBy { it.youTubeVideoId }
                .take(FeedParser.MAX_EPISODES)
        val avatar =
            channel
                ?.obj("avatar")
                ?.array("thumbnails")
                ?.lastOrNull()
                ?.let { (it as? JsonObject)?.text("url") }
        return ParsedFeed(
            title = title,
            author = owner ?: channel?.text("title"),
            description = channel?.text("description")?.let(FeedParser::plainText),
            imageUrl = avatar ?: episodes.firstOrNull()?.imageUrl,
            link = channel?.text("channelUrl"),
            categories = emptyList(),
            keywords = channel?.text("keywords")?.let(::keywords).orEmpty(),
            episodes = episodes,
            youTubeChannelId = channel?.text("externalId") ?: channelId,
        )
    }

    private fun episode(
        lockup: JsonObject,
        nowMs: Long,
    ): ParsedEpisode? {
        if (lockup.text("contentType") != "LOCKUP_CONTENT_TYPE_VIDEO") return null
        val videoId = lockup.text("contentId")?.takeIf { it.length == 11 } ?: return null
        val metadata = lockup.obj("metadata")?.obj("lockupMetadataViewModel") ?: return null
        val title = metadata.obj("title")?.text("content") ?: return null
        val parts =
            metadata
                .obj("metadata")
                ?.obj("contentMetadataViewModel")
                ?.array("metadataRows")
                .orEmpty()
                .flatMap { row -> (row as? JsonObject)?.array("metadataParts").orEmpty() }
                .mapNotNull { part -> (part as? JsonObject)?.obj("text")?.text("content") }
        val ageMs = parts.firstNotNullOfOrNull(::ageMs)
        val length =
            collect(lockup["contentImage"], "thumbnailBadgeViewModel")
                .firstNotNullOfOrNull { it.text("text")?.let(FeedParser::parseDuration) }
        // A video still to premiere or a live stream on now has no length and no age.
        if (ageMs == null && length == null) return null
        return ParsedEpisode(
            guid = "yt:video:$videoId",
            title = title,
            description = null,
            publishedAtMs = ageMs?.let { nowMs - it },
            durationSeconds = length,
            audioUrl = null,
            audioType = null,
            imageUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            youTubeVideoId = videoId,
            link = "https://www.youtube.com/watch?v=$videoId",
        )
    }

    /** The continuation token for the next page of videos, if there is one. */
    fun continuation(answer: JsonElement): String? =
        collect(answer, "continuationCommand").lastOrNull()?.text("token")

    /** The videos of a continuation answer (`onResponseReceivedActions`), in order. */
    fun continuationEpisodes(
        answer: JsonObject,
        nowMs: Long,
    ): List<ParsedEpisode> = lockups(answer).mapNotNull { episode(it, nowMs) }

    /** "3 weeks ago", "Streamed 2 days ago", "1 year ago": how long ago, in milliseconds. */
    fun ageMs(text: String): Long? {
        val m = Regex("""(\d+)\s+(second|minute|hour|day|week|month|year)s?\s+ago""").find(text.lowercase()) ?: return null
        val n = m.groupValues[1].toLong()
        val unit =
            when (m.groupValues[2]) {
                "second" -> 1_000L
                "minute" -> 60_000L
                "hour" -> 3_600_000L
                "day" -> 86_400_000L
                "week" -> 7 * 86_400_000L
                "month" -> 30 * 86_400_000L
                else -> 365 * 86_400_000L
            }
        return n * unit
    }

    /** `keywords` is a space-separated list where multi-word entries are quoted. */
    private fun keywords(text: String): List<String> =
        Regex(""""([^"]+)"|(\S+)""")
            .findAll(text)
            .map { (it.groupValues[1].ifEmpty { it.groupValues[2] }).trim() }
            .filter { it.length >= 3 }
            .distinct()
            .toList()

    private fun lockups(answer: JsonElement): List<JsonObject> = collect(answer, "lockupViewModel")

    /** Every value under [key], anywhere in [element], in document order. */
    private fun collect(
        element: JsonElement?,
        key: String,
    ): List<JsonObject> {
        val out = ArrayList<JsonObject>()

        fun walk(e: JsonElement?) {
            when (e) {
                is JsonObject ->
                    for ((k, v) in e) {
                        if (k == key && v is JsonObject) out += v else walk(v)
                    }

                is JsonArray -> e.forEach(::walk)
                else -> {}
            }
        }
        walk(element)
        return out
    }

    private fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject

    private fun JsonObject.array(key: String): JsonArray? = this[key] as? JsonArray

    private fun JsonObject.text(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
}
