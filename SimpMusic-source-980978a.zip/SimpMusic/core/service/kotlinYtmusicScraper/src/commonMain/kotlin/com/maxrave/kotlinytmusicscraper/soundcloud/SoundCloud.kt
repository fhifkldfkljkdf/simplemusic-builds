package com.maxrave.kotlinytmusicscraper.soundcloud

import com.maxrave.ktorext.getEngine
import com.maxrave.logger.Logger
import io.ktor.client.HttpClient
import io.ktor.client.engine.ProxyConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

/**
 * SoundCloud as a backup source: when YouTube will not stream a song, find the same recording on
 * SoundCloud and play that instead.
 *
 * This uses SoundCloud's own public web API, the one soundcloud.com itself calls, with the
 * `client_id` its web player ships in its scripts. No account is involved, and only tracks that
 * SoundCloud streams to anyone in full are used ([SoundCloudMatcher.fullStream]); previews of
 * label releases are skipped rather than played as 30-second clips.
 */
class SoundCloud {
    private val json = Json { ignoreUnknownKeys = true }

    var proxy: ProxyConfig? = null
        set(value) {
            if (field == value) return
            field = value
            client.close()
            client = createClient()
        }

    private var client = createClient()

    private val clientIdMutex = Mutex()
    private var clientId: String? = null
    private var clientIdFetchedAtMs = 0L

    private fun createClient() =
        HttpClient(getEngine()) {
            expectSuccess = false
            install(HttpTimeout) {
                requestTimeoutMillis = REQUEST_TIMEOUT_MS
                connectTimeoutMillis = REQUEST_TIMEOUT_MS
            }
            if (proxy != null) {
                engine {
                    proxy = this@SoundCloud.proxy
                }
            }
        }

    /** The same recording as the song, with a url its audio can be fetched from now. */
    suspend fun findStream(
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): Result<SoundCloudStream> =
        runCatching {
            val queries =
                listOf(SoundCloudMatcher.query(title, artists), SoundCloudMatcher.query(title, emptyList()))
                    .filter { it.isNotBlank() }
                    .distinct()
            for (query in queries) {
                val candidates = search(query)
                val (track, transcoding) =
                    SoundCloudMatcher.pick(candidates, title, artists, durationSeconds) ?: continue
                Logger.d(TAG, "Matched \"$title\" to SoundCloud ${track.id} \"${track.title}\" by ${track.user?.username}")
                return@runCatching resolve(track, transcoding.url, track.trackAuthorization)
            }
            error("No full-length SoundCloud upload matches \"$title\"")
        }

    /** A fresh url for a stream found earlier; the signed url only lives for a few minutes. */
    suspend fun renew(stream: SoundCloudStream): Result<SoundCloudStream> =
        runCatching {
            val url = streamUrl(stream.transcodingUrl, stream.trackAuthorization)
            stream.copy(url = url, validForSeconds = validForSeconds(url))
        }

    private suspend fun resolve(
        track: SoundCloudTrack,
        transcodingUrl: String,
        trackAuthorization: String?,
    ): SoundCloudStream {
        val url = streamUrl(transcodingUrl, trackAuthorization)
        return SoundCloudStream(
            trackId = track.id,
            title = track.title.orEmpty(),
            uploader = track.user?.username.orEmpty(),
            durationMs = track.duration ?: 0L,
            url = url,
            validForSeconds = validForSeconds(url),
            transcodingUrl = transcodingUrl,
            trackAuthorization = trackAuthorization,
        )
    }

    private suspend fun search(query: String): List<SoundCloudTrack> {
        val body =
            api(SEARCH_URL) {
                parameter("q", query)
                parameter("limit", SEARCH_LIMIT)
            }
        return json.decodeFromString<SoundCloudSearchResponse>(body).collection
    }

    private suspend fun streamUrl(
        transcodingUrl: String,
        trackAuthorization: String?,
    ): String {
        val body =
            api(transcodingUrl) {
                if (trackAuthorization != null) parameter("track_authorization", trackAuthorization)
            }
        return json.decodeFromString<SoundCloudStreamUrl>(body).url ?: error("SoundCloud gave no stream url")
    }

    /**
     * A GET against api-v2 with the web player's client_id. SoundCloud rotates that id now and
     * then; a 401 or 403 means it has, so it is fetched again once and the request repeated.
     */
    private suspend fun api(
        url: String,
        params: io.ktor.client.request.HttpRequestBuilder.() -> Unit,
    ): String {
        var response = apiOnce(url, clientId(forceRefresh = false), params)
        if (response.status == HttpStatusCode.Unauthorized || response.status == HttpStatusCode.Forbidden) {
            response = apiOnce(url, clientId(forceRefresh = true), params)
        }
        if (response.status.value !in 200..299) error("SoundCloud answered ${response.status.value}")
        return response.bodyAsText()
    }

    private suspend fun apiOnce(
        url: String,
        id: String,
        params: io.ktor.client.request.HttpRequestBuilder.() -> Unit,
    ): HttpResponse =
        client.get(url) {
            parameter("client_id", id)
            header("User-Agent", USER_AGENT)
            header("Accept", "application/json")
            params()
        }

    @OptIn(ExperimentalTime::class)
    private suspend fun clientId(forceRefresh: Boolean): String =
        clientIdMutex.withLock {
            val now = Clock.System.now().toEpochMilliseconds()
            val cached = clientId
            if (!forceRefresh && cached != null && now - clientIdFetchedAtMs < CLIENT_ID_TTL_MS) return@withLock cached
            val fresh = fetchClientId()
            clientId = fresh
            clientIdFetchedAtMs = now
            fresh
        }

    /** soundcloud.com links its app scripts; one of them, usually a late one, holds the client_id. */
    private suspend fun fetchClientId(): String {
        val page = client.get(HOME_URL) { header("User-Agent", USER_AGENT) }.bodyAsText()
        val scripts = SCRIPT_URL.findAll(page).map { it.value }.distinct().toList()
        for (script in scripts.asReversed()) {
            val source = runCatching { client.get(script) { header("User-Agent", USER_AGENT) }.bodyAsText() }.getOrNull() ?: continue
            CLIENT_ID.find(source)?.let { return it.groupValues[1] }
        }
        error("SoundCloud client_id not found in ${scripts.size} scripts")
    }

    companion object {
        private const val TAG = "SoundCloud"
        private const val HOME_URL = "https://soundcloud.com/"
        private const val SEARCH_URL = "https://api-v2.soundcloud.com/search/tracks"
        private const val SEARCH_LIMIT = 20
        private const val REQUEST_TIMEOUT_MS = 10_000L
        private const val CLIENT_ID_TTL_MS = 6 * 60 * 60 * 1000L

        /** When the policy cannot be read, assume the shortest life SoundCloud has been seen to give. */
        private const val DEFAULT_VALID_SECONDS = 300L

        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

        private val SCRIPT_URL = Regex("""https://a-v2\.sndcdn\.com/assets/[^"'\s]+\.js""")
        private val CLIENT_ID = Regex("""client_id\s*[:=]\s*"([A-Za-z0-9]{32})"""")
        private val POLICY = Regex("""[?&]Policy=([^&]+)""")
        private val EPOCH = Regex(""""AWS:EpochTime"\s*:\s*(\d+)""")

        /**
         * Seconds until the signed url stops working. It is a CloudFront url whose `Policy` is
         * base64 JSON naming the expiry, written with CloudFront's url-safe substitutions.
         */
        @OptIn(ExperimentalEncodingApi::class, ExperimentalTime::class)
        fun validForSeconds(url: String): Long {
            val policy = POLICY.find(url)?.groupValues?.get(1) ?: return DEFAULT_VALID_SECONDS
            val standard = policy.replace('-', '+').replace('_', '=').replace('~', '/')
            val decoded =
                runCatching { Base64.Default.withPadding(Base64.PaddingOption.PRESENT_OPTIONAL).decode(standard).decodeToString() }.getOrNull()
                    ?: return DEFAULT_VALID_SECONDS
            val expiry = EPOCH.find(decoded)?.groupValues?.get(1)?.toLongOrNull() ?: return DEFAULT_VALID_SECONDS
            return (expiry - Clock.System.now().epochSeconds).coerceAtLeast(0L)
        }
    }
}
