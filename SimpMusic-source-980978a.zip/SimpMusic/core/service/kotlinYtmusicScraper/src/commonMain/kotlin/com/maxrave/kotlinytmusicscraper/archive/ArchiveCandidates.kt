package com.maxrave.kotlinytmusicscraper.archive

import com.maxrave.kotlinytmusicscraper.matching.RecordingCandidate
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject

/** A FLAC file on archive.org that can stand in for a song. */
data class ArchiveFile(
    val identifier: String,
    /** The file's path inside the item, as `/metadata` lists it. */
    val name: String,
    val durationMs: Long?,
    val sizeBytes: Long?,
    /** What the file's own header says; filled in once the file has been checked. */
    val flac: FlacInfo? = null,
    /**
     * Where the audio starts, past the metadata. Uploaders often embed a cover of several
     * megabytes, so the first bytes of a file can be all picture. Filled in with [flac].
     */
    val audioOffset: Long = 0,
) {
    /** Average bit rate, from size and length; FLAC is variable, so this is what the file averages. */
    val bitrateBps: Int?
        get() {
            val size = sizeBytes ?: return null
            val ms = durationMs?.takeIf { it > 0 } ?: return null
            return (size * 8 * 1000 / ms).toInt()
        }

    /** More than CD quality: 24-bit or a high sample rate, judged by what it averages. */
    val isHighResolution: Boolean
        get() = flac?.let { it.bitsPerSample > 16 || it.sampleRate > 48_000 } ?: ((bitrateBps ?: 0) > HIGH_RESOLUTION_BPS)

    private companion object {
        /** 16-bit stereo at 48 kHz is 1.54 Mbps before compression; FLAC never averages above that. */
        const val HIGH_RESOLUTION_BPS = 1_600_000
    }
}

/**
 * Turns archive.org's JSON into match candidates. Pure, so the rules can be tested against real
 * responses. archive.org's metadata is loose: `creator` and `collection` are a string or a list,
 * `length` is seconds ("358.46") or a clock ("5:58"), and most uploads give a file no title of its
 * own, so the file name stands in for one.
 */
object ArchiveCandidates {
    /**
     * Collections of material that is never the released recording: isolated tracks and
     * multitracks; concert tapes (the Live Music Archive and the Grateful Dead's own); transfers
     * of 78 rpm records (the Great 78 Project); radio broadcasts.
     */
    private val SKIPPED_COLLECTIONS =
        setOf(
            "stems", "etree", "livemusicarchive", "gratefuldead", "78rpm", "georgeblood", "oldtimeradio",
            "radioprograms", "audio_bookspoetry", "librivoxaudio",
            // Tapers' uploads and "recordings of indeterminate origin": concert bootlegs.
            "taperssection", "roiocollection",
        )

    /** A show's date in an item's title or identifier ("Nirvana Live - 1992-06-27"): a concert tape. */
    private val SHOW_DATE = Regex("""(?<!\d)(19|20)\d{2}-\d{2}-\d{2}(?!\d)""")

    /**
     * Fields only a concert tape fills in: who recorded it, where, and the chain of copies it went
     * through ("SBD > DAT > CD"). The Live Music Archive's tapes carry them wherever they were filed.
     */
    private val TAPE_FIELDS = listOf("venue", "taper", "transferer", "lineage")

    /** `identifier`s from an advancedsearch answer, minus items in [SKIPPED_COLLECTIONS]. */
    fun identifiers(search: JsonElement): List<String> =
        search.jsonObject["response"]
            ?.jsonObject
            ?.get("docs")
            ?.jsonArray
            ?.mapNotNull { doc ->
                val obj = doc as? JsonObject ?: return@mapNotNull null
                if (strings(obj["collection"]).any { it.lowercase() in SKIPPED_COLLECTIONS }) return@mapNotNull null
                if (strings(obj["mediatype"]).any { it.equals("etree", ignoreCase = true) }) return@mapNotNull null
                strings(obj["identifier"]).firstOrNull()
            }.orEmpty()

    /** Every FLAC file of one item, from its `/metadata/<identifier>` answer. */
    fun candidates(
        identifier: String,
        metadata: JsonElement,
    ): List<RecordingCandidate<ArchiveFile>> {
        val root = metadata as? JsonObject ?: return emptyList()
        val item = root["metadata"] as? JsonObject
        if (strings(item?.get("collection")).any { it.lowercase() in SKIPPED_COLLECTIONS }) return emptyList()
        // A concert, not the released recording, even when it plays the same song at the same length.
        if (strings(item?.get("mediatype")).any { it.equals("etree", ignoreCase = true) }) return emptyList()
        if (TAPE_FIELDS.any { strings(item?.get(it)).any(String::isNotBlank) }) return emptyList()
        if (SHOW_DATE.containsMatchIn(identifier) || strings(item?.get("title")).any(SHOW_DATE::containsMatchIn)) return emptyList()
        // Lending-library and darkened items list their files but refuse to serve them: the player
        // would get an error page where the audio should be.
        if (root.isTrue("is_dark") || item.isTrue("access-restricted-item")) return emptyList()
        val itemCreators = strings(item?.get("creator")) + strings(item?.get("artist"))
        val itemTitle = strings(item?.get("title")).firstOrNull().orEmpty()
        // Read for version words only: the item's tags and what its uploader says it was taken from.
        val itemNotes = strings(item?.get("subject")).flatMap { it.split(';') } + strings(item?.get("source"))
        val files = (root["files"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
        // "Flac FingerPrint" (.ffp) is a text file of checksums; only real .flac files count.
        val flacs =
            files.filter { file ->
                strings(file["format"]).any { f -> f.contains("flac", ignoreCase = true) } &&
                    strings(file["name"]).firstOrNull()?.endsWith(".flac", ignoreCase = true) == true &&
                    !file.isTrue("private")
            }
        // A YouTube rip saved as FLAC is lossless in name only: it holds what YouTube's own stream
        // holds, one more generation down. The item then says where it came from.
        if (looksLikeRip(identifier) || looksLikeRip(itemTitle)) return emptyList()
        return flacs.mapNotNull { file ->
            val name = strings(file["name"]).firstOrNull() ?: return@mapNotNull null
            if (looksLikeRip(name) || strings(file["title"]).any(::looksLikeRip)) return@mapNotNull null
            val title =
                strings(file["title"]).firstOrNull()
                    // A single-file item is usually titled after its one song.
                    ?: itemTitle.takeIf { flacs.size == 1 && it.isNotBlank() }
                    ?: titleFromFileName(name)
            RecordingCandidate(
                item =
                    ArchiveFile(
                        identifier = identifier,
                        name = name,
                        durationMs = lengthMs(strings(file["length"]).firstOrNull()),
                        sizeBytes = strings(file["size"]).firstOrNull()?.toLongOrNull(),
                    ),
                title = title,
                artistFields = strings(file["creator"]) + strings(file["artist"]) + itemCreators,
                durationMs = lengthMs(strings(file["length"]).firstOrNull()),
                // "Smells Like Teen Spirit" inside "Boombox Demo Full Cut" is the demo; an item tagged
                // "concert", or whose source note says "vinyl" or "soundboard", is not the release.
                context = (listOf(itemTitle) + itemNotes).joinToString(" "),
            )
        }
    }

    /**
     * Whether a name says the file was taken from a video site: a downloader's name, or the way
     * YouTube titles an upload ("Official Audio", "Official Music Video", "Lyric Video").
     */
    fun looksLikeRip(text: String): Boolean {
        val lower = text.lowercase()
        return RIP_MARKERS.any { it in lower }
    }

    private val RIP_MARKERS =
        listOf(
            "y2mate", "yt1s", "ytmp3", "yt2mp3", "savefrom", "x2convert", "flvto", "onlymp3", "mp3juice", "youtube",
            "official audio", "official video", "official music video", "official lyric video", "lyric video",
            "official visualizer", "(audio)", "[audio]", "(lyrics)", "[lyrics]",
        )

    /** "1)bohemian rhapsody-queen.flac" → "bohemian rhapsody-queen"; "03 - Time.flac" → "Time". */
    fun titleFromFileName(name: String): String =
        name
            .substringAfterLast('/')
            .substringBeforeLast('.')
            .replace('_', ' ')
            .replace(LEADING_TRACK_NUMBER, "")
            .trim()

    /** Seconds ("358.46") or a clock ("5:58", "1:02:03") to milliseconds. */
    fun lengthMs(length: String?): Long? {
        val text = length?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        if (':' !in text) return text.toDoubleOrNull()?.let { (it * 1000).toLong() }
        var seconds = 0.0
        for (part in text.split(':')) seconds = seconds * 60 + (part.toDoubleOrNull() ?: return null)
        return (seconds * 1000).toLong()
    }

    private fun JsonObject?.isTrue(key: String): Boolean =
        this?.get(key)?.let { strings(it).firstOrNull() }?.equals("true", ignoreCase = true) == true

    private val LEADING_TRACK_NUMBER = Regex("""^\s*\d{1,3}\s*[).\-_ ]\s*""")

    private fun strings(element: JsonElement?): List<String> =
        when (element) {
            null -> emptyList()
            is JsonPrimitive -> listOfNotNull(element.contentOrNull)
            is JsonArray -> element.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
            else -> emptyList()
        }
}
