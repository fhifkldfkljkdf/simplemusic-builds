package com.maxrave.kotlinytmusicscraper.pages

import com.maxrave.kotlinytmusicscraper.models.Album
import com.maxrave.kotlinytmusicscraper.models.Artist
import com.maxrave.kotlinytmusicscraper.models.BrowseEndpoint
import com.maxrave.kotlinytmusicscraper.models.MusicResponsiveListItemRenderer
import com.maxrave.kotlinytmusicscraper.models.PlaylistPanelRenderer
import com.maxrave.kotlinytmusicscraper.models.PlaylistPanelVideoRenderer
import com.maxrave.kotlinytmusicscraper.models.SongItem
import com.maxrave.kotlinytmusicscraper.models.WatchEndpoint
import com.maxrave.kotlinytmusicscraper.models.oddElements
import com.maxrave.kotlinytmusicscraper.models.splitBySeparator
import com.maxrave.kotlinytmusicscraper.utils.parseTime

data class NextResult(
    val title: String? = null,
    val items: List<SongItem>,
    val currentIndex: Int? = null,
    val lyricsEndpoint: BrowseEndpoint? = null,
    val relatedEndpoint: BrowseEndpoint? = null,
    val continuation: String?,
    val endpoint: WatchEndpoint, // current or continuation next endpoint
)

object NextPage {
    fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
        val videoId = renderer.videoId ?: return null
        val artistRuns =
            renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.oddElements() ?: return null
        val albumRuns =
            renderer.flexColumns
                .getOrNull(2)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.firstOrNull()
        val setVideoId =
            renderer.menu
                ?.menuRenderer
                ?.items
                ?.find { it.menuServiceItemRenderer?.icon?.iconType == "REMOVE_FROM_PLAYLIST" }
                ?.menuServiceItemRenderer
                ?.serviceEndpoint
                ?.playlistEditEndpoint
                ?.actions
                ?.firstOrNull()
                ?.setVideoId
        return SongItem(
            id = videoId,
            setVideoId = setVideoId,
            title =
                renderer.flexColumns
                    .firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer
                    ?.text
                    ?.runs
                    ?.firstOrNull()
                    ?.text ?: return null,
            artists =
                artistRuns.map {
                    Artist(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId,
                    )
                },
            album =
                albumRuns?.let {
                    Album(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId ?: "",
                    )
                },
            duration =
                renderer.fixedColumns
                    ?.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer
                    ?.text
                    ?.runs
                    ?.firstOrNull()
                    ?.text
                    ?.parseTime(),
            thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: "",
            explicit = false,
            endpoint =
                renderer.flexColumns
                    .firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer
                    ?.text
                    ?.runs
                    ?.firstOrNull()
                    ?.navigationEndpoint
                    ?.watchEndpoint,
            thumbnails = renderer.thumbnail?.musicThumbnailRenderer?.thumbnail,
            musicVideoType = renderer.musicVideoType,
        )
    }

    /** A queue row, carrying its other rendition as [SongItem.counterpart] when YouTube sent one. */
    fun fromPlaylistPanelContent(content: PlaylistPanelRenderer.Content): SongItem? =
        content.track?.let(::fromPlaylistPanelVideoRenderer)?.copy(
            counterpart = content.counterpartTrack?.let(::fromPlaylistPanelVideoRenderer),
        )

    fun fromPlaylistPanelVideoRenderer(renderer: PlaylistPanelVideoRenderer): SongItem? {
        val longByLineRuns = renderer.longBylineText?.runs?.splitBySeparator() ?: return null
        // A video's byline reads "artist • 536M views • 3M likes"; a song's "artist • album • year".
        val hasAlbum = longByLineRuns.getOrNull(1)?.firstOrNull()?.navigationEndpoint?.browseEndpoint != null
        val counts = if (hasAlbum) emptyList() else longByLineRuns.drop(1).map { segment -> segment.joinToString("") { it.text } }
        return SongItem(
            id = renderer.videoId ?: return null,
            title =
                renderer.title
                    ?.runs
                    ?.firstOrNull()
                    ?.text ?: return null,
            artists =
                longByLineRuns.firstOrNull()?.oddElements()?.map {
                    Artist(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId,
                    )
                } ?: return null,
            album =
                longByLineRuns
                    .getOrNull(1)
                    ?.firstOrNull()
                    ?.takeIf {
                        it.navigationEndpoint?.browseEndpoint != null
                    }?.let {
                        Album(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId!!,
                        )
                    },
            duration =
                renderer.lengthText
                    ?.runs
                    ?.firstOrNull()
                    ?.text
                    ?.parseTime() ?: return null,
            thumbnail =
                renderer.thumbnail.thumbnails
                    .lastOrNull()
                    ?.url ?: return null,
            explicit =
                renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
            thumbnails = renderer.thumbnail,
            musicVideoType =
                renderer.navigationEndpoint.watchEndpoint
                    ?.watchEndpointMusicSupportedConfigs
                    ?.watchEndpointMusicConfig
                    ?.musicVideoType,
            viewCount = counts.getOrNull(0)?.let(::parseCount),
            likeCount = counts.getOrNull(1)?.let(::parseCount),
        )
    }

    private val COUNT = Regex("""(\d{1,3}(?:,\d{3})+|\d+(?:[.,]\d+)?)\s*([^\d\s]*)""")

    /**
     * "536M views", "2.1B views", "3M likes", "1,234 views", and the common localised forms
     * ("536 Tr lượt xem", "2,1 Mrd. Aufrufe"). Null for anything without a word in it — a bare
     * number is a year — or with no number.
     */
    internal fun parseCount(text: String): Long? {
        if (text.none { it.isLetter() }) return null
        val match = COUNT.find(text) ?: return null
        val digits = match.groupValues[1]
        val number =
            if (Regex("""\d{1,3}(,\d{3})+""").matches(digits)) {
                digits.replace(",", "").toDoubleOrNull()
            } else {
                digits.replace(',', '.').toDoubleOrNull()
            } ?: return null
        val multiplier =
            when (match.groupValues[2].lowercase().trimEnd('.')) {
                "k", "n", "tsd", "nghìn", "mil" -> 1_000.0
                "m", "mn", "mio", "mln", "tr", "triệu", "mi" -> 1_000_000.0
                "b", "bn", "md", "mrd", "tỷ" -> 1_000_000_000.0
                else -> 1.0
            }
        return (number * multiplier).toLong()
    }
}