package com.maxrave.kotlinytmusicscraper.soundcloud

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** The fields of `api-v2.soundcloud.com/search/tracks` this app reads; everything else is ignored. */
@Serializable
internal data class SoundCloudSearchResponse(
    val collection: List<SoundCloudTrack> = emptyList(),
)

@Serializable
data class SoundCloudTrack(
    val id: Long,
    val title: String? = null,
    /** Milliseconds. For a preview this is the preview's own 30 seconds, not the song's. */
    val duration: Long? = null,
    /** `SNIP` = a 30-second preview only; `ALLOW` and `MONETIZE` stream in full. */
    val policy: String? = null,
    val streamable: Boolean? = null,
    val user: SoundCloudUser? = null,
    @SerialName("publisher_metadata")
    val publisherMetadata: SoundCloudPublisher? = null,
    val media: SoundCloudMedia? = null,
    @SerialName("track_authorization")
    val trackAuthorization: String? = null,
    @SerialName("permalink_url")
    val permalinkUrl: String? = null,
)

@Serializable
data class SoundCloudUser(
    val username: String? = null,
)

@Serializable
data class SoundCloudPublisher(
    val artist: String? = null,
)

@Serializable
data class SoundCloudMedia(
    val transcodings: List<SoundCloudTranscoding> = emptyList(),
)

@Serializable
data class SoundCloudTranscoding(
    /** Not the audio: an API url that answers with a short-lived signed url of the audio. */
    val url: String,
    /** True when this rendition is cut to a preview. */
    val snipped: Boolean? = null,
    val format: SoundCloudTranscodingFormat? = null,
)

@Serializable
data class SoundCloudTranscodingFormat(
    /** `progressive` (one file) or `hls`. */
    val protocol: String? = null,
    @SerialName("mime_type")
    val mimeType: String? = null,
)

@Serializable
internal data class SoundCloudStreamUrl(
    val url: String? = null,
)

/** A SoundCloud upload matched to a song, and a url its audio can be fetched from right now. */
data class SoundCloudStream(
    val trackId: Long,
    val title: String,
    val uploader: String,
    val durationMs: Long,
    /** A signed `cf-media.sndcdn.com` MP3 (128 kbps) that answers range requests. */
    val url: String,
    /** How long [url] stays valid from the moment it was resolved. */
    val validForSeconds: Long,
    /** Kept so [url] can be renewed without searching again. */
    val transcodingUrl: String,
    val trackAuthorization: String?,
)
