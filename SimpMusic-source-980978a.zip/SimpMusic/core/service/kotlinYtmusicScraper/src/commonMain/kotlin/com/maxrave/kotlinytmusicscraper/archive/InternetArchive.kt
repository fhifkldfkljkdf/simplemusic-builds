package com.maxrave.kotlinytmusicscraper.archive

import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher
import com.maxrave.ktorext.getEngine
import com.maxrave.logger.Logger
import io.ktor.client.HttpClient
import io.ktor.client.engine.ProxyConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.prepareGet
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.statement.bodyAsText
import io.ktor.client.statement.bodyAsChannel
import io.ktor.utils.io.readRemaining
import kotlinx.io.readByteArray
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

/**
 * The Internet Archive as a lossless source: FLAC files on archive.org, found through its public
 * search and metadata APIs. No account and no key — everything here is open to anyone.
 *
 * Coverage is patchy: most of what is there was uploaded by users, so one well-known song is in
 * FLAC and the next is not at all. Every candidate therefore goes through [RecordingMatcher]
 * (length within 5 s, the same title and artist, no live/demo/remix/stems version), and when
 * nothing passes, the song plays from YouTube as before. Measured on ten well-known songs on
 * 2026-10-04: items for Queen, the Beatles, Michael Jackson and Nirvana; none for Taylor Swift,
 * Pink Floyd, Eagles or Miles Davis.
 */
class InternetArchive {
    private val json = Json { ignoreUnknownKeys = true }

    var proxy: ProxyConfig? = null
        set(value) {
            if (field == value) return
            field = value
            client.close()
            client = createClient()
        }

    private var client = createClient()

    private fun createClient() =
        HttpClient(getEngine()) {
            expectSuccess = true
            install(HttpTimeout) {
                requestTimeoutMillis = REQUEST_TIMEOUT_MS
                connectTimeoutMillis = REQUEST_TIMEOUT_MS
            }
            if (proxy != null) {
                engine {
                    proxy = this@InternetArchive.proxy
                }
            }
        }

    /** A FLAC file that is the same recording as the song, or a failure when there is none. */
    suspend fun findLossless(
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): Result<ArchiveFile> =
        runCatching {
            val cleanTitle = clean(RecordingMatcher.searchTitle(title))
            val artist = clean(artists.firstOrNull { it.isNotBlank() }.orEmpty())
            require(cleanTitle.isNotEmpty()) { "No title to search for" }
            val queries =
                buildList {
                    // mediatype audio leaves out the Live Music Archive, whose concert recordings are
                    // their own mediatype ("etree"); ArchiveCandidates refuses the rest of what is
                    // not a released recording (other concert tapes, vinyl and 78 rpm transfers).
                    if (artist.isNotEmpty()) {
                        // The song uploaded on its own, titled after it.
                        add("""title:("$cleanTitle") AND creator:("$artist") AND format:(Flac) AND $RELEASES""")
                        // An album or collection by the artist that names the song anywhere.
                        add("""creator:("$artist") AND format:(Flac) AND ("$cleanTitle") AND $RELEASES""")
                    } else {
                        add("""title:("$cleanTitle") AND format:(Flac) AND $RELEASES""")
                    }
                }
            val seen = mutableSetOf<String>()
            for (query in queries) {
                val identifiers = search(query).filter { seen.add(it) }.take(MAX_ITEMS_PER_QUERY)
                if (identifiers.isEmpty()) continue
                val candidates =
                    coroutineScope {
                        identifiers
                            .map { id -> async { runCatching { ArchiveCandidates.candidates(id, metadata(id)) }.getOrDefault(emptyList()) } }
                            .awaitAll()
                            .flatten()
                    }
                val matches = RecordingMatcher.ranked(candidates, title, artists, durationSeconds)
                // CD quality first: Android plays 24-bit as 16-bit and resamples it for the mixer,
                // so a high-resolution file only costs three to six times the data — and stutters
                // on archive.org's slower data nodes.
                val ordered = matches.filter { !it.isHighResolution } + matches.filter { it.isHighResolution }
                for (file in ordered.take(MAX_PROBES)) {
                    val checked = check(file, durationSeconds) ?: continue
                    Logger.d(TAG, "Matched \"$title\" to ${file.identifier}/${file.name} (${checked.flac})")
                    return@runCatching checked
                }
            }
            error("No lossless file on archive.org matches \"$title\"")
        }

    /**
     * [file] with its header read, or null when it is not something the players can use: not a
     * FLAC file after all, more than two channels (a surround mix is another version of the song,
     * and the phone would fold it down), a rate above 96 kHz, a length that does not match after
     * all, or a file archive.org will not serve.
     */
    private suspend fun check(
        file: ArchiveFile,
        durationSeconds: Long,
    ): ArchiveFile? {
        val head =
            runCatching {
                // Read no further than the probe even if a node ignores the range and sends it all.
                client
                    .prepareGet(streamUrl(file)) {
                        header("User-Agent", USER_AGENT)
                        header("Range", "bytes=0-${FlacHeader.PROBE_BYTES - 1}")
                    }.execute { response ->
                        response.bodyAsChannel().readRemaining(FlacHeader.PROBE_BYTES.toLong()).readByteArray()
                    }
            }.getOrElse {
                Logger.d(TAG, "${file.identifier}/${file.name} could not be read: ${it.message}")
                return null
            }
        val info = FlacHeader.parse(head)
        if (info == null) {
            Logger.d(TAG, "${file.identifier}/${file.name} is not a FLAC file")
            return null
        }
        // Above 96 kHz a file streams at 4–6 Mbps for nothing Android lets through (the mixer runs at
        // 48 kHz, the decoder hands over 16 bits), and stutters on archive.org's slower data nodes.
        if (info.channels !in 1..2 || info.sampleRate !in 8_000..MAX_SAMPLE_RATE || info.bitsPerSample !in 8..32) {
            Logger.d(TAG, "${file.identifier}/${file.name} is $info; not used")
            return null
        }
        val lengthMs = info.durationMs
        if (lengthMs != null && durationSeconds > 0 &&
            kotlin.math.abs(lengthMs / 1000.0 - durationSeconds) > RecordingMatcher.DURATION_TOLERANCE_SECONDS
        ) {
            Logger.d(TAG, "${file.identifier}/${file.name} really lasts ${lengthMs / 1000} s; not used")
            return null
        }
        val audioOffset = audioStart(file, head, info) ?: return null
        // Music in FLAC does not compress below a few hundred kbps; a file that averages less is
        // silence, or nearly — a placeholder, a broken transfer. Measured past the cover, which
        // can be most of a short file's size.
        val size = file.sizeBytes
        val ms = lengthMs ?: file.durationMs
        if (size != null && ms != null && ms > 0) {
            val audioBps = (size - audioOffset) * 8 * 1000 / ms
            if (audioBps < MIN_AUDIO_BPS_PER_CHANNEL * info.channels) {
                Logger.d(TAG, "${file.identifier}/${file.name} averages ${audioBps / 1000} kbps of audio, too little to be music; not used")
                return null
            }
        }
        return file.copy(flac = info, durationMs = lengthMs ?: file.durationMs, audioOffset = audioOffset)
    }

    /**
     * Where [file]'s audio starts: its metadata blocks are walked from [head], and a block that
     * runs past it (a large embedded cover) is stepped over with a small read at the next header.
     * Null when the metadata cannot be read, or runs on for more than [MAX_METADATA_BYTES].
     */
    private suspend fun audioStart(
        file: ArchiveFile,
        head: ByteArray,
        info: FlacInfo,
    ): Long? {
        var walk = FlacHeader.walk(head, 0, info.metadataStart.toLong())
        var reads = 0
        while (walk.audioOffset == null) {
            if (++reads > MAX_HEADER_READS || walk.nextHeader > MAX_METADATA_BYTES) {
                Logger.d(TAG, "${file.identifier}/${file.name}: metadata runs past ${walk.nextHeader} bytes; not used")
                return null
            }
            val at = walk.nextHeader
            val bytes =
                runCatching {
                    client
                        .prepareGet(streamUrl(file)) {
                            header("User-Agent", USER_AGENT)
                            header("Range", "bytes=$at-${at + HEADER_READ_BYTES - 1}")
                        }.execute { response -> response.bodyAsChannel().readRemaining(HEADER_READ_BYTES.toLong()).readByteArray() }
                }.getOrElse {
                    Logger.d(TAG, "${file.identifier}/${file.name}: metadata at $at could not be read: ${it.message}")
                    return null
                }
            walk = FlacHeader.walk(bytes, at, at)
        }
        return walk.audioOffset
    }

    /** The file's address; archive.org redirects it to the data node holding the item. */
    fun streamUrl(file: ArchiveFile): String = "$DOWNLOAD_URL${encodePath(file.identifier)}/${encodePath(file.name)}"

    private suspend fun search(query: String): List<String> {
        val body =
            client
                .get(SEARCH_URL) {
                    header("User-Agent", USER_AGENT)
                    parameter("q", query)
                    parameter("fl[]", "identifier")
                    parameter("fl[]", "collection")
                    parameter("fl[]", "mediatype")
                    parameter("rows", SEARCH_ROWS)
                    parameter("output", "json")
                }.bodyAsText()
        return ArchiveCandidates.identifiers(json.parseToJsonElement(body))
    }

    private suspend fun metadata(identifier: String): JsonElement =
        json.parseToJsonElement(
            client.get(METADATA_URL + encodePath(identifier)) { header("User-Agent", USER_AGENT) }.bodyAsText(),
        )

    companion object {
        private const val TAG = "InternetArchive"
        private const val SEARCH_URL = "https://archive.org/advancedsearch.php"
        private const val METADATA_URL = "https://archive.org/metadata/"
        private const val DOWNLOAD_URL = "https://archive.org/download/"
        private const val REQUEST_TIMEOUT_MS = 8_000L
        private const val SEARCH_ROWS = 12
        private const val MAX_ITEMS_PER_QUERY = 6
        private const val MAX_PROBES = 3
        private const val MAX_SAMPLE_RATE = 96_000

        /** Released recordings only; see the search queries. */
        private const val RELEASES = "mediatype:(audio)"

        /** Below this per channel, a FLAC file holds silence or close to it (music is 300+ kbps a channel). */
        private const val MIN_AUDIO_BPS_PER_CHANNEL = 100_000L

        /** Block headers to step to past an oversized block, and how far the metadata may run. */
        private const val MAX_HEADER_READS = 6
        private const val MAX_METADATA_BYTES = 16L * 1024 * 1024
        private const val HEADER_READ_BYTES = 4_096
        private const val USER_AGENT = "SimpMusic (private build)"

        /** Quotes and backslashes would end the quoted phrase early in archive.org's query syntax. */
        private fun clean(text: String): String = text.replace("\"", " ").replace("\\", " ").trim()

        /** Percent-encodes each path segment, keeping the slashes between them. */
        fun encodePath(path: String): String =
            path.split('/').joinToString("/") { segment ->
                buildString {
                    for (byte in segment.encodeToByteArray()) {
                        val c = byte.toInt() and 0xFF
                        val ch = c.toChar()
                        if (ch.isLetterOrDigit() && c < 0x80 || ch in "-._~") {
                            append(ch)
                        } else {
                            append('%')
                            append(HEX[c shr 4])
                            append(HEX[c and 0xF])
                        }
                    }
                }
            }

        private const val HEX = "0123456789ABCDEF"
    }
}
