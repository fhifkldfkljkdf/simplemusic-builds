package com.maxrave.kotlinytmusicscraper.soundcloud

import com.maxrave.kotlinytmusicscraper.matching.RecordingCandidate
import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher

/**
 * Picks the SoundCloud upload that is the same recording as a song from YouTube Music, or nothing.
 *
 * SoundCloud's own gate comes first: the track must stream in full. Major-label tracks on
 * SoundCloud are mostly `SNIP` previews; those are out. Everything else — length, version words,
 * title, artist — is [RecordingMatcher], with the publisher's artist tag and the uploader's name as
 * the artist fields.
 */
object SoundCloudMatcher {
    const val DURATION_TOLERANCE_SECONDS = RecordingMatcher.DURATION_TOLERANCE_SECONDS

    /** "artist title", the way a person would search for the song. */
    fun query(
        title: String,
        artists: List<String>,
    ): String = RecordingMatcher.query(title, artists)

    /** Letters and digits of the song's name, without upload decorations or featured artists. */
    fun titleKey(title: String): String = RecordingMatcher.titleKey(title)

    /**
     * The best of [candidates] for the song, with the progressive MP3 rendition to play, or null
     * when none of them is the same recording.
     */
    fun pick(
        candidates: List<SoundCloudTrack>,
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): Pair<SoundCloudTrack, SoundCloudTranscoding>? =
        RecordingMatcher.pick(
            candidates.mapNotNull { track ->
                val transcoding = fullStream(track) ?: return@mapNotNull null
                RecordingCandidate(
                    item = track to transcoding,
                    title = track.title.orEmpty(),
                    artistFields = listOfNotNull(track.publisherMetadata?.artist, track.user?.username),
                    durationMs = track.duration,
                )
            },
            title,
            artists,
            durationSeconds,
        )

    /** The one-file MP3 rendition, if the track streams in full. */
    fun fullStream(track: SoundCloudTrack): SoundCloudTranscoding? {
        if (track.policy.equals("SNIP", ignoreCase = true)) return null
        if (track.streamable == false) return null
        return track.media?.transcodings?.firstOrNull {
            it.snipped != true &&
                it.format?.protocol == "progressive" &&
                it.format?.mimeType?.startsWith("audio/mpeg") == true
        }
    }
}
