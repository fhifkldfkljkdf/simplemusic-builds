package com.maxrave.kotlinytmusicscraper.monochrome

import com.maxrave.kotlinytmusicscraper.matching.RecordingCandidate
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.longOrNull

/** A track on Monochrome's track streamer that can stand in for a song. */
data class MonochromeTrack(
    val id: String,
    val title: String,
    /** The release's artists, in TIDAL's order; the first is the main one. */
    val artists: List<String>,
    val durationMs: Long?,
    val isrc: String?,
    /** The whole file's average bitrate, from its size and the song's length; null when unknown. */
    val bitrateBps: Int? = null,
)

/**
 * Turns Monochrome search results into match candidates. Pure, so the rules can be tested against
 * real answers.
 *
 * Monochrome streams TIDAL, whose catalog is the official releases, so this does not need Audius's
 * uploader rules: the shared matcher's title, artist and length gates already keep out the live
 * take, the remix and the wrong recording.
 */
object MonochromeCandidates {
    fun candidates(search: JsonElement): List<RecordingCandidate<MonochromeTrack>> {
        val rows = (search as? JsonObject)?.get("tracks") ?: return emptyList()
        return runCatching { rows.jsonArray }.getOrNull().orEmpty().mapNotNull { row ->
            val track = row as? JsonObject ?: return@mapNotNull null
            if (bool(track["playable"]) == false) return@mapNotNull null
            val id = text(track["trackId"]) ?: text(track["id"]) ?: return@mapNotNull null
            val title = text(track["title"]) ?: return@mapNotNull null
            val names = (track["artistNames"] as? JsonArray)?.mapNotNull { text(it) }.orEmpty()
            val durationMs = (track["duration"] as? JsonPrimitive)?.longOrNull
            RecordingCandidate(
                item = MonochromeTrack(id = id, title = title, artists = names, durationMs = durationMs, isrc = text(track["isrc"])),
                title = title,
                artistFields = names,
                durationMs = durationMs,
            )
        }
    }

    private fun text(element: JsonElement?): String? = (element as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull?.trim()?.takeIf { it.isNotEmpty() }

    private fun bool(element: JsonElement?): Boolean? = (element as? JsonPrimitive)?.booleanOrNull
}
