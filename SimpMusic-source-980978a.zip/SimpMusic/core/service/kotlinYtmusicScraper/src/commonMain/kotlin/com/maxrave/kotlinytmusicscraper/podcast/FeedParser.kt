package com.maxrave.kotlinytmusicscraper.podcast

/** A feed as read: a podcast's RSS, or a YouTube channel's or playlist's Atom feed. */
data class ParsedFeed(
    val title: String,
    val author: String?,
    val description: String?,
    val imageUrl: String?,
    val link: String?,
    /** iTunes categories and the feed's own `<category>` words, most specific last. */
    val categories: List<String>,
    /** `itunes:keywords`, split. */
    val keywords: List<String>,
    /** Newest first, at most [FeedParser.MAX_EPISODES]. */
    val episodes: List<ParsedEpisode>,
    /** The channel id when this is a YouTube feed. */
    val youTubeChannelId: String?,
)

data class ParsedEpisode(
    /** The feed's own id for the episode (`guid`, Atom `id`), else its audio address. */
    val guid: String,
    val title: String,
    val description: String?,
    val publishedAtMs: Long?,
    val durationSeconds: Int?,
    /** The enclosure: what plays. Null for a YouTube entry, which plays as [youTubeVideoId]. */
    val audioUrl: String?,
    val audioType: String?,
    val imageUrl: String?,
    val youTubeVideoId: String?,
    val link: String?,
)

/** Turns a feed's XML into [ParsedFeed]: RSS 2.0 (with iTunes tags), RSS 1.0 and Atom. */
object FeedParser {
    /** Huge back catalogues are cut: the newest this many episodes are what a listener scrolls. */
    const val MAX_EPISODES = 300
    private const val MAX_DESCRIPTION = 4000

    fun parse(xml: String): ParsedFeed? {
        val document = FeedXml.parse(xml)
        document.child("rss")?.let { rss -> return rss.child("channel")?.let { rss(it, it.all("item")) } }
        document.child("rdf:RDF")?.let { rdf -> return rdf.child("channel")?.let { rss(it, rdf.all("item")) } }
        document.child("feed")?.let { return atom(it) }
        return null
    }

    private fun rss(
        channel: FeedElement,
        items: List<FeedElement>,
    ): ParsedFeed? {
        val title = channel.childText("title")?.let(::oneLine) ?: return null
        val episodes =
            items
                .mapNotNull(::rssEpisode)
                .sortedByDescending { it.publishedAtMs ?: Long.MIN_VALUE }
                .take(MAX_EPISODES)
        val categories = ArrayList<String>()
        fun addCategories(element: FeedElement) {
            for (category in element.all("itunes:category")) {
                category.attribute("text")?.let { categories += FeedXml.decodeEntities(it).trim() }
                addCategories(category)
            }
        }
        addCategories(channel)
        channel.all("category").mapNotNullTo(categories) { it.deepText().takeIf(String::isNotBlank) }
        return ParsedFeed(
            title = title,
            author =
                (
                    channel.childText("itunes:author")
                        ?: channel.child("itunes:owner")?.childText("itunes:name")
                        ?: channel.childText("dc:creator")
                        ?: channel.childText("managingEditor")
                )?.let(::oneLine),
            description = (channel.childText("itunes:summary") ?: channel.childText("description"))?.let(::plainText),
            imageUrl =
                channel.child("itunes:image")?.attribute("href")
                    ?: channel.child("image")?.childText("url")
                    ?: channel.child("media:thumbnail")?.attribute("url"),
            link = channel.childText("link")?.takeIf { it.startsWith("http") },
            categories = categories.distinct(),
            keywords =
                channel
                    .childText("itunes:keywords")
                    ?.split(',')
                    ?.map { it.trim() }
                    ?.filter { it.isNotEmpty() }
                    .orEmpty(),
            episodes = episodes,
            youTubeChannelId = null,
        )
    }

    private fun rssEpisode(item: FeedElement): ParsedEpisode? {
        val enclosure =
            item.all("enclosure").firstOrNull { it.attribute("type")?.startsWith("audio") == true }
                ?: item.all("enclosure").firstOrNull { it.attribute("url") != null }
                ?: item.child("media:group")?.all("media:content")?.firstOrNull { it.attribute("type")?.startsWith("audio") == true }
                ?: item.all("media:content").firstOrNull { it.attribute("type")?.startsWith("audio") == true }
        val audioUrl = enclosure?.attribute("url")?.trim()?.takeIf { it.startsWith("http") } ?: return null
        val title = item.childText("title")?.let(::oneLine) ?: item.childText("itunes:title")?.let(::oneLine) ?: return null
        return ParsedEpisode(
            guid = item.childText("guid") ?: audioUrl,
            title = title,
            description =
                (item.childText("itunes:summary") ?: item.childText("description") ?: item.childText("content:encoded"))
                    ?.let(::plainText),
            publishedAtMs = (item.childText("pubDate") ?: item.childText("dc:date"))?.let(::parseDate),
            durationSeconds = item.childText("itunes:duration")?.let(::parseDuration),
            audioUrl = audioUrl,
            audioType = enclosure.attribute("type"),
            imageUrl = item.child("itunes:image")?.attribute("href") ?: item.child("media:thumbnail")?.attribute("url"),
            youTubeVideoId = null,
            link = item.childText("link")?.takeIf { it.startsWith("http") },
        )
    }

    private fun atom(feed: FeedElement): ParsedFeed? {
        val title = feed.childText("title")?.let(::oneLine) ?: return null
        val channelId =
            feed.childText("yt:channelId")?.let { if (it.startsWith("UC")) it else "UC$it" }
                ?: feed.all("entry").firstNotNullOfOrNull { it.childText("yt:channelId") }
        val episodes =
            feed
                .all("entry")
                .mapNotNull(::atomEpisode)
                .sortedByDescending { it.publishedAtMs ?: Long.MIN_VALUE }
                .take(MAX_EPISODES)
        val alternate = feed.all("link").firstOrNull { it.attribute("rel").let { rel -> rel == null || rel == "alternate" } }?.attribute("href")
        return ParsedFeed(
            title = title,
            author = feed.child("author")?.childText("name")?.let(::oneLine),
            description = feed.childText("subtitle")?.let(::plainText),
            // YouTube's channel feed has no picture of its own; the newest video's thumbnail stands in.
            imageUrl = feed.childText("icon") ?: feed.childText("logo") ?: episodes.firstOrNull()?.imageUrl,
            link = alternate,
            categories = feed.all("category").mapNotNull { it.attribute("term") ?: it.attribute("label") },
            keywords = emptyList(),
            episodes = episodes,
            youTubeChannelId = channelId,
        )
    }

    private fun atomEpisode(entry: FeedElement): ParsedEpisode? {
        val group = entry.child("media:group")
        val links = entry.all("link")
        val alternate = links.firstOrNull { it.attribute("rel").let { rel -> rel == null || rel == "alternate" } }?.attribute("href")
        // A channel's Shorts are clips of its episodes, not episodes.
        if (alternate?.contains("/shorts/") == true) return null
        val videoId = entry.childText("yt:videoId") ?: alternate?.let(::youTubeVideoIdOf)
        val enclosure = links.firstOrNull { it.attribute("rel") == "enclosure" }
        val audioUrl = enclosure?.attribute("href")?.takeIf { it.startsWith("http") }
        if (videoId == null && audioUrl == null) return null
        val title = (entry.childText("title") ?: group?.childText("media:title"))?.let(::oneLine) ?: return null
        return ParsedEpisode(
            guid = entry.childText("id") ?: videoId ?: audioUrl!!,
            title = title,
            description = (group?.childText("media:description") ?: entry.childText("summary") ?: entry.childText("content"))?.let(::plainText),
            publishedAtMs = (entry.childText("published") ?: entry.childText("updated"))?.let(::parseDate),
            durationSeconds = null,
            audioUrl = if (videoId == null) audioUrl else null,
            audioType = enclosure?.attribute("type"),
            imageUrl = group?.child("media:thumbnail")?.attribute("url") ?: videoId?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" },
            youTubeVideoId = videoId,
            link = alternate,
        )
    }

    /** The id in a watch, shorts or youtu.be link. */
    fun youTubeVideoIdOf(url: String): String? =
        Regex("""(?:[?&]v=|/shorts/|youtu\.be/|/live/)([A-Za-z0-9_-]{11})""").find(url)?.groupValues?.get(1)

    private fun oneLine(text: String): String = text.replace(Regex("\\s+"), " ").trim()

    /** HTML as text: paragraphs and line breaks kept as new lines, every other tag dropped. */
    fun plainText(html: String): String? {
        val text =
            html
                .replace(Regex("(?i)<br\\s*/?>"), "\n")
                .replace(Regex("(?i)</(p|div|li|h[1-6])>"), "\n")
                .replace(Regex("(?i)<li[^>]*>"), "• ")
                .replace(Regex("<[^>]*>"), "")
                .let(FeedXml::decodeEntities)
                .lines()
                .map { it.replace(Regex("[ \\t\\u00A0]+"), " ").trim() }
                .joinToString("\n")
                .replace(Regex("\n{3,}"), "\n\n")
                .trim()
        if (text.isEmpty()) return null
        return if (text.length > MAX_DESCRIPTION) text.take(MAX_DESCRIPTION).trimEnd() + "…" else text
    }

    /** `itunes:duration`: seconds ("3723", "3723.5") or a clock ("62:03", "1:02:03"). */
    fun parseDuration(text: String): Int? {
        val parts = text.trim().split(':')
        if (parts.size == 1) return parts[0].toDoubleOrNull()?.takeIf { it >= 0 }?.toInt()
        if (parts.size > 3) return null
        var seconds = 0
        for (part in parts) {
            val value = part.trim().toDoubleOrNull()?.toInt() ?: return null
            if (value < 0) return null
            seconds = seconds * 60 + value
        }
        return seconds
    }

    /** RFC 822 (`Tue, 26 May 2026 05:00:00 -0000`, RSS) or ISO 8601 (`2026-09-17T00:34:47+00:00`, Atom). */
    fun parseDate(text: String): Long? = parseIso(text.trim()) ?: parseRfc822(text.trim())

    private val ISO =
        Regex("""^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?)?\s*(Z|[+-]\d{2}:?\d{2})?$""")

    private fun parseIso(text: String): Long? {
        val m = ISO.find(text) ?: return null
        val g = m.groupValues
        return epochMs(
            year = g[1].toInt(),
            month = g[2].toInt(),
            day = g[3].toInt(),
            hour = g[4].toIntOrNull() ?: 0,
            minute = g[5].toIntOrNull() ?: 0,
            second = g[6].toIntOrNull() ?: 0,
            offsetMinutes = g[7].let(::offsetMinutes),
        )
    }

    private val MONTHS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    private fun parseRfc822(text: String): Long? {
        val tokens =
            text
                .substringAfter(',', text)
                .trim()
                .split(Regex("\\s+"))
        if (tokens.size < 3) return null
        val day = tokens[0].toIntOrNull() ?: return null
        val month = MONTHS.indexOf(tokens[1].take(3).lowercase()).takeIf { it >= 0 }?.plus(1) ?: return null
        var year = tokens[2].toIntOrNull() ?: return null
        if (year < 100) year += if (year < 70) 2000 else 1900
        val time = tokens.getOrNull(3)?.split(':')
        val hour = time?.getOrNull(0)?.toIntOrNull() ?: 0
        val minute = time?.getOrNull(1)?.toIntOrNull() ?: 0
        val second = time?.getOrNull(2)?.toIntOrNull() ?: 0
        return epochMs(year, month, day, hour, minute, second, offsetMinutes(tokens.getOrNull(4).orEmpty()))
    }

    private val ZONES = mapOf("EST" to -300, "EDT" to -240, "CST" to -360, "CDT" to -300, "MST" to -420, "MDT" to -360, "PST" to -480, "PDT" to -420)

    private fun offsetMinutes(zone: String): Int {
        if (zone.isEmpty() || zone == "Z") return 0
        ZONES[zone.uppercase()]?.let { return it }
        val m = Regex("""^([+-])(\d{2}):?(\d{2})$""").find(zone) ?: return 0
        val minutes = m.groupValues[2].toInt() * 60 + m.groupValues[3].toInt()
        return if (m.groupValues[1] == "-") -minutes else minutes
    }

    private fun epochMs(
        year: Int,
        month: Int,
        day: Int,
        hour: Int,
        minute: Int,
        second: Int,
        offsetMinutes: Int,
    ): Long? {
        if (month !in 1..12 || day !in 1..31 || hour !in 0..24 || minute !in 0..59 || second !in 0..60) return null
        // Days from 1970-01-01 to the date (Howard Hinnant's days_from_civil).
        val y = if (month <= 2) year - 1 else year
        val era = (if (y >= 0) y else y - 399) / 400
        val yoe = y - era * 400
        val doy = (153 * (month + (if (month > 2) -3 else 9)) + 2) / 5 + day - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        val days = era.toLong() * 146097 + doe - 719468
        val seconds = days * 86_400 + hour * 3600 + minute * 60 + second - offsetMinutes * 60L
        return seconds * 1000
    }
}
