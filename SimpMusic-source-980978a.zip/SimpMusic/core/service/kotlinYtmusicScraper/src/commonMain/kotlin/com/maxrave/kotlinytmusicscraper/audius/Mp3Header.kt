package com.maxrave.kotlinytmusicscraper.audius

/** What the first frame of an MP3 file says about it. */
data class Mp3Info(
    val bitrateBps: Int,
    val sampleRate: Int,
    val channels: Int,
)

/**
 * Reads the first MPEG audio frame of a file's opening bytes, after any ID3v2 tag. Pure, for tests.
 * Only Layer III is accepted: anything else is not an MP3 a player would expect here.
 */
object Mp3Header {
    /** Enough for an ID3 tag with a small cover picture and the first frame after it. */
    const val PROBE_BYTES = 64 * 1024

    private val V1_L3_KBPS = intArrayOf(0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0)
    private val V2_L3_KBPS = intArrayOf(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0)
    private val V1_RATES = intArrayOf(44_100, 48_000, 32_000)

    fun parse(bytes: ByteArray): Mp3Info? {
        var i = 0
        if (bytes.size >= 10 && bytes[0] == 'I'.code.toByte() && bytes[1] == 'D'.code.toByte() && bytes[2] == '3'.code.toByte()) {
            val size = syncSafe(bytes, 6)
            val footer = (bytes[5].toInt() and 0x10) != 0
            i = 10 + size + if (footer) 10 else 0
        }
        while (i + 4 <= bytes.size) {
            val b0 = bytes[i].toInt() and 0xFF
            val b1 = bytes[i + 1].toInt() and 0xFF
            if (b0 == 0xFF && (b1 and 0xE0) == 0xE0) {
                frame(bytes, i)?.let { return it }
            }
            i++
        }
        return null
    }

    private fun frame(
        bytes: ByteArray,
        at: Int,
    ): Mp3Info? {
        val b1 = bytes[at + 1].toInt() and 0xFF
        val b2 = bytes[at + 2].toInt() and 0xFF
        val b3 = bytes[at + 3].toInt() and 0xFF
        val version = (b1 shr 3) and 3 // 3 = MPEG 1, 2 = MPEG 2, 0 = MPEG 2.5, 1 = reserved
        val layer = (b1 shr 1) and 3 // 1 = Layer III
        if (version == 1 || layer != 1) return null
        val bitrateIndex = (b2 shr 4) and 0xF
        val rateIndex = (b2 shr 2) and 3
        if (bitrateIndex == 0 || bitrateIndex == 15 || rateIndex == 3) return null
        val kbps = if (version == 3) V1_L3_KBPS[bitrateIndex] else V2_L3_KBPS[bitrateIndex]
        val rate =
            when (version) {
                3 -> V1_RATES[rateIndex]
                2 -> V1_RATES[rateIndex] / 2
                else -> V1_RATES[rateIndex] / 4
            }
        val channels = if ((b3 shr 6) and 3 == 3) 1 else 2
        return Mp3Info(bitrateBps = kbps * 1000, sampleRate = rate, channels = channels)
    }

    private fun syncSafe(
        bytes: ByteArray,
        at: Int,
    ): Int =
        ((bytes[at].toInt() and 0x7F) shl 21) or ((bytes[at + 1].toInt() and 0x7F) shl 14) or
            ((bytes[at + 2].toInt() and 0x7F) shl 7) or (bytes[at + 3].toInt() and 0x7F)
}
