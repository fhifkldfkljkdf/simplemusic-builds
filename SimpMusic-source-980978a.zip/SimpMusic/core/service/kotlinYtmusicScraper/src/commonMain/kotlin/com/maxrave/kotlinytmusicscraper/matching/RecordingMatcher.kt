package com.maxrave.kotlinytmusicscraper.matching

import com.maxrave.domain.mediaservice.handler.RadioCurator
import kotlin.math.abs

/** One upload a backup source offers for a song, reduced to what matching needs. */
data class RecordingCandidate<T>(
    /** What the caller gets back when this candidate wins. */
    val item: T,
    val title: String,
    /** Fields that name who made it: an artist tag, the uploader, the album's creator… */
    val artistFields: List<String>,
    val durationMs: Long?,
    /**
     * Text around the upload that is not its title but can say it is another version: the album
     * or item it sits in ("Live at Wembley", "Boombox Demo"). Only read for version words.
     */
    val context: String = "",
)

/**
 * Picks, among uploads on some other site, the one that is the same recording as a song from
 * YouTube Music, or nothing. Shared by the SoundCloud backup and the Internet Archive lossless
 * source; each source first drops what it cannot play in full, then hands the rest here.
 *
 * Nothing is the right answer far more often than a guess: a remix, a live take or a demo is worse
 * than the stream it replaces. So a candidate has to clear every gate below, and only then is the
 * best of them taken.
 *
 * - Its length is within [DURATION_TOLERANCE_SECONDS] of the song's. This is what separates the
 *   album take from the radio edit, the live version and the extended mix, which a title cannot.
 * - It does not call itself another version ("remix", "live", "stems"…) unless the song does.
 * - Its title, with the upload decorations removed and an "Artist - " part split off, is the
 *   song's title.
 * - The song's artist appears: in an artist field, or in the title — as the whole name or its
 *   start, never merely contained ("Killer Queen Band Page" is a Queen tribute band).
 */
object RecordingMatcher {
    const val DURATION_TOLERANCE_SECONDS = 5L

    /** Anything shorter is a preview or a clip, never a whole song. */
    private const val MIN_DURATION_MS = 30_500L

    /** Words that mark another recording of the song. Refused unless the song's own title has them. */
    private val OTHER_VERSION_WORDS =
        setOf(
            "remix", "cover", "live", "sped", "speed", "slowed", "nightcore", "reverb", "karaoke",
            "instrumental", "acoustic", "8d", "mashup", "bootleg", "rework", "extended", "edit", "piano",
            "chipmunk", "reversed", "loop", "hour", "hours", "boosted", "tiktok", "flip", "vip", "demo",
            "unreleased", "snippet", "preview", "parody", "tribute", "medley", "multitrack", "multitracks",
            "stem", "stems", "acapella", "isolated", "recreation", "boombox",
            // Concert recordings and session takes: the same song, not the released recording.
            "concert", "tour", "festival", "gig", "soundboard", "sbd", "unplugged", "rehearsal", "session",
            "sessions", "outtake", "outtakes", "alternate",
            // Transfers from records and tapes: the release, but through a needle or a tape head.
            "vinyl", "needledrop", "shellac", "cassette", "78rpm", "acetate",
        )

    /** A bracket holding any of these names an upload, not a song: "(Official Video)", "[HD]". */
    private val BRACKET_UPLOAD_WORDS =
        setOf(
            "official", "video", "audio", "lyric", "lyrics", "visualizer", "visualiser", "hd", "hq", "4k",
            "remaster", "remastered", "mv", "explicit", "clean", "feat", "ft", "featuring", "with", "prod",
            "from", "letra", "download",
        )

    /** A dashed part made only of these (and numbers) is a decoration too: " - Remastered 2011". */
    private val DASH_UPLOAD_WORDS =
        BRACKET_UPLOAD_WORDS +
            setOf(
                "single", "mono", "stereo", "original", "mix", "version", "radio", "the", "music", "full",
                "album", "song", "free", "out", "now", "dl", "m", "v",
            )

    private val BRACKETED = Regex("""[(\[{]([^)\]}]*)[)\]}]""")
    private val FEATURING = Regex("""\s(feat\.?|ft\.?|featuring)\s.*$""", RegexOption.IGNORE_CASE)
    private val DASHES = Regex("""\s[-–—|]\s""")

    /** The song's title as a search box wants it: no upload decorations, no featured artists. */
    fun searchTitle(title: String): String = FEATURING.replace(dropUploadParts(title), "").trim()

    /** "artist title", the way a person would search for the song. */
    fun query(
        title: String,
        artists: List<String>,
    ): String {
        val cleanTitle = FEATURING.replace(dropUploadParts(title), "").trim()
        val artist = artists.firstOrNull { it.isNotBlank() }.orEmpty()
        return listOf(artist, cleanTitle).filter { it.isNotBlank() }.joinToString(" ")
    }

    /**
     * The best of [candidates] for the song, or null when none of them is the same recording.
     * [durationSeconds] <= 0 means the length is unknown, and then only an exact title by a named
     * artist is accepted.
     */
    fun <T> pick(
        candidates: List<RecordingCandidate<T>>,
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): T? = ranked(candidates, title, artists, durationSeconds).firstOrNull()

    /**
     * Every candidate that is the same recording as the song, best first; empty when none is.
     * For a source whose files still have to be checked before use, so a file that fails the check
     * gives way to the next match instead of to nothing.
     */
    fun <T> ranked(
        candidates: List<RecordingCandidate<T>>,
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): List<T> {
        val wantTitle = titleKey(title)
        if (wantTitle.isEmpty()) return emptyList()
        val wantArtists = artists.map(RadioCurator::artistKey).filter { it.isNotEmpty() }
        val songWords = words(title)

        return candidates
            .mapIndexedNotNull { order, candidate ->
                val lengthMs = candidate.durationMs ?: return@mapIndexedNotNull null
                if (lengthMs < MIN_DURATION_MS) return@mapIndexedNotNull null
                val off = if (durationSeconds > 0) abs(lengthMs / 1000.0 - durationSeconds) else 0.0
                if (off > DURATION_TOLERANCE_SECONDS) return@mapIndexedNotNull null

                val otherVersion =
                    (words(candidate.title) + words(candidate.context)).any { it in OTHER_VERSION_WORDS && it !in songWords }
                if (otherVersion) return@mapIndexedNotNull null

                val titleScore = titleScore(wantTitle, candidate.title)
                if (titleScore == 0) return@mapIndexedNotNull null
                val artistScore = artistScore(wantArtists, candidate)
                if (wantArtists.isNotEmpty() && artistScore == 0) return@mapIndexedNotNull null
                if (durationSeconds <= 0 && (titleScore < 3 || artistScore < 2)) return@mapIndexedNotNull null

                Scored(candidate.item, titleScore * 10 + artistScore * 5 - off, order)
            }.sortedWith(compareByDescending<Scored<T>> { it.score }.thenBy { it.order })
            .map { it.item }
    }

    private class Scored<T>(
        val item: T,
        val score: Double,
        val order: Int,
    )

    /** 3 = the title is the song's, 1 = it contains the song's title and something more. */
    private fun titleScore(
        want: String,
        candidateTitle: String,
    ): Int {
        val keys = candidateTitleKeys(candidateTitle)
        if (want in keys) return 3
        if (want.length >= 4 && keys.any { it.contains(want) }) return 1
        return 0
    }

    /** 2 = an artist field names the song's artist, 1 = only the title does, 0 = nothing does. */
    private fun artistScore(
        wantArtists: List<String>,
        candidate: RecordingCandidate<*>,
    ): Int {
        if (wantArtists.isEmpty()) return 0
        val fields = candidate.artistFields.map(RadioCurator::artistKey).filter { it.isNotEmpty() }
        if (wantArtists.any { want -> fields.any { sameArtist(want, it) } }) return 2
        val title = candidate.title
        val titleArtists = title.split(DASHES).map(RadioCurator::artistKey)
        if (wantArtists.any { want -> titleArtists.any { sameArtist(want, it) } }) return 1
        val whole = compact(title)
        if (wantArtists.any { it.length >= 3 && whole.startsWith(it) }) return 1
        return 0
    }

    /**
     * The same name, or one that only adds words after it ("Queen Band" for "Queen"). Never a name
     * that merely contains the artist's: "Killer Queen Band Page" is a Queen tribute band, and its
     * uploads are covers at exactly the right length.
     */
    private fun sameArtist(
        want: String,
        field: String,
    ): Boolean = want == field || (minOf(want.length, field.length) >= 4 && (field.startsWith(want) || want.startsWith(field)))

    /** The title as it might be read: whole, and each side of an "Artist - Title" split. */
    private fun candidateTitleKeys(title: String): Set<String> {
        val cleaned = dropUploadParts(title)
        val parts = cleaned.split(DASHES).filter { it.isNotBlank() }
        val keys = mutableSetOf(titleKey(cleaned))
        if (parts.size >= 2) {
            keys += titleKey(parts.drop(1).joinToString(" "))
            keys += titleKey(parts.dropLast(1).joinToString(" "))
            parts.forEach { keys += titleKey(it) }
        }
        return keys.filterTo(mutableSetOf()) { it.isNotEmpty() }
    }

    /** Letters and digits of the song's name, without upload decorations or featured artists. */
    fun titleKey(title: String): String = compact(FEATURING.replace(dropUploadParts(title), ""))

    /** "(Official Video)", "[HD]", " - Remastered 2011" and the like, removed; anything else kept. */
    private fun dropUploadParts(title: String): String {
        val noBrackets =
            BRACKETED.replace(title) { match ->
                val inside = match.groupValues[1]
                val upload = compact(inside) in BRACKET_UPLOAD_WORDS || words(inside).any { it in BRACKET_UPLOAD_WORDS }
                if (upload) " " else match.value
            }
        val parts = noBrackets.split(DASHES)
        if (parts.size < 2) return noBrackets.trim()
        val kept =
            parts.filterIndexed { index, part ->
                val w = words(part)
                index == 0 || w.isEmpty() || !w.all { it in DASH_UPLOAD_WORDS || it.all(Char::isDigit) }
            }
        return kept.joinToString(" - ").trim()
    }

    private fun words(text: String): List<String> =
        text
            .lowercase()
            .splitWhere { !it.isLetterOrDigit() }
            .filter { it.isNotEmpty() }

    private fun String.splitWhere(isSeparator: (Char) -> Boolean): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        for (c in this) {
            if (isSeparator(c)) {
                out += current.toString()
                current.clear()
            } else {
                current.append(c)
            }
        }
        out += current.toString()
        return out
    }

    private fun compact(text: String): String =
        buildString(text.length) {
            for (c in text) if (c.isLetterOrDigit()) append(c.lowercaseChar())
        }
}
