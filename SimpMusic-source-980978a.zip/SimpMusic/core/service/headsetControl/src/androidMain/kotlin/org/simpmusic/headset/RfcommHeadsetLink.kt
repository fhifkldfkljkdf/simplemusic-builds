package org.simpmusic.headset

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * The headphones' control service over Bluetooth Classic RFCOMM. Opening it needs
 * `BLUETOOTH_CONNECT` from Android 12.
 *
 * Reads and writes block a thread; [close] is what ends a blocked read.
 */
class RfcommHeadsetLink private constructor(
    private val socket: BluetoothSocket,
) : HeadsetLink {
    private val input = socket.inputStream
    private val output = socket.outputStream

    override suspend fun read(buffer: ByteArray): Int = withContext(Dispatchers.IO) { input.read(buffer) }

    override suspend fun write(bytes: ByteArray) =
        withContext(Dispatchers.IO) {
            output.write(bytes)
            output.flush()
        }

    override fun close() {
        try {
            socket.close()
        } catch (_: IOException) {
        }
    }

    companion object {
        /** The standard Serial Port Profile service, which Huawei earbuds' control channel is registered under. */
        val SERIAL_PORT: UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")

        /**
         * Connects to [device]'s control service registered under [service] (found by SDP, never
         * by guessing a channel). `connect()` blocks for up to ~12 s and ignores thread
         * interrupts, so it runs on a thread of its own and cancelling closes the socket, which is
         * the one thing that makes it return.
         *
         * The caller has checked `BLUETOOTH_CONNECT` (Android 12+); without it this throws
         * SecurityException.
         */
        @SuppressLint("MissingPermission")
        suspend fun open(
            device: BluetoothDevice,
            service: UUID,
        ): RfcommHeadsetLink = connect(withContext(Dispatchers.IO) { device.createRfcommSocketToServiceRecord(service) })

        /**
         * Connects to RFCOMM [channel] directly: OpenFreebuds' per-model channel, for when the SDP
         * lookup of the service fails. Android has no public call for this; the hidden
         * `createRfcommSocket(int)` is used through reflection and may be refused, which ends in
         * an IOException like any failed connection.
         */
        @SuppressLint("MissingPermission", "DiscouragedPrivateApi")
        suspend fun openChannel(
            device: BluetoothDevice,
            channel: Int,
        ): RfcommHeadsetLink {
            val socket =
                withContext(Dispatchers.IO) {
                    try {
                        device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(device, channel) as BluetoothSocket
                    } catch (e: ReflectiveOperationException) {
                        throw IOException("RFCOMM channel $channel is not reachable on this Android", e)
                    }
                }
            return connect(socket)
        }

        private suspend fun connect(socket: BluetoothSocket): RfcommHeadsetLink =
            suspendCancellableCoroutine { continuation ->
                continuation.invokeOnCancellation {
                    try {
                        socket.close()
                    } catch (_: IOException) {
                    }
                }
                Thread({
                    try {
                        socket.connect()
                        continuation.resume(RfcommHeadsetLink(socket)) { _, link, _ -> link.close() }
                    } catch (e: IOException) {
                        try {
                            socket.close()
                        } catch (_: IOException) {
                        }
                        if (continuation.isActive) continuation.resumeWithException(e)
                    }
                }, "Headset-Connect").start()
            }
    }
}
