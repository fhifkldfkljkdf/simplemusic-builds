package org.simpmusic.headset

import com.maxrave.domain.data.model.headset.NoiseLevel
import com.maxrave.domain.data.model.headset.NoiseMode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.simpmusic.headset.huawei.HuaweiHeadset
import org.simpmusic.headset.huawei.HuaweiModels
import org.simpmusic.headset.huawei.HuaweiProfile
import org.simpmusic.headset.momentum.HeadsetIoException
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull
import kotlin.test.assertTrue

class HuaweiHeadsetTest {
    private val pro4 = HuaweiModels.profileFor("HUAWEI FreeBuds Pro 4")!!
    private val fast = HuaweiHeadset.Timing(answerTimeoutMs = 300, settleMs = 50, firstReadAttempts = 2)

    private fun withSession(
        buds: FakeHuaweiBuds,
        profile: HuaweiProfile = pro4,
        block: suspend CoroutineScope.(HuaweiHeadset) -> Unit,
    ) = runBlocking {
        withTimeout(20_000) {
            val session = HuaweiHeadset(buds, profile, fast)
            val job = launch(Dispatchers.Default) { session.run() }
            session.report.first { it.ready }
            try {
                block(session)
            } finally {
                job.cancelAndJoin()
            }
        }
    }

    @Test
    fun readsNoiseControlAndBattery() =
        withSession(FakeHuaweiBuds(mode = 1, level = 3)) { session ->
            val report = session.report.value
            assertEquals(NoiseMode.ANC, report.noise?.mode)
            assertEquals(NoiseLevel.DYNAMIC, report.noise?.level)
            assertEquals(listOf(NoiseMode.ANC, NoiseMode.TRANSPARENCY, NoiseMode.OFF), report.noise?.modes)
            assertEquals(64, report.battery.percent)
            assertEquals(70, report.battery.left)
            assertEquals(30, report.battery.case)
            assertEquals(true, report.battery.charging)
        }

    @Test
    fun switchesModesAndLevels() {
        val buds = FakeHuaweiBuds()
        withSession(buds) { session ->
            session.setMode(NoiseMode.ANC)
            assertEquals(1, buds.mode)
            session.setLevel(NoiseLevel.ULTRA)
            assertEquals(2, buds.level)
            assertEquals(NoiseLevel.ULTRA, session.report.value.noise?.level)
            session.setMode(NoiseMode.TRANSPARENCY)
            session.setLevel(NoiseLevel.VOICE_BOOST)
            assertEquals(1, buds.level)
            session.setMode(NoiseMode.OFF)
            assertEquals(0, buds.mode)
            // Mode writes as FreeBuddy and Gadgetbridge send them.
            assertTrue("2B04 1=01FF" in buds.sent)
            assertTrue("2B04 1=0000" in buds.sent)
        }
    }

    @Test
    fun learnsWhichParameterALevelGoesIn() {
        val buds = FakeHuaweiBuds(mode = 1, levelParam = 2)
        withSession(buds) { session ->
            session.setLevel(NoiseLevel.COMFORT)
            assertEquals(1, buds.level)
            // Learned: the next level write goes straight to parameter 2.
            val before = buds.sent.size
            session.setLevel(NoiseLevel.ULTRA)
            assertEquals(listOf("2B04 2=0102"), buds.sent.drop(before).filter { it.startsWith("2B04") })
        }
    }

    @Test
    fun followsTheEarbudsOwnControls() {
        val buds = FakeHuaweiBuds(mode = 0)
        withSession(buds) { session ->
            buds.pressButton(1)
            withTimeout(2_000) { session.report.first { it.noise?.mode == NoiseMode.ANC } }
            buds.reportBattery(41)
            withTimeout(2_000) { session.report.first { it.battery.percent == 41 } }
        }
        val legacy = FakeHuaweiBuds(mode = 0, legacyChange = true)
        withSession(legacy, HuaweiModels.profileFor("HUAWEI FreeLace Pro")!!.copy(connectDelayMs = 0)) { session ->
            legacy.pressButton(2)
            withTimeout(2_000) { session.report.first { it.noise?.mode == NoiseMode.TRANSPARENCY } }
        }
    }

    @Test
    fun earbudsWithoutNoiseControlStillShowBattery() =
        withSession(FakeHuaweiBuds(hasAnc = false), HuaweiModels.profileFor("HUAWEI FreeBuds SE 2")!!) { session ->
            assertNull(session.report.value.noise)
            assertEquals(64, session.report.value.battery.percent)
            assertFailsWith<NotSupportedException> { session.setMode(NoiseMode.ANC) }
        }

    @Test
    fun aGuessedModelWithoutNoiseControlFallsBackToBattery() =
        withSession(FakeHuaweiBuds(hasAnc = false), HuaweiModels.profileFor("HUAWEI FreeClip 3")!!) { session ->
            assertTrue(session.report.value.ready)
            assertNull(session.report.value.noise)
        }

    @Test
    fun nothingAnsweringEndsTheSession() =
        runBlocking {
            val buds = FakeHuaweiBuds(silent = true)
            val failure = CompletableDeferred<Throwable>()
            val job =
                launch(Dispatchers.Default) {
                    try {
                        HuaweiHeadset(buds, pro4, fast).run()
                    } catch (e: Throwable) {
                        failure.complete(e)
                    }
                }
            assertTrue(withTimeout(10_000) { failure.await() } is HeadsetIoException)
            assertTrue(buds.closed)
            job.cancelAndJoin()
        }
}
