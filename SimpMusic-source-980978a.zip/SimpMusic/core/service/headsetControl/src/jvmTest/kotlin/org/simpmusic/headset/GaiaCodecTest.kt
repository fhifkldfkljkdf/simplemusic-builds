package org.simpmusic.headset

import org.simpmusic.headset.gaia.GaiaCodec
import org.simpmusic.headset.gaia.GaiaFrame
import org.simpmusic.headset.gaia.GaiaFrameReader
import org.simpmusic.headset.momentum.AncModeTable
import org.simpmusic.headset.momentum.AntiWind
import org.simpmusic.headset.momentum.Momentum4
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** Bytes captured from a MOMENTUM 4 on firmware 3.37.3 (Tumult1337/momentum4-control, tests/CapturedPackets). */
class GaiaCodecTest {
    private fun bytes(hex: String): ByteArray = hex.split(" ").filter { it.isNotBlank() }.map { it.toInt(16).toByte() }.toByteArray()

    @Test
    fun encodesCommandsAsTheHeadsetWasSentThem() {
        assertContentEquals(bytes("FF 03 00 00 04 95 1A 05"), GaiaCodec.encode(Momentum4.VENDOR, Momentum4.GET_ANC_ENABLED))
        assertContentEquals(bytes("FF 03 00 01 04 95 1A 02 1E"), GaiaCodec.encode(Momentum4.VENDOR, Momentum4.SET_ANC_LEVEL, bytes("1E")))
        assertContentEquals(
            bytes("FF 03 00 06 04 95 1A 00 01 01 02 00 03 01"),
            GaiaCodec.encode(Momentum4.VENDOR, Momentum4.SET_ANC_MODE, bytes("01 01 02 00 03 01")),
        )
        assertContentEquals(bytes("FF 03 00 01 04 95 00 07 0D"), GaiaCodec.encode(Momentum4.VENDOR, Momentum4.REGISTER_NOTIFICATION, bytes("0D")))
    }

    @Test
    fun readsResponsesNotificationsAndErrors() {
        val reader = GaiaFrameReader()
        val frames =
            reader.push(
                bytes("FF 03 00 01 04 95 1B 05 01") + // GetAncEnabled answer
                    bytes("FF 03 00 06 04 95 1A 81 01 02 02 00 03 00") + // modes notification
                    bytes("FF 03 00 01 04 95 1B 80 05") + // SetAncMode refused, reason 5
                    bytes("FF 03 00 00 04 95 01 07"), // RegisterNotification answer
            )
        assertEquals(4, frames.size)
        assertEquals(GaiaFrame.TYPE_RESPONSE, frames[0].type)
        assertEquals(Momentum4.GET_ANC_ENABLED, frames[0].baseCommand)
        assertContentEquals(bytes("01"), frames[0].payload)
        assertEquals(GaiaFrame.TYPE_NOTIFICATION, frames[1].type)
        assertEquals(Momentum4.GET_ANC_MODES, frames[1].baseCommand)
        assertEquals(GaiaFrame.TYPE_ERROR, frames[2].type)
        assertEquals(Momentum4.SET_ANC_MODE, frames[2].baseCommand)
        assertEquals(Momentum4.REGISTER_NOTIFICATION, frames[3].baseCommand)
        assertEquals(0, reader.pendingBytes)
    }

    @Test
    fun reassemblesFramesSplitAcrossReadsAndSkipsNoise() {
        val reader = GaiaFrameReader()
        val stream = bytes("00 12 FF 07") + bytes("FF 03 00 01 04 95 1A 83 64") + bytes("FF 03 00 01 04 95 18 85 01")
        val frames = stream.toList().chunked(2).flatMap { reader.push(it.toByteArray()) }
        assertEquals(listOf(0x1A83, 0x1885), frames.map { it.command })
        assertEquals(100, frames[0].payload[0].toInt())
    }

    @Test
    fun checksVersionsWithAChecksumAndALongLength() {
        // flags 0x03: two-byte length and an XOR checksum over everything before it.
        val body = bytes("FF 03 03 00 01 04 95 1B 03 1E")
        val checksum = body.fold(0) { acc, b -> acc xor (b.toInt() and 0xFF) }.toByte()
        val reader = GaiaFrameReader()
        val good = reader.push(body + checksum)
        assertEquals(1, good.size)
        assertEquals(30, good[0].payload[0].toInt())
        // A wrong checksum is dropped, and the next frame still reads.
        val bad = reader.push(body + (checksum.toInt() xor 1).toByte() + bytes("FF 03 00 01 04 95 1B 03 00"))
        assertEquals(listOf(0), bad.map { it.payload[0].toInt() })
    }

    @Test
    fun modeTableWritesTheWholeTableOrOnePair() {
        val table = AncModeTable.decode(bytes("01 01 02 00 03 00"))
        assertEquals(AntiWind.MAXIMUM, table.antiWind)
        assertEquals(false, table.adaptive)
        assertContentEquals(bytes("01 02 02 00 03 00"), table.write(Momentum4.MODE_ANTI_WIND, AntiWind.AUTOMATIC.value, fullTable = true))
        assertContentEquals(bytes("01 02"), table.write(Momentum4.MODE_ANTI_WIND, AntiWind.AUTOMATIC.value, fullTable = false))
        assertContentEquals(bytes("01 01 02 00 03 01"), table.write(Momentum4.MODE_ADAPTIVE, 1, fullTable = true))
        assertTrue(runCatching { AncModeTable.decode(bytes("01 01 02")) }.isFailure)
    }
}
