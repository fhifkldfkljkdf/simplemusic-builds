package org.simpmusic.headset

import kotlinx.coroutines.channels.Channel
import org.simpmusic.headset.huawei.HuaweiHeadset
import org.simpmusic.headset.huawei.HuaweiPacket
import org.simpmusic.headset.huawei.HuaweiPacketReader

/**
 * Huawei earbuds as OpenFreebuds, FreeBuddy and Gadgetbridge describe them: noise control read
 * with `2B 2A` as `[level, mode]`, written with `2B 04` as `[mode, FF]` / `[mode, level]`, battery
 * on `01 08`. Bytes go out in small pieces to exercise reassembly.
 */
class FakeHuaweiBuds(
    var mode: Int = 0,
    var level: Int = 0,
    var overall: Int = 64,
    var left: Int = 70,
    var right: Int = 60,
    var case: Int = 30,
    /** Which parameter a level write must arrive in; the other is acknowledged and ignored. */
    var levelParam: Int = 1,
    /** No noise control: `2B 2A` and `2B 04` go unanswered, as on the FreeBuds SE. */
    var hasAnc: Boolean = true,
    /** Older models: a button press sends only `2B 03`. */
    var legacyChange: Boolean = false,
    var silent: Boolean = false,
    private val chunk: Int = 4,
) : HeadsetLink {
    private val outgoing = Channel<ByteArray>(Channel.UNLIMITED)
    private val reader = HuaweiPacketReader()
    private var pendingChunk: ByteArray? = null

    val sent = mutableListOf<String>()

    var closed = false
        private set

    override suspend fun read(buffer: ByteArray): Int {
        val bytes = pendingChunk ?: outgoing.receiveCatching().getOrNull() ?: return -1
        val n = minOf(bytes.size, buffer.size, chunk)
        bytes.copyInto(buffer, 0, 0, n)
        pendingChunk = if (n < bytes.size) bytes.copyOfRange(n, bytes.size) else null
        return n
    }

    override suspend fun write(bytes: ByteArray) {
        for (packet in reader.push(bytes)) {
            sent += packet.toString()
            if (!silent) handle(packet)
        }
    }

    override fun close() {
        closed = true
        outgoing.close()
    }

    /** The earbuds' own control changes the mode. */
    fun pressButton(newMode: Int) {
        mode = newMode
        if (legacyChange) send(HuaweiPacket.write(HuaweiHeadset.CMD_NOISE_CHANGED, 1 to byteArrayOf(newMode.toByte()))) else sendNoise()
    }

    fun reportBattery(newOverall: Int) {
        overall = newOverall
        send(batteryPacket(HuaweiHeadset.CMD_BATTERY_NOTIFY))
    }

    private fun handle(packet: HuaweiPacket) {
        when (packet.command) {
            HuaweiHeadset.CMD_BATTERY_READ -> send(batteryPacket(HuaweiHeadset.CMD_BATTERY_READ))
            HuaweiHeadset.CMD_NOISE_READ -> if (hasAnc) sendNoise()
            HuaweiHeadset.CMD_NOISE_WRITE -> {
                if (!hasAnc) return
                send(HuaweiPacket.write(HuaweiHeadset.CMD_NOISE_WRITE, HuaweiPacket.RESULT to byteArrayOf(0, 1, 0x86.toByte(), 0xA0.toByte())))
                val p1 = packet.param(1)?.map { it.toInt() and 0xFF }
                val byLevelParam = packet.param(levelParam)?.map { it.toInt() and 0xFF }
                when {
                    // [mode, FF], or [00, 00] for off.
                    p1 != null && p1.size == 2 && (p1[1] == 0xFF || (p1[0] == 0 && p1[1] == 0)) -> {
                        mode = p1[0]
                        // A new mode starts at its default step, as the earbuds do.
                        level = if (mode == 2) 2 else 0
                    }
                    // [current mode, level], only in the parameter this model reads it from.
                    byLevelParam != null && byLevelParam.size == 2 && byLevelParam[0] == mode && mode != 0 -> level = byLevelParam[1]
                }
            }
        }
    }

    private fun batteryPacket(command: Int) =
        HuaweiPacket.write(
            command,
            1 to byteArrayOf(overall.toByte()),
            2 to byteArrayOf(left.toByte(), right.toByte(), case.toByte()),
            3 to byteArrayOf(0, 1, 0),
        )

    private fun sendNoise() = send(HuaweiPacket.write(HuaweiHeadset.CMD_NOISE_READ, 1 to byteArrayOf(level.toByte(), mode.toByte())))

    private fun send(packet: HuaweiPacket) {
        outgoing.trySend(packet.encode())
    }
}
