package org.simpmusic.headset

import com.maxrave.domain.data.model.headset.NoiseLevel
import org.simpmusic.headset.huawei.HuaweiModels
import org.simpmusic.headset.huawei.HuaweiPacket
import org.simpmusic.headset.huawei.HuaweiPacketReader
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** Packets captured from real earbuds, from OpenFreebuds' tests (`driver/huawei/test/`). */
class HuaweiPacketTest {
    private fun hex(s: String): ByteArray = s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    @Test
    fun encodesReadsAndWritesAsCaptured() {
        assertContentEquals(hex("5a0009000108010002000300fbb9"), HuaweiPacket.read(0x0108, 1, 2, 3).encode())
        assertContentEquals(hex("5a0005002b110100772a"), HuaweiPacket.read(0x2B11, 1).encode())
        assertContentEquals(hex("5a0006002b10010101a956"), HuaweiPacket.write(0x2B10, 1 to byteArrayOf(1)).encode())
        assertContentEquals(hex("5a0009002b1e0101ff0201ff9d9b"), HuaweiPacket.write(0x2B1E, 1 to hex("ff"), 2 to hex("ff")).encode())
        assertContentEquals(hex("5a000600011f01010203c1"), HuaweiPacket.write(0x011F, 1 to hex("02")).encode())
    }

    @Test
    fun readsCapturedAnswersWithTheirChecksums() {
        val reader = HuaweiPacketReader()
        val packets =
            reader.push(
                hex("5a0014000108010140020310203003030001000402140a1461") +
                    hex("5a0009002b107f04000186a0729d") +
                    hex("5a0017000120010101020102030501070200ff0401ff060200ffcf60"),
            )
        assertEquals(listOf(0x0108, 0x2B10, 0x0120), packets.map { it.command })
        assertContentEquals(hex("40"), packets[0].param(1))
        assertContentEquals(hex("102030"), packets[0].param(2))
        assertContentEquals(hex("000100"), packets[0].param(3))
        assertContentEquals(hex("000186a0"), packets[1].param(HuaweiPacket.RESULT))
        assertEquals(0, reader.checksumMismatches)
        assertEquals(0, reader.pendingBytes)
    }

    @Test
    fun reassemblesAcrossReadsAndSkipsNoise() {
        val reader = HuaweiPacketReader()
        val stream = hex("00115a") + hex("5a0009000108010140030100ed2e") + hex("5a0006002b6c020100ed60")
        val packets = stream.toList().chunked(3).flatMap { reader.push(it.toByteArray()) }
        assertEquals(listOf(0x0108, 0x2B6C), packets.map { it.command })
        assertContentEquals(hex("00"), packets[1].param(2))
    }

    @Test
    fun recognisesModelsByName() {
        assertEquals("HUAWEI FreeBuds 6i", HuaweiModels.profileFor("HUAWEI FreeBuds 6i")?.name)
        val pro4 = HuaweiModels.profileFor("HUAWEI FreeBuds Pro 4")!!
        assertEquals(listOf(NoiseLevel.COMFORT, NoiseLevel.NORMAL, NoiseLevel.ULTRA, NoiseLevel.DYNAMIC), pro4.cancelLevels)
        assertTrue(pro4.voiceBoost)
        assertEquals(false, HuaweiModels.profileFor("huawei freebuds se 2")?.anc)
        assertEquals("HUAWEI FreeBuds 5i", HuaweiModels.profileFor("HUAWEI FreeBuds 5i (A1B2)")?.name)
        // Not in OpenFreebuds' list: a guess by family.
        val next = HuaweiModels.profileFor("HUAWEI FreeBuds Pro 6")!!
        assertTrue(next.guessed && next.voiceBoost)
        val plain = HuaweiModels.profileFor("HUAWEI FreeBuds 7i")!!
        assertTrue(plain.guessed && plain.anc && plain.cancelLevels.isEmpty())
        assertNull(HuaweiModels.profileFor("MOMENTUM 4"))
        assertNull(HuaweiModels.profileFor("WH-1000XM5"))
        assertIs<HeadsetKind.Momentum4Kind>(HeadsetModels.recognise("MOMENTUM 4"))
        assertIs<HeadsetKind.Huawei>(HeadsetModels.recognise("HONOR Earbuds 2 Lite"))
    }
}
