package org.simpmusic.headset

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.simpmusic.headset.momentum.AntiWind
import org.simpmusic.headset.momentum.HeadsetIoException
import org.simpmusic.headset.momentum.Momentum4
import org.simpmusic.headset.momentum.Momentum4Headset
import org.simpmusic.headset.momentum.Momentum4Session
import org.simpmusic.headset.momentum.NoiseControlMode
import org.simpmusic.headset.momentum.NoiseControlPlan
import org.simpmusic.headset.momentum.NoiseControlState
import org.simpmusic.headset.momentum.NoiseWrite
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class Momentum4SessionTest {
    private val transparency = NoiseControlState(true, adaptive = false, level = 100, antiWind = AntiWind.MAXIMUM, transparentHearing = true)

    @Test
    fun plansFollowTheVerifiedSequences() {
        // Adaptive from transparency: Transparent Hearing off, then the table (capture 00:26:51).
        assertEquals(
            listOf(NoiseWrite.TransparentHearing(false), NoiseWrite.Mode(3, 1)),
            NoiseControlPlan.toMode(transparency, NoiseControlMode.ADAPTIVE),
        )
        // Transparency from off: ANC on ends Transparent Hearing, so it is turned on after.
        val off = transparency.copy(ancEnabled = false)
        assertEquals(
            listOf(NoiseWrite.AncEnabled(true), NoiseWrite.TransparentHearing(true)),
            NoiseControlPlan.toMode(off, NoiseControlMode.TRANSPARENCY),
        )
        assertEquals(listOf(NoiseWrite.AncEnabled(false)), NoiseControlPlan.toMode(transparency, NoiseControlMode.OFF))
        assertEquals(emptyList(), NoiseControlPlan.toMode(transparency, NoiseControlMode.TRANSPARENCY))
        // A strength from transparency: leave it, then set the level.
        assertEquals(
            listOf(NoiseWrite.TransparentHearing(false), NoiseWrite.Level(30)),
            NoiseControlPlan.toLevel(transparency, 30),
        )
        // Anti-wind in ANC at level 40 puts the level back after the table write drops it to 0.
        val custom = transparency.copy(transparentHearing = false, level = 40)
        assertEquals(
            listOf(NoiseWrite.Mode(1, 2), NoiseWrite.Level(40)),
            NoiseControlPlan.toAntiWind(custom, AntiWind.AUTOMATIC),
        )
        assertEquals(
            listOf(NoiseWrite.Mode(1, 0), NoiseWrite.TransparentHearing(true)),
            NoiseControlPlan.toAntiWind(transparency, AntiWind.OFF),
        )
    }

    private fun withSession(
        headset: FakeMomentum4,
        timing: Momentum4Session.Timing = Momentum4Session.Timing(),
        block: suspend CoroutineScope.(Momentum4Session) -> Unit,
    ) = runBlocking {
        withTimeout(20_000) {
            val session = Momentum4Session(headset, timing)
            val ready = CompletableDeferred<Unit>()
            val job = launch(Dispatchers.Default) { session.run { ready.complete(Unit) } }
            ready.await()
            try {
                block(session)
            } finally {
                job.cancelAndJoin()
            }
        }
    }

    @Test
    fun readsTheStateOnConnect() =
        withSession(FakeMomentum4(battery = 64)) { session ->
            val status = session.status.value
            assertEquals(NoiseControlMode.TRANSPARENCY, status.noiseControl?.mode)
            assertEquals(AntiWind.MAXIMUM, status.noiseControl?.antiWind)
            assertEquals(64, status.batteryPercent)
            assertEquals(false, status.charging)
        }

    @Test
    fun switchesBetweenAllModes() {
        val headset = FakeMomentum4()
        withSession(headset) { session ->
            assertEquals(NoiseControlMode.ADAPTIVE, session.setMode(NoiseControlMode.ADAPTIVE).mode)
            assertEquals(NoiseControlMode.CUSTOM, session.setMode(NoiseControlMode.CUSTOM).mode)
            assertEquals(NoiseControlMode.OFF, session.setMode(NoiseControlMode.OFF).mode)
            assertEquals(NoiseControlMode.TRANSPARENCY, session.setMode(NoiseControlMode.TRANSPARENCY).mode)
            assertEquals(100, headset.level)
        }
    }

    @Test
    fun aSwitchSendsItsWritesAndOneReadBack() {
        val headset = FakeMomentum4()
        withSession(headset) { session ->
            val before = headset.sent.size
            assertEquals(NoiseControlMode.ADAPTIVE, session.setMode(NoiseControlMode.ADAPTIVE).mode)
            // Notifications keep the status current, so nothing is read before the writes.
            assertEquals(
                listOf("1804", "1A00", "1A05", "1A01", "1A03", "1805"),
                headset.sent.drop(before).map { it.substringBefore(' ') },
            )
        }
    }

    @Test
    fun aStaleStartIsPlannedAgainFromWhatWasRead() {
        val headset = FakeMomentum4()
        withSession(headset) { session ->
            // Changed behind the session's back: no notification says so.
            headset.ancEnabled = false
            assertEquals(NoiseControlMode.ADAPTIVE, session.setMode(NoiseControlMode.ADAPTIVE).mode)
            assertTrue(headset.ancEnabled)
        }
    }

    @Test
    fun withoutNotificationsTheStateIsReadFirst() {
        val headset = FakeMomentum4(refusedFeatures = setOf(Momentum4.FEATURE_TRANSPARENT_HEARING))
        withSession(headset) { session ->
            val before = headset.sent.size
            session.setMode(NoiseControlMode.OFF)
            assertEquals("1A05", headset.sent.drop(before).first().substringBefore(' '))
        }
    }

    @Test
    fun setsTheStrengthFromAnyMode() {
        val headset = FakeMomentum4()
        withSession(headset) { session ->
            val custom = session.setLevel(30)
            assertEquals(NoiseControlMode.CUSTOM, custom.mode)
            assertEquals(30, custom.level)
            session.setMode(NoiseControlMode.ADAPTIVE)
            val back = session.setLevel(70)
            assertEquals(NoiseControlMode.CUSTOM, back.mode)
            assertEquals(70, headset.level)
            // Nothing is written when it is already there.
            val before = headset.sent.size
            session.setLevel(70)
            assertTrue(headset.sent.drop(before).none { it.startsWith("1A02") })
        }
    }

    @Test
    fun antiWindKeepsTheModeAndStrength() {
        val headset = FakeMomentum4()
        withSession(headset) { session ->
            session.setLevel(40)
            val after = session.setAntiWind(AntiWind.AUTOMATIC)
            assertEquals(AntiWind.AUTOMATIC, after.antiWind)
            assertEquals(NoiseControlMode.CUSTOM, after.mode)
            assertEquals(40, after.level)
            session.setMode(NoiseControlMode.TRANSPARENCY)
            assertEquals(NoiseControlMode.TRANSPARENCY, session.setAntiWind(AntiWind.OFF).mode)
        }
    }

    @Test
    fun fallsBackToTheOtherTableFormat() {
        val headset = FakeMomentum4(acceptsFullTable = false)
        withSession(headset) { session ->
            assertEquals(NoiseControlMode.ADAPTIVE, session.setMode(NoiseControlMode.ADAPTIVE).mode)
            // Learned: the second write goes straight out as a pair.
            val before = headset.sent.size
            session.setMode(NoiseControlMode.CUSTOM)
            assertEquals(listOf("1A00 [03 00]"), headset.sent.drop(before).filter { it.startsWith("1A00") })
        }
    }

    @Test
    fun followsTheHeadsetsOwnGesture() {
        val headset = FakeMomentum4()
        withSession(headset) { session ->
            session.setLevel(25)
            headset.touchGesture()
            withTimeout(2_000) { session.status.first { it.noiseControl?.mode == NoiseControlMode.TRANSPARENCY } }
            headset.touchGesture()
            val back = withTimeout(2_000) { session.status.first { it.noiseControl?.mode == NoiseControlMode.CUSTOM } }
            assertEquals(25, back.level)
        }
    }

    @Test
    fun aSilentHeadsetEndsTheSession() =
        runBlocking {
            val headset = FakeMomentum4()
            val session = Momentum4Session(headset, Momentum4Session.Timing(answerTimeoutMs = 200))
            val ready = CompletableDeferred<Unit>()
            val failure = CompletableDeferred<Throwable>()
            val job =
                launch(Dispatchers.Default) {
                    try {
                        session.run { ready.complete(Unit) }
                    } catch (e: Throwable) {
                        failure.complete(e)
                    }
                }
            withTimeout(5_000) { ready.await() }
            headset.silent = true
            assertFailsWith<HeadsetIoException> { session.setMode(NoiseControlMode.OFF) }
            repeat(2) { runCatching { session.setMode(NoiseControlMode.OFF) } }
            // Three unanswered commands close the channel, which ends run().
            assertTrue(withTimeout(5_000) { failure.await() } is HeadsetIoException)
            assertTrue(headset.closed)
            job.cancelAndJoin()
            delay(1)
        }

    @Test
    fun theAdapterSpeaksTheSharedModel() =
        runBlocking {
            withTimeout(20_000) {
                val headset = FakeMomentum4()
                val adapter = Momentum4Headset(headset)
                val job = launch(Dispatchers.Default) { adapter.run() }
                val first = adapter.report.first { it.ready && it.noise != null }
                assertEquals(com.maxrave.domain.data.model.headset.NoiseMode.TRANSPARENCY, first.noise?.mode)
                assertEquals(80, first.battery.percent)
                adapter.setStrength(70)
                assertEquals(30, headset.level)
                val after = adapter.report.first { it.noise?.strength == 70 }
                assertEquals(com.maxrave.domain.data.model.headset.NoiseMode.ANC, after.noise?.mode)
                assertEquals(com.maxrave.domain.data.model.headset.AntiWindMode.MAXIMUM, after.noise?.antiWind)
                job.cancelAndJoin()
            }
        }

    @Test
    fun aSilentBatteryDoesNotKeepNoiseControlAway() =
        withSession(
            FakeMomentum4(battery = 55, unanswered = setOf(Momentum4.GET_BATTERY_LEVEL)),
            Momentum4Session.Timing(batteryTimeoutMs = 300),
        ) { session ->
            assertEquals(NoiseControlMode.TRANSPARENCY, session.status.value.noiseControl?.mode)
            // The registration's notification still told us.
            assertEquals(55, session.status.value.batteryPercent)
            assertEquals(NoiseControlMode.OFF, session.setMode(NoiseControlMode.OFF).mode)
        }

    @Test
    fun aRefusedRegistrationDoesNotEndTheSession() =
        withSession(FakeMomentum4(refusedFeatures = setOf(Momentum4.FEATURE_TRANSPARENT_HEARING, Momentum4.FEATURE_BATTERY))) { session ->
            assertEquals(NoiseControlMode.TRANSPARENCY, session.status.value.noiseControl?.mode)
            assertEquals(80, session.status.value.batteryPercent)
            assertEquals(NoiseControlMode.ADAPTIVE, session.setMode(NoiseControlMode.ADAPTIVE).mode)
        }
}
