package org.simpmusic.headset

import kotlinx.coroutines.channels.Channel
import org.simpmusic.headset.gaia.GaiaCodec
import org.simpmusic.headset.gaia.GaiaFrameReader
import org.simpmusic.headset.momentum.Momentum4

/**
 * A MOMENTUM 4 as the captures in Tumult1337/momentum4-control show it behaving: answers, change
 * notifications and the firmware's side effects (a table write ends Transparent Hearing and drops
 * the level to 0; Transparent Hearing on saves the level and sets 100, off restores it; ANC on ends
 * Transparent Hearing at level 0). Bytes go out in small pieces to exercise reassembly.
 */
class FakeMomentum4(
    var ancEnabled: Boolean = true,
    var table: MutableList<Pair<Int, Int>> = mutableListOf(1 to 1, 2 to 0, 3 to 0),
    var level: Int = 100,
    var transparentHearing: Boolean = true,
    var battery: Int = 80,
    /** Which `0x1A00` formats the firmware takes; the other is refused with reason 0x05. */
    var acceptsFullTable: Boolean = true,
    var acceptsPair: Boolean = true,
    /** Stop answering, as a headset that walked out of range. */
    var silent: Boolean = false,
    /** Commands left unanswered, as firmware too slow or too old to answer them. */
    var unanswered: Set<Int> = emptySet(),
    /** Features whose notification registration the firmware refuses. */
    var refusedFeatures: Set<Int> = emptySet(),
    private val chunk: Int = 3,
) : HeadsetLink {
    private val outgoing = Channel<ByteArray>(Channel.UNLIMITED)
    private val reader = GaiaFrameReader()
    private var levelBeforeTransparency = 0
    private var pendingChunk: ByteArray? = null

    /** Every command the phone sent, in order, as `command [payload]`. */
    val sent = mutableListOf<String>()

    var closed = false
        private set

    override suspend fun read(buffer: ByteArray): Int {
        val bytes = pendingChunk ?: outgoing.receiveCatching().getOrNull() ?: return -1
        val n = minOf(bytes.size, buffer.size, chunk)
        bytes.copyInto(buffer, 0, 0, n)
        pendingChunk = if (n < bytes.size) bytes.copyOfRange(n, bytes.size) else null
        return n
    }

    override suspend fun write(bytes: ByteArray) {
        for (frame in reader.push(bytes)) {
            sent += "%04X %s".format(frame.command, frame.payload.joinToString(" ", "[", "]") { "%02X".format(it) })
            if (!silent && frame.command !in unanswered) handle(frame.command, frame.payload)
        }
    }

    override fun close() {
        closed = true
        outgoing.close()
    }

    /** The headset's own touch gesture: toggles Transparent Hearing, as captured. */
    fun touchGesture() {
        switchTransparentHearing(!transparentHearing)
    }

    private fun handle(
        command: Int,
        payload: ByteArray,
    ) {
        val v = payload.firstOrNull()?.toInt()?.and(0xFF)
        when (command) {
            Momentum4.REGISTER_NOTIFICATION -> {
                if (v in refusedFeatures) {
                    error(command, 0x01)
                    return
                }
                respond(command)
                when (v) {
                    Momentum4.FEATURE_ANC -> {
                        notify(Momentum4.GET_ANC_ENABLED, switch(ancEnabled))
                        notify(Momentum4.GET_ANC_MODES, tableBytes())
                        notify(Momentum4.GET_ANC_LEVEL, byteArrayOf(level.toByte()))
                    }
                    Momentum4.FEATURE_TRANSPARENT_HEARING -> notify(Momentum4.GET_TRANSPARENT_HEARING, switch(transparentHearing))
                    Momentum4.FEATURE_BATTERY -> {
                        notify(Momentum4.GET_CHARGING_STATE, byteArrayOf(0))
                        notify(Momentum4.GET_BATTERY_LEVEL, byteArrayOf(battery.toByte()))
                    }
                }
            }
            Momentum4.GET_ANC_ENABLED -> respond(command, switch(ancEnabled))
            Momentum4.GET_ANC_MODES -> respond(command, tableBytes())
            Momentum4.GET_ANC_LEVEL -> respond(command, byteArrayOf(level.toByte()))
            Momentum4.GET_TRANSPARENT_HEARING -> respond(command, switch(transparentHearing))
            Momentum4.GET_BATTERY_LEVEL -> respond(command, byteArrayOf(battery.toByte()))
            Momentum4.SET_ANC_ENABLED -> {
                respond(command)
                val on = v == 1
                if (on && !ancEnabled) {
                    transparentHearing = false
                    level = 0
                    notify(Momentum4.GET_ANC_LEVEL, byteArrayOf(0))
                }
                ancEnabled = on
                notify(Momentum4.GET_ANC_ENABLED, switch(on))
            }
            Momentum4.SET_TRANSPARENT_HEARING -> {
                respond(command)
                switchTransparentHearing(v == 1)
            }
            Momentum4.SET_ANC_LEVEL -> {
                respond(command)
                level = v ?: level
                notify(Momentum4.GET_ANC_LEVEL, byteArrayOf(level.toByte()))
            }
            Momentum4.SET_ANC_MODE -> {
                val pair = payload.size == 2
                if ((pair && !acceptsPair) || (!pair && !acceptsFullTable)) {
                    error(command, 0x05)
                    return
                }
                respond(command)
                for (i in payload.indices step 2) {
                    val id = payload[i].toInt()
                    val value = payload[i + 1].toInt()
                    val index = table.indexOfFirst { it.first == id }
                    if (index >= 0) table[index] = id to value
                }
                transparentHearing = false
                level = 0
                notify(Momentum4.GET_ANC_MODES, tableBytes())
                notify(Momentum4.GET_ANC_LEVEL, byteArrayOf(0))
            }
            else -> error(command, 0x01)
        }
    }

    private fun switchTransparentHearing(on: Boolean) {
        if (on && !transparentHearing) {
            levelBeforeTransparency = level
            level = 100
        } else if (!on && transparentHearing) {
            level = levelBeforeTransparency
        }
        transparentHearing = on
        notify(Momentum4.GET_ANC_LEVEL, byteArrayOf(level.toByte()))
        notify(Momentum4.GET_TRANSPARENT_HEARING, switch(on))
    }

    private fun tableBytes(): ByteArray = table.flatMap { listOf(it.first.toByte(), it.second.toByte()) }.toByteArray()

    private fun switch(on: Boolean) = byteArrayOf(if (on) 1 else 0)

    private fun respond(
        command: Int,
        payload: ByteArray = ByteArray(0),
    ) {
        outgoing.trySend(GaiaCodec.encode(Momentum4.VENDOR, GaiaCodec.responseTo(command), payload))
    }

    private fun error(
        command: Int,
        reason: Int,
    ) {
        outgoing.trySend(GaiaCodec.encode(Momentum4.VENDOR, GaiaCodec.errorTo(command), byteArrayOf(reason.toByte())))
    }

    private fun notify(
        command: Int,
        payload: ByteArray,
    ) {
        outgoing.trySend(GaiaCodec.encode(Momentum4.VENDOR, GaiaCodec.notificationOf(command), payload))
    }
}
