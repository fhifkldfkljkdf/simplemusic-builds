package org.simpmusic.headset.momentum

/**
 * What the Sennheiser MOMENTUM 4 says about its own noise control, and the commands that change it.
 *
 * All values are from captures on a real headset (firmware 3.37.3 / 3.38.3) published by
 * Tumult1337/momentum4-control (MIT); the tests replay those bytes. Four values make up the state:
 *
 * - ANC on/off (`0x1A04` / `0x1A05`). Off means no noise control at all.
 * - A table of mode values (`0x1A00` / `0x1A01`): (1) anti-wind 0 off, 1 maximum, 2 automatic;
 *   (2) comfort; (3) adaptive 0/1.
 * - The ANC level (`0x1A02` / `0x1A03`), 0…100, where **0 is the strongest** cancellation.
 * - Transparent Hearing (`0x1804` / `0x1805`), the headset's own transparency mode.
 *
 * The firmware has side effects the plans below must respect, all observed:
 * - Any write of `0x1A00`, even of unchanged values, ends Transparent Hearing and sets the level to 0.
 * - Turning Transparent Hearing on sets the level to 100; turning it off restores the level from before.
 * - Turning ANC on ends Transparent Hearing and sets the level to 0.
 * - The headset's touch gesture toggles Transparent Hearing (reported as notifications).
 */
object Momentum4 {
    /** The SDP service the control channel is registered under (Sennheiser's GAIA service). */
    const val SERVICE_UUID = "a2129ff3-081b-4c45-8afe-469d9c4842ec"

    /** The name the headset gives itself; Sennheiser's own apps match on it too. */
    const val NAME = "MOMENTUM 4"

    const val VENDOR = 0x0495

    const val REGISTER_NOTIFICATION = 0x0007
    const val GET_CHARGING_STATE = 0x0602
    const val GET_BATTERY_LEVEL = 0x0603
    const val SET_TRANSPARENT_HEARING = 0x1804
    const val GET_TRANSPARENT_HEARING = 0x1805
    const val SET_ANC_MODE = 0x1A00
    const val GET_ANC_MODES = 0x1A01
    const val SET_ANC_LEVEL = 0x1A02
    const val GET_ANC_LEVEL = 0x1A03
    const val SET_ANC_ENABLED = 0x1A04
    const val GET_ANC_ENABLED = 0x1A05

    const val FEATURE_BATTERY = 3
    const val FEATURE_TRANSPARENT_HEARING = 12
    const val FEATURE_ANC = 13

    const val MODE_ANTI_WIND = 1
    const val MODE_COMFORT = 2
    const val MODE_ADAPTIVE = 3

    /** GAIA error reason for a payload the headset cannot read: `0x1A00` in the other format. */
    const val ERROR_INVALID_PARAMETER = 0x05

    fun isMomentum4(name: String?): Boolean = name?.contains(NAME, ignoreCase = true) == true
}

enum class AntiWind(
    val value: Int,
) {
    OFF(0),
    MAXIMUM(1),
    AUTOMATIC(2),
    ;

    companion object {
        fun of(value: Int): AntiWind? = entries.firstOrNull { it.value == value }
    }
}

enum class NoiseControlMode {
    /** ANC switched off. */
    OFF,

    /** Transparent Hearing: the outside world comes through. */
    TRANSPARENCY,

    /** ANC that sets its own strength. */
    ADAPTIVE,

    /** ANC at the strength the level sets. */
    CUSTOM,
}

class ProtocolFormatException(
    message: String,
) : Exception(message)

/** The `0x1A01` table as (id, value) pairs, kept in the headset's order for writing it back. */
class AncModeTable(
    val pairs: List<Pair<Int, Int>>,
) {
    fun value(id: Int): Int? = pairs.firstOrNull { it.first == id }?.second

    val antiWind: AntiWind? get() = value(Momentum4.MODE_ANTI_WIND)?.let(AntiWind::of)

    val adaptive: Boolean? get() = value(Momentum4.MODE_ADAPTIVE)?.let { if (it <= 1) it == 1 else null }

    /**
     * The `0x1A00` payload that sets [id] to [value]: the whole table with that one value changed,
     * or just the pair. Both were accepted by firmware 3.37.3.
     */
    fun write(
        id: Int,
        value: Int,
        fullTable: Boolean,
    ): ByteArray {
        if (!fullTable || pairs.none { it.first == id }) return byteArrayOf(id.toByte(), value.toByte())
        val out = ByteArray(pairs.size * 2)
        pairs.forEachIndexed { i, (pairId, pairValue) ->
            out[2 * i] = pairId.toByte()
            out[2 * i + 1] = (if (pairId == id) value else pairValue).toByte()
        }
        return out
    }

    override fun equals(other: Any?): Boolean = other is AncModeTable && other.pairs == pairs

    override fun hashCode(): Int = pairs.hashCode()

    override fun toString(): String = pairs.joinToString(" ", "[", "]") { "${it.first}=${it.second}" }

    companion object {
        fun decode(payload: ByteArray): AncModeTable {
            if (payload.size < 2 || payload.size % 2 != 0) throw ProtocolFormatException("ANC modes: ${payload.size} bytes")
            return AncModeTable(
                (payload.indices step 2).map { (payload[it].toInt() and 0xFF) to (payload[it + 1].toInt() and 0xFF) },
            )
        }
    }
}

/** The complete noise-control state, once all four values are known. */
data class NoiseControlState(
    val ancEnabled: Boolean,
    val adaptive: Boolean,
    /** 0 strongest … 100 weakest. */
    val level: Int,
    val antiWind: AntiWind,
    val transparentHearing: Boolean,
) {
    /** The same reading as the projects this was learned from, so behaviour matches theirs. */
    val mode: NoiseControlMode
        get() =
            when {
                !ancEnabled -> NoiseControlMode.OFF
                transparentHearing -> NoiseControlMode.TRANSPARENCY
                adaptive -> NoiseControlMode.ADAPTIVE
                else -> NoiseControlMode.CUSTOM
            }
}

/** Everything the session knows, filled in field by field from answers and notifications. */
data class Momentum4Status(
    val ancEnabled: Boolean? = null,
    val modes: AncModeTable? = null,
    val level: Int? = null,
    val transparentHearing: Boolean? = null,
    val batteryPercent: Int? = null,
    val charging: Boolean? = null,
) {
    val noiseControl: NoiseControlState?
        get() {
            val enabled = ancEnabled ?: return null
            val table = modes ?: return null
            return NoiseControlState(
                ancEnabled = enabled,
                adaptive = table.adaptive ?: return null,
                level = level ?: return null,
                antiWind = table.antiWind ?: return null,
                transparentHearing = transparentHearing ?: return null,
            )
        }
}

/** One write the headset is sent. */
sealed interface NoiseWrite {
    data class AncEnabled(
        val on: Boolean,
    ) : NoiseWrite

    data class TransparentHearing(
        val on: Boolean,
    ) : NoiseWrite

    data class Mode(
        val id: Int,
        val value: Int,
    ) : NoiseWrite

    data class Level(
        val level: Int,
    ) : NoiseWrite
}

/**
 * The writes that take the headset from one state to another, ported from the sequences
 * Tumult1337/momentum4-control verified by ear on the headset. Pure, so the tests can check them.
 */
object NoiseControlPlan {
    fun toMode(
        from: NoiseControlState,
        target: NoiseControlMode,
    ): List<NoiseWrite> =
        when (target) {
            NoiseControlMode.OFF -> if (from.ancEnabled) listOf(NoiseWrite.AncEnabled(false)) else emptyList()

            NoiseControlMode.TRANSPARENCY ->
                when {
                    // Turning ANC on ends Transparent Hearing, so it is turned on after.
                    !from.ancEnabled -> listOf(NoiseWrite.AncEnabled(true), NoiseWrite.TransparentHearing(true))
                    !from.transparentHearing -> listOf(NoiseWrite.TransparentHearing(true))
                    else -> emptyList()
                }

            NoiseControlMode.ADAPTIVE, NoiseControlMode.CUSTOM -> {
                val writes = ArrayList<NoiseWrite>(3)
                if (from.transparentHearing && from.ancEnabled) writes += NoiseWrite.TransparentHearing(false)
                if (!from.ancEnabled) writes += NoiseWrite.AncEnabled(true)
                val adaptive = target == NoiseControlMode.ADAPTIVE
                if (from.adaptive != adaptive) writes += NoiseWrite.Mode(Momentum4.MODE_ADAPTIVE, if (adaptive) 1 else 0)
                writes
            }
        }

    /** ANC at [level] (0 strongest … 100 weakest), leaving adaptive or transparency first. */
    fun toLevel(
        from: NoiseControlState,
        level: Int,
    ): List<NoiseWrite> {
        val target = level.coerceIn(0, 100)
        if (from.mode == NoiseControlMode.CUSTOM && from.level == target) return emptyList()
        return toMode(from, NoiseControlMode.CUSTOM) + NoiseWrite.Level(target)
    }

    /**
     * Anti-wind set to [antiWind]. Writing the table ends Transparent Hearing and drops the level
     * to 0, so both are put back afterwards: transparency stays transparency, and ANC keeps the
     * strength it had.
     */
    fun toAntiWind(
        from: NoiseControlState,
        antiWind: AntiWind,
    ): List<NoiseWrite> {
        if (from.antiWind == antiWind) return emptyList()
        val writes = arrayListOf<NoiseWrite>(NoiseWrite.Mode(Momentum4.MODE_ANTI_WIND, antiWind.value))
        when (from.mode) {
            NoiseControlMode.TRANSPARENCY -> writes += NoiseWrite.TransparentHearing(true)
            NoiseControlMode.CUSTOM -> if (from.level != 0) writes += NoiseWrite.Level(from.level)
            else -> Unit
        }
        return writes
    }
}
