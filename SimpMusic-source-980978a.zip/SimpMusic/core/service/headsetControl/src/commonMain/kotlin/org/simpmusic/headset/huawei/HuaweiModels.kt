package org.simpmusic.headset.huawei

import com.maxrave.domain.data.model.headset.NoiseLevel

/**
 * What one Huawei / Honor model can do, from OpenFreebuds' per-model drivers
 * (`driver/huawei/driver/per_model/`, `driver/constants.py`).
 */
data class HuaweiProfile(
    val name: String,
    /** The RFCOMM channel OpenFreebuds opens; used when the serial-port service is not found. */
    val channel: Int,
    val anc: Boolean,
    /** Noise-cancelling steps, in the order shown; empty for on/off only. */
    val cancelLevels: List<NoiseLevel> = emptyList(),
    /** Transparency has a voice boost step. */
    val voiceBoost: Boolean = false,
    /** Reports each bud and the case, not one value. */
    val tws: Boolean = true,
    /** Some models hang when the channel is opened straight after connecting. */
    val connectDelayMs: Long = 0,
    /** Answers `2B 03` when its button changes the mode, instead of sending the new state. */
    val legacyModeChange: Boolean = false,
    /** Not in OpenFreebuds' list, only recognised by its name: what it can do is a guess. */
    val guessed: Boolean = false,
)

object HuaweiModels {
    private val LEVELS = listOf(NoiseLevel.COMFORT, NoiseLevel.NORMAL, NoiseLevel.ULTRA)
    private val LEVELS_DYNAMIC = LEVELS + NoiseLevel.DYNAMIC

    private val buds4i = HuaweiProfile("HUAWEI FreeBuds 4i", channel = 16, anc = true)
    private val buds3 = HuaweiProfile("HUAWEI FreeBuds 3", channel = 1, anc = false)
    private val buds5i = HuaweiProfile("HUAWEI FreeBuds 5i", channel = 16, anc = true, cancelLevels = LEVELS_DYNAMIC)
    private val buds6i = HuaweiProfile("HUAWEI FreeBuds 6i", channel = 1, anc = true, cancelLevels = LEVELS_DYNAMIC)
    private val pro = HuaweiProfile("HUAWEI FreeBuds Pro", channel = 1, anc = true, cancelLevels = LEVELS_DYNAMIC, voiceBoost = true)
    private val pro2 = HuaweiProfile("HUAWEI FreeBuds Pro 2", channel = 1, anc = true, cancelLevels = LEVELS)
    private val pro3 = HuaweiProfile("HUAWEI FreeBuds Pro 3", channel = 1, anc = true, cancelLevels = LEVELS_DYNAMIC, voiceBoost = true)
    private val se = HuaweiProfile("HUAWEI FreeBuds SE", channel = 16, anc = false)
    private val se2 = HuaweiProfile("HUAWEI FreeBuds SE 2", channel = 1, anc = false)
    private val se4 = HuaweiProfile("HUAWEI FreeBuds SE 4 ANC", channel = 1, anc = true, cancelLevels = LEVELS_DYNAMIC)
    private val studio = HuaweiProfile("HUAWEI FreeBuds Studio", channel = 1, anc = true, cancelLevels = LEVELS_DYNAMIC, voiceBoost = true, tws = false)
    private val freeClip2 = HuaweiProfile("HUAWEI FreeClip 2", channel = 1, anc = false)
    private val lacePro =
        HuaweiProfile(
            "HUAWEI FreeLace Pro",
            channel = 16,
            anc = true,
            cancelLevels = LEVELS,
            tws = false,
            connectDelayMs = 2_000,
            legacyModeChange = true,
        )
    private val lacePro2 = HuaweiProfile("HUAWEI FreeLace Pro 2", channel = 1, anc = true, cancelLevels = LEVELS_DYNAMIC, voiceBoost = true, tws = false)

    /** OpenFreebuds' `DEVICE_TO_DRIVER_MAP`, by the name the earbuds give themselves. */
    val known: Map<String, HuaweiProfile> =
        mapOf(
            "HONOR Earbuds 2" to buds4i,
            "HONOR Earbuds 2 SE" to buds4i,
            "HONOR Earbuds 2 Lite" to buds4i,
            "HUAWEI FreeBuds 3" to buds3,
            "FreeBuds 3" to buds3,
            "HUAWEI FreeBuds 4i" to buds4i,
            "HUAWEI FreeBuds 5i" to buds5i,
            "HUAWEI FreeBuds 6i" to buds6i,
            "HUAWEI FreeBuds Pro" to pro,
            "HUAWEI FreeBuds Pro 2" to pro2,
            "HUAWEI FreeBuds Pro 3" to pro3,
            // OpenFreebuds drives the Pro 4, Pro 5 and the first FreeClip with the Pro 3's driver.
            "HUAWEI FreeBuds Pro 4" to pro3.copy(name = "HUAWEI FreeBuds Pro 4"),
            "HUAWEI FreeBuds Pro 5" to pro3.copy(name = "HUAWEI FreeBuds Pro 5"),
            "HUAWEI FreeClip" to pro3.copy(name = "HUAWEI FreeClip"),
            "HUAWEI FreeClip 2" to freeClip2,
            "HUAWEI FreeBuds SE" to se,
            "HUAWEI FreeBuds SE 2" to se2,
            "HUAWEI FreeBuds SE 4 ANC" to se4,
            "HUAWEI FreeBuds Studio" to studio,
            "HUAWEI FreeLace Pro" to lacePro,
            "HUAWEI FreeLace Pro 2" to lacePro2,
        )

    private val knownLowercase = known.mapKeys { it.key.lowercase() }

    private val TAG_STARTS = setOf('(', '[', '-', '_', '#')

    /** Names of Huawei and Honor audio products not in [known]. */
    private val family = Regex("""\b(freebuds|freeclip|freelace|freearc|honor\s+(earbuds|choice))\b""", RegexOption.IGNORE_CASE)

    /**
     * The profile for a Bluetooth name. An exact name is the model; a name the user changed or a
     * model OpenFreebuds does not list yet still counts when it names a Huawei audio family:
     * a later "Pro" behaves like the Pro 3, anything else gets on/off noise control without steps.
     */
    fun profileFor(name: String?): HuaweiProfile? {
        val trimmed = name?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        knownLowercase[trimmed.lowercase()]?.let { return it }
        // "HUAWEI FreeBuds 6i (ABCD)" and the like: a listed name followed by a tag. Not a listed
        // name followed by more of a model name: "FreeBuds Pro 6" is not the first FreeBuds Pro.
        val lower = trimmed.lowercase()
        knownLowercase.entries
            .filter { lower.startsWith(it.key) && lower.substring(it.key.length).trimStart().firstOrNull() in TAG_STARTS }
            .maxByOrNull { it.key.length }
            ?.let { return it.value }
        if (!family.containsMatchIn(trimmed)) return null
        return if (Regex("""freebuds\s+pro""", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)) {
            pro3.copy(name = trimmed, guessed = true)
        } else {
            HuaweiProfile(trimmed, channel = 1, anc = true, guessed = true)
        }
    }
}
