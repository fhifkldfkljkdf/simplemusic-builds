package org.simpmusic.headset

/** A byte channel to the headset's control service (RFCOMM on Android, a fake in the tests). */
interface HeadsetLink {
    /** Waits for bytes; returns how many were read, or -1 once the channel has closed. */
    suspend fun read(buffer: ByteArray): Int

    suspend fun write(bytes: ByteArray)

    /** Closes the channel; a [read] in progress then returns or throws. Safe to call twice. */
    fun close()
}
