package org.simpmusic.headset.momentum

import com.maxrave.logger.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import org.simpmusic.headset.HeadsetLink
import org.simpmusic.headset.gaia.GaiaCodec
import org.simpmusic.headset.gaia.GaiaFrame
import org.simpmusic.headset.gaia.GaiaFrameReader
import kotlin.concurrent.Volatile

/** The headset answered a command with a GAIA error. */
class GaiaErrorException(
    val command: Int,
    val reason: Int?,
) : Exception("Command ${GaiaFrame.hex(command, 4)} refused, reason ${reason?.let { GaiaFrame.hex(it, 2) } ?: "none"}")

/** The headset did not answer in time, or the channel is gone. */
class HeadsetIoException(
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)

/** A write was accepted but reading back shows something else. */
class SettingNotAppliedException(
    message: String,
) : Exception(message)

/**
 * One open control channel to a MOMENTUM 4: answers matched to commands, notifications folded into
 * [status], and the noise-control actions, each read before, written and read back to verify.
 *
 * [run] owns the channel: it reads until the channel closes and closes it when it returns. Actions
 * only work while [run] is running.
 */
class Momentum4Session(
    private val link: HeadsetLink,
    private val timing: Timing = Timing(),
) {
    data class Timing(
        val answerTimeoutMs: Long = 3_000,
        /** Battery is slow to answer (seen up to several seconds on the headset). */
        val batteryTimeoutMs: Long = 9_000,
        /** A full re-read now and then catches a missed notification. */
        val refreshEveryMs: Long = 60_000,
    )

    private class InFlight(
        val command: Int,
        val answer: CompletableDeferred<GaiaFrame>,
    )

    private val _status = MutableStateFlow(Momentum4Status())
    val status: StateFlow<Momentum4Status> = _status.asStateFlow()

    private val requestLock = Mutex()
    private val actionLock = Mutex()
    private val reader = GaiaFrameReader()

    @Volatile
    private var inFlight: InFlight? = null

    @Volatile
    private var consecutiveTimeouts = 0

    /**
     * True once the headset sends a notification for every noise-control change (both ANC and
     * Transparent Hearing registered): the status is then current, and a change can be planned
     * from it without reading the four values first.
     */
    @Volatile
    private var statusFollowsHeadset = false

    /** Which `0x1A00` format the headset takes; null until a write has told us. */
    @Volatile
    private var fullTableWrites: Boolean? = null

    /**
     * Registers for notifications, reads the state, calls [onReady], then keeps the channel open
     * until it fails (throws) or the caller is cancelled. Never returns normally.
     */
    suspend fun run(onReady: () -> Unit = {}) {
        coroutineScope {
            val readerJob = launch { readLoop() }
            try {
                val registered = mutableSetOf<Int>()
                for (feature in listOf(Momentum4.FEATURE_ANC, Momentum4.FEATURE_TRANSPARENT_HEARING, Momentum4.FEATURE_BATTERY)) {
                    // Without a notification the state is still read, and re-read every minute: a
                    // firmware that refuses or ignores one registration must not cost the whole
                    // channel. A dead channel still ends run(): three silences in a row close it.
                    try {
                        request(Momentum4.REGISTER_NOTIFICATION, byteArrayOf(feature.toByte()))
                        registered += feature
                    } catch (e: GaiaErrorException) {
                        Logger.w(TAG, "notifications for feature $feature: ${e.message}")
                    } catch (e: HeadsetIoException) {
                        Logger.w(TAG, "notifications for feature $feature: ${e.message}")
                    }
                }
                readNoiseControl()
                statusFollowsHeadset = Momentum4.FEATURE_ANC in registered && Momentum4.FEATURE_TRANSPARENT_HEARING in registered
                readBattery()
                onReady()
                while (true) {
                    delay(timing.refreshEveryMs)
                    actionLock.withLock { readNoiseControl() }
                }
            } finally {
                readerJob.cancel()
                link.close()
            }
        }
    }

    suspend fun setMode(mode: NoiseControlMode): NoiseControlState =
        act("mode $mode", { NoiseControlPlan.toMode(it, mode) }) { it.mode == mode }

    /** ANC at [level], 0 strongest … 100 weakest. */
    suspend fun setLevel(level: Int): NoiseControlState =
        act("level $level", { NoiseControlPlan.toLevel(it, level) }) {
            it.mode == NoiseControlMode.CUSTOM && it.level == level.coerceIn(0, 100)
        }

    suspend fun setAntiWind(antiWind: AntiWind): NoiseControlState {
        // The mode the change started in, kept if the plan is made a second time (see act).
        var modeBefore: NoiseControlMode? = null
        return act("anti-wind $antiWind", {
            if (modeBefore == null) modeBefore = it.mode
            NoiseControlPlan.toAntiWind(it, antiWind)
        }) { it.antiWind == antiWind && it.mode == modeBefore }
    }

    private suspend fun act(
        description: String,
        plan: (NoiseControlState) -> List<NoiseWrite>,
        applied: (NoiseControlState) -> Boolean,
    ): NoiseControlState =
        actionLock.withLock {
            // With notifications on, the status already holds what the headset reports, so the
            // switch costs only its writes and the read back that checks them: half the round
            // trips, which is what makes it feel immediate. Should that start have been stale, the
            // read back shows it, and the change is planned once more from what was read.
            val current = _status.value
            val known = current.noiseControl?.takeIf { statusFollowsHeadset }
            val knownTable = current.modes
            var (before, table) = if (known != null && knownTable != null) known to knownTable else readNoiseControl()
            var fromStatus = known != null && knownTable != null
            while (true) {
                val writes = plan(before)
                Logger.d(TAG, "$description: $before → $writes")
                for (write in writes) execute(write, table)
                val (after, afterTable) = readNoiseControl()
                if (applied(after)) return@withLock after
                if (!fromStatus) throw SettingNotAppliedException("$description: headset reports $after")
                fromStatus = false
                before = after
                table = afterTable
            }
            @Suppress("UNREACHABLE_CODE")
            error("unreachable")
        }

    private suspend fun execute(
        write: NoiseWrite,
        table: AncModeTable,
    ) {
        when (write) {
            is NoiseWrite.AncEnabled -> request(Momentum4.SET_ANC_ENABLED, switch(write.on))
            is NoiseWrite.TransparentHearing -> request(Momentum4.SET_TRANSPARENT_HEARING, switch(write.on))
            is NoiseWrite.Level -> request(Momentum4.SET_ANC_LEVEL, byteArrayOf(write.level.toByte()))
            is NoiseWrite.Mode -> {
                val full = fullTableWrites ?: true
                try {
                    request(Momentum4.SET_ANC_MODE, table.write(write.id, write.value, full))
                    fullTableWrites = full
                } catch (e: GaiaErrorException) {
                    // Firmware that wants the other format says so with reason 0x05; learn it once.
                    if (fullTableWrites != null || e.reason != Momentum4.ERROR_INVALID_PARAMETER) throw e
                    request(Momentum4.SET_ANC_MODE, table.write(write.id, write.value, !full))
                    fullTableWrites = !full
                }
            }
        }
    }

    private suspend fun readNoiseControl(): Pair<NoiseControlState, AncModeTable> {
        val enabled = decodeSwitch(request(Momentum4.GET_ANC_ENABLED))
        val table = AncModeTable.decode(request(Momentum4.GET_ANC_MODES))
        val level = decodeLevel(request(Momentum4.GET_ANC_LEVEL))
        val transparentHearing = decodeSwitch(request(Momentum4.GET_TRANSPARENT_HEARING))
        _status.update { it.copy(ancEnabled = enabled, modes = table, level = level, transparentHearing = transparentHearing) }
        val state =
            _status.value.noiseControl
                ?: throw ProtocolFormatException("incomplete noise control: enabled=$enabled modes=$table level=$level th=$transparentHearing")
        return state to table
    }

    private suspend fun readBattery() {
        // Registering feature 3 already brought the level as a notification; this is a fallback,
        // and a headset that does not answer it still has noise control.
        try {
            val percent = decodeBattery(request(Momentum4.GET_BATTERY_LEVEL, timeoutMs = timing.batteryTimeoutMs))
            _status.update { it.copy(batteryPercent = percent) }
        } catch (e: GaiaErrorException) {
            Logger.w(TAG, "battery: ${e.message}")
        } catch (e: ProtocolFormatException) {
            Logger.w(TAG, "battery: ${e.message}")
        } catch (e: HeadsetIoException) {
            // No answer in time. Battery is slow on this headset, and the level usually came as a
            // notification already; a missing one must not keep noise control from showing.
            Logger.w(TAG, "battery: ${e.message}")
        }
    }

    /** Sends [command] and waits for its answer; one command in flight at a time. */
    suspend fun request(
        command: Int,
        payload: ByteArray = ByteArray(0),
        timeoutMs: Long = timing.answerTimeoutMs,
    ): ByteArray =
        requestLock.withLock {
            val pending = InFlight(command, CompletableDeferred())
            inFlight = pending
            try {
                link.write(GaiaCodec.encode(Momentum4.VENDOR, command, payload))
                val frame: GaiaFrame = withTimeoutOrNull(timeoutMs) { pending.answer.await() } ?: throw unanswered(command)
                consecutiveTimeouts = 0
                if (frame.type == GaiaFrame.TYPE_ERROR) {
                    throw GaiaErrorException(command, frame.payload.firstOrNull()?.toInt()?.and(0xFF))
                }
                frame.payload
            } finally {
                inFlight = null
            }
        }

    private fun unanswered(command: Int): HeadsetIoException {
        // Three in a row: the channel is open but nobody is answering. Closing it ends run().
        if (++consecutiveTimeouts >= MAX_TIMEOUTS) link.close()
        return HeadsetIoException("No answer to ${GaiaFrame.hex(command, 4)}")
    }

    private suspend fun readLoop() {
        val buffer = ByteArray(1024)
        while (true) {
            val read =
                try {
                    link.read(buffer)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    throw HeadsetIoException("Channel failed", e)
                }
            if (read < 0) throw HeadsetIoException("Channel closed")
            for (frame in reader.push(buffer, 0, read)) dispatch(frame)
        }
    }

    internal fun dispatch(frame: GaiaFrame) {
        if (frame.vendor != Momentum4.VENDOR) return
        when (frame.type) {
            GaiaFrame.TYPE_RESPONSE, GaiaFrame.TYPE_ERROR -> {
                val pending = inFlight
                // An answer nobody waits for (late, after a timeout) is dropped.
                if (pending != null && pending.command == frame.baseCommand) pending.answer.complete(frame)
            }

            GaiaFrame.TYPE_NOTIFICATION -> {
                try {
                    applyNotification(frame)
                } catch (e: ProtocolFormatException) {
                    Logger.w(TAG, "notification $frame: ${e.message}")
                }
            }
        }
    }

    private fun applyNotification(frame: GaiaFrame) {
        val payload = frame.payload
        when (frame.baseCommand) {
            Momentum4.GET_ANC_ENABLED -> _status.update { it.copy(ancEnabled = decodeSwitch(payload)) }
            Momentum4.GET_ANC_MODES -> _status.update { it.copy(modes = AncModeTable.decode(payload)) }
            Momentum4.GET_ANC_LEVEL -> _status.update { it.copy(level = decodeLevel(payload)) }
            Momentum4.GET_TRANSPARENT_HEARING -> _status.update { it.copy(transparentHearing = decodeSwitch(payload)) }
            Momentum4.GET_BATTERY_LEVEL -> _status.update { it.copy(batteryPercent = decodeBattery(payload)) }
            Momentum4.GET_CHARGING_STATE ->
                if (payload.isNotEmpty()) _status.update { it.copy(charging = payload[0].toInt() == 1) }
        }
    }

    companion object {
        private const val TAG = "Momentum4"
        private const val MAX_TIMEOUTS = 3

        private fun switch(on: Boolean) = byteArrayOf(if (on) 1 else 0)

        internal fun decodeSwitch(payload: ByteArray): Boolean {
            if (payload.size != 1 || payload[0].toInt() !in 0..1) throw ProtocolFormatException("switch: ${payload.size} bytes")
            return payload[0].toInt() == 1
        }

        internal fun decodeLevel(payload: ByteArray): Int {
            val level = payload.singleOrNull()?.toInt()?.and(0xFF) ?: throw ProtocolFormatException("level: ${payload.size} bytes")
            if (level > 100) throw ProtocolFormatException("level $level")
            return level
        }

        /** The first byte is the headset; earbud models append more. */
        internal fun decodeBattery(payload: ByteArray): Int {
            val percent = payload.firstOrNull()?.toInt()?.and(0xFF) ?: throw ProtocolFormatException("battery: empty")
            if (percent > 100) throw ProtocolFormatException("battery $percent")
            return percent
        }
    }
}
