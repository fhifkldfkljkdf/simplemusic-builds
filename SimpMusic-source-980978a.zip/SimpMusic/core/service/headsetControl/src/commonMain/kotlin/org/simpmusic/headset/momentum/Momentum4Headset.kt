package org.simpmusic.headset.momentum

import com.maxrave.domain.data.model.headset.AntiWindMode
import com.maxrave.domain.data.model.headset.HeadsetBattery
import com.maxrave.domain.data.model.headset.NoiseControl
import com.maxrave.domain.data.model.headset.NoiseLevel
import com.maxrave.domain.data.model.headset.NoiseMode
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import org.simpmusic.headset.HeadsetLink
import org.simpmusic.headset.HeadsetReport
import org.simpmusic.headset.HeadsetSession
import org.simpmusic.headset.NotSupportedException

/** A MOMENTUM 4 as a [HeadsetSession]: [Momentum4Session] in the domain's terms. */
class Momentum4Headset(
    link: HeadsetLink,
    timing: Momentum4Session.Timing = Momentum4Session.Timing(),
) : HeadsetSession {
    val session = Momentum4Session(link, timing)
    private val ready = MutableStateFlow(false)
    private val _report = MutableStateFlow(HeadsetReport())
    override val report: StateFlow<HeadsetReport> = _report.asStateFlow()

    override suspend fun run() {
        coroutineScope {
            // Ends with run: the session throws when the channel goes, which cancels this too.
            launch { combine(session.status, ready) { status, ready -> status.toReport(ready) }.collect { _report.value = it } }
            session.run { ready.value = true }
        }
    }

    override suspend fun setMode(mode: NoiseMode) {
        session.setMode(
            when (mode) {
                NoiseMode.ANC -> NoiseControlMode.CUSTOM
                NoiseMode.ADAPTIVE -> NoiseControlMode.ADAPTIVE
                NoiseMode.TRANSPARENCY -> NoiseControlMode.TRANSPARENCY
                NoiseMode.OFF -> NoiseControlMode.OFF
            },
        )
    }

    // The headset counts the other way: 0 is the strongest cancellation.
    override suspend fun setStrength(strength: Int) {
        session.setLevel(100 - strength.coerceIn(0, 100))
    }

    override suspend fun setLevel(level: NoiseLevel): Unit = throw NotSupportedException("MOMENTUM 4 has a strength, not levels")

    override suspend fun setAntiWind(antiWind: AntiWindMode) {
        session.setAntiWind(
            when (antiWind) {
                AntiWindMode.OFF -> AntiWind.OFF
                AntiWindMode.MAXIMUM -> AntiWind.MAXIMUM
                AntiWindMode.AUTOMATIC -> AntiWind.AUTOMATIC
            },
        )
    }

    private companion object {
        fun Momentum4Status.toReport(ready: Boolean): HeadsetReport {
            val nc = noiseControl
            return HeadsetReport(
                // Noise control is what this headset is for: once it is known, it is ready.
                ready = ready || nc != null,
                noise =
                    nc?.let {
                        NoiseControl(
                            mode =
                                when (it.mode) {
                                    NoiseControlMode.OFF -> NoiseMode.OFF
                                    NoiseControlMode.TRANSPARENCY -> NoiseMode.TRANSPARENCY
                                    NoiseControlMode.ADAPTIVE -> NoiseMode.ADAPTIVE
                                    NoiseControlMode.CUSTOM -> NoiseMode.ANC
                                },
                            modes = listOf(NoiseMode.ANC, NoiseMode.ADAPTIVE, NoiseMode.TRANSPARENCY, NoiseMode.OFF),
                            strength = 100 - it.level,
                            antiWind =
                                when (it.antiWind) {
                                    AntiWind.OFF -> AntiWindMode.OFF
                                    AntiWind.MAXIMUM -> AntiWindMode.MAXIMUM
                                    AntiWind.AUTOMATIC -> AntiWindMode.AUTOMATIC
                                },
                        )
                    },
                battery = HeadsetBattery(percent = batteryPercent, charging = charging),
            )
        }
    }
}
