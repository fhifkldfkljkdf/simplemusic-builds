package org.simpmusic.headset

import com.maxrave.domain.data.model.headset.AntiWindMode
import com.maxrave.domain.data.model.headset.HeadsetBattery
import com.maxrave.domain.data.model.headset.NoiseControl
import com.maxrave.domain.data.model.headset.NoiseLevel
import com.maxrave.domain.data.model.headset.NoiseMode
import kotlinx.coroutines.flow.StateFlow

/** What an open channel knows about the headphones. */
data class HeadsetReport(
    /** The first reads are done; [noise] stays null for headphones without noise control. */
    val ready: Boolean = false,
    val noise: NoiseControl? = null,
    val battery: HeadsetBattery = HeadsetBattery(),
)

/**
 * One open control channel to a pair of headphones, whatever their make. [run] owns the channel:
 * it reads until the channel closes, closes it when it returns, and never returns normally. The
 * changes only work while [run] runs; each is checked by reading the headphones back, and throws
 * when they did not take it.
 */
interface HeadsetSession {
    val report: StateFlow<HeadsetReport>

    suspend fun run()

    suspend fun setMode(mode: NoiseMode)

    /** Continuous strength, 0…100 strongest; only where [NoiseControl.strength] is offered. */
    suspend fun setStrength(strength: Int)

    /** A step from [NoiseControl.levels]. */
    suspend fun setLevel(level: NoiseLevel)

    suspend fun setAntiWind(antiWind: AntiWindMode)
}

/** A change the headphones have no such control for. */
class NotSupportedException(
    message: String,
) : Exception(message)
