package org.simpmusic.headset

import org.simpmusic.headset.huawei.HuaweiModels
import org.simpmusic.headset.huawei.HuaweiProfile
import org.simpmusic.headset.momentum.Momentum4

/** Which protocol a pair of headphones speaks. */
sealed interface HeadsetKind {
    data object Momentum4Kind : HeadsetKind

    data class Huawei(
        val profile: HuaweiProfile,
    ) : HeadsetKind
}

object HeadsetModels {
    /** The kind of headphones a Bluetooth name belongs to, or null for ones this app cannot control. */
    fun recognise(name: String?): HeadsetKind? =
        when {
            Momentum4.isMomentum4(name) -> HeadsetKind.Momentum4Kind
            else -> HuaweiModels.profileFor(name)?.let(HeadsetKind::Huawei)
        }
}
