package org.simpmusic.headset.gaia

/**
 * Qualcomm GAIA v3 framing as Sennheiser headphones speak it over their RFCOMM control channel.
 *
 * Read off two MIT-licensed projects that verified it on a MOMENTUM 4 (firmware 3.37.3 and 3.38.3):
 * Tumult1337/momentum4-control and Zhengyang-Liu/m4-companion. A frame is
 * `FF version flags length vendor(2) command(2) payload [checksum]`, big-endian, where flag 0x01
 * appends an XOR checksum and flag 0x02 widens the length to two bytes. The headset sends version 3
 * with no flags; the reader accepts the other forms too, so a firmware that starts using them does
 * not silently break.
 */
class GaiaFrame(
    val vendor: Int,
    val command: Int,
    val payload: ByteArray,
) {
    /** Bits 8–7 of the command word. */
    val type: Int get() = (command shr 7) and 0x3

    /** The command this frame answers or reports on, with the type bits cleared. */
    val baseCommand: Int get() = command and TYPE_MASK.inv() and 0xFFFF

    override fun toString(): String = "${hex(vendor, 4)}/${hex(command, 4)} [${payload.joinToString(" ") { hex(it.toInt() and 0xFF, 2) }}]"

    companion object {
        const val TYPE_COMMAND = 0
        const val TYPE_NOTIFICATION = 1
        const val TYPE_RESPONSE = 2
        const val TYPE_ERROR = 3
        private const val TYPE_MASK = 0x0180

        internal fun hex(
            value: Int,
            digits: Int,
        ): String = value.toString(16).uppercase().padStart(digits, '0')
    }
}

object GaiaCodec {
    const val START_OF_FRAME: Int = 0xFF
    const val VERSION: Int = 3
    const val MAX_SHORT_PAYLOAD = 255

    /** A command frame, the only kind the phone sends. */
    fun encode(
        vendor: Int,
        command: Int,
        payload: ByteArray = ByteArray(0),
    ): ByteArray {
        require(payload.size <= MAX_SHORT_PAYLOAD) { "payload of ${payload.size} bytes" }
        val out = ByteArray(8 + payload.size)
        out[0] = START_OF_FRAME.toByte()
        out[1] = VERSION.toByte()
        out[2] = 0
        out[3] = payload.size.toByte()
        out[4] = (vendor shr 8).toByte()
        out[5] = vendor.toByte()
        out[6] = (command shr 8).toByte()
        out[7] = command.toByte()
        payload.copyInto(out, 8)
        return out
    }

    /** The command word of the response to [command]. */
    fun responseTo(command: Int): Int = command or 0x0100

    /** The command word of the error answer to [command]. */
    fun errorTo(command: Int): Int = command or 0x0180

    /** The command word of the notification the headset sends when what [command] reads changes. */
    fun notificationOf(command: Int): Int = command or 0x0080
}

/**
 * Turns the byte stream into frames: buffers across reads, yields several frames per read, and
 * resynchronises on the next `FF` after anything it cannot read. Not thread-safe: one per stream.
 */
class GaiaFrameReader {
    private var buffer = ByteArray(1024)
    private var size = 0

    val pendingBytes: Int get() = size

    fun push(
        data: ByteArray,
        offset: Int = 0,
        length: Int = data.size,
    ): List<GaiaFrame> {
        ensureCapacity(size + length)
        data.copyInto(buffer, size, offset, offset + length)
        size += length
        val frames = ArrayList<GaiaFrame>(1)
        while (size > 0) {
            val start = indexOfStart()
            if (start < 0) {
                size = 0
                break
            }
            if (start > 0) discard(start)
            if (size < 4) break
            val version = byte(1)
            val flags = byte(2)
            if ((version != 1 && version != 3 && version != 4) || (flags and (FLAG_CHECKSUM or FLAG_LONG).inv()) != 0) {
                discard(1)
                continue
            }
            val headerLength: Int
            val payloadLength: Int
            if (flags and FLAG_LONG != 0) {
                if (size < 5) break
                headerLength = 5
                payloadLength = (byte(3) shl 8) or byte(4)
                if (payloadLength > MAX_LONG_PAYLOAD) {
                    discard(1)
                    continue
                }
            } else {
                headerLength = 4
                payloadLength = byte(3)
            }
            val hasChecksum = flags and FLAG_CHECKSUM != 0
            val total = headerLength + 4 + payloadLength + if (hasChecksum) 1 else 0
            if (size < total) break
            if (hasChecksum) {
                var xor = 0
                for (i in 0 until total - 1) xor = xor xor byte(i)
                if (xor != byte(total - 1)) {
                    discard(1)
                    continue
                }
            }
            val vendor = (byte(headerLength) shl 8) or byte(headerLength + 1)
            val command = (byte(headerLength + 2) shl 8) or byte(headerLength + 3)
            val payload = buffer.copyOfRange(headerLength + 4, headerLength + 4 + payloadLength)
            discard(total)
            frames += GaiaFrame(vendor, command, payload)
        }
        return frames
    }

    private fun byte(i: Int): Int = buffer[i].toInt() and 0xFF

    private fun indexOfStart(): Int {
        for (i in 0 until size) if (byte(i) == GaiaCodec.START_OF_FRAME) return i
        return -1
    }

    private fun discard(count: Int) {
        buffer.copyInto(buffer, 0, count, size)
        size -= count
    }

    private fun ensureCapacity(needed: Int) {
        if (needed > buffer.size) buffer = buffer.copyOf(maxOf(needed, buffer.size * 2))
    }

    private companion object {
        const val FLAG_CHECKSUM = 0x01
        const val FLAG_LONG = 0x02
        const val MAX_LONG_PAYLOAD = 4096
    }
}
