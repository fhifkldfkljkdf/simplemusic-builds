package org.simpmusic.headset.huawei

import com.maxrave.domain.data.model.headset.AntiWindMode
import com.maxrave.domain.data.model.headset.HeadsetBattery
import com.maxrave.domain.data.model.headset.NoiseControl
import com.maxrave.domain.data.model.headset.NoiseLevel
import com.maxrave.domain.data.model.headset.NoiseMode
import com.maxrave.logger.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import org.simpmusic.headset.HeadsetLink
import org.simpmusic.headset.HeadsetReport
import org.simpmusic.headset.HeadsetSession
import org.simpmusic.headset.NotSupportedException
import org.simpmusic.headset.momentum.HeadsetIoException
import org.simpmusic.headset.momentum.ProtocolFormatException
import org.simpmusic.headset.momentum.SettingNotAppliedException
import kotlin.concurrent.Volatile

/** The earbuds answered a write with a result code other than "done". */
class HuaweiRefusedException(
    val command: Int,
    val code: Int,
) : Exception("Command ${HuaweiPacket.hex(command, 4)} refused with result $code")

/**
 * One open control channel to Huawei or Honor earbuds: noise control and battery, as OpenFreebuds
 * (melianmiko/OpenFreebuds, GPL-3.0) reads and writes them (`handler/anc.py`, `handler/battery.py`).
 *
 * - Noise control is read with `2B 2A` (parameters 1, 2). The answer's parameter 1 is
 *   `[level, mode]`: mode 0 off, 1 noise cancelling, 2 awareness; the earbuds also send it unasked
 *   when their own controls change it. A mode is written with `2B 04` parameter 1 =
 *   `[mode, FF]` (`[00, 00]` for off) — the order differs from the read. FreeBuddy
 *   (TheLastGimbus/FreeBuddy) and Gadgetbridge write it the same way.
 * - A level is written as `[current mode, level]`, in parameter 1 by OpenFreebuds and in parameter 2
 *   by Gadgetbridge. Parameter 1 is sent first; when reading back shows no change, parameter 2,
 *   and whichever worked is used from then on.
 * - Cancelling levels: 0 normal, 1 comfort, 2 ultra, 3 dynamic. Awareness: 1 voice boost, 2 normal.
 * - Battery is read with `01 08` (parameters 1, 2, 3) and also sent unasked as `01 27`:
 *   1 = overall %, 2 = left, right, case, 3 = a charging flag per part.
 */
class HuaweiHeadset(
    private val link: HeadsetLink,
    val profile: HuaweiProfile,
    private val timing: Timing = Timing(),
) : HeadsetSession {
    data class Timing(
        val answerTimeoutMs: Long = 3_000,
        val refreshEveryMs: Long = 60_000,
        /** Some models report the new mode a moment after acknowledging the write. */
        val settleMs: Long = 400,
        /** OpenFreebuds tries each first read up to five times; fewer here, since a dead channel is retried anyway. */
        val firstReadAttempts: Int = 3,
    )

    private class InFlight(
        val command: Int,
        val answer: CompletableDeferred<HuaweiPacket>,
    )

    private val _report = MutableStateFlow(HeadsetReport())
    override val report: StateFlow<HeadsetReport> = _report.asStateFlow()

    private val requestLock = Mutex()
    private val actionLock = Mutex()
    private val reader = HuaweiPacketReader()
    private val rereadNoise = Channel<Unit>(Channel.CONFLATED)

    @Volatile
    private var inFlight: InFlight? = null

    @Volatile
    private var ready = false

    @Volatile
    private var consecutiveTimeouts = 0

    @Volatile
    private var ancSupported = profile.anc

    /** The last `[level, mode]` the earbuds reported. */
    @Volatile
    private var noiseRaw: ByteArray? = null

    /** The parameter a level write took (see the class notes); null until one has. */
    @Volatile
    private var levelParam: Int? = null

    override suspend fun run() {
        coroutineScope {
            val readerJob = launch { readLoop() }
            val rereader = launch { for (signal in rereadNoise) actionLock.withLock { quietly { readNoise() } } }
            try {
                val batteryRead = firstRead { readBattery() }
                if (ancSupported) ancSupported = firstRead { readNoise() }
                if (!batteryRead && !ancSupported) throw HeadsetIoException("No answer from ${profile.name}")
                ready = true
                _report.update { it.copy(ready = true) }
                while (true) {
                    delay(timing.refreshEveryMs)
                    actionLock.withLock {
                        quietly { readBattery() }
                        if (ancSupported) quietly { readNoise() }
                    }
                }
            } finally {
                readerJob.cancel()
                rereader.cancel()
                link.close()
            }
        }
    }

    override suspend fun setMode(mode: NoiseMode) {
        val modeByte =
            when (mode) {
                NoiseMode.OFF -> MODE_OFF
                NoiseMode.ANC -> MODE_CANCELLING
                NoiseMode.TRANSPARENCY -> MODE_AWARENESS
                NoiseMode.ADAPTIVE -> throw NotSupportedException("Huawei earbuds have no adaptive mode; dynamic is a cancelling level")
            }
        val payload = byteArrayOf(modeByte.toByte(), if (modeByte == MODE_OFF) 0 else 0xFF.toByte())
        act("mode $mode", listOf(1 to payload)) { it.mode == mode }
    }

    override suspend fun setLevel(level: NoiseLevel) {
        val raw = noiseRaw ?: throw NotSupportedException("noise control not read yet")
        val mode = raw[1].toInt() and 0xFF
        val levelByte =
            when (mode) {
                MODE_CANCELLING -> if (level in profile.cancelLevels) CANCEL_LEVELS[level] else null
                MODE_AWARENESS -> if (profile.voiceBoost) AWARENESS_LEVELS[level] else null
                else -> null
            } ?: throw NotSupportedException("$level in mode $mode")
        val payload = byteArrayOf(mode.toByte(), levelByte.toByte())
        val attempts = levelParam?.let { listOf(it to payload) } ?: listOf(1 to payload, 2 to payload)
        levelParam = act("level $level", attempts) { it.level == level }
    }

    override suspend fun setStrength(strength: Int): Unit = throw NotSupportedException("Huawei earbuds have levels, not a strength")

    override suspend fun setAntiWind(antiWind: AntiWindMode): Unit = throw NotSupportedException("no wind noise setting")

    /**
     * Writes `2B 04` with each of [attempts] (parameter type to value) in turn until reading back
     * shows [applied]; returns the parameter type that worked.
     */
    private suspend fun act(
        description: String,
        attempts: List<Pair<Int, ByteArray>>,
        applied: (NoiseControl) -> Boolean,
    ): Int {
        if (!ancSupported) throw NotSupportedException("${profile.name} has no noise control")
        actionLock.withLock {
            var failure: Exception? = null
            for ((type, payload) in attempts) {
                Logger.d(TAG, "${profile.name}: $description as parameter $type")
                // A write the earbuds take without acknowledging still counts when reading back shows it.
                try {
                    val answer = request(HuaweiPacket.write(CMD_NOISE_WRITE, type to payload))
                    answer.result()?.let { if (it != HuaweiPacket.RESULT_OK) throw HuaweiRefusedException(CMD_NOISE_WRITE, it) }
                } catch (e: HeadsetIoException) {
                    failure = e
                } catch (e: HuaweiRefusedException) {
                    failure = e
                    continue
                }
                if (readNoise()?.let(applied) == true) return type
                delay(timing.settleMs)
                val after = readNoise()
                if (after?.let(applied) == true) return type
                failure = SettingNotAppliedException("$description: earbuds report $after")
            }
            throw failure ?: SettingNotAppliedException(description)
        }
    }

    /** True when [read] answered within the first-read attempts. */
    private suspend fun firstRead(read: suspend () -> Unit): Boolean {
        repeat(timing.firstReadAttempts) {
            try {
                read()
                return true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Logger.w(TAG, "${profile.name}: first read: ${e.message}")
                if (e is ProtocolFormatException) return false
            }
        }
        return false
    }

    private suspend fun quietly(block: suspend () -> Unit) {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Logger.w(TAG, "${profile.name}: ${e.message}")
        }
    }

    private suspend fun readNoise(): NoiseControl? {
        val answer = request(HuaweiPacket.read(CMD_NOISE_READ, 1, 2))
        if (!applyNoise(answer)) throw ProtocolFormatException("noise control: $answer")
        return _report.value.noise
    }

    private suspend fun readBattery() {
        val answer = request(HuaweiPacket.read(CMD_BATTERY_READ, 1, 2, 3))
        if (!applyBattery(answer)) throw ProtocolFormatException("battery: $answer")
    }

    /** Sends [packet] and waits for the packet with the same command; one in flight at a time. */
    internal suspend fun request(
        packet: HuaweiPacket,
        timeoutMs: Long = timing.answerTimeoutMs,
    ): HuaweiPacket =
        requestLock.withLock {
            val pending = InFlight(packet.command, CompletableDeferred())
            inFlight = pending
            try {
                link.write(packet.encode())
                val answer: HuaweiPacket = withTimeoutOrNull(timeoutMs) { pending.answer.await() } ?: throw unanswered(packet.command)
                consecutiveTimeouts = 0
                answer
            } finally {
                inFlight = null
            }
        }

    private fun unanswered(command: Int): HeadsetIoException {
        // Once the channel has worked, three silences in a row mean it is gone; closing it ends run().
        if (ready && ++consecutiveTimeouts >= MAX_TIMEOUTS) link.close()
        return HeadsetIoException("No answer to ${HuaweiPacket.hex(command, 4)}")
    }

    private suspend fun readLoop() {
        val buffer = ByteArray(1024)
        while (true) {
            val read =
                try {
                    link.read(buffer)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    throw HeadsetIoException("Channel failed", e)
                }
            if (read < 0) throw HeadsetIoException("Channel closed")
            for (packet in reader.push(buffer, 0, read)) dispatch(packet)
        }
    }

    internal fun dispatch(packet: HuaweiPacket) {
        val pending = inFlight
        if (pending != null && pending.command == packet.command) {
            pending.answer.complete(packet)
            return
        }
        when (packet.command) {
            CMD_NOISE_READ -> applyNoise(packet)
            CMD_BATTERY_READ, CMD_BATTERY_NOTIFY -> applyBattery(packet)
            // Older models only say "the mode changed" and expect to be asked what it is now.
            CMD_NOISE_CHANGED -> if (ancSupported) rereadNoise.trySend(Unit)
            else -> Unit
        }
    }

    private fun applyNoise(packet: HuaweiPacket): Boolean {
        val raw = packet.param(1)?.takeIf { it.size == 2 } ?: return false
        val noise = noiseOf(raw) ?: return false
        noiseRaw = raw
        _report.update { it.copy(noise = noise) }
        return true
    }

    private fun noiseOf(raw: ByteArray): NoiseControl? {
        val levelByte = raw[0].toInt() and 0xFF
        val modes = listOf(NoiseMode.ANC, NoiseMode.TRANSPARENCY, NoiseMode.OFF)
        return when (raw[1].toInt() and 0xFF) {
            MODE_OFF -> NoiseControl(mode = NoiseMode.OFF, modes = modes)
            MODE_CANCELLING ->
                if (profile.cancelLevels.isEmpty()) {
                    NoiseControl(mode = NoiseMode.ANC, modes = modes)
                } else {
                    NoiseControl(
                        mode = NoiseMode.ANC,
                        modes = modes,
                        level = CANCEL_LEVELS.entries.firstOrNull { it.value == levelByte }?.key?.takeIf { it in profile.cancelLevels },
                        levels = profile.cancelLevels,
                    )
                }
            MODE_AWARENESS ->
                if (!profile.voiceBoost) {
                    NoiseControl(mode = NoiseMode.TRANSPARENCY, modes = modes)
                } else {
                    NoiseControl(
                        mode = NoiseMode.TRANSPARENCY,
                        modes = modes,
                        level = AWARENESS_LEVELS.entries.firstOrNull { it.value == levelByte }?.key,
                        levels = listOf(NoiseLevel.NORMAL, NoiseLevel.VOICE_BOOST),
                    )
                }
            else -> null
        }
    }

    private fun applyBattery(packet: HuaweiPacket): Boolean {
        val overall = packet.param(1)?.singleOrNull()?.let { it.toInt() and 0xFF }?.takeIf { it <= 100 }
        val parts = packet.param(2)?.takeIf { it.size == 3 && profile.tws }?.map { it.toInt() and 0xFF }
        val charging = packet.param(3)?.takeIf { it.isNotEmpty() }?.any { it.toInt() == 1 }
        if (overall == null && parts == null) return false
        _report.update {
            it.copy(
                battery =
                    HeadsetBattery(
                        percent = overall,
                        left = parts?.get(0)?.takeIf { p -> p in 1..100 },
                        right = parts?.get(1)?.takeIf { p -> p in 1..100 },
                        case = parts?.get(2)?.takeIf { p -> p in 1..100 },
                        charging = charging,
                    ),
            )
        }
        return true
    }

    companion object {
        private const val TAG = "HuaweiBuds"
        private const val MAX_TIMEOUTS = 3

        const val CMD_BATTERY_READ = 0x0108
        const val CMD_BATTERY_NOTIFY = 0x0127
        const val CMD_NOISE_CHANGED = 0x2B03
        const val CMD_NOISE_WRITE = 0x2B04
        const val CMD_NOISE_READ = 0x2B2A

        const val MODE_OFF = 0
        const val MODE_CANCELLING = 1
        const val MODE_AWARENESS = 2

        val CANCEL_LEVELS = mapOf(NoiseLevel.NORMAL to 0, NoiseLevel.COMFORT to 1, NoiseLevel.ULTRA to 2, NoiseLevel.DYNAMIC to 3)
        val AWARENESS_LEVELS = mapOf(NoiseLevel.VOICE_BOOST to 1, NoiseLevel.NORMAL to 2)

        /** The result code an answer to a write carries, if any. */
        private fun HuaweiPacket.result(): Int? =
            param(HuaweiPacket.RESULT)?.takeIf { it.isNotEmpty() && it.size <= 4 }?.fold(0) { acc, b -> (acc shl 8) or (b.toInt() and 0xFF) }
    }
}
