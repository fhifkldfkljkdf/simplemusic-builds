package org.simpmusic.headset.huawei

/**
 * The packets Huawei and Honor earbuds speak over their Bluetooth serial port, ported from
 * OpenFreebuds (melianmiko/OpenFreebuds, GPL-3.0, `driver/huawei/package.py`).
 *
 * `5A len(2) 00 command(2) [type(1) length(1) value]… crc(2)`, big-endian. `len` counts the `00`
 * byte, the command and the parameters, so a whole packet is `len + 5` bytes. The checksum is
 * CRC-16/XMODEM over everything before it. The command is two bytes: a service (`2B` for most
 * earbud settings, `01` for device basics) and a command within it.
 */
class HuaweiPacket(
    val command: Int,
    /** Parameters by type, in the order they were written. */
    val params: Map<Int, ByteArray> = emptyMap(),
) {
    fun param(type: Int): ByteArray? = params[type]

    fun encode(): ByteArray {
        var bodyLength = 2
        for (value in params.values) bodyLength += 2 + value.size
        val length = bodyLength + 1
        require(length <= 0xFFFF) { "packet of $length bytes" }
        val out = ByteArray(length + 5)
        out[0] = START.toByte()
        out[1] = (length shr 8).toByte()
        out[2] = length.toByte()
        out[3] = 0
        out[4] = (command shr 8).toByte()
        out[5] = command.toByte()
        var p = 6
        for ((type, value) in params) {
            require(value.size <= 0xFF) { "parameter $type of ${value.size} bytes" }
            out[p++] = type.toByte()
            out[p++] = value.size.toByte()
            value.copyInto(out, p)
            p += value.size
        }
        val crc = crc16(out, 0, p)
        out[p] = (crc shr 8).toByte()
        out[p + 1] = crc.toByte()
        return out
    }

    override fun toString(): String =
        hex(command, 4) + params.entries.joinToString("") { (type, value) ->
            " $type=" + value.joinToString("") { hex(it.toInt() and 0xFF, 2) }
        }

    companion object {
        const val START = 0x5A

        /** Parameter type of the result code some answers to a write carry. */
        const val RESULT = 0x7F

        /** The result code meaning "done". */
        const val RESULT_OK = 100_000

        /** A read: each wanted parameter type, with no value. */
        fun read(
            command: Int,
            vararg types: Int,
        ): HuaweiPacket = HuaweiPacket(command, types.associateWith { ByteArray(0) })

        fun write(
            command: Int,
            vararg params: Pair<Int, ByteArray>,
        ): HuaweiPacket = HuaweiPacket(command, linkedMapOf(*params))

        /**
         * CRC-16/XMODEM: polynomial 0x1021, initial value 0, no reflection — what OpenFreebuds'
         * table computes.
         */
        fun crc16(
            data: ByteArray,
            from: Int = 0,
            to: Int = data.size,
        ): Int {
            var crc = 0
            for (i in from until to) {
                crc = crc xor ((data[i].toInt() and 0xFF) shl 8)
                repeat(8) {
                    crc = if (crc and 0x8000 != 0) (crc shl 1) xor 0x1021 else crc shl 1
                }
                crc = crc and 0xFFFF
            }
            return crc
        }

        internal fun hex(
            value: Int,
            digits: Int,
        ): String = value.toString(16).uppercase().padStart(digits, '0')
    }
}

/**
 * Turns the byte stream into packets: buffers across reads, yields several packets per read, and
 * resynchronises on the next `5A` after anything it cannot read. A packet whose checksum is wrong
 * but whose parameters fill it exactly is still taken (RFCOMM has its own checksum; a firmware
 * that computes this one differently should not go deaf), anything else is skipped.
 */
class HuaweiPacketReader {
    private var buffer = ByteArray(1024)
    private var size = 0

    val pendingBytes: Int get() = size

    /** Packets taken despite a wrong checksum; for logging. */
    var checksumMismatches = 0
        private set

    fun push(
        data: ByteArray,
        offset: Int = 0,
        length: Int = data.size,
    ): List<HuaweiPacket> {
        ensureCapacity(size + length)
        data.copyInto(buffer, size, offset, offset + length)
        size += length
        val packets = ArrayList<HuaweiPacket>(1)
        while (size > 0) {
            val start = indexOfStart()
            if (start < 0) {
                size = 0
                break
            }
            if (start > 0) discard(start)
            if (size < 4) break
            if (byte(3) != 0) {
                discard(1)
                continue
            }
            val declared = (byte(1) shl 8) or byte(2)
            // The smallest packet is 00 + a two-byte command.
            if (declared < 3 || declared > MAX_LENGTH) {
                discard(1)
                continue
            }
            val total = declared + 5
            if (size < total) break
            val params = parseParams(6, declared + 3)
            val crcOk = HuaweiPacket.crc16(buffer, 0, total - 2) == ((byte(total - 2) shl 8) or byte(total - 1))
            if (params == null) {
                discard(1)
                continue
            }
            if (!crcOk) checksumMismatches++
            val command = (byte(4) shl 8) or byte(5)
            discard(total)
            packets += HuaweiPacket(command, params)
        }
        return packets
    }

    /** The parameters in `[from, to)`, or null when they do not fill it exactly. */
    private fun parseParams(
        from: Int,
        to: Int,
    ): Map<Int, ByteArray>? {
        val params = LinkedHashMap<Int, ByteArray>()
        var p = from
        while (p < to) {
            if (p + 2 > to) return null
            val type = byte(p)
            val length = byte(p + 1)
            if (p + 2 + length > to) return null
            params[type] = buffer.copyOfRange(p + 2, p + 2 + length)
            p += 2 + length
        }
        return params
    }

    private fun byte(i: Int): Int = buffer[i].toInt() and 0xFF

    private fun indexOfStart(): Int {
        for (i in 0 until size) if (byte(i) == HuaweiPacket.START) return i
        return -1
    }

    private fun discard(count: Int) {
        buffer.copyInto(buffer, 0, count, size)
        size -= count
    }

    private fun ensureCapacity(needed: Int) {
        if (needed > buffer.size) buffer = buffer.copyOf(maxOf(needed, buffer.size * 2))
    }

    private companion object {
        /** Earbud packets are small; anything bigger is not a length but noise. */
        const val MAX_LENGTH = 4096
    }
}
