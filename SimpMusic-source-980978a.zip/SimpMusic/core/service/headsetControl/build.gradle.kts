import com.android.build.gradle.internal.tasks.CompileArtProfileTask

plugins {
    alias(libs.plugins.kotlin.multiplatform)
    alias(libs.plugins.android.kotlin.multiplatform.library)
    alias(libs.plugins.android.lint)
}

// Private copy: control of Bluetooth headphones over their vendor channel (Sennheiser MOMENTUM 4,
// Huawei / Honor earbuds: noise cancelling and battery). The protocols and sessions are common code;
// only Android opens the channel. The JVM target exists for the tests.
kotlin {
    android {
        namespace = "org.simpmusic.headset"
        compileSdk = 37
        minSdk = 26
    }

    jvm()

    sourceSets {
        commonMain {
            dependencies {
                implementation(libs.kotlin.stdlib)
                // Kept out of the version catalog, which upstream owns; same version as the rest of the app.
                implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:${libs.versions.coroutines.android.get()}")
                // Logger.
                implementation(projects.common)
                // Sessions report in the domain's headset model, as kotlinYtmusicScraper does for its own.
                implementation(projects.domain)
            }
        }

        commonTest {
            dependencies {
                implementation(libs.kotlin.test)
            }
        }
    }
}

tasks.withType<CompileArtProfileTask> {
    enabled = false
}
