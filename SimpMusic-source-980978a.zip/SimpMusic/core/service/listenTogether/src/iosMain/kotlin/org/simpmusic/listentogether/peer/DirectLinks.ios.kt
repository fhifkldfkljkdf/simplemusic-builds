package org.simpmusic.listentogether.peer

internal actual fun platformDirectLinks(): DirectLinks = NoDirectLinks
