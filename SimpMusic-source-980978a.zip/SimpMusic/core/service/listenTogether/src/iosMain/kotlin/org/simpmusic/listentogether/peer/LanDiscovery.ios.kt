package org.simpmusic.listentogether.peer

internal actual fun platformLanDiscovery(): LanDiscovery = NoLanDiscovery
