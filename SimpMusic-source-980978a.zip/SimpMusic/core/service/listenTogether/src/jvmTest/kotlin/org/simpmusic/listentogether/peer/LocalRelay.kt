package org.simpmusic.listentogether.peer

import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.engine.EmbeddedServer
import io.ktor.server.engine.embeddedServer
import io.ktor.server.routing.routing
import io.ktor.server.websocket.DefaultWebSocketServerSession
import io.ktor.server.websocket.WebSockets
import io.ktor.server.websocket.webSocket
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import org.simpmusic.nostr.NostrEvent
import org.simpmusic.nostr.NostrFilter
import java.net.ServerSocket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * A NIP-01 relay for the peer-room tests, behaving as public relays do for what rooms use:
 * ids and signatures are checked, and ephemeral events (20000–29999) are passed on to current
 * subscribers and never stored. (The nostr module's tests carry a fuller one; test sources cannot
 * be shared between modules.)
 */
internal class LocalRelay(
    val port: Int = ServerSocket(0).use { it.localPort },
) {
    val url = "ws://127.0.0.1:$port"
    val forwarded = AtomicInteger()

    /** Events this returns true for are acknowledged and then lost, as a flaky relay loses them. */
    @Volatile
    var drop: (NostrEvent) -> Boolean = { false }
    private val clients = ConcurrentHashMap<DefaultWebSocketServerSession, ConcurrentHashMap<String, List<NostrFilter>>>()
    private var server: EmbeddedServer<*, *>? = null

    fun start() {
        server =
            embeddedServer(CIO, port = port, host = "127.0.0.1") {
                install(WebSockets)
                routing {
                    webSocket("/") {
                        val subs = ConcurrentHashMap<String, List<NostrFilter>>()
                        clients[this] = subs
                        try {
                            for (frame in incoming) {
                                if (frame is Frame.Text) handle(this, subs, frame.readText())
                            }
                        } finally {
                            clients.remove(this)
                        }
                    }
                }
            }.start(wait = false)
    }

    fun stop() {
        server?.stop(0, 500)
        server = null
    }

    val subscriptionCount: Int get() = clients.values.sumOf { subs -> subs.keys.count { it != "keepalive" } }

    private suspend fun handle(
        session: DefaultWebSocketServerSession,
        subs: MutableMap<String, List<NostrFilter>>,
        text: String,
    ) {
        val message = Json.parseToJsonElement(text).jsonArray
        when (message[0].jsonPrimitive.content) {
            "EVENT" -> {
                val event = NostrEvent.fromJson(message[1] as JsonObject)
                val ok = event != null && event.isValid()
                session.sendJson(JsonArray(listOf(JsonPrimitive("OK"), JsonPrimitive(event?.id ?: ""), JsonPrimitive(ok), JsonPrimitive(if (ok) "" else "invalid"))))
                if (!ok || event == null) return
                if (drop(event)) return
                for ((other, otherSubs) in clients) {
                    for ((subId, filters) in otherSubs) {
                        if (filters.any { it.matches(event) }) {
                            forwarded.incrementAndGet()
                            other.sendJson(JsonArray(listOf(JsonPrimitive("EVENT"), JsonPrimitive(subId), event.toJson())))
                        }
                    }
                }
            }

            "REQ" -> {
                val subId = message[1].jsonPrimitive.content
                subs[subId] = message.drop(2).map { NostrFilter.fromJson(it as JsonObject) }
                session.sendJson(JsonArray(listOf(JsonPrimitive("EOSE"), JsonPrimitive(subId))))
            }

            "CLOSE" -> subs.remove(message[1].jsonPrimitive.content)
        }
    }

    private suspend fun DefaultWebSocketServerSession.sendJson(json: JsonElement) = send(Frame.Text(json.toString()))
}
