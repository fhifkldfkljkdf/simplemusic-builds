package org.simpmusic.listentogether

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.ServerSocket
import java.nio.file.Files
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Staying in a room across a dropped connection, against a REAL metroserver run on this machine.
 *
 * Unlike [LiveRoomSyncTest] this never touches someone else's server: it starts its own
 * (MetrolistGroup/metroserver built from source) on a free local port, so it can do what a public
 * server cannot be asked to — restart, lose its state, or freeze. Skipped unless
 * `LT_SERVER_BINARY` points at a metroserver binary:
 *
 *     LT_SERVER_BINARY=/path/to/metroserver ./gradlew :listenTogether:jvmTest --tests '*LocalServerResumeTest*'
 */
class LocalServerResumeTest {
    private val binary: File? = System.getenv("LT_SERVER_BINARY")?.let(::File)?.takeIf { it.canExecute() }

    private class LocalServer(
        private val binary: File,
    ) {
        val port = ServerSocket(0).use { it.localPort }
        val url = "ws://127.0.0.1:$port/ws"
        private val dir = Files.createTempDirectory("metroserver").toFile()
        private var process: Process? = null

        fun start(freshState: Boolean = false) {
            if (freshState) File(dir, "metroserver.db").delete()
            process =
                ProcessBuilder(binary.absolutePath)
                    .directory(dir)
                    .redirectErrorStream(true)
                    .redirectOutput(File(dir, "server.log"))
                    .also {
                        it.environment()["PORT"] = port.toString()
                        it.environment()["DATABASE_FILE"] = File(dir, "metroserver.db").absolutePath
                    }.start()
            Thread.sleep(700)
        }

        /** SIGTERM: metroserver closes every client and saves rooms and seats before exiting. */
        fun stop() {
            process?.let {
                it.destroy()
                it.waitFor()
            }
        }

        fun signal(name: String) {
            val pid = process?.pid() ?: return
            ProcessBuilder("kill", "-$name", pid.toString()).start().waitFor()
        }

        fun cleanUp() {
            process?.destroyForcibly()
            dir.deleteRecursively()
        }
    }

    // metroserver's default policy lets "ktor-client" user agents host.
    private fun session(server: LocalServer) =
        ListenTogetherSession(
            ListenTogetherClient(
                clientVersion = "simpmusic-resume-test",
                userAgent = "ktor-client SimpMusic/test",
                serverUrl = { server.url },
            ),
        )

    private suspend fun <T> eventually(
        label: String,
        timeoutMs: Long = 30_000,
        block: () -> T?,
    ): T? =
        withTimeoutOrNull(timeoutMs) {
            while (true) {
                block()?.let { return@withTimeoutOrNull it }
                delay(100)
            }
            @Suppress("UNREACHABLE_CODE")
            null
        }.also { if (it == null) println("  ✗ timed out waiting for $label") }

    /** A host and a guest in one room; returns the room code. */
    private suspend fun fillRoom(
        host: ListenTogetherSession,
        guest: ListenTogetherSession,
    ): String {
        host.connect()
        guest.connect()
        assertNotNull(eventually("host connected") { host.state.value.isConnected.takeIf { it } })
        assertNotNull(eventually("guest connected") { guest.state.value.isConnected.takeIf { it } })
        host.createRoom("Host")
        val code = assertNotNull(eventually("room_created") { host.state.value.roomCode })
        guest.joinRoom(code, "Guest")
        val request = assertNotNull(eventually("join_request") { host.state.value.joinRequests.firstOrNull() })
        host.approveJoin(request.userId)
        assertNotNull(eventually("join_approved") { guest.state.value.roomCode })
        return code
    }

    @Test
    fun bothMembersGetTheirSeatsBackAfterTheServerRestarts() {
        val bin = binary ?: return println("LT_SERVER_BINARY not set — skipped")
        val server = LocalServer(bin)
        val host = session(server)
        val guest = session(server)
        try {
            runBlocking {
                server.start()
                val code = fillRoom(host, guest)
                println("✓ room $code with two members")

                server.stop()
                assertNotNull(eventually("guest notices the drop") { guest.state.value.isConnected.not().takeIf { it } })
                // The room is kept while retrying — the old client wiped it here after ~31 s at most.
                assertEquals(code, guest.state.value.roomCode)
                println("✓ connection dropped, room kept while retrying")

                server.start()
                assertNotNull(eventually("guest resumed") { guest.state.value.takeIf { it.isConnected && it.roomCode == code } })
                assertNotNull(eventually("host resumed") { host.state.value.takeIf { it.isConnected && it.isHost && it.roomCode == code } })
                assertNull(guest.state.value.error)
                assertTrue(!guest.state.value.isHost)
                println("✓ both back in $code, host still host")
            }
        } finally {
            host.release()
            guest.release()
            server.cleanUp()
        }
    }

    @Test
    fun aSeatTheServerNoLongerHasClearsTheRoomWithAReason() {
        val bin = binary ?: return println("LT_SERVER_BINARY not set — skipped")
        val server = LocalServer(bin)
        val host = session(server)
        val guest = session(server)
        try {
            runBlocking {
                server.start()
                fillRoom(host, guest)
                server.stop()
                // A server that comes back without its saved state no longer knows the token.
                server.start(freshState = true)
                val lost = assertNotNull(eventually("seat lost") { guest.state.value.takeIf { !it.inRoom && it.error != null } })
                assertTrue(lost.isConnected, "the connection itself should be back")
                println("✓ guest told: ${lost.error}")
            }
        } finally {
            host.release()
            guest.release()
            server.cleanUp()
        }
    }

    @Test
    fun aFrozenConnectionIsNoticedAndTheSeatResumed() {
        val bin = binary ?: return println("LT_SERVER_BINARY not set — skipped")
        val server = LocalServer(bin)
        val host = session(server)
        val guest = session(server)
        try {
            runBlocking {
                server.start()
                val code = fillRoom(host, guest)
                // SIGSTOP keeps every TCP connection open but nothing answers: exactly what a
                // vanished network looks like from the phone. Only the watchdog can notice it.
                server.signal("STOP")
                assertNotNull(
                    eventually("watchdog fires", timeoutMs = 75_000) { guest.state.value.isConnected.not().takeIf { it } },
                    "the silence watchdog never declared the socket dead",
                )
                assertEquals(code, guest.state.value.roomCode)
                println("✓ silent socket noticed, room kept")
                server.signal("CONT")
                assertNotNull(eventually("guest resumed", timeoutMs = 60_000) { guest.state.value.takeIf { it.isConnected && it.roomCode == code } })
                println("✓ back in $code")
            }
        } finally {
            host.release()
            guest.release()
            server.cleanUp()
        }
    }
}
