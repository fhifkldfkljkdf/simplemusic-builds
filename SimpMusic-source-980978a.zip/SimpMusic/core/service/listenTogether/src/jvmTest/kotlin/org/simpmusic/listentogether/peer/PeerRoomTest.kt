package org.simpmusic.listentogether.peer

import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.simpmusic.listentogether.ConnectionState
import org.simpmusic.listentogether.ListenTogetherSession
import org.simpmusic.listentogether.ListenTogetherState
import org.simpmusic.listentogether.MessageCodec
import org.simpmusic.listentogether.MessageTypes
import org.simpmusic.listentogether.PlaybackActions
import org.simpmusic.listentogether.TrackInfo
import org.simpmusic.nostr.Nip44
import org.simpmusic.nostr.NostrEvent
import org.simpmusic.nostr.SharedCodeSecret
import kotlin.io.encoding.Base64
import kotlin.test.AfterTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlin.time.Duration.Companion.seconds

/**
 * Whole devices — [ListenTogetherSession] on [PeerRoomTransport] — meeting through a relay on
 * localhost, exactly as they meet through public relays: no server anywhere.
 */
class PeerRoomTest {
    private val relay = LocalRelay().also { it.start() }
    private val transports = mutableListOf<PeerRoomTransport>()

    @AfterTest
    fun tearDown() {
        transports.forEach { it.release() }
        relay.stop()
    }

    /**
     * One device. Relay-only unless [direct]: the tests that lose messages on the relay on purpose
     * must not have them rescued by a direct link. [relayUrls] can point nowhere, for a room with
     * no relay at all.
     */
    private suspend fun device(
        joinTimeoutMs: Long = 20_000,
        timing: PeerRoomTransport.Timing = PeerRoomTransport.Timing(),
        direct: Boolean = false,
        relayUrls: List<String> = listOf(relay.url),
        /** The Wi-Fi this device is on, for tests of finding each other there; none by default. */
        lan: LocalLan? = null,
    ): ListenTogetherSession {
        val links: DirectLinks = if (direct) SocketDirectLinks(localAddresses = { listOf("127.0.0.1") }) else NoDirectLinks
        val transport =
            PeerRoomTransport(
                relayUrls = relayUrls,
                joinAnswerTimeoutMs = joinTimeoutMs,
                timing = timing,
                direct = links,
                discovery = lan?.device() ?: NoLanDiscovery,
            ).also(transports::add)
        val session = ListenTogetherSession(transport)
        session.connect()
        session.state.first { it.connection is ConnectionState.Connected }
        return session
    }

    private suspend fun ListenTogetherSession.await(check: (ListenTogetherState) -> Boolean): ListenTogetherState = state.first(check)

    private val song = TrackInfo(id = "s1", title = "One", artist = "A", duration = 200_000)
    private val next = TrackInfo(id = "s2", title = "Two", artist = "B", duration = 180_000)

    /** Failover in seconds rather than a minute. */
    private val fast =
        PeerRoomTransport.Timing(pingMs = 300, tickMs = 200, stateRefreshMs = 1_000, hubSilentMs = 5_000, failoverAfterMs = 1_500, failoverStaggerMs = 1_500)

    /** A hosts, B joins (A lets people in automatically). */
    private suspend fun roomOfTwo(timing: PeerRoomTransport.Timing = PeerRoomTransport.Timing()): Triple<ListenTogetherSession, ListenTogetherSession, String> {
        val a = device(timing = timing)
        a.autoApproveJoins = true
        a.createRoom("Alice")
        val code = a.await { it.roomCode != null }.roomCode!!
        assertEquals(8, code.length)
        val b = device(timing = timing)
        b.joinRoom(code, "Bob")
        val joined = b.await { it.inRoom }
        assertFalse(joined.isHost)
        assertEquals(setOf("Alice", "Bob"), joined.members.map { it.username }.toSet())
        a.await { it.members.size == 2 }
        return Triple(a, b, code)
    }

    @Test
    fun aGuestJoinsAndFollowsTheHost() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo()
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song, queue = listOf(song, next))
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 30_000, null)
                val following = b.await { it.currentTrack?.id == "s1" && it.isPlaying }
                assertEquals(listOf("s2"), following.queue.map { it.id })
                assertTrue(following.position >= 30_000)
                // The clock is calibrated against the host's device, so live positions move on.
                val live = b.positionAt(following.position, isPlaying = true)
                assertTrue(live in 30_000..40_000, "live position $live")

                a.sendPlaybackAction(PlaybackActions.PAUSE, "s1", 31_000, null)
                assertEquals(31_000, b.await { !it.isPlaying }.position)
            }
        }

    @Test
    fun hostingMovesToAnotherDeviceAndTheRoomCarriesOn() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo()
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                b.await { it.currentTrack?.id == "s1" }

                val bob = b.state.value.selfUserId
                a.transferHost(bob)
                b.await { it.isHost }
                a.await { !it.isHost && it.members.single { m -> m.isHost }.userId == bob }

                // B's device runs the room now: its commands reach A.
                b.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s2", 0, next)
                a.await { it.currentTrack?.id == "s2" }

                // And a newcomer is answered by B's device.
                b.autoApproveJoins = true
                val c = device()
                c.joinRoom(b.state.value.roomCode!!, "Carol")
                val carol = c.await { it.inRoom }
                assertEquals(setOf("Alice", "Bob", "Carol"), carol.members.map { it.username }.toSet())
                assertEquals("s2", c.await { it.currentTrack != null }.currentTrack?.id)
            }
        }

    @Test
    fun whenTheHostLeavesSomeoneElseRunsTheRoom() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo()
                a.leaveRoom()
                val alone = b.await { it.isHost && it.members.size == 1 }
                assertEquals("Bob", alone.members.single().username)
                b.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                b.await { it.currentTrack?.id == "s1" }
                // A's leave finishes once the relays have its goodbye, which can be after B moved on.
                assertFalse(a.await { !it.inRoom }.inRoom)
            }
        }

    @Test
    fun whenTheHostsDeviceVanishesTheNextMemberTakesOver() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, code) = roomOfTwo(fast)
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song, queue = listOf(song, next))
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 10_000, null)
                b.await { it.isPlaying && it.currentTrack?.id == "s1" }
                delay(600) // B has heard what the room is by now.

                transports[0].vanish()
                b.await { it.isHost }

                // B's device runs the room: its own commands work, and a newcomer gets in.
                b.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s2", 0, next)
                b.await { it.currentTrack?.id == "s2" }
                b.autoApproveJoins = true
                val c = device(timing = fast)
                c.joinRoom(code, "Carol")
                val carol = c.await { it.inRoom && it.currentTrack != null }
                assertEquals("s2", carol.currentTrack?.id)
                assertEquals(b.state.value.selfUserId, carol.members.single { it.isHost }.userId)
                // Alice keeps her seat for now, in case she comes back.
                assertTrue("Alice" in carol.members.map { it.username })
            }
        }

    @Test
    fun aHostThatComesBackFollowsTheRoomItLost() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo(fast)
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                b.await { it.currentTrack?.id == "s1" }
                delay(600)

                transports[0].offline = true
                b.await { it.isHost }
                b.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s2", 0, next)
                delay(300)
                transports[0].offline = false

                // B's next state beacon reaches A, which steps down and follows B's room.
                val back = a.await { !it.isHost && it.currentTrack?.id == "s2" }
                assertEquals(b.state.value.selfUserId, back.members.single { it.isHost }.userId)
                assertTrue(b.state.value.isHost)
                b.sendPlaybackAction(PlaybackActions.PLAY, "s2", 5_000, null)
                assertTrue(a.await { it.isPlaying }.position >= 5_000)
            }
        }

    /** The type inside a room event, read the way a member reads it (the test knows the code). */
    private fun typeOf(
        event: NostrEvent,
        code: String,
    ): String? =
        runCatching {
            val secret = SharedCodeSecret(code, "simpmusic/listen-together")
            val body = Json.parseToJsonElement(Nip44.decrypt(event.content, secret.conversationKey)).jsonObject
            MessageCodec(compressionEnabled = true).decode(Base64.decode(body["e"]!!.jsonPrimitive.content)).first
        }.getOrNull()

    @Test
    fun aGuestThatMissesAPauseCatchesUp() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, code) = roomOfTwo(fast)
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 1_000, null)
                b.await { it.isPlaying && it.currentTrack?.id == "s1" }

                // Every playback frame from now on is lost on the way.
                relay.drop = { typeOf(it, code) == MessageTypes.SYNC_PLAYBACK }
                a.sendPlaybackAction(PlaybackActions.PAUSE, "s1", 2_000, null)
                // The host's next frame (a pong) says the room moved on; B asks and is told.
                val caughtUp = b.await { !it.isPlaying }
                assertEquals(2_000, caughtUp.position)
            }
        }

    @Test
    fun aGuestThatMissesAJoinStillSeesEveryone() =
        runBlocking {
            withTimeout(30.seconds) {
                val (_, b, code) = roomOfTwo(fast)
                relay.drop = { typeOf(it, code) == MessageTypes.USER_JOINED }
                val c = device(timing = fast)
                c.joinRoom(code, "Carol")
                c.await { it.inRoom }
                // B never got user_joined; the host's state beacon fills it in.
                val seen = b.await { it.members.size == 3 }
                assertEquals(setOf("Alice", "Bob", "Carol"), seen.members.map { it.username }.toSet())
            }
        }

    /** Nothing listens there: a relay that never answers. */
    private val nowhere = listOf("ws://127.0.0.1:${java.net.ServerSocket(0).use { it.localPort }}")

    @Test
    fun aRoomRunsOverADirectLinkWithNoRelayAtAll() =
        runBlocking {
            withTimeout(30.seconds) {
                val a = device(direct = true, relayUrls = nowhere)
                a.autoApproveJoins = true
                a.createRoom("Alice")
                val code = a.await { it.roomCode != null }.roomCode!!
                val host = transports[0]
                val endpoints = host.links.first { it.directEndpoints.isNotEmpty() }.directEndpoints
                assertEquals(0, host.links.value.relays)

                // The invite's QR code carries the host's local address.
                val b = device(direct = true, relayUrls = nowhere)
                transports[1].hintDirect(code, endpoints)
                b.joinRoom(code, "Bob")
                assertEquals(setOf("Alice", "Bob"), b.await { it.inRoom }.members.map { it.username }.toSet())
                assertEquals(1, transports[1].links.value.direct)

                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song, queue = listOf(song, next))
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 30_000, null)
                val following = b.await { it.currentTrack?.id == "s1" && it.isPlaying }
                assertEquals(listOf("s2"), following.queue.map { it.id })
            }
        }

    @Test
    fun aGuestWithOnlyTheCodeFindsTheHostOnTheSameWifi() =
        runBlocking {
            withTimeout(30.seconds) {
                val wifi = LocalLan()
                val a = device(direct = true, relayUrls = nowhere, lan = wifi)
                a.autoApproveJoins = true
                a.createRoom("Alice")
                val code = a.await { it.roomCode != null }.roomCode!!

                // No QR code and no relay: the code, typed in, is all B has.
                val b = device(direct = true, relayUrls = nowhere, lan = wifi)
                b.joinRoom(code, "Bob")
                assertEquals(setOf("Alice", "Bob"), b.await { it.inRoom }.members.map { it.username }.toSet())
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 5_000, null)
                assertEquals("s1", b.await { it.isPlaying }.currentTrack?.id)
            }
        }

    @Test
    fun aRoomOnTheSameWifiShowsUpNearbyUnlessTheHostHidesIt() =
        runBlocking {
            withTimeout(30.seconds) {
                val wifi = LocalLan()
                val a = device(direct = true, relayUrls = nowhere, lan = wifi)
                a.createRoom("Alice")
                val code = a.await { it.roomCode != null }.roomCode!!
                val c = device(direct = true, relayUrls = nowhere, lan = wifi)
                val seen = c.nearby.first { it.isNotEmpty() }.single()
                assertEquals(code, seen.code)
                assertEquals("Alice", seen.hostName)
                assertEquals(1, seen.listeners)
                // The host's own room is not "nearby" to itself.
                assertTrue(a.nearby.value.isEmpty())

                a.setVisibleNearby(false)
                c.nearby.first { it.isEmpty() }
                // Off the list, yet someone who has the code still connects straight to the host.
                a.autoApproveJoins = true
                c.joinRoom(code, "Carol")
                c.await { it.inRoom }
                assertEquals(1, transports[1].links.value.direct)
            }
        }

    @Test
    fun withNoRelayTheRoomOutlivesItsHostOnTheSameWifi() =
        runBlocking {
            withTimeout(30.seconds) {
                val wifi = LocalLan()
                // Carol, second in line, must hear Bob's room before her own turn to take it over
                // comes: seconds in real rooms (announced every 2 s, her turn 15 s after Bob's).
                val timing = fast.copy(failoverStaggerMs = 6_000)
                val a = device(timing = timing, direct = true, relayUrls = nowhere, lan = wifi)
                a.autoApproveJoins = true
                a.createRoom("Alice")
                val code = a.await { it.roomCode != null }.roomCode!!
                val b = device(timing = timing, direct = true, relayUrls = nowhere, lan = wifi)
                b.joinRoom(code, "Bob")
                b.await { it.inRoom }
                val c = device(timing = timing, direct = true, relayUrls = nowhere, lan = wifi)
                c.joinRoom(code, "Carol")
                c.await { it.inRoom }
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                c.await { it.currentTrack?.id == "s1" && it.members.size == 3 }
                delay(1_200) // Everyone has heard what the room is by now.

                transports[0].vanish()
                b.await { it.isHost }
                // Carol's link went down with Alice's device; she finds Bob's on the Wi-Fi by herself.
                val bob = b.state.value.selfUserId
                c.await { it.members.singleOrNull { m -> m.isHost }?.userId == bob }
                b.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s2", 0, next)
                assertEquals("s2", c.await { it.currentTrack?.id == "s2" }.currentTrack?.id)
            }
        }

    @Test
    fun aGuestFindsTheHostsDirectLinkAndKeepsItWhenTheRelaysGo() =
        runBlocking {
            withTimeout(30.seconds) {
                val a = device(direct = true)
                a.autoApproveJoins = true
                a.createRoom("Alice")
                val code = a.await { it.roomCode != null }.roomCode!!
                transports[0].links.first { it.directEndpoints.isNotEmpty() }
                // Joined through the relay alone, with no address to go on…
                val b = device(direct = true)
                b.joinRoom(code, "Bob")
                b.await { it.inRoom }
                // …and the host's answer said where it listens.
                transports[1].links.first { it.direct == 1 }

                relay.drop = { true }
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s2", 0, next)
                assertEquals("s2", b.await { it.currentTrack != null }.currentTrack?.id)
                b.suggestTrack(song)
                assertEquals("Bob", a.await { it.suggestions.isNotEmpty() }.suggestions.single().fromUsername)
            }
        }

    @Test
    fun aMessageThatArrivesBothWaysCountsOnce() =
        runBlocking {
            withTimeout(30.seconds) {
                val a = device(direct = true)
                a.autoApproveJoins = true
                a.createRoom("Alice")
                val code = a.await { it.roomCode != null }.roomCode!!
                val b = device(direct = true)
                b.joinRoom(code, "Bob")
                b.await { it.inRoom }
                transports[1].links.first { it.direct == 1 && it.relays == 1 }
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                b.await { it.currentTrack != null }

                b.suggestTrack(next)
                a.await { it.suggestions.isNotEmpty() }
                delay(1_000)
                // Through the relay and the direct link, handled once.
                assertEquals(1, a.state.value.suggestions.size)
                assertEquals(2, a.state.value.members.size)
            }
        }

    @Test
    fun suggestionsReachTheHost() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo()
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song)
                b.await { it.currentTrack != null }
                b.suggestTrack(next)
                val suggestion = a.await { it.suggestions.isNotEmpty() }.suggestions.single()
                assertEquals("Bob", suggestion.fromUsername)
                a.approveSuggestion(suggestion.suggestionId)
                assertEquals("s2", b.await { it.queue.isNotEmpty() }.queue.first().id)
            }
        }

    @Test
    fun aCodeNobodyHostsSaysSo() =
        runBlocking {
            withTimeout(30.seconds) {
                val lonely = device(joinTimeoutMs = 2_000)
                lonely.joinRoom("ZZZZ2222", "Dave")
                val refused = lonely.await { it.error != null }
                assertTrue(refused.error!!.contains("No one is hosting"), refused.error)
                assertFalse(refused.inRoom)
            }
        }

    @Test
    fun aGuestControlsPlaybackThroughTheHost() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo()
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song, queue = listOf(song, next))
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 30_000, null)
                // Rooms created here let guests control playback unless the host said otherwise.
                b.await { it.isPlaying && it.guestControl && it.canControl }

                val asked = async(start = CoroutineStart.UNDISPATCHED) { a.controlRequests.first() }
                b.sendControl(PlaybackActions.PAUSE, 31_000)
                val request = asked.await()
                assertEquals("Bob", request.username)
                assertEquals(PlaybackActions.PAUSE, request.action.action)
                assertEquals(31_000, request.action.position)

                val picked = async(start = CoroutineStart.UNDISPATCHED) { a.controlRequests.first() }
                b.sendControl(PlaybackActions.CHANGE_TRACK, 0, next)
                assertEquals("s2", picked.await().action.trackInfo?.id)

                a.setGuestControl(false)
                b.await { !it.guestControl && !it.canControl }
                b.sendControl(PlaybackActions.PAUSE, 0)
                assertTrue(b.await { it.error != null }.error!!.contains("host"))
            }
        }

    @Test
    fun aQueueChangeLeavesTheGuestsPlayheadAlone() =
        runBlocking {
            withTimeout(30.seconds) {
                val (a, b, _) = roomOfTwo()
                val third = TrackInfo(id = "s3", title = "Three", artist = "C", duration = 150_000)
                a.sendPlaybackAction(PlaybackActions.CHANGE_TRACK, "s1", 0, song, queue = listOf(song, next))
                a.sendPlaybackAction(PlaybackActions.PLAY, "s1", 30_000, null)
                b.await { it.isPlaying && it.position >= 30_000 }
                // The answer to the sync asked for on joining can land after the play.
                delay(700)
                val playing = b.state.value

                // What endless queue does on its own: more songs behind the one playing.
                a.sendQueue(listOf(next, third), "")
                val grown = b.await { s -> s.queue.map { it.id } == listOf("s2", "s3") }
                assertEquals(playing.position, grown.position)
                assertEquals(playing.lastActionServerTime, grown.lastActionServerTime)

                // And a suggestion the host approves goes in the queue, not on the speakers.
                val fourth = TrackInfo(id = "s4", title = "Four", artist = "D", duration = 150_000)
                b.suggestTrack(fourth)
                val suggestion = a.await { it.suggestions.isNotEmpty() }.suggestions.single()
                a.approveSuggestion(suggestion.suggestionId)
                val queued = b.await { s -> s.queue.any { it.id == "s4" } }
                assertEquals("s1", queued.currentTrack?.id)
                assertEquals(playing.position, queued.position)
            }
        }
}
