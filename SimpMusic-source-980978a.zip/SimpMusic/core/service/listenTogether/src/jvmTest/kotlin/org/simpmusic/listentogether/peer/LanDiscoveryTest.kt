package org.simpmusic.listentogether.peer

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.time.Duration.Companion.seconds

class LanDiscoveryTest {
    private val announcement =
        LanAnnouncement(tag = "tag1", endpoints = listOf("192.168.1.20:40000"), hostName = "Alice", code = "ABCD2345", listeners = 3)

    @Test
    fun aBeaconReadsBackAsTheRoomItAnnounces() {
        val room = LanBeacon.decode(LanBeacon.encode(announcement), "192.168.1.20")!!
        assertEquals(LanRoom("tag1", listOf("192.168.1.20:40000"), "Alice", "ABCD2345", 3), room)
    }

    @Test
    fun theAddressItWasHeardFromIsAddedWhenTheHostDidNotListIt() {
        val room = LanBeacon.decode(LanBeacon.encode(announcement), "10.0.0.5")!!
        assertEquals(listOf("192.168.1.20:40000", "10.0.0.5:40000"), room.endpoints)
    }

    @Test
    fun anythingElseOnThePortIsIgnored() {
        assertNull(LanBeacon.decode("hello".encodeToByteArray()))
        assertNull(LanBeacon.decode("""{"m":"other","t":"x","l":["1.2.3.4:5"]}""".encodeToByteArray()))
        // No address to dial.
        assertNull(LanBeacon.decode("""{"m":"SMLT-D/1","t":"x","l":["not an address"]}""".encodeToByteArray()))
        // A code that is not one is dropped, the room is kept.
        val odd = LanBeacon.decode("""{"m":"SMLT-D/1","t":"x","l":["1.2.3.4:5"],"c":"<script>"}""".encodeToByteArray())!!
        assertNull(odd.code)
    }

    @Test
    fun oneDeviceHearsAnotherOverUdp(): Unit =
        runBlocking {
            withTimeout(15.seconds) {
                val port = DatagramSocket(0).use { it.localPort }
                val loopback = { listOf(InetAddress.getLoopbackAddress()) }
                val host = SocketLanDiscovery(port = port, targets = loopback)
                val guest = SocketLanDiscovery(port = port, targets = loopback)
                try {
                    guest.listen(true)
                    host.announce(announcement)
                    val heard = guest.rooms.first { it.isNotEmpty() }.single()
                    assertEquals("tag1", heard.tag)
                    assertEquals("ABCD2345", heard.code)
                    assertEquals(listOf("192.168.1.20:40000", "127.0.0.1:40000"), heard.endpoints)
                    // Stopping takes the room off the list once it goes unheard.
                    host.announce(null)
                    guest.rooms.first { it.isEmpty() }
                } finally {
                    host.release()
                    guest.release()
                }
            }
        }
}
