package org.simpmusic.listentogether.peer

import org.simpmusic.listentogether.ApproveJoinPayload
import org.simpmusic.listentogether.ApproveSuggestionPayload
import org.simpmusic.listentogether.ControlRequestPayload
import org.simpmusic.listentogether.ErrorPayload
import org.simpmusic.listentogether.HostChangedPayload
import org.simpmusic.listentogether.JoinApprovedPayload
import org.simpmusic.listentogether.JoinRequestPayload
import org.simpmusic.listentogether.JoinRoomPayload
import org.simpmusic.listentogether.KickUserPayload
import org.simpmusic.listentogether.MessageTypes
import org.simpmusic.listentogether.PingPayload
import org.simpmusic.listentogether.PlaybackActionPayload
import org.simpmusic.listentogether.PlaybackActions
import org.simpmusic.listentogether.PongPayload
import org.simpmusic.listentogether.RoomSettingsPayload
import org.simpmusic.listentogether.SuggestTrackPayload
import org.simpmusic.listentogether.SyncStatePayload
import org.simpmusic.listentogether.TrackInfo
import org.simpmusic.listentogether.TransferHostPayload
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class RoomHubTest {
    private var time = 1_000_000L
    private val host = "host"
    private val guest = "guest"
    private val song = TrackInfo(id = "s1", title = "One", artist = "A", duration = 200_000)
    private val next = TrackInfo(id = "s2", title = "Two", artist = "B", duration = 180_000)

    private fun room(): RoomHub {
        val (hub, created) = RoomHub.create("ABCD2345", host, "Hosty", { time })
        assertEquals(MessageTypes.ROOM_CREATED, created.type)
        assertEquals(listOf(host), created.to)
        return hub
    }

    private fun RoomHub.withGuest(): RoomHub {
        val asked = handle(guest, MessageTypes.JOIN_ROOM, JoinRoomPayload("abcd2345", "Guesty"))
        assertEquals(listOf(RoomHub.Out(listOf(host), MessageTypes.JOIN_REQUEST, JoinRequestPayload(guest, "Guesty"))), asked)
        val approved = handle(host, MessageTypes.APPROVE_JOIN, ApproveJoinPayload(guest))
        val approval = approved.single { it.type == MessageTypes.JOIN_APPROVED }
        assertEquals(listOf(guest), approval.to)
        assertEquals(listOf("Hosty", "Guesty"), (approval.payload as JoinApprovedPayload).state!!.users.map { it.username })
        assertEquals(listOf(host), approved.single { it.type == MessageTypes.USER_JOINED }.to)
        return this
    }

    private fun List<RoomHub.Out>.payloadOf(type: String) = single { it.type == type }.payload

    @Test
    fun theHostControlsPlaybackAndGuestsLandOnTheLivePosition() {
        val hub = room().withGuest()
        val changed = hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song, queue = listOf(song, next)))
        val change = changed.single()
        assertEquals(listOf(host, guest), change.to)
        assertEquals(listOf(next), (change.payload as PlaybackActionPayload).queue, "the current track leaves the queue")

        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.PLAY, trackId = "s1", position = 10_000))
        time += 2_000
        val sync = hub.handle(guest, MessageTypes.REQUEST_SYNC, null).payloadOf(MessageTypes.SYNC_STATE) as SyncStatePayload
        assertTrue(sync.isPlaying)
        assertEquals(12_000, sync.position)
        assertEquals(time, sync.lastUpdate)

        val refused = hub.handle(guest, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.PAUSE))
        assertEquals("not_host", (refused.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)
    }

    @Test
    fun aPlayThatSpentTimeInFlightIsMovedOn() {
        val hub = room()
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song))
        val play =
            hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.PLAY, trackId = "s1", position = 5_000, capturedAtServerTime = time - 700))
        assertEquals(5_700, (play.single().payload as PlaybackActionPayload).position)
    }

    @Test
    fun suggestionsGoToTheHostAndApprovedOnesPlayNext() {
        val hub = room().withGuest()
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song, queue = listOf(next)))
        val suggested = hub.handle(guest, MessageTypes.SUGGEST_TRACK, SuggestTrackPayload(TrackInfo("s3", "Three", "C")))
        val received = suggested.single()
        assertEquals(listOf(host), received.to)
        val id = (received.payload as org.simpmusic.listentogether.SuggestionReceivedPayload).suggestionId
        val approved = hub.handle(host, MessageTypes.APPROVE_SUGGESTION, ApproveSuggestionPayload(id))
        val queued = approved.payloadOf(MessageTypes.SYNC_PLAYBACK) as PlaybackActionPayload
        assertEquals(listOf("s3", "s2"), queued.queue.map { it.id })
        assertEquals("Guesty", queued.trackInfo!!.suggestedBy)
        assertEquals(listOf(guest), approved.single { it.type == MessageTypes.SUGGESTION_APPROVED }.to)
    }

    @Test
    fun whenTheHostLeavesTheRoomPassesOn() {
        val hub = room().withGuest()
        val left = hub.handle(host, MessageTypes.LEAVE_ROOM, null)
        assertEquals(listOf(MessageTypes.USER_LEFT, MessageTypes.HOST_CHANGED), left.map { it.type })
        assertEquals(guest, (left.last().payload as HostChangedPayload).newHostId)
        assertEquals(guest, hub.hostId)
        assertEquals(listOf(guest), hub.memberIds)
    }

    @Test
    fun theLastOneOutEmptiesTheRoom() {
        val hub = room()
        assertTrue(hub.handle(host, MessageTypes.LEAVE_ROOM, null).isEmpty())
        assertTrue(hub.isEmpty)
    }

    @Test
    fun silentGuestsShowAsAwayThenLeave() {
        val hub = room().withGuest()
        time += RoomHub.DISCONNECT_AFTER_MS + 1
        assertEquals(listOf(MessageTypes.USER_DISCONNECTED), hub.tick().map { it.type })
        assertTrue(hub.tick().isEmpty(), "reported once")

        val back = hub.handle(guest, MessageTypes.PING, PingPayload(clientTime = 5, sequence = 1))
        assertEquals(listOf(MessageTypes.USER_RECONNECTED, MessageTypes.PONG), back.map { it.type })
        val pong = back.last().payload as PongPayload
        assertEquals(5, pong.clientTime)
        assertEquals(time, pong.serverSendTime)

        time += RoomHub.SEAT_GRACE_MS + 1
        val gone = hub.tick()
        assertTrue(gone.any { it.type == MessageTypes.USER_LEFT })
        assertEquals(listOf(host), hub.memberIds)
    }

    @Test
    fun kickingAndTransferring() {
        val hub = room().withGuest()
        val moved = hub.handle(host, MessageTypes.TRANSFER_HOST, TransferHostPayload(guest))
        assertEquals(guest, (moved.single().payload as HostChangedPayload).newHostId)
        val kicked = hub.handle(guest, MessageTypes.KICK_USER, KickUserPayload(host))
        assertEquals(listOf(MessageTypes.KICKED, MessageTypes.USER_LEFT), kicked.map { it.type })
        assertEquals(listOf(host), kicked.first().to)
        assertEquals(listOf(guest), hub.memberIds)
    }

    @Test
    fun aWrongCodeOrNoNameIsRefused() {
        val hub = room()
        assertEquals("room_not_found", (hub.handle(guest, MessageTypes.JOIN_ROOM, JoinRoomPayload("ZZZZZZZZ", "G")).single().payload as ErrorPayload).code)
        assertEquals("missing_username", (hub.handle(guest, MessageTypes.JOIN_ROOM, JoinRoomPayload("ABCD2345", " ")).single().payload as ErrorPayload).code)
    }

    @Test
    fun aMemberTakesOverFromWhatItLastSaw() {
        val hub = room().withGuest()
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song, queue = listOf(next)))
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.PLAY, trackId = "s1", position = 1_000))
        val lastSeen = hub.snapshot()

        // The host's device went quiet 30 s ago; the guest runs the room from its own clock.
        var guestTime = 7L
        val taken = RoomHub.claim(lastSeen, guest, silentForMs = 30_000, now = { guestTime })
        assertEquals(guest, taken.hostId)
        assertEquals(lastSeen.epoch + 1, taken.epoch)
        val sync = taken.handle(guest, MessageTypes.REQUEST_SYNC, null).single().payload as SyncStatePayload
        assertEquals(31_000, sync.position, "the song kept playing while the host was silent")
        assertEquals(listOf(next), sync.queue)

        // The old host keeps its seat: away for now, back if it returns in time.
        guestTime += RoomHub.DISCONNECT_AFTER_MS + 1
        assertEquals(listOf(MessageTypes.USER_DISCONNECTED), taken.tick().map { it.type })
        val back = taken.handle(host, MessageTypes.PING, PingPayload(clientTime = 1, sequence = 1))
        assertEquals(listOf(MessageTypes.USER_RECONNECTED, MessageTypes.PONG), back.map { it.type })
        val refused = taken.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.PAUSE))
        assertEquals("not_host", (refused.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)
    }

    @Test
    fun anotherDeviceTakesOverWhereThisOneLeftOff() {
        val hub = room().withGuest()
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song, queue = listOf(next)))
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.PLAY, trackId = "s1", position = 1_000))
        time += 4_000
        hub.handle(host, MessageTypes.TRANSFER_HOST, TransferHostPayload(guest))
        val snapshot = hub.snapshot()
        assertEquals(5_000, snapshot.position)

        // The new device's clock is somewhere else entirely.
        var otherTime = 42L
        val taken = RoomHub.takeOver(snapshot) { otherTime }
        otherTime += 1_000
        val sync = taken.handle(host, MessageTypes.REQUEST_SYNC, null).single().payload as SyncStatePayload
        assertEquals(6_000, sync.position)
        assertEquals(listOf(next), sync.queue)
        assertEquals(guest, taken.hostId)
        assertNotNull(sync.currentTrack)
    }

    @Test
    fun guestsControlPlaybackOnlyWhenTheHostLetsThem() {
        val hub = room().withGuest()
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song))
        assertFalse(hub.guestControl, "a room starts host-only until told otherwise")

        val refused = hub.handle(guest, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.PAUSE, position = 4_000))
        assertEquals("control_not_allowed", (refused.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)
        assertEquals(listOf(guest), refused.single().to)

        val notHost = hub.handle(guest, MessageTypes.SET_ROOM_SETTINGS, RoomSettingsPayload(guestControl = true))
        assertEquals("not_host", (notHost.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)

        val allowed = hub.handle(host, MessageTypes.SET_ROOM_SETTINGS, RoomSettingsPayload(guestControl = true))
        assertEquals(listOf(host, guest), allowed.single().to, "everyone hears the room's new settings")
        assertTrue((allowed.payloadOf(MessageTypes.ROOM_SETTINGS) as RoomSettingsPayload).guestControl)
        val sync = hub.handle(guest, MessageTypes.REQUEST_SYNC, null).payloadOf(MessageTypes.SYNC_STATE) as SyncStatePayload
        assertTrue(sync.guestControl, "and a guest re-syncing learns it too")

        // The request goes to the host alone, as the guest sent it; the room does not change yet.
        val revision = hub.revision
        val asked = hub.handle(guest, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.PAUSE, position = 4_000))
        assertEquals(listOf(host), asked.single().to)
        val request = asked.payloadOf(MessageTypes.CONTROL_REQUEST) as ControlRequestPayload
        assertEquals(guest, request.userId)
        assertEquals("Guesty", request.username)
        assertEquals(PlaybackActions.PAUSE, request.action?.action)
        assertEquals(4_000, request.action?.position)
        assertEquals(revision, hub.revision, "the host's own command changes the room, not the request")

        val pick = hub.handle(guest, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = next))
        assertEquals(next, (pick.payloadOf(MessageTypes.CONTROL_REQUEST) as ControlRequestPayload).action?.trackInfo)
        val noTrack = hub.handle(guest, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK))
        assertEquals("missing_track_info", (noTrack.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)
        val queueEdit = hub.handle(guest, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.QUEUE_CLEAR))
        assertEquals("unknown_action", (queueEdit.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)

        val stranger = hub.handle("someone", MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.PAUSE))
        assertEquals("not_in_room", (stranger.payloadOf(MessageTypes.ERROR) as ErrorPayload).code)
    }

    @Test
    fun guestControlStaysWithTheRoomWhenTheHostChanges() {
        val hub = room().withGuest()
        hub.handle(host, MessageTypes.SET_ROOM_SETTINGS, RoomSettingsPayload(guestControl = true))
        hub.handle(host, MessageTypes.TRANSFER_HOST, TransferHostPayload(guest))
        val moved = RoomHub.takeOver(hub.snapshot()) { time }
        assertTrue(moved.guestControl)
        // The old host is a guest now, and may control playback like any other.
        val asked = moved.handle(host, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.SEEK, position = 30_000))
        assertEquals(listOf(guest), asked.single().to)
        assertEquals(MessageTypes.CONTROL_REQUEST, asked.single().type)
    }

    @Test
    fun theHostsOwnControlIsAnOrdinaryCommand() {
        val hub = room().withGuest()
        hub.handle(host, MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(PlaybackActions.CHANGE_TRACK, trackInfo = song))
        val out = hub.handle(host, MessageTypes.CONTROL, PlaybackActionPayload(PlaybackActions.PLAY, trackId = "s1", position = 1_000))
        assertEquals(MessageTypes.SYNC_PLAYBACK, out.single().type)
        assertEquals(listOf(host, guest), out.single().to)
    }
}
