package org.simpmusic.listentogether.peer

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * One Wi-Fi network in memory: every device on it that listens hears every announcement, its own
 * included, as it would with UDP broadcast. What goes over the air is [LanBeacon]'s encoding, so the
 * wire format is exercised too.
 */
class LocalLan {
    private val devices = mutableListOf<Device>()

    fun device(): LanDiscovery = Device().also { synchronized(devices) { devices += it } }

    private fun refresh() {
        val all = synchronized(devices) { devices.toList() }
        val heard = all.mapNotNull { d -> d.announcement?.let { LanBeacon.decode(LanBeacon.encode(it), "127.0.0.1") } }
        all.forEach { d -> d.rooms.value = if (d.listening && !d.released) heard else emptyList() }
    }

    private inner class Device : LanDiscovery {
        @Volatile
        var announcement: LanAnnouncement? = null

        @Volatile
        var listening = false

        @Volatile
        var released = false

        override val rooms = MutableStateFlow<List<LanRoom>>(emptyList())

        override fun announce(announcement: LanAnnouncement?) {
            if (released) return
            this.announcement = announcement
            refresh()
        }

        override fun listen(enabled: Boolean) {
            listening = enabled
            refresh()
        }

        override fun release() {
            released = true
            announcement = null
            listening = false
            refresh()
        }
    }
}
