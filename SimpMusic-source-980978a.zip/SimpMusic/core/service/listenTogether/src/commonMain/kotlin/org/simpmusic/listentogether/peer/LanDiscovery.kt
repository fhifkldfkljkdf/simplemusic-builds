package org.simpmusic.listentogether.peer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** What the device running a room tells everyone on its network. */
data class LanAnnouncement(
    /** The room's [org.simpmusic.nostr.SharedCodeSecret.tag]: says which room without saying its code. */
    val tag: String,
    /** Where its [DirectLinks] listen: the same list the room's own frames carry. */
    val endpoints: List<String>,
    val hostName: String? = null,
    /** Only when the host lets people nearby find the room; joining still needs the host's OK. */
    val code: String? = null,
    val listeners: Int = 0,
)

/** A room announced on this network, as heard. */
data class LanRoom(
    val tag: String,
    val endpoints: List<String>,
    val hostName: String? = null,
    val code: String? = null,
    val listeners: Int = 0,
)

/**
 * Finds rooms on the local network by themselves, so phones on one Wi-Fi connect to each other with
 * no QR code to scan and no relay to go through: the device running a room [announce]s it every
 * couple of seconds, and every device that [listen]s hears it.
 *
 * An announcement names the room by its tag (a hash of the code) and where to dial it. A guest who
 * typed the code recognises the tag and dials; nobody else learns the code from it unless the host
 * chose to show the room nearby ([LanAnnouncement.code]).
 */
interface LanDiscovery {
    /** Rooms heard in the last few seconds, one per tag. */
    val rooms: StateFlow<List<LanRoom>>

    /** Starts announcing (or changes what is announced); null stops. */
    fun announce(announcement: LanAnnouncement?)

    fun listen(enabled: Boolean)

    fun release()
}

internal expect fun platformLanDiscovery(): LanDiscovery

/** No local network to look at (iOS, and tests that want relays only). */
internal object NoLanDiscovery : LanDiscovery {
    override val rooms: StateFlow<List<LanRoom>> = MutableStateFlow<List<LanRoom>>(emptyList()).asStateFlow()

    override fun announce(announcement: LanAnnouncement?) = Unit

    override fun listen(enabled: Boolean) = Unit

    override fun release() = Unit
}

/** The datagram every implementation sends: small JSON behind a fixed marker. */
internal object LanBeacon {
    const val MAGIC = "SMLT-D/1"
    private const val MAX_ENDPOINTS = 8
    private const val MAX_NAME = 64
    private val ENDPOINT = Regex("""^\d{1,3}(\.\d{1,3}){3}:\d{1,5}$""")
    private val CODE = Regex("""^[A-Z0-9]{4,16}$""")
    private val json = Json { ignoreUnknownKeys = true }

    fun encode(a: LanAnnouncement): ByteArray =
        buildJsonObject {
            put("m", MAGIC)
            put("t", a.tag)
            put("l", JsonArray(a.endpoints.take(MAX_ENDPOINTS).map(::JsonPrimitive)))
            a.hostName?.let { put("h", it.take(MAX_NAME)) }
            a.code?.let { put("c", it) }
            put("n", a.listeners)
        }.toString().encodeToByteArray()

    /**
     * Reads a datagram, or null for anything that is not a well-formed beacon. [source] (the
     * sender's address) stands in when the beacon lists no address of its own.
     */
    fun decode(
        bytes: ByteArray,
        source: String? = null,
    ): LanRoom? =
        try {
            val o = json.parseToJsonElement(bytes.decodeToString()).jsonObject
            if (o["m"]?.jsonPrimitive?.contentOrNull != MAGIC) {
                null
            } else {
                val tag = o["t"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() && it.length <= 128 }
                val listed =
                    o["l"]
                        ?.jsonArray
                        ?.mapNotNull { it.jsonPrimitive.contentOrNull }
                        ?.filter { ENDPOINT.matches(it) }
                        ?.take(MAX_ENDPOINTS)
                        .orEmpty()
                val port = listed.firstOrNull()?.substringAfterLast(':')
                val endpoints =
                    when {
                        source == null || port == null -> listed
                        // A host that could not list the address it was heard from is still reachable there.
                        listed.none { it.startsWith("$source:") } && ENDPOINT.matches("$source:$port") -> listed + "$source:$port"
                        else -> listed
                    }
                tag?.takeIf { endpoints.isNotEmpty() }?.let {
                    LanRoom(
                        tag = it,
                        endpoints = endpoints,
                        hostName = o["h"]?.jsonPrimitive?.contentOrNull?.take(MAX_NAME),
                        code = o["c"]?.jsonPrimitive?.contentOrNull?.takeIf { c -> CODE.matches(c) },
                        listeners = o["n"]?.jsonPrimitive?.intOrNull?.coerceIn(0, 999) ?: 0,
                    )
                }
            }
        } catch (e: Exception) {
            null
        }
}
