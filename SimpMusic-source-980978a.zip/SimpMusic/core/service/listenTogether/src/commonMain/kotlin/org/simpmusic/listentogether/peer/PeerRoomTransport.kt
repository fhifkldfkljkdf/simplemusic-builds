package org.simpmusic.listentogether.peer

import com.maxrave.logger.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import okio.Buffer
import okio.GzipSink
import okio.GzipSource
import okio.buffer
import okio.use
import org.simpmusic.listentogether.CreateRoomPayload
import org.simpmusic.listentogether.ErrorPayload
import org.simpmusic.listentogether.HostChangedPayload
import org.simpmusic.listentogether.JoinApprovedPayload
import org.simpmusic.listentogether.PlaybackActionPayload
import org.simpmusic.listentogether.RoomSettingsPayload
import org.simpmusic.listentogether.SyncStatePayload
import org.simpmusic.listentogether.UserDisconnectedPayload
import org.simpmusic.listentogether.UserJoinedPayload
import org.simpmusic.listentogether.UserLeftPayload
import org.simpmusic.listentogether.UserReconnectedPayload
import org.simpmusic.listentogether.JoinRoomPayload
import org.simpmusic.listentogether.ListenTogetherEvent
import org.simpmusic.listentogether.MessageCodec
import org.simpmusic.listentogether.MessageTypes
import org.simpmusic.listentogether.NearbyRoom
import org.simpmusic.listentogether.PingPayload
import org.simpmusic.listentogether.PongPayload
import org.simpmusic.listentogether.RoomLinks
import org.simpmusic.listentogether.RoomTransport
import org.simpmusic.listentogether.ServerClock
import org.simpmusic.nostr.Nip44
import org.simpmusic.nostr.NostrEvent
import org.simpmusic.nostr.NostrFilter
import org.simpmusic.nostr.NostrKeys
import org.simpmusic.nostr.RelayPool
import org.simpmusic.nostr.SharedCodeSecret
import org.simpmusic.nostr.friends.FriendsSession
import org.simpmusic.nostr.secureRandomBytes
import kotlin.coroutines.CoroutineContext
import kotlin.io.encoding.Base64
import kotlin.concurrent.Volatile
import kotlin.time.Clock
import kotlin.time.Duration.Companion.seconds
import kotlin.time.ExperimentalTime
import kotlin.time.TimeSource

private const val TAG = "PeerRoomTransport"

/**
 * Listen Together without a server.
 *
 * The device that creates a room runs it: a [RoomHub] holding metroserver's rules. Everyone else
 * reaches it through public Nostr relays, and it answers the same way, so the session, playback
 * bridge and UI above see exactly the protocol they saw from a server.
 *
 * - Every message is an ephemeral event (kind [KIND], never stored by relays) tagged with the
 *   room's tag and NIP-44 encrypted with a key derived from the room code. Relays see a random tag
 *   and ciphertext; only someone with the code can read or write the room.
 * - Messages carry a per-sender sequence number, and arrive through every relay, so they are put
 *   back in order and duplicates dropped (a short wait closes a gap before giving up on it).
 * - Every device has a key of its own for this process — its user id in the room. A member's
 *   messages are signed with it, so only the hub's device can speak as the hub.
 * - When the host role moves (transfer, or the host leaving), the room moves with it: the old hub
 *   hands its [HubSnapshot] to the new host's device, and everyone follows.
 * - Guests ping the hub every [Timing.pingMs]: that calibrates the room clock and tells the hub
 *   who is still there.
 * - Direct links: the device running the room also listens on its local network, and guests that
 *   can reach it (the same Wi-Fi) connect straight to it ([DirectLinks]). The same signed, encrypted
 *   events go both ways, the first copy wins, and either path alone keeps the room going — relays
 *   across the internet, the direct link on one Wi-Fi with no internet at all.
 * - The hub tells the members what the room is whenever that changes. If the device running it
 *   goes silent (its app was closed, its phone died) for [Timing.failoverAfterMs], the first member
 *   in line takes it over from there; if the old device comes back, it finds it replaced and
 *   follows along. A room nobody can take over ends after [RoomHub.SEAT_GRACE_MS].
 */
@OptIn(ExperimentalCoroutinesApi::class, ExperimentalTime::class)
class PeerRoomTransport(
    userAgent: String = "SimpMusic",
    relayUrls: List<String> = FriendsSession.DEFAULT_RELAYS,
    private val wallClock: () -> Long = { Clock.System.now().toEpochMilliseconds() },
    private val elapsedRealtime: () -> Long = { MONOTONIC.elapsedNow().inWholeMilliseconds },
    /** How long a join waits for any hub to answer before saying no one hosts that code. */
    private val joinAnswerTimeoutMs: Long = 20_000L,
    private val timing: Timing = Timing(),
    /** Device-to-device links beside the relays; none on iOS. */
    private val direct: DirectLinks = platformDirectLinks(),
    /** Finds the hub on the local network with no QR code or relay; none on iOS. */
    private val discovery: LanDiscovery = platformLanDiscovery(),
    dispatcher: CoroutineContext = Dispatchers.Default,
) : RoomTransport,
    CoroutineScope {
    override val coroutineContext: CoroutineContext = SupervisorJob() + dispatcher

    /** Every piece of state below is touched only on this one thread. */
    private val serial = Dispatchers.Default.limitedParallelism(1)

    // A phone that changes networks leaves its sockets looking open. In a room every relay carries
    // traffic every few seconds (pings, pongs), so a quiet one is dead: give up on it in 35 s, not 100.
    private val pool = RelayPool(relayUrls, userAgent, dispatcher, keepAliveInterval = 15.seconds, deadAfter = 35.seconds)
    private val codec = MessageCodec(compressionEnabled = true)
    private val json = Json { ignoreUnknownKeys = true }
    private val keys by lazy { NostrKeys.generate() }
    private val selfId: String get() = keys.publicKeyHex
    private val clock = ServerClock(elapsedRealtime)

    private val _events = MutableSharedFlow<ListenTogetherEvent>(extraBufferCapacity = 256)
    override val events: SharedFlow<ListenTogetherEvent> = _events.asSharedFlow()

    private val relaysTotal = relayUrls.size
    private val _links = MutableStateFlow(RoomLinks(relaysTotal = relaysTotal))
    override val links: StateFlow<RoomLinks> = _links.asStateFlow()

    // ── Direct links (see [DirectLinks]) ──

    /** Where guests can dial this device while it runs the room; empty otherwise. */
    private var servingAt: List<String> = emptyList()

    /** The hub's direct addresses this guest is dialling. */
    private var dialing: List<String> = emptyList()

    /** The hub's addresses as its own frames (or the QR code) listed them, and as heard on the network. */
    private var frameEndpoints: List<String> = emptyList()
    private var lanEndpoints: List<String> = emptyList()

    private val _nearby = MutableStateFlow<List<NearbyRoom>>(emptyList())
    override val nearby: StateFlow<List<NearbyRoom>> = _nearby.asStateFlow()

    /** Whether a room run here announces its code to the network (see [announceRoom]). */
    private var visibleNearby = true
    private var announced: LanAnnouncement? = null

    /** Direct addresses for a room about to be joined, from its QR code. */
    @Volatile
    private var directHints: Pair<String, List<String>>? = null

    /** Ids of the events already handled: the same event arrives from every relay and the direct link. */
    private val seenEvents = LinkedHashSet<String>()
    private var lastRelayCount = 0
    private var lastDirectCount = 0

    private class Room(
        val code: String,
        val secret: SharedCodeSecret,
        /** Whose events speak for the hub; null while a join has not been answered yet. */
        var hubId: String?,
        var member: Boolean,
    ) {
        /** The highest term of running this room heard of (see [HubSnapshot.epoch]). */
        var epoch: Long = 0L

        /** The room as the hub last described it, kept to take the room over if the hub goes silent. */
        var lastState: HubSnapshot? = null
        var lastStateAt: Long = 0L
    }

    private var room: Room? = null

    /** Read by [serverNow]/[positionAt] from the session's threads too. */
    @Volatile
    private var hub: RoomHub? = null
    private var started = false
    private var linkUp = false
    private var outSeq = 0L
    private var pingSeq = 0L
    private var lastHubHeardAt = 0L
    private var inbound = mutableMapOf<String, SequenceGate>()

    // ── What this guest's session has been told, to notice what it missed (see [repair]). ──

    /** Revision of the last playback change delivered to the session. */
    private var lastRevision = -1L

    /** Highest revision the hub has stamped on any frame seen. */
    private var announcedRevision = -1L

    private class KnownMember(
        val name: String,
        val connected: Boolean,
    )

    /** The member list as the session has it, from the frames delivered to it. */
    private val knownMembers = LinkedHashMap<String, KnownMember>()
    private var knownHost: String? = null

    /** Whether the session was told guests may control playback; null until it was told anything. */
    private var knownGuestControl: Boolean? = null
    private var lastSyncRequestAt = Long.MIN_VALUE / 2
    private var syncCheckJob: Job? = null

    /** What the last state beacon said (see [beacon]), and when it went out. */
    private var beaconKey: String? = null
    private var beaconAt = 0L

    /** Live while connected: relay events, link state. */
    private val connectionJobs = mutableListOf<Job>()

    /** Live while in (or joining) a room: pings, the hub's tick, the join timeout. */
    private val roomJobs = mutableListOf<Job>()

    // ───────────────────────────── RoomTransport ─────────────────────────────

    override fun connect() {
        launch(serial) {
            if (started) return@launch
            started = true
            pool.start()
            connectionJobs += launch(serial) { pool.events.collect { onEvent(it) } }
            connectionJobs += launch(serial) { direct.incoming.collect { onDirect(it) } }
            connectionJobs += launch(serial) { pool.connectedCount.collect { onLinksChanged() } }
            connectionJobs += launch(serial) { direct.peers.collect { onLinksChanged() } }
            discovery.listen(true)
            connectionJobs += launch(serial) { discovery.rooms.collect { onNearby(it) } }
            // Ready at once: a room can be hosted or joined over a direct link with no relay at all.
            // Whether the relays answer shows in [links].
            updateLink()
        }
    }

    override fun disconnect() {
        launch(serial) {
            leaveRoomInternal()
            connectionJobs.forEach { it.cancel() }
            connectionJobs.clear()
            discovery.listen(false)
            _nearby.value = emptyList()
            pool.stop()
            started = false
            linkUp = false
        }
    }

    override fun forgetSession() = Unit

    override fun release() {
        disconnect()
        launch(serial) {
            pool.release()
            direct.release()
            discovery.release()
            this@PeerRoomTransport.cancel()
        }
    }

    override fun hintDirect(
        roomCode: String,
        endpoints: List<String>,
    ) {
        directHints = roomCode.trim().uppercase() to endpoints
    }

    override fun setVisibleNearby(visible: Boolean) {
        launch(serial) {
            visibleNearby = visible
            announceRoom()
        }
    }

    override suspend fun send(
        msgType: String,
        payload: Any?,
    ): Boolean =
        withContext(serial) {
            when (msgType) {
                MessageTypes.CREATE_ROOM -> createRoom(payload as? CreateRoomPayload)
                MessageTypes.JOIN_ROOM -> joinRoom(payload as? JoinRoomPayload)
                MessageTypes.LEAVE_ROOM -> leaveRoomInternal()
                // Handled by this transport itself; there is no server to negotiate with.
                MessageTypes.CLIENT_CAPABILITIES, MessageTypes.RECONNECT, MessageTypes.PING -> true
                else -> toHub(msgType, payload)
            }
        }

    override fun serverNow(): Long? = if (hub != null) wallClock() else clock.now()

    override fun positionAt(
        position: Long,
        effectiveAtServerTime: Long?,
        isPlaying: Boolean,
    ): Long {
        if (hub == null) return clock.positionAt(position, effectiveAtServerTime, isPlaying)
        if (!isPlaying || effectiveAtServerTime == null || effectiveAtServerTime <= 0L) return position
        return position + (wallClock() - effectiveAtServerTime).coerceAtLeast(0L)
    }

    // ───────────────────────────── rooms ─────────────────────────────

    private suspend fun createRoom(p: CreateRoomPayload?): Boolean {
        if (room != null) {
            emit(MessageTypes.ERROR, ErrorPayload("already_in_room", "Leave the current room before creating another"))
            return true
        }
        val name = p?.username?.trim().orEmpty()
        if (name.isEmpty()) {
            emit(MessageTypes.ERROR, ErrorPayload("missing_username", "Username is required"))
            return true
        }
        val code = newRoomCode()
        openRoom(code, hubId = selfId, member = true)
        val (created, answer) = RoomHub.create(code, selfId, name, wallClock)
        becomeHub(created)
        runHub(created, listOf(answer))
        return true
    }

    private suspend fun joinRoom(p: JoinRoomPayload?): Boolean {
        val code = p?.roomCode?.trim()?.uppercase().orEmpty()
        if (code.isEmpty()) {
            emit(MessageTypes.ERROR, ErrorPayload("missing_room_code", "Room code is required"))
            return true
        }
        val current = room
        if (current != null && (current.member || current.code != code)) {
            emit(MessageTypes.ERROR, ErrorPayload("already_in_room", "Leave the current room before joining another"))
            return true
        }
        if (current == null) openRoom(code, hubId = null, member = false)
        // The host's local addresses came with the invite, or the host is announcing the room on
        // this network: go straight to it, and give the link a moment so the request does not
        // leave by the relays alone. Heard later, the host is dialled then (see [onNearby]) and the
        // repeated request below goes over that link.
        val hinted = directHints?.takeIf { it.first == code }?.second.orEmpty()
        val tag = room?.secret?.tag
        val heard = discovery.rooms.value.firstOrNull { it.tag == tag }?.endpoints.orEmpty()
        if (hinted.isNotEmpty() || heard.isNotEmpty()) {
            frameEndpoints = hinted
            lanEndpoints = heard
            dialKnownHubEndpoints()
            withTimeoutOrNull(DIRECT_JOIN_WAIT_MS) { direct.peers.first { it > 0 } }
        }
        publish(up(MessageTypes.JOIN_ROOM, p))
        // Asked again while unanswered: a relay may not have registered this device's subscription
        // yet when the first request went out, and then the answer has nowhere to go. The hub
        // treats a repeat from someone already waiting as the same request.
        roomJobs +=
            launch(serial) {
                for (wait in JOIN_RETRY_DELAYS_MS) {
                    delay(wait)
                    val waiting = room ?: return@launch
                    if (waiting.code != code || waiting.hubId != null) return@launch
                    publish(up(MessageTypes.JOIN_ROOM, p))
                }
            }
        roomJobs +=
            launch(serial) {
                delay(joinAnswerTimeoutMs)
                val waiting = room
                if (waiting != null && waiting.code == code && waiting.hubId == null) {
                    closeRoom()
                    emit(
                        MessageTypes.ERROR,
                        ErrorPayload("room_not_found", "No one is hosting room $code right now. Check the code, or ask the host to open Listen Together."),
                    )
                }
            }
        // Accepted even when nothing is connected yet: the request waits for a relay or a direct
        // link and is sent again above, and a room nobody answers ends in room_not_found.
        return true
    }

    private suspend fun leaveRoomInternal(): Boolean {
        val current = room ?: return true
        val running = hub
        if (running != null) {
            runHub(running, running.handle(selfId, MessageTypes.LEAVE_ROOM, null), final = true)
        } else if (current.hubId != null) {
            publish(up(MessageTypes.LEAVE_ROOM, null), await = true)
        }
        closeRoom()
        return true
    }

    private suspend fun toHub(
        type: String,
        payload: Any?,
    ): Boolean {
        val current = room ?: return false
        val running = hub
        if (running != null) {
            runHub(running, running.handle(selfId, type, payload))
            return true
        }
        if (current.hubId == null) return false
        return publish(up(type, payload))
    }

    private fun openRoom(
        code: String,
        hubId: String?,
        member: Boolean,
    ) {
        val secret = SharedCodeSecret(code, "simpmusic/listen-together")
        room = Room(code, secret, hubId, member)
        inbound = mutableMapOf()
        forgetWhatSessionKnows()
        lastHubHeardAt = elapsedRealtime()
        pool.subscribe(
            SUBSCRIPTION,
            listOf(NostrFilter(kinds = listOf(KIND), tags = mapOf('h' to listOf(secret.tag)), since = wallClock() / 1000 - 60)),
        )
        roomJobs += launch(serial) { pingLoop() }
    }

    private fun closeRoom() {
        room = null
        hub = null
        beaconKey = null
        direct.stopServing()
        servingAt = emptyList()
        forgetHubEndpoints()
        directHints = null
        announceRoom()
        publishLinks()
        forgetWhatSessionKnows()
        pool.unsubscribe(SUBSCRIPTION)
        clock.reset()
        roomJobs.forEach { it.cancel() }
        roomJobs.clear()
    }

    private fun becomeHub(created: RoomHub) {
        hub = created
        beaconKey = null
        room?.let {
            it.hubId = selfId
            it.epoch = maxOf(it.epoch, created.epoch)
        }
        forgetHubEndpoints()
        roomJobs +=
            launch(serial) {
                val endpoints = direct.serve()
                if (hub !== created) return@launch
                servingAt = endpoints
                // The next beacon carries them, so guests already in the room dial in too.
                beaconKey = null
                publishLinks()
                announceRoom()
            }
        roomJobs +=
            launch(serial) {
                while (isActive && hub === created) {
                    delay(timing.tickMs)
                    if (hub === created) runHub(created, created.tick())
                    if (hub === created) beacon(created)
                    announceRoom()
                }
            }
    }

    /**
     * Tells the members what the room is, whenever that changed and at least every
     * [Timing.stateRefreshMs]: what they need to take it over if this device goes silent (see
     * [maybeClaim]), and how a device that ran the room before learns it has been replaced.
     */
    private suspend fun beacon(running: RoomHub) {
        val others = running.memberIds.filter { it != selfId }
        if (others.isEmpty()) return
        // Addresses change when a phone moves between networks; the port does not.
        if (servingAt.isNotEmpty()) {
            val now = direct.serve()
            if (now != servingAt) {
                servingAt = now
                beaconKey = null
                publishLinks()
            }
        }
        val snapshot = running.snapshot()
        // Positions and presence times move all the time; what counts as a change is the rest.
        val key =
            json.encodeToString(
                HubSnapshot.serializer(),
                snapshot.copy(
                    position = 0L,
                    lastUpdate = 0L,
                    members = snapshot.members.map { it.copy(lastSeen = 0L) },
                    pending = snapshot.pending.map { it.copy(lastSeen = 0L) },
                ),
            )
        val t = elapsedRealtime()
        if (key == beaconKey && t - beaconAt < timing.stateRefreshMs) return
        beaconKey = key
        beaconAt = t
        publish(frame("d", others, stateBody(STATE, selfId, snapshot)))
    }

    private fun stateBody(
        kind: String,
        hubId: String,
        snapshot: HubSnapshot,
    ) = buildJsonObject {
        put("x", kind)
        put("h", hubId)
        put("t", snapshot.epoch)
        put("s", pack(snapshot))
        // Only a hub can say where it listens; a hand-over names another device.
        if (hubId == selfId) putDirect()
    }

    private fun kotlinx.serialization.json.JsonObjectBuilder.putDirect() {
        if (servingAt.isNotEmpty()) put("l", JsonArray(servingAt.map(::JsonPrimitive)))
    }

    /**
     * Sends one hub step's answers ([outs], just returned by [running]): those for this device
     * straight up to the session, the rest through the relays. If the host role has just left this
     * device, the room goes with it.
     *
     * Everything that decides ORDER happens before the first suspension: whether to hand over, and
     * every frame's sequence number. Other hub steps (a pong, a tick) run on this same thread while
     * a publish is suspended, and one of them handing the room over mid-way sent `hub_moved` ahead
     * of this step's own `host_changed` — which the new host then dropped as coming from a device
     * that was no longer the hub.
     */
    private suspend fun runHub(
        running: RoomHub,
        outs: List<RoomHub.Out>,
        final: Boolean = false,
    ) {
        val local = outs.filter { selfId in it.to }
        val frames =
            outs
                .mapNotNull { out -> out.to.filter { it != selfId }.takeIf { it.isNotEmpty() }?.let { down(out.type, out.payload, it) } }
                .toMutableList()
        var handOff = false
        if (hub === running) {
            if (running.isEmpty) {
                hub = null
            } else if (running.hostId != selfId) {
                frames += handOffFrame(running)
                handOff = true
            }
        }
        local.forEach { deliver(it.type, it.payload) }
        frames.forEachIndexed { i, frame ->
            // The hand-over is the last word this device says as the hub: make sure it is out.
            publish(frame, await = final || (handOff && i == frames.lastIndex))
        }
        // Not before: the guests dialled in here hear the hand-over through this very link.
        if (handOff) stopServing()
    }

    private fun stopServing() {
        direct.stopServing()
        servingAt = emptyList()
        announceRoom()
        publishLinks()
    }

    /** Dials the hub's direct addresses; empty hangs up. */
    private fun dialHub(endpoints: List<String>) {
        if (endpoints == dialing) return
        dialing = endpoints
        direct.dial(endpoints)
    }

    /** Dials every address known for the hub: its own list first, then any heard only on the network. */
    private fun dialKnownHubEndpoints() = dialHub((frameEndpoints + lanEndpoints).distinct())

    /** The hub changed, or this device runs the room or left it: whatever was known is stale. */
    private fun forgetHubEndpoints() {
        frameEndpoints = emptyList()
        lanEndpoints = emptyList()
        dialHub(emptyList())
    }

    /**
     * Tells the local network about the room this device runs, so guests with the code connect
     * straight here — and, unless the host hid it, so people nearby see the room. Stops when this
     * device no longer runs a room or no longer listens for direct links.
     */
    private fun announceRoom() {
        val current = room
        val running = hub
        val next =
            if (current != null && running != null && servingAt.isNotEmpty()) {
                val snapshot = running.snapshot()
                LanAnnouncement(
                    tag = current.secret.tag,
                    endpoints = servingAt,
                    hostName = nameIn(snapshot, snapshot.hostId).ifBlank { null },
                    code = current.code.takeIf { visibleNearby },
                    listeners = snapshot.members.count { it.connected },
                )
            } else {
                null
            }
        if (next == announced) return
        announced = next
        discovery.announce(next)
    }

    /** What the local network says: rooms to show nearby, and where this guest's hub is. */
    private fun onNearby(rooms: List<LanRoom>) {
        val current = room
        _nearby.value =
            rooms.mapNotNull { r ->
                r.code?.takeIf { r.tag != current?.secret?.tag }?.let { NearbyRoom(it, r.hostName, r.listeners) }
            }
        if (current == null || hub != null) return
        // Not hearing the hub for a while is not news: the list it gave stays until the hub changes.
        val heard = rooms.firstOrNull { it.tag == current.secret.tag }?.endpoints.orEmpty()
        if (heard.isEmpty() || heard == lanEndpoints) return
        lanEndpoints = heard
        dialKnownHubEndpoints()
    }

    /** Stops being the hub (synchronously) and returns the frame that tells the room who is. */
    private fun handOffFrame(running: RoomHub): JsonObject {
        val snapshot = running.snapshot().let { it.copy(epoch = it.epoch + 1) }
        Logger.i(TAG, "Handing room ${snapshot.roomCode} to ${snapshot.hostId.take(8)}")
        hub = null
        room?.let {
            it.hubId = snapshot.hostId
            it.epoch = snapshot.epoch
            it.lastState = snapshot
            it.lastStateAt = elapsedRealtime()
        }
        clock.reset()
        lastHubHeardAt = elapsedRealtime()
        return frame("d", running.memberIds.filter { it != selfId }, stateBody(HUB_MOVED, snapshot.hostId, snapshot))
    }

    // ───────────────────────────── inbound ─────────────────────────────

    /** An event from a direct link, checked the way the relay pool checks what relays deliver. */
    private suspend fun onDirect(text: String) {
        val event =
            try {
                NostrEvent.fromJson(json.parseToJsonElement(text).jsonObject)
            } catch (e: Exception) {
                null
            } ?: return
        if (!event.isValid()) return
        onEvent(event)
    }

    private suspend fun onEvent(event: NostrEvent) {
        if (offline) return
        if (!seenEvents.add(event.id)) return
        if (seenEvents.size > SEEN_EVENTS) seenEvents.remove(seenEvents.first())
        val current = room ?: return
        if (event.pubkey == selfId || event.kind != KIND || event.tagValue("h") != current.secret.tag) return
        if (event.createdAt < wallClock() / 1000 - MAX_EVENT_AGE_S) return
        val body =
            try {
                json.parseToJsonElement(Nip44.decrypt(event.content, current.secret.conversationKey)).jsonObject
            } catch (e: Exception) {
                Logger.w(TAG, "Dropped a room message that does not decrypt: ${e.message}")
                return
            }
        if (body["v"]?.jsonPrimitive?.intOrNull != VERSION) return
        val seq = body["n"]?.jsonPrimitive?.longOrNull ?: return
        val direction = body["d"]?.jsonPrimitive?.contentOrNull ?: return
        val from = event.pubkey
        when (direction) {
            "u" -> {
                if (hub == null) return
                gate(from).offer(seq, body) { frameBody ->
                    val to = recipients(frameBody)
                    // Addressed to whoever runs the room; empty from a joiner that does not know yet.
                    if (to.isEmpty() || selfId in to) onUp(from, frameBody)
                }
            }
            "d" -> {
                // Before a join is answered the hub is not known yet: the first hub message that
                // names this device is the hub. After that, only the hub's key speaks for it —
                // or a member announcing it has taken the room over (see isWinningClaim).
                if (current.hubId == null && selfId in recipients(body)) current.hubId = from
                if (from != current.hubId && !isWinningClaim(from, body, current)) return
                if (from == current.hubId) {
                    lastHubHeardAt = elapsedRealtime()
                    updateLink()
                }
                gate(from).offer(seq, body) { frameBody ->
                    if (selfId in recipients(frameBody)) onDown(from, frameBody)
                    // Frames to other members count too: any of them can show this device is behind.
                    announced(frameBody["r"]?.jsonPrimitive?.longOrNull)
                    // Where the hub listens on the local network: dial it, beside the relays.
                    if (hub == null && from == room?.hubId) {
                        (frameBody["l"] as? JsonArray)?.mapNotNull { it.jsonPrimitive.contentOrNull }?.let {
                            frameEndpoints = it
                            dialKnownHubEndpoints()
                        }
                    }
                }
            }
        }
    }

    private fun recipients(body: JsonObject): List<String> = body["to"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()

    /**
     * Whether [from], which is not running this room as far as this device knows, says it is — and
     * wins. That happens after a take-over ([claimRoom]), and when the device that used to run the
     * room comes back to find it replaced. Only members can say so, and the higher term wins, then
     * the smaller key, so every device ends up agreeing on one.
     */
    private fun isWinningClaim(
        from: String,
        body: JsonObject,
        current: Room,
    ): Boolean {
        val kind = body["x"]?.jsonPrimitive?.contentOrNull
        if (kind != STATE && kind != HUB_MOVED) return false
        if (body["h"]?.jsonPrimitive?.contentOrNull != from) return false
        val epoch = body["t"]?.jsonPrimitive?.longOrNull ?: return false
        val running = hub
        val members = running?.memberIds ?: current.lastState?.members?.map { it.id }.orEmpty()
        if (from !in members) return false
        val ownEpoch = running?.epoch ?: current.epoch
        val ownHub = if (running != null) selfId else current.hubId
        return epoch > ownEpoch || (epoch == ownEpoch && (ownHub == null || from < ownHub))
    }

    private suspend fun onUp(
        from: String,
        body: JsonObject,
    ) {
        val running = hub ?: return
        val (type, payload) = decodeFrame(body) ?: return
        if (type == MessageTypes.JOIN_ROOM) {
            // Tells the joiner which key is the hub, before the host has decided anything.
            publish(
                frame(
                    "d",
                    listOf(from),
                    buildJsonObject {
                        put("x", JOIN_SEEN)
                        putDirect()
                    },
                ),
            )
        }
        runHub(running, running.handle(from, type, payload))
    }

    private suspend fun onDown(
        from: String,
        body: JsonObject,
    ) {
        when (body["x"]?.jsonPrimitive?.contentOrNull) {
            JOIN_SEEN -> return
            HUB_MOVED -> return onHubMoved(body)
            STATE -> return onState(from, body)
        }
        val (type, payload) = decodeFrame(body) ?: return
        when (type) {
            MessageTypes.PONG -> {
                val p = payload as? PongPayload ?: return
                if (clock.recordPong(p.clientTime, p.serverReceiveTime, p.serverSendTime)) _events.emit(ListenTogetherEvent.ClockReady)
                return
            }
            MessageTypes.JOIN_APPROVED -> room?.member = true
            MessageTypes.HOST_CHANGED ->
                if ((payload as? HostChangedPayload)?.newHostId == selfId && hub == null) {
                    // Sent just ahead of the room itself (hub_moved, next in sequence), which says it
                    // again once this device runs the room. Passed on now, the session would act as
                    // host at once and send its first command to the old device, which drops it.
                    return
                }
        }
        deliver(type, payload)
        when (type) {
            // Out of the room, one way or another: stop listening to it.
            MessageTypes.KICKED -> closeRoom()
            MessageTypes.JOIN_REJECTED -> closeRoom()
            MessageTypes.ERROR -> if (room?.member == false) closeRoom()
        }
    }

    private suspend fun onHubMoved(body: JsonObject) {
        val current = room ?: return
        val newHub = body["h"]?.jsonPrimitive?.contentOrNull ?: return
        val snapshot = unpack(body["s"]?.jsonPrimitive?.contentOrNull)
        val epoch = body["t"]?.jsonPrimitive?.longOrNull ?: snapshot?.epoch ?: current.epoch
        if (snapshot != null) {
            current.lastState = snapshot
            current.lastStateAt = elapsedRealtime()
        }
        if (newHub != selfId) return adopt(newHub, epoch, snapshot)
        if (hub != null || snapshot == null) return
        clock.reset()
        lastHubHeardAt = elapsedRealtime()
        Logger.i(TAG, "Now running room ${snapshot.roomCode}")
        becomeHub(RoomHub.takeOver(snapshot, wallClock))
        deliver(MessageTypes.HOST_CHANGED, HostChangedPayload(selfId, nameIn(snapshot, selfId)))
    }

    private suspend fun onState(
        from: String,
        body: JsonObject,
    ) {
        val current = room ?: return
        val snapshot = unpack(body["s"]?.jsonPrimitive?.contentOrNull) ?: return
        val epoch = body["t"]?.jsonPrimitive?.longOrNull ?: snapshot.epoch
        // Let through by isWinningClaim: another device runs the room now.
        if (from != current.hubId || hub != null) adopt(from, epoch, snapshot)
        current.epoch = maxOf(current.epoch, epoch)
        current.lastState = snapshot
        current.lastStateAt = elapsedRealtime()
        reconcileMembers(snapshot)
    }

    /** Follows [newHub] from now on. If this device was running the room, it stops. */
    private suspend fun adopt(
        newHub: String,
        epoch: Long,
        snapshot: HubSnapshot?,
    ) {
        val current = room ?: return
        val wasHub = hub != null
        if (wasHub) Logger.i(TAG, "Room ${current.code} is run by ${newHub.take(8)} now; stepping down")
        hub = null
        if (wasHub) stopServing()
        // The new hub says where it listens in its next beacon, and on the network.
        if (newHub != current.hubId) forgetHubEndpoints()
        current.hubId = newHub
        current.epoch = maxOf(current.epoch, epoch)
        clock.reset()
        lastHubHeardAt = elapsedRealtime()
        updateLink()
        deliver(MessageTypes.HOST_CHANGED, HostChangedPayload(newHub, snapshot?.let { nameIn(it, newHub) }.orEmpty()))
        // What this device's session holds is its own old view of the room.
        if (wasHub) publish(up(MessageTypes.REQUEST_SYNC, null))
    }

    private fun nameIn(
        snapshot: HubSnapshot,
        id: String,
    ): String = snapshot.members.firstOrNull { it.id == id }?.name.orEmpty()

    private suspend fun deliver(
        type: String,
        payload: Any?,
    ) {
        observe(type, payload)
        _events.emit(ListenTogetherEvent.Message(type, payload))
    }

    private suspend fun emit(
        type: String,
        payload: Any?,
    ) = deliver(type, payload)

    private fun gate(from: String) = inbound.getOrPut(from) { SequenceGate(this, serial) { onGap(from) } }

    // ───────────────────────────── link and clock ─────────────────────────────

    /**
     * Connected = usable: always, unless this device is a guest whose hub has gone quiet. Rooms
     * run over relays or direct links, so no single path decides it; [links] tells them apart.
     */
    private suspend fun updateLink() {
        val current = room
        val hubSilent =
            current != null && current.member && hub == null && elapsedRealtime() - lastHubHeardAt > timing.hubSilentMs
        val up = started && !hubSilent
        if (up == linkUp) return
        linkUp = up
        if (up) {
            _events.emit(ListenTogetherEvent.Connected(serverVersion = SERVER_VERSION, compressionEnabled = true, resumed = false))
            // Whatever the room did while this device could not hear it is lost for good.
            requestSync("connection back")
        } else {
            _events.emit(ListenTogetherEvent.Disconnected(if (hubSilent) "Can't reach the host" else "Offline", willRetry = true))
        }
    }

    /** A relay or a direct link came or went. Coming back from none means the room may have moved on meanwhile. */
    private suspend fun onLinksChanged() {
        val relays = pool.connectedCount.value
        val peers = direct.peers.value
        val cameBack = (relays > 0 && lastRelayCount == 0) || (peers > 0 && lastDirectCount == 0)
        lastRelayCount = relays
        lastDirectCount = peers
        publishLinks()
        updateLink()
        if (cameBack) requestSync("connection back")
    }

    private fun publishLinks() {
        _links.value = RoomLinks(pool.connectedCount.value, relaysTotal, direct.peers.value, servingAt)
    }

    private suspend fun pingLoop() {
        var quick = QUICK_PINGS
        while (isActive) {
            delay(if (quick-- > 0) QUICK_PING_INTERVAL_MS else timing.pingMs)
            val current = room ?: return
            if (hub != null) continue
            if (current.hubId == null) continue
            if (current.member && elapsedRealtime() - lastHubHeardAt > RoomHub.SEAT_GRACE_MS) {
                closeRoom()
                _events.emit(ListenTogetherEvent.SeatLost("The host has been gone too long, so the room has ended"))
                return
            }
            if (current.member && maybeClaim(current)) continue
            updateLink()
            publish(up(MessageTypes.PING, PingPayload(clientTime = elapsedRealtime(), sequence = ++pingSeq)))
        }
    }

    /**
     * Takes the room over when the device running it has gone silent — its app was closed, or it
     * lost its connection — instead of leaving everyone waiting for it. The members queue up in
     * the order the room lists them (connected ones first), each waiting [Timing.failoverStaggerMs]
     * longer than the one before, so the first one still around takes it.
     */
    private suspend fun maybeClaim(current: Room): Boolean {
        val state = current.lastState ?: return false
        val silentFor = elapsedRealtime() - lastHubHeardAt
        val line = state.members.filter { it.id != current.hubId }.sortedBy { !it.connected }.map { it.id }
        val place = line.indexOf(selfId)
        if (place < 0 || silentFor < timing.failoverAfterMs + place * timing.failoverStaggerMs) return false
        claimRoom(current, state)
        return true
    }

    private suspend fun claimRoom(
        current: Room,
        state: HubSnapshot,
    ) {
        val running = RoomHub.claim(state, selfId, elapsedRealtime() - current.lastStateAt, wallClock)
        Logger.i(TAG, "Room ${current.code}: ${current.hubId?.take(8)} went silent; running it here")
        clock.reset()
        becomeHub(running)
        val snapshot = running.snapshot()
        current.lastState = snapshot
        current.lastStateAt = elapsedRealtime()
        val others = running.memberIds.filter { it != selfId }
        if (others.isNotEmpty()) publish(frame("d", others, stateBody(HUB_MOVED, selfId, snapshot)))
        deliver(MessageTypes.HOST_CHANGED, HostChangedPayload(selfId, nameIn(snapshot, selfId)))
    }

    // ───────────────────────────── repair ─────────────────────────────
    //
    // Relays drop events, and a device that loses its connection hears nothing of what went on
    // meanwhile. Nothing is re-sent; instead a guest notices what it missed and asks the hub for
    // the room as it is (request_sync), or fixes the member list from the hub's state beacon.

    private fun forgetWhatSessionKnows() {
        lastRevision = -1L
        announcedRevision = -1L
        knownMembers.clear()
        knownHost = null
        knownGuestControl = null
        syncCheckJob?.cancel()
        syncCheckJob = null
    }

    /** Keeps track of what the session has been told, from every message handed to it. */
    private fun observe(
        type: String,
        payload: Any?,
    ) {
        when (type) {
            MessageTypes.ROOM_CREATED -> {
                knownMembers.clear()
                knownHost = selfId
            }
            MessageTypes.JOIN_APPROVED -> {
                val state = (payload as? JoinApprovedPayload)?.state ?: return
                knownMembers.clear()
                state.users.forEach { knownMembers[it.userId] = KnownMember(it.username, it.isConnected) }
                knownHost = state.hostId
                knownGuestControl = state.guestControl
                lastRevision = maxOf(lastRevision, state.revision)
            }
            MessageTypes.USER_JOINED -> (payload as? UserJoinedPayload)?.let { knownMembers[it.userId] = KnownMember(it.username, true) }
            MessageTypes.USER_LEFT -> (payload as? UserLeftPayload)?.let { knownMembers.remove(it.userId) }
            MessageTypes.USER_DISCONNECTED ->
                (payload as? UserDisconnectedPayload)?.let { p -> knownMembers[p.userId]?.let { knownMembers[p.userId] = KnownMember(it.name, false) } }
            MessageTypes.USER_RECONNECTED ->
                (payload as? UserReconnectedPayload)?.let { p -> knownMembers[p.userId]?.let { knownMembers[p.userId] = KnownMember(it.name, true) } }
            MessageTypes.HOST_CHANGED -> (payload as? HostChangedPayload)?.let { knownHost = it.newHostId }
            MessageTypes.SYNC_PLAYBACK, MessageTypes.PLAYBACK_ACTION ->
                (payload as? PlaybackActionPayload)?.let { lastRevision = maxOf(lastRevision, it.revision) }
            MessageTypes.SYNC_STATE ->
                (payload as? SyncStatePayload)?.let {
                    lastRevision = maxOf(lastRevision, it.revision)
                    knownGuestControl = it.guestControl
                }
            MessageTypes.ROOM_SETTINGS -> (payload as? RoomSettingsPayload)?.let { knownGuestControl = it.guestControl }
        }
    }

    /**
     * The hub stamps its revision on every frame. One ahead of what reached the session means a
     * playback change got lost — or is still on its way through a slower relay, hence the wait.
     */
    private fun announced(revision: Long?) {
        if (revision == null || hub != null || room?.member != true) return
        if (revision <= lastRevision) return
        announcedRevision = maxOf(announcedRevision, revision)
        if (syncCheckJob?.isActive == true) return
        syncCheckJob =
            launch(serial) {
                delay(SYNC_GRACE_MS)
                if (lastRevision < announcedRevision) requestSync("missed revision ${lastRevision + 1}..$announcedRevision")
            }
    }

    /** The hub's frames had a hole the gate gave up waiting for: something in it is lost. */
    private fun onGap(from: String) {
        val current = room ?: return
        if (from != current.hubId || hub != null || !current.member) return
        launch(serial) { requestSync("lost frames") }
    }

    private suspend fun requestSync(reason: String) {
        val current = room ?: return
        if (hub != null || !current.member || current.hubId == null) return
        val now = elapsedRealtime()
        if (now - lastSyncRequestAt < SYNC_REQUEST_GAP_MS) return
        lastSyncRequestAt = now
        Logger.i(TAG, "Asking the hub for the room's state: $reason")
        publish(up(MessageTypes.REQUEST_SYNC, null))
    }

    /** Brings the session's member list in line with the hub's, for joins, leaves and hand-overs it never heard of. */
    private suspend fun reconcileMembers(snapshot: HubSnapshot) {
        val current = room ?: return
        if (!current.member || hub != null || knownHost == null) return
        for (m in snapshot.members) {
            val known = knownMembers[m.id]
            if (known == null) deliver(MessageTypes.USER_JOINED, UserJoinedPayload(m.id, m.name))
            if ((known?.connected ?: true) != m.connected) {
                if (m.connected) {
                    deliver(MessageTypes.USER_RECONNECTED, UserReconnectedPayload(m.id, m.name))
                } else {
                    deliver(MessageTypes.USER_DISCONNECTED, UserDisconnectedPayload(m.id, m.name))
                }
            }
        }
        val present = snapshot.members.mapTo(HashSet()) { it.id }
        knownMembers.entries.filter { it.key !in present }.forEach { (id, known) -> deliver(MessageTypes.USER_LEFT, UserLeftPayload(id, known.name)) }
        if (snapshot.hostId != knownHost) deliver(MessageTypes.HOST_CHANGED, HostChangedPayload(snapshot.hostId, nameIn(snapshot, snapshot.hostId)))
        // A room_settings that never arrived: the beacon carries the room's settings too.
        if (knownGuestControl != null && snapshot.guestControl != knownGuestControl) {
            deliver(MessageTypes.ROOM_SETTINGS, RoomSettingsPayload(snapshot.guestControl))
        }
    }

    // ───────────────────────────── frames ─────────────────────────────

    /** A snapshot for the wire: gzipped, as a queue of a hundred tracks runs to tens of kilobytes. */
    private fun pack(snapshot: HubSnapshot): String {
        val bytes = json.encodeToString(HubSnapshot.serializer(), snapshot).encodeToByteArray()
        val buffer = Buffer()
        GzipSink(buffer).buffer().use { it.write(bytes) }
        return Base64.Default.encode(buffer.readByteArray())
    }

    private fun unpack(text: String?): HubSnapshot? {
        if (text == null) return null
        return try {
            val bytes = GzipSource(Buffer().apply { write(Base64.Default.decode(text)) }).buffer().use { it.readByteArray() }
            json.decodeFromString(HubSnapshot.serializer(), bytes.decodeToString())
        } catch (e: Exception) {
            Logger.w(TAG, "Unreadable room state: ${e.message}")
            null
        }
    }

    private fun up(
        type: String,
        payload: Any?,
    ) = frame("u", listOfNotNull(room?.hubId), envelope(type, payload))

    private fun down(
        type: String,
        payload: Any?,
        to: List<String>,
    ) = frame("d", to, envelope(type, payload))

    private fun envelope(
        type: String,
        payload: Any?,
    ) = buildJsonObject { put("e", Base64.Default.encode(codec.encode(type, payload))) }

    private fun frame(
        direction: String,
        to: List<String>,
        content: JsonObject,
    ): JsonObject =
        JsonObject(
            content +
                mapOf(
                    "v" to JsonPrimitive(VERSION),
                    "n" to JsonPrimitive(++outSeq),
                    "d" to JsonPrimitive(direction),
                    "to" to JsonArray(to.map(::JsonPrimitive)),
                ) + listOfNotNull(hub?.takeIf { direction == "d" }?.let { "r" to JsonPrimitive(it.revision) }),
        )

    private fun decodeFrame(body: JsonObject): Pair<String, Any?>? =
        try {
            val bytes = Base64.Default.decode(body["e"]!!.jsonPrimitive.content)
            val (type, payloadBytes) = codec.decode(bytes)
            type to codec.decodePayload(type, payloadBytes)
        } catch (e: Exception) {
            Logger.w(TAG, "Unreadable room frame: ${e.message}")
            null
        }

    /**
     * Sends [body] to the room. By default without waiting for the relays' answers — the room runs on
     * one thread, and a slow relay must not hold every other message up; order is restored at the
     * other end by [SequenceGate]. [await] waits, for the last words before this device stops
     * listening (leaving, handing the room over).
     */
    private suspend fun publish(
        body: JsonObject,
        await: Boolean = false,
    ): Boolean {
        val current = room ?: return false
        if (offline) return false
        val event =
            try {
                NostrEvent.create(
                    keys,
                    createdAt = wallClock() / 1000,
                    kind = KIND,
                    tags = listOf(listOf("h", current.secret.tag)),
                    content = Nip44.encrypt(body.toString(), current.secret.conversationKey),
                )
            } catch (e: Exception) {
                Logger.w(TAG, "Could not build a room message: ${e.message}")
                return false
            }
        // Straight to the direct peers first (the hub's guests, or this guest's hub), then the relays.
        val directSent = direct.send(event.toJson().toString())
        val relaysUp = pool.connectedCount.value > 0
        if (!await) {
            launch {
                val result = pool.publish(event)
                if (result.accepted == 0 && !directSent) Logger.w(TAG, "No relay took a room message (${result.attempted} tried) ${result.rejections}")
            }
            return relaysUp || directSent
        }
        // A room on one Wi-Fi with no internet: the direct link has it, waiting for relays only delays.
        if (!relaysUp && directSent) return true
        val result = pool.publish(event, timeout = FINAL_PUBLISH_TIMEOUT)
        return result.accepted > 0 || directSent
    }

    private fun newRoomCode(): String {
        val bytes = secureRandomBytes(ROOM_CODE_LENGTH)
        // 32 symbols divide 256 evenly, so the modulo adds no bias.
        return CharArray(ROOM_CODE_LENGTH) { ROOM_CODE_ALPHABET[(bytes[it].toInt() and 0xff) % ROOM_CODE_ALPHABET.length] }.concatToString()
    }

    /** How often things happen. Tests shorten these; the app uses the defaults. */
    data class Timing(
        /** Guests' clock pings, which are also how the hub knows who is still there. */
        val pingMs: Long = 10_000L,
        /** The hub's housekeeping: presence, and the state beacon when something changed. */
        val tickMs: Long = 5_000L,
        /** The state beacon goes out at least this often, changed or not. */
        val stateRefreshMs: Long = 60_000L,
        /** A hub silent this long shows as reconnecting. */
        val hubSilentMs: Long = 45_000L,
        /** How long the device running a room may be silent before the first member in line takes over. */
        val failoverAfterMs: Long = 30_000L,
        /** How much longer each next member in line waits, in case the ones before it are gone too. */
        val failoverStaggerMs: Long = 15_000L,
    )

    /** Tests: while set, this device neither hears nor says anything, like a phone that lost its signal. */
    @Volatile
    internal var offline = false

    /** Tests: this device disappears mid-room, the way a killed app does — no goodbye. */
    internal fun vanish() {
        offline = true
        launch(serial) {
            direct.release()
            discovery.release()
            pool.release()
            this@PeerRoomTransport.cancel()
        }
    }

    companion object {
        /** Ephemeral (20000–29999): relays pass these on to subscribers and never store them. */
        const val KIND = 21078
        const val SERVER_VERSION = "peer-to-peer"
        private const val VERSION = 1
        private const val SUBSCRIPTION = "simpmusic-room"
        private const val JOIN_SEEN = "join_seen"
        private const val HUB_MOVED = "hub_moved"
        private const val STATE = "state"

        /** Same length and alphabet the rest of the app expects (8 letters and digits), minus look-alikes. */
        const val ROOM_CODE_LENGTH = 8
        private const val ROOM_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

        private const val QUICK_PING_INTERVAL_MS = 1_000L

        /** How long a revision may be ahead before the missing change counts as lost. */
        private const val SYNC_GRACE_MS = 1_500L

        /** At most one request_sync in this long, whatever keeps finding things missing. */
        private const val SYNC_REQUEST_GAP_MS = 2_000L
        private const val QUICK_PINGS = 3
        private const val DIRECT_JOIN_WAIT_MS = 2_000L
        private const val SEEN_EVENTS = 4_000
        private const val MAX_EVENT_AGE_S = 120L
        private val JOIN_RETRY_DELAYS_MS = listOf(3_000L, 5_000L)
        private val FINAL_PUBLISH_TIMEOUT = 3.seconds

        private val MONOTONIC = TimeSource.Monotonic.markNow()
    }
}

/**
 * Puts one sender's messages back in order. They come through every relay, so each one usually
 * arrives several times and occasionally out of order; a gap is waited out for [HOLD_MS] before
 * the messages behind it are let through anyway.
 */
internal class SequenceGate(
    private val scope: CoroutineScope,
    private val context: CoroutineContext,
    /** Called when a hole is given up on: whatever was in it is not coming. */
    private val onGap: () -> Unit = {},
) {
    private var delivered = -1L
    private val held = mutableMapOf<Long, JsonObject>()
    private var flushJob: Job? = null

    private fun firstHeld(): Long = held.keys.min()

    suspend fun offer(
        seq: Long,
        body: JsonObject,
        handle: suspend (JsonObject) -> Unit,
    ) {
        // The first message from a sender sets the baseline: joining mid-stream is normal.
        if (delivered < 0) delivered = seq - 1
        if (seq <= delivered || held.containsKey(seq)) return
        held[seq] = body
        drain(handle)
        if (held.isNotEmpty() && flushJob?.isActive != true) {
            flushJob =
                scope.launch(context) {
                    delay(HOLD_MS)
                    if (held.isNotEmpty()) {
                        delivered = firstHeld() - 1
                        onGap()
                        drain(handle)
                    }
                }
        }
    }

    private suspend fun drain(handle: suspend (JsonObject) -> Unit) {
        while (held.isNotEmpty() && firstHeld() == delivered + 1) {
            val next = held.remove(firstHeld())!!
            delivered++
            handle(next)
        }
    }

    companion object {
        const val HOLD_MS = 400L
    }
}
