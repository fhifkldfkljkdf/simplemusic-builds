package org.simpmusic.listentogether

/**
 * Decides whether, and how soon, a dropped connection is retried.
 *
 * Two budgets, because the two situations want opposite things:
 *
 * - **Holding a room seat** (a session token from `room_created` / `join_approved`): metroserver
 *   keeps a disconnected member's place for [seatGraceMs] (`ReconnectGracePeriod`, 15 minutes)
 *   and the same token keeps working for all of it. Giving up any earlier throws away a seat the
 *   server is still holding — which is what the old five-attempt budget did after about half a
 *   minute, so a phone that lost signal in a lift, or an app the OS froze in the background, came
 *   back to an empty screen. Retries are capped at [seatMaxDelayMs] so a returning network is
 *   noticed within seconds rather than a minute.
 * - **No seat** (connected to the server, not in a room): nothing is lost by stopping, so the
 *   original [maxAttempts] budget stays and the user is told plainly that it failed.
 *
 * Pure and clock-injected, so both budgets are unit-tested without a socket.
 */
internal class ReconnectPolicy(
    private val initialDelayMs: Long,
    private val maxDelayMs: Long,
    private val seatMaxDelayMs: Long,
    private val maxAttempts: Int,
    private val seatGraceMs: Long,
) {
    sealed interface Decision {
        data class RetryIn(
            val delayMs: Long,
        ) : Decision

        /** Retrying cannot help any more; [seatExpired] says the room seat went with it. */
        data class GiveUp(
            val seatExpired: Boolean,
        ) : Decision
    }

    private var attempts = 0
    private var nextDelayMs = initialDelayMs

    /** When the seat was first found unreachable; null while connected. */
    private var seatLostAtMs: Long? = null

    /**
     * Refills every budget. Called on a COMPLETED handshake, not merely an open socket — a server
     * that accepts TCP but never answers must not buy itself unlimited retries — and when the user
     * starts a connection by hand.
     */
    fun reset() {
        attempts = 0
        nextDelayMs = initialDelayMs
        seatLostAtMs = null
    }

    fun next(
        nowMs: Long,
        holdingSeat: Boolean,
    ): Decision {
        if (holdingSeat) {
            val lostAt = seatLostAtMs ?: nowMs.also { seatLostAtMs = it }
            if (nowMs - lostAt >= seatGraceMs) return Decision.GiveUp(seatExpired = true)
            val delay = nextDelayMs.coerceAtMost(seatMaxDelayMs)
            nextDelayMs = (nextDelayMs * 2).coerceAtMost(seatMaxDelayMs)
            return Decision.RetryIn(delay)
        }
        if (attempts >= maxAttempts) return Decision.GiveUp(seatExpired = false)
        attempts++
        val delay = nextDelayMs
        nextDelayMs = (nextDelayMs * 2).coerceAtMost(maxDelayMs)
        return Decision.RetryIn(delay)
    }
}
