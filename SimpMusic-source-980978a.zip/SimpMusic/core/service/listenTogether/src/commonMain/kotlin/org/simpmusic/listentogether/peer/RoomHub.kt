package org.simpmusic.listentogether.peer

import kotlinx.serialization.Serializable
import org.simpmusic.listentogether.ApproveJoinPayload
import org.simpmusic.listentogether.ApproveSuggestionPayload
import org.simpmusic.listentogether.BufferCompletePayload
import org.simpmusic.listentogether.BufferReadyPayload
import org.simpmusic.listentogether.ControlRequestPayload
import org.simpmusic.listentogether.ErrorPayload
import org.simpmusic.listentogether.HostChangedPayload
import org.simpmusic.listentogether.JoinApprovedPayload
import org.simpmusic.listentogether.JoinRejectedPayload
import org.simpmusic.listentogether.JoinRequestPayload
import org.simpmusic.listentogether.JoinRoomPayload
import org.simpmusic.listentogether.KickUserPayload
import org.simpmusic.listentogether.KickedPayload
import org.simpmusic.listentogether.MessageTypes
import org.simpmusic.listentogether.PingPayload
import org.simpmusic.listentogether.PlaybackActionPayload
import org.simpmusic.listentogether.PlaybackActions
import org.simpmusic.listentogether.PongPayload
import org.simpmusic.listentogether.RejectJoinPayload
import org.simpmusic.listentogether.RejectSuggestionPayload
import org.simpmusic.listentogether.RoomCreatedPayload
import org.simpmusic.listentogether.RoomSettingsPayload
import org.simpmusic.listentogether.RoomState
import org.simpmusic.listentogether.SuggestTrackPayload
import org.simpmusic.listentogether.SuggestionApprovedPayload
import org.simpmusic.listentogether.SuggestionReceivedPayload
import org.simpmusic.listentogether.SuggestionRejectedPayload
import org.simpmusic.listentogether.SyncStatePayload
import org.simpmusic.listentogether.TrackInfo
import org.simpmusic.listentogether.TransferHostPayload
import org.simpmusic.listentogether.UserDisconnectedPayload
import org.simpmusic.listentogether.UserInfo
import org.simpmusic.listentogether.UserJoinedPayload
import org.simpmusic.listentogether.UserLeftPayload
import org.simpmusic.listentogether.UserReconnectedPayload

@Serializable
data class HubMember(
    val id: String,
    val name: String,
    val connected: Boolean = true,
    /** Hub wall clock (ms) of the last message from this member. */
    val lastSeen: Long = 0L,
)

@Serializable
data class HubSuggestion(
    val id: String,
    val fromId: String,
    val fromName: String,
    val track: TrackInfo,
)

/** Everything a room is, so the hub can move to another device (see [RoomHub.snapshot]). */
@Serializable
data class HubSnapshot(
    val roomCode: String,
    val hostId: String,
    /** In joining order: the first connected one after the host inherits the room. */
    val members: List<HubMember>,
    val pending: List<HubMember> = emptyList(),
    val suggestions: List<HubSuggestion> = emptyList(),
    val currentTrack: TrackInfo? = null,
    val isPlaying: Boolean = false,
    /** Position at [lastUpdate]. */
    val position: Long = 0L,
    val lastUpdate: Long = 0L,
    val volume: Float = 1f,
    val queue: List<TrackInfo> = emptyList(),
    val revision: Long = 0L,
    val suggestionCounter: Long = 0L,
    /**
     * Which term of running this room the snapshot belongs to: one more every time the room moves
     * to another device. When two devices both think they run it (the old host came back after
     * someone took over), the higher term wins, then the smaller key.
     */
    val epoch: Long = 0L,
    /**
     * Whether guests may play, pause, seek and change the track for everyone ([MessageTypes.CONTROL]).
     * Belongs to the room, so it stays the same when the host role moves to another device.
     */
    val guestControl: Boolean = false,
)

/**
 * A Listen Together room, run by the host's own device instead of a server.
 *
 * The rules are metroserver's (MetrolistGroup/metroserver, `internal/server/rooms.go` and
 * `playback.go`), message for message, so [org.simpmusic.listentogether.ListenTogetherSession]
 * behaves exactly as it did against the server. Pure: messages in, messages out, time injected —
 * [RoomHubTest] drives it without any network.
 *
 * What differs from the server: there are no session tokens (a member IS its Nostr key), no
 * user-agent policy, and presence comes from the members' clock pings — a member silent for
 * [DISCONNECT_AFTER_MS] is shown as disconnected, and one gone for [SEAT_GRACE_MS] leaves.
 */
class RoomHub(
    snapshot: HubSnapshot,
    private val now: () -> Long,
) {
    /** One message to [to]; the transport sends it to exactly those members. */
    data class Out(
        val to: List<String>,
        val type: String,
        val payload: Any?,
    )

    private var s = snapshot

    val roomCode: String get() = s.roomCode
    val hostId: String get() = s.hostId
    val memberIds: List<String> get() = s.members.map { it.id }
    val epoch: Long get() = s.epoch

    val guestControl: Boolean get() = s.guestControl

    /** Goes up with every change to what plays; stamped on the hub's frames so guests can tell they missed one. */
    val revision: Long get() = s.revision
    val isEmpty: Boolean get() = s.members.isEmpty()

    /**
     * The room as it is now, with the position made live — what the next hub starts from.
     * [lastUpdate] is on THIS device's clock; the receiving hub re-bases it on its own.
     */
    fun snapshot(): HubSnapshot = s.copy(position = livePosition(), lastUpdate = now())

    /** Messages from [from], in the protocol's own types. Returns what to send, to whom. */
    fun handle(
        from: String,
        type: String,
        payload: Any?,
    ): List<Out> {
        val out = mutableListOf<Out>()
        touch(from, out)
        when (type) {
            MessageTypes.JOIN_ROOM -> join(from, payload as? JoinRoomPayload, out)
            MessageTypes.LEAVE_ROOM -> leave(from, out)
            MessageTypes.APPROVE_JOIN -> approve(from, (payload as? ApproveJoinPayload)?.userId, out)
            MessageTypes.REJECT_JOIN -> reject(from, payload as? RejectJoinPayload, out)
            MessageTypes.PLAYBACK_ACTION -> playback(from, payload as? PlaybackActionPayload, out)
            MessageTypes.BUFFER_READY -> bufferReady(from, payload as? BufferReadyPayload, out)
            MessageTypes.REQUEST_SYNC -> if (isMember(from)) out += Out(listOf(from), MessageTypes.SYNC_STATE, syncState())
            MessageTypes.KICK_USER -> kick(from, payload as? KickUserPayload, out)
            MessageTypes.TRANSFER_HOST -> transferHost(from, (payload as? TransferHostPayload)?.newHostId, out)
            MessageTypes.SUGGEST_TRACK -> suggest(from, payload as? SuggestTrackPayload, out)
            MessageTypes.APPROVE_SUGGESTION -> approveSuggestion(from, (payload as? ApproveSuggestionPayload)?.suggestionId, out)
            MessageTypes.REJECT_SUGGESTION -> rejectSuggestion(from, payload as? RejectSuggestionPayload, out)
            MessageTypes.CONTROL -> control(from, payload as? PlaybackActionPayload, out)
            MessageTypes.SET_ROOM_SETTINGS -> settings(from, payload as? RoomSettingsPayload, out)
            MessageTypes.PING -> {
                val p = payload as? PingPayload ?: return out
                val t = now()
                out += Out(listOf(from), MessageTypes.PONG, PongPayload(p.clientTime, t, t, p.sequence))
            }
        }
        return out
    }

    /** Presence housekeeping; call every few seconds. */
    fun tick(): List<Out> {
        val out = mutableListOf<Out>()
        val t = now()
        val gone = s.members.filter { it.id != s.hostId && t - it.lastSeen > SEAT_GRACE_MS }
        gone.forEach { removeMember(it.id, out) }
        val silent = s.members.filter { it.id != s.hostId && it.connected && t - it.lastSeen > DISCONNECT_AFTER_MS }
        if (silent.isNotEmpty()) {
            s = s.copy(members = s.members.map { m -> if (silent.any { it.id == m.id }) m.copy(connected = false) else m })
            silent.forEach { out += Out(others(it.id), MessageTypes.USER_DISCONNECTED, UserDisconnectedPayload(it.id, it.name)) }
        }
        s = s.copy(pending = s.pending.filter { t - it.lastSeen <= SEAT_GRACE_MS })
        return out
    }

    // ───────────────────────────── membership ─────────────────────────────

    private fun touch(
        from: String,
        out: MutableList<Out>,
    ) {
        val t = now()
        val member = s.members.firstOrNull { it.id == from }
        if (member != null) {
            s = s.copy(members = s.members.map { if (it.id == from) it.copy(lastSeen = t, connected = true) else it })
            if (!member.connected) out += Out(others(from), MessageTypes.USER_RECONNECTED, UserReconnectedPayload(from, member.name))
        } else {
            s = s.copy(pending = s.pending.map { if (it.id == from) it.copy(lastSeen = t) else it })
        }
    }

    private fun join(
        from: String,
        p: JoinRoomPayload?,
        out: MutableList<Out>,
    ) {
        val name = p?.username?.trim()?.take(MAX_NAME).orEmpty()
        when {
            name.isEmpty() -> out += error(from, "missing_username", "Username is required")
            p?.roomCode?.uppercase() != s.roomCode -> out += error(from, "room_not_found", "Room not found")
            // The same device asking again (its first answer was lost): answer again.
            isMember(from) -> out += Out(listOf(from), MessageTypes.JOIN_APPROVED, approval(from))
            s.pending.any { it.id == from } -> Unit
            s.members.size >= MAX_MEMBERS -> out += error(from, "room_full", "Room is full")
            s.pending.size >= MAX_PENDING -> out += error(from, "too_many_pending", "Too many pending join requests")
            else -> {
                s = s.copy(pending = s.pending + HubMember(from, name, lastSeen = now()))
                out += Out(listOf(s.hostId), MessageTypes.JOIN_REQUEST, JoinRequestPayload(from, name))
            }
        }
    }

    private fun approve(
        from: String,
        userId: String?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can approve join requests") }
        val joining = s.pending.firstOrNull { it.id == userId } ?: return run { out += error(from, "join_request_not_found", "Join request not found") }
        if (s.members.size >= MAX_MEMBERS) return run { out += error(from, "room_full", "Room is full") }
        s = s.copy(pending = s.pending - joining, members = s.members + joining.copy(connected = true, lastSeen = now()))
        out += Out(listOf(joining.id), MessageTypes.JOIN_APPROVED, approval(joining.id))
        out += Out(others(joining.id), MessageTypes.USER_JOINED, UserJoinedPayload(joining.id, joining.name))
    }

    private fun reject(
        from: String,
        p: RejectJoinPayload?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can reject join requests") }
        val joining = s.pending.firstOrNull { it.id == p?.userId } ?: return run { out += error(from, "join_request_not_found", "Join request not found") }
        s = s.copy(pending = s.pending - joining)
        out += Out(listOf(joining.id), MessageTypes.JOIN_REJECTED, JoinRejectedPayload(p?.reason?.ifBlank { null } ?: "Join request rejected by host"))
    }

    private fun leave(
        from: String,
        out: MutableList<Out>,
    ) {
        s = s.copy(pending = s.pending.filterNot { it.id == from })
        if (isMember(from)) removeMember(from, out)
    }

    private fun kick(
        from: String,
        p: KickUserPayload?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can kick users") }
        val target = p?.userId ?: return
        if (target == from) return run { out += error(from, "cannot_kick_self", "You cannot kick yourself") }
        val member = s.members.firstOrNull { it.id == target } ?: return run { out += error(from, "user_not_found", "User not found in room") }
        s = s.copy(members = s.members - member)
        out += Out(listOf(target), MessageTypes.KICKED, KickedPayload(p.reason.ifBlank { "You have been kicked from the room" }))
        out += Out(memberIds, MessageTypes.USER_LEFT, UserLeftPayload(target, member.name))
    }

    private fun transferHost(
        from: String,
        newHostId: String?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can transfer ownership") }
        if (newHostId == from) return run { out += error(from, "cannot_transfer_to_self", "You are already the host") }
        val next = s.members.firstOrNull { it.id == newHostId } ?: return run { out += error(from, "user_not_found", "Target user not found in room") }
        setHost(next, out)
    }

    private fun removeMember(
        id: String,
        out: MutableList<Out>,
    ) {
        val member = s.members.firstOrNull { it.id == id } ?: return
        s = s.copy(members = s.members - member, suggestions = s.suggestions.filterNot { it.fromId == id })
        if (s.members.isEmpty()) return
        out += Out(memberIds, MessageTypes.USER_LEFT, UserLeftPayload(id, member.name))
        if (id == s.hostId) {
            // metroserver's firstEligibleHost, preferring someone who is actually online.
            val next = s.members.firstOrNull { it.connected } ?: s.members.first()
            setHost(next, out)
        }
    }

    private fun setHost(
        next: HubMember,
        out: MutableList<Out>,
    ) {
        s = s.copy(hostId = next.id)
        out += Out(memberIds, MessageTypes.HOST_CHANGED, HostChangedPayload(next.id, next.name))
    }

    // ───────────────────────────── playback ─────────────────────────────

    private fun playback(
        from: String,
        input: PlaybackActionPayload?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can control playback") }
        var p = input ?: return
        if (p.action.isEmpty()) return run { out += error(from, "missing_action", "Action is required") }
        val t = now()
        val current = s.currentTrack
        fun staleTrack(): Boolean = current != null && p.trackId.isNotEmpty() && p.trackId != current.id
        when (p.action) {
            PlaybackActions.PLAY -> {
                if (current == null) return run { out += error(from, "no_track", "Cannot play without a track") }
                if (staleTrack()) return run { out += error(from, "stale_track", "Playback action targets a stale track") }
                val position = clamp(compensate(p.position, p.capturedAtServerTime, t), current)
                p = p.copy(trackId = current.id, position = position)
                s = s.copy(isPlaying = true, position = position, lastUpdate = t)
            }

            PlaybackActions.PAUSE -> {
                if (staleTrack()) return run { out += error(from, "stale_track", "Playback action targets a stale track") }
                val position = clamp(p.position, current)
                p = p.copy(trackId = current?.id ?: p.trackId, position = position)
                s = s.copy(isPlaying = false, position = position, lastUpdate = t)
            }

            PlaybackActions.SEEK -> {
                if (staleTrack()) return run { out += error(from, "stale_track", "Playback action targets a stale track") }
                val raw = if (s.isPlaying) compensate(p.position, p.capturedAtServerTime, t) else p.position
                val position = clamp(raw, current)
                p = p.copy(trackId = current?.id ?: p.trackId, position = position)
                s = s.copy(position = position, lastUpdate = t)
            }

            PlaybackActions.CHANGE_TRACK -> {
                val track = p.trackInfo?.takeIf { it.id.isNotBlank() } ?: return run { out += error(from, "missing_track_info", "Track info is required for track change") }
                val queue = upcoming(if (p.queue.isNotEmpty()) p.queue else s.queue, track.id)
                s = s.copy(currentTrack = track, queue = queue, position = 0L, isPlaying = false, lastUpdate = t)
                p = p.copy(trackId = track.id, position = 0L)
            }

            PlaybackActions.SKIP_NEXT, PlaybackActions.SKIP_PREV -> return // the host's own change_track follows

            PlaybackActions.QUEUE_ADD -> {
                val track = p.trackInfo?.takeIf { it.id.isNotBlank() } ?: return run { out += error(from, "missing_track_info", "Track info is required for queue add") }
                if (s.queue.size >= MAX_QUEUE) return run { out += error(from, "queue_full", "Queue is full") }
                if (current?.id == track.id || s.queue.any { it.id == track.id }) {
                    return run { out += error(from, "duplicate_track", "Track is already playing or queued") }
                }
                s = s.copy(queue = if (p.insertNext) listOf(track) + s.queue else s.queue + track)
            }

            PlaybackActions.QUEUE_REMOVE -> s = s.copy(queue = s.queue.filterNot { it.id == p.trackId })
            PlaybackActions.QUEUE_CLEAR -> s = s.copy(queue = emptyList())
            PlaybackActions.SYNC_QUEUE -> s = s.copy(queue = upcoming(p.queue, current?.id))
            PlaybackActions.SET_VOLUME -> {
                if (p.volume.isNaN() || p.volume < 0f || p.volume > 1f) return run { out += error(from, "invalid_volume", "Volume must be between 0 and 1") }
                s = s.copy(volume = p.volume)
            }

            else -> return run { out += error(from, "unknown_action", "Unknown action: ${p.action}") }
        }
        if (p.action in QUEUE_CARRYING_ACTIONS) p = p.copy(queue = s.queue)
        s = s.copy(revision = s.revision + 1)
        out += Out(memberIds, MessageTypes.SYNC_PLAYBACK, p.copy(revision = s.revision, serverTime = t))
    }

    // ───────────────────────────── shared control (private copy) ─────────────────────────────

    /**
     * A guest asking to play, pause, seek or change the track for everyone.
     *
     * The room is not changed here: the request goes to the host, whose player carries it out and
     * publishes the result like any other command of its own. That keeps one device deciding what
     * plays — its queue, its radio, its endless queue — so a guest's skip lands on the same next
     * song everyone else would have heard.
     */
    private fun control(
        from: String,
        p: PlaybackActionPayload?,
        out: MutableList<Out>,
    ) {
        if (!isMember(from)) return run { out += error(from, "not_in_room", "You are not in a room") }
        val action = p ?: return
        if (isHost(from)) return playback(from, action, out)
        if (!s.guestControl) return run { out += error(from, "control_not_allowed", "Only the host controls playback in this room") }
        when (action.action) {
            PlaybackActions.PLAY, PlaybackActions.PAUSE, PlaybackActions.SEEK, PlaybackActions.SKIP_NEXT, PlaybackActions.SKIP_PREV -> Unit
            PlaybackActions.CHANGE_TRACK ->
                if (action.trackInfo?.id.isNullOrBlank()) {
                    return run { out += error(from, "missing_track_info", "Track info is required for track change") }
                }
            else -> return run { out += error(from, "unknown_action", "Unknown action: ${action.action}") }
        }
        val name = s.members.first { it.id == from }.name
        out += Out(listOf(s.hostId), MessageTypes.CONTROL_REQUEST, ControlRequestPayload(from, name, action))
    }

    private fun settings(
        from: String,
        p: RoomSettingsPayload?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can change the room's settings") }
        val settings = p ?: return
        if (settings.guestControl == s.guestControl) {
            out += Out(listOf(from), MessageTypes.ROOM_SETTINGS, settings)
            return
        }
        s = s.copy(guestControl = settings.guestControl)
        out += Out(memberIds, MessageTypes.ROOM_SETTINGS, settings)
    }

    /** metroserver's non-coordinated path: tell this member where the room is, then release it. */
    private fun bufferReady(
        from: String,
        p: BufferReadyPayload?,
        out: MutableList<Out>,
    ) {
        if (!isMember(from)) return
        val current = s.currentTrack ?: return run { out += error(from, "stale_track", "Buffer readiness targets a stale track") }
        if (p?.trackId != current.id) return run { out += error(from, "stale_track", "Buffer readiness targets a stale track") }
        val t = now()
        val position = livePosition()
        out += Out(listOf(from), MessageTypes.SYNC_PLAYBACK, PlaybackActionPayload(action = PlaybackActions.SEEK, trackId = current.id, position = position, serverTime = t, revision = s.revision))
        val action = if (s.isPlaying) PlaybackActions.PLAY else PlaybackActions.PAUSE
        out += Out(listOf(from), MessageTypes.SYNC_PLAYBACK, PlaybackActionPayload(action = action, trackId = current.id, position = position, serverTime = t, revision = s.revision))
        out += Out(listOf(from), MessageTypes.BUFFER_COMPLETE, BufferCompletePayload(current.id))
    }

    // ───────────────────────────── suggestions ─────────────────────────────

    private fun suggest(
        from: String,
        p: SuggestTrackPayload?,
        out: MutableList<Out>,
    ) {
        if (!isMember(from)) return run { out += error(from, "not_in_room", "You are not in a room") }
        val track = p?.trackInfo?.takeIf { it.id.isNotBlank() && it.title.isNotBlank() } ?: return run { out += error(from, "invalid_track_info", "Track must have ID and title") }
        if (from == s.hostId) return
        if (s.suggestions.size >= MAX_SUGGESTIONS) return run { out += error(from, "suggestions_full", "Too many pending suggestions") }
        val name = s.members.first { it.id == from }.name
        val id = "sug_${s.suggestionCounter + 1}_${now()}"
        s = s.copy(suggestionCounter = s.suggestionCounter + 1, suggestions = s.suggestions + HubSuggestion(id, from, name, track))
        out += Out(listOf(s.hostId), MessageTypes.SUGGESTION_RECEIVED, SuggestionReceivedPayload(id, from, name, track))
    }

    private fun approveSuggestion(
        from: String,
        id: String?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can approve suggestions") }
        val suggestion = s.suggestions.firstOrNull { it.id == id } ?: return run { out += error(from, "suggestion_not_found", "Suggestion not found") }
        if (s.queue.size >= MAX_QUEUE) return run { out += error(from, "queue_full", "Queue is full") }
        val track = suggestion.track.copy(suggestedBy = suggestion.fromName)
        if (s.currentTrack?.id == track.id || s.queue.any { it.id == track.id }) {
            return run { out += error(from, "duplicate_track", "Track is already playing or queued") }
        }
        s = s.copy(suggestions = s.suggestions - suggestion, queue = listOf(track) + s.queue, revision = s.revision + 1)
        out +=
            Out(
                memberIds,
                MessageTypes.SYNC_PLAYBACK,
                PlaybackActionPayload(
                    action = PlaybackActions.QUEUE_ADD,
                    trackInfo = track,
                    insertNext = true,
                    queue = s.queue,
                    serverTime = now(),
                    revision = s.revision,
                ),
            )
        if (isMember(suggestion.fromId)) {
            out += Out(listOf(suggestion.fromId), MessageTypes.SUGGESTION_APPROVED, SuggestionApprovedPayload(suggestion.id, track))
        }
    }

    private fun rejectSuggestion(
        from: String,
        p: RejectSuggestionPayload?,
        out: MutableList<Out>,
    ) {
        if (!isHost(from)) return run { out += error(from, "not_host", "Only the host can reject suggestions") }
        val suggestion = s.suggestions.firstOrNull { it.id == p?.suggestionId } ?: return run { out += error(from, "suggestion_not_found", "Suggestion not found") }
        s = s.copy(suggestions = s.suggestions - suggestion)
        if (isMember(suggestion.fromId)) {
            out += Out(listOf(suggestion.fromId), MessageTypes.SUGGESTION_REJECTED, SuggestionRejectedPayload(suggestion.id, p?.reason.orEmpty()))
        }
    }

    // ───────────────────────────── helpers ─────────────────────────────

    private fun isMember(id: String) = s.members.any { it.id == id }

    private fun isHost(id: String) = id == s.hostId && isMember(id)

    private fun others(id: String) = memberIds.filter { it != id }

    private fun error(
        to: String,
        code: String,
        message: String,
    ) = Out(listOf(to), MessageTypes.ERROR, ErrorPayload(code, message))

    private fun approval(id: String) =
        JoinApprovedPayload(
            roomCode = s.roomCode,
            userId = id,
            sessionToken = "",
            state = roomState(),
        )

    private fun roomState() =
        RoomState(
            roomCode = s.roomCode,
            hostId = s.hostId,
            users = s.members.map { UserInfo(it.id, it.name, it.id == s.hostId, it.connected) },
            currentTrack = s.currentTrack,
            isPlaying = s.isPlaying,
            position = livePosition(),
            lastUpdate = now(),
            volume = s.volume,
            queue = s.queue,
            revision = s.revision,
            guestControl = s.guestControl,
        )

    private fun syncState() =
        SyncStatePayload(
            currentTrack = s.currentTrack,
            isPlaying = s.isPlaying,
            position = livePosition(),
            lastUpdate = now(),
            queue = s.queue,
            volume = s.volume,
            revision = s.revision,
            guestControl = s.guestControl,
        )

    private fun livePosition(): Long {
        val position = s.position.coerceAtLeast(0L)
        if (!s.isPlaying || s.lastUpdate <= 0L) return position
        return clamp(position + (now() - s.lastUpdate).coerceAtLeast(0L), s.currentTrack)
    }

    private fun clamp(
        position: Long,
        track: TrackInfo?,
    ): Long {
        val p = position.coerceAtLeast(0L)
        return if (track != null && track.duration > 0 && p > track.duration) track.duration else p
    }

    /** metroserver's compensateActionTransit: at most 5 s of flight time is added back. */
    private fun compensate(
        position: Long,
        capturedAt: Long,
        t: Long,
    ): Long {
        if (capturedAt <= 0L || capturedAt >= t) return position
        return position + (t - capturedAt).coerceAtMost(MAX_TRANSIT_COMPENSATION_MS)
    }

    private fun upcoming(
        queue: List<TrackInfo>,
        currentId: String?,
    ): List<TrackInfo> =
        queue
            .filter { it.id.isNotBlank() && it.title.isNotBlank() && it.id != currentId }
            .distinctBy { it.id }
            .take(MAX_QUEUE)

    companion object {
        const val DISCONNECT_AFTER_MS = 35_000L
        const val SEAT_GRACE_MS = 15 * 60_000L
        const val MAX_MEMBERS = 20
        const val MAX_PENDING = 20
        const val MAX_SUGGESTIONS = 30

        /** Keeps a room's messages well under NIP-44's 64 KiB. */
        const val MAX_QUEUE = 100
        private const val MAX_NAME = 50
        private const val MAX_TRANSIT_COMPENSATION_MS = 5_000L

        private val QUEUE_CARRYING_ACTIONS =
            setOf(
                PlaybackActions.CHANGE_TRACK,
                PlaybackActions.QUEUE_ADD,
                PlaybackActions.QUEUE_REMOVE,
                PlaybackActions.QUEUE_CLEAR,
                PlaybackActions.SYNC_QUEUE,
            )

        /** A new room with [hostId] alone in it, and the answer to its creator. */
        fun create(
            roomCode: String,
            hostId: String,
            hostName: String,
            now: () -> Long,
        ): Pair<RoomHub, Out> {
            val t = now()
            val hub =
                RoomHub(
                    HubSnapshot(
                        roomCode = roomCode,
                        hostId = hostId,
                        members = listOf(HubMember(hostId, hostName.trim().take(MAX_NAME), lastSeen = t)),
                        lastUpdate = t,
                    ),
                    now,
                )
            return hub to Out(listOf(hostId), MessageTypes.ROOM_CREATED, RoomCreatedPayload(roomCode, hostId, ""))
        }

        /**
         * Runs the room from what a guest last saw of it, because the device running it went silent
         * for [silentForMs]. [newHostId] becomes host; the silent one stays a member like any other,
         * shown as away and then gone, and gets its seat back if it returns in time.
         */
        fun claim(
            snapshot: HubSnapshot,
            newHostId: String,
            silentForMs: Long,
            now: () -> Long,
        ): RoomHub {
            val duration = snapshot.currentTrack?.duration ?: 0L
            val advanced = if (snapshot.isPlaying) snapshot.position + silentForMs.coerceAtLeast(0L) else snapshot.position
            return takeOver(
                snapshot.copy(
                    hostId = newHostId,
                    position = if (duration > 0L) advanced.coerceAtMost(duration) else advanced,
                    epoch = snapshot.epoch + 1,
                ),
                now,
            )
        }

        /** Takes over a room another device ran; its times were on that device's clock. */
        fun takeOver(
            snapshot: HubSnapshot,
            now: () -> Long,
        ): RoomHub {
            val t = now()
            return RoomHub(
                snapshot.copy(
                    lastUpdate = t,
                    // Nobody has been heard on THIS clock yet; count everyone as just seen.
                    members = snapshot.members.map { it.copy(lastSeen = t) },
                    pending = snapshot.pending.map { it.copy(lastSeen = t) },
                ),
                now,
            )
        }
    }
}
