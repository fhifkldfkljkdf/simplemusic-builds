package org.simpmusic.listentogether.peer

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Direct device-to-device links on the local network, beside the relays.
 *
 * The device running a room listens on its local addresses; guests that can reach one of them (the
 * same Wi-Fi, the same tailnet) connect straight to it. Exactly the same events travel both ways
 * — signed by their sender and encrypted with the room's key — so a direct link needs no trust of
 * its own and adds no second protocol: [PeerRoomTransport] checks what arrives here the way it
 * checks what a relay delivers, and drops the copy that arrives second. A room keeps working on
 * either path alone: without internet on one Wi-Fi, or across the internet with no shared network.
 */
interface DirectLinks {
    /** Events from direct peers, as the JSON text of a Nostr event; not yet checked. */
    val incoming: SharedFlow<String>

    /** Connected peers: the guests while serving, the host (0 or 1) while dialled in. */
    val peers: StateFlow<Int>

    /** Starts listening, unless already; `ip:port` for each local address, empty if it cannot listen. */
    suspend fun serve(): List<String>

    /** Stops listening. Connected guests still get what was already queued for them. */
    fun stopServing()

    /** Keeps one connection to the first of [endpoints] that answers, re-dialling if it drops. Empty hangs up. */
    fun dial(endpoints: List<String>)

    /** Queues [text] for every connected peer. False when there is none. */
    fun send(text: String): Boolean

    fun release()
}

/** The platform's direct links: sockets on Android and Desktop, none on iOS. */
internal expect fun platformDirectLinks(): DirectLinks

/** For platforms without direct links: a room runs over the relays alone. */
internal object NoDirectLinks : DirectLinks {
    override val incoming: SharedFlow<String> = kotlinx.coroutines.flow.MutableSharedFlow()
    override val peers: StateFlow<Int> = kotlinx.coroutines.flow.MutableStateFlow(0)

    override suspend fun serve(): List<String> = emptyList()

    override fun stopServing() = Unit

    override fun dial(endpoints: List<String>) = Unit

    override fun send(text: String): Boolean = false

    override fun release() = Unit
}
