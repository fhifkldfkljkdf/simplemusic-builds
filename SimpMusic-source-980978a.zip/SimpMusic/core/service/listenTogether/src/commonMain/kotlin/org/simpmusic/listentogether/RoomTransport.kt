package org.simpmusic.listentogether

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * How this device reaches the room right now, for the UI: relays connected (of how many), direct
 * device-to-device links, and the local addresses others can dial while this device hosts.
 */
data class RoomLinks(
    val relays: Int = 0,
    val relaysTotal: Int = 0,
    val direct: Int = 0,
    val directEndpoints: List<String> = emptyList(),
)

/**
 * What [ListenTogetherSession] needs from whatever carries its messages.
 *
 * Two implementations speak the same protocol: [ListenTogetherClient], a WebSocket to a
 * metroserver, and [org.simpmusic.listentogether.peer.PeerRoomTransport], where the host's own device
 * plays the server's part and everyone reaches it through public Nostr relays. The session, the
 * playback bridge and the UI cannot tell them apart, which is the point.
 */
interface RoomTransport {
    val events: SharedFlow<ListenTogetherEvent>

    fun connect()

    fun disconnect()

    /** Forgets the room seat after leaving it on purpose. */
    fun forgetSession()

    /** Stops for good. The instance is unusable afterwards. */
    fun release()

    /** Sends one protocol message; false when it could not go out at all. */
    suspend fun send(
        msgType: String,
        payload: Any? = null,
    ): Boolean

    /** The room's clock now (the server's, or the hosting device's), or null until it is known. */
    fun serverNow(): Long?

    /** Where a track is, given where it was at [effectiveAtServerTime] on the room's clock. */
    fun positionAt(
        position: Long,
        effectiveAtServerTime: Long?,
        isPlaying: Boolean,
    ): Long

    /** How the room is reached right now. A server transport has no such detail to give. */
    val links: StateFlow<RoomLinks> get() = NO_LINKS

    /**
     * Local addresses where the device hosting [roomCode] may be reached directly (from its QR
     * code), tried before the relays when joining. Ignored by transports that have no direct links.
     */
    fun hintDirect(
        roomCode: String,
        endpoints: List<String>,
    ) = Unit

    /** Rooms hosted on this device's network whose hosts let people nearby find them. */
    val nearby: StateFlow<List<NearbyRoom>> get() = NO_NEARBY

    /**
     * Whether a room this device runs shows up for people on the same network. Guests who have the
     * code connect directly either way; this only decides whether the code is announced.
     */
    fun setVisibleNearby(visible: Boolean) = Unit
}

/** A room someone on this network is hosting and lets people nearby find. */
data class NearbyRoom(
    val code: String,
    val hostName: String?,
    val listeners: Int,
)

private val NO_LINKS: StateFlow<RoomLinks> = MutableStateFlow(RoomLinks())
private val NO_NEARBY: StateFlow<List<NearbyRoom>> = MutableStateFlow(emptyList())
