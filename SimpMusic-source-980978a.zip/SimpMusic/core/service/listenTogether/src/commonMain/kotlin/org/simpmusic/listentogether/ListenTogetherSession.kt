package org.simpmusic.listentogether

import com.maxrave.logger.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.cancellation.CancellationException

private const val TAG = "ListenTogetherSession"

/** Where the socket is, independent of whether a room has been joined. */
sealed interface ConnectionState {
    data object Disconnected : ConnectionState

    data object Connecting : ConnectionState

    data class Connected(val serverVersion: String) : ConnectionState

    /** Retries are exhausted or the server refused us; the user has to act. */
    data class Failed(val reason: String) : ConnectionState
}

/** One person in the room, as the UI needs them. */
data class RoomMember(
    val userId: String,
    val username: String,
    val isHost: Boolean,
    val isConnected: Boolean,
    /** True while this member has not answered `buffer_ready` for the current track. */
    val isBuffering: Boolean = false,
)

data class PendingJoin(
    val userId: String,
    val username: String,
)

data class PendingSuggestion(
    val suggestionId: String,
    val fromUsername: String,
    val track: TrackInfo,
)

/** A guest asking the host to play, pause, seek or change the track for everyone (see [MessageTypes.CONTROL]). */
data class ControlRequest(
    val userId: String,
    val username: String,
    val action: PlaybackActionPayload,
)

data class ListenTogetherState(
    val connection: ConnectionState = ConnectionState.Disconnected,
    /** Null until a room is created or joined. */
    val roomCode: String? = null,
    val selfUserId: String = "",
    val isHost: Boolean = false,
    val members: List<RoomMember> = emptyList(),
    val joinRequests: List<PendingJoin> = emptyList(),
    val suggestions: List<PendingSuggestion> = emptyList(),
    val currentTrack: TrackInfo? = null,
    val isPlaying: Boolean = false,
    val position: Long = 0L,
    /**
     * The room's queue, in the host's order.
     *
     * Without this a guest only ever knows the *current* track, so the moment it ends they carry
     * on with whatever their own player had queued — which is everyone listening to something
     * different one track later.
     */
    val queue: List<TrackInfo> = emptyList(),
    /** Non-empty while the room is held at the buffer barrier. */
    val waitingFor: List<String> = emptyList(),
    /** Server time the last transport command was captured at; 0 when unknown. */
    val lastActionServerTime: Long = 0L,
    /**
     * The code we asked to join and have not heard back about.
     *
     * Joining is not immediate — the host has to approve it — and without this the UI has nothing
     * to show between sending `join_room` and `join_approved` arriving, so a wrong code and a host
     * who simply has not looked at their phone are indistinguishable: both look like nothing
     * happened.
     */
    val pendingJoinCode: String? = null,
    /** Set once and cleared by the UI, so a transient failure cannot wedge the screen. */
    val error: String? = null,
    /** The room lets guests play, pause, seek and change the track for everyone. */
    val guestControl: Boolean = false,
) {
    val inRoom: Boolean get() = roomCode != null

    /** Whether this device may control the room's playback: the host always, guests when allowed. */
    val canControl: Boolean get() = inRoom && (isHost || guestControl)
    val isConnected: Boolean get() = connection is ConnectionState.Connected

    /** Names, not ids — "Waiting for Long" is the only useful phrasing of the barrier. */
    val waitingForNames: List<String>
        get() = waitingFor.mapNotNull { id -> members.firstOrNull { it.userId == id }?.username }
}

/**
 * The room state machine.
 *
 * Consumes [RoomTransport.events] and never touches a frame, which is what keeps it
 * testable without a socket and identical on Android and Desktop — the two platforms run entirely
 * separate player handlers, so anything that reached into playback from here would have to be
 * written twice.
 */
class ListenTogetherSession(
    private val client: RoomTransport,
    dispatcher: CoroutineContext = Dispatchers.Default,
) : CoroutineScope {
    override val coroutineContext: CoroutineContext = SupervisorJob() + dispatcher

    private val _state = MutableStateFlow(ListenTogetherState())
    val state: StateFlow<ListenTogetherState> = _state.asStateFlow()

    private var pump: Job? = null

    /**
     * Outgoing messages, sent one at a time in the order they were asked for.
     *
     * Each send used to be a coroutine of its own, so two sent back to back — a track change and
     * then play — could reach the transport the other way round: the room then refused a play with
     * no track, or played the previous one.
     */
    private val outbox = Channel<suspend () -> Unit>(Channel.UNLIMITED)

    init {
        launch {
            for (step in outbox) {
                try {
                    step()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Logger.w(TAG, "Send failed: ${e.message}")
                }
            }
        }
    }

    private fun inOrder(step: suspend () -> Unit) {
        outbox.trySend(step)
    }

    /** Host-side conveniences from settings; both default off, matching the design's toggles. */
    var autoApproveJoins: Boolean = false
    var autoApproveSuggestions: Boolean = false

    /** Whether a room created here starts out letting guests control playback (see [setGuestControl]). */
    var guestControlDefault: Boolean = true

    private val _controlRequests = MutableSharedFlow<ControlRequest>(extraBufferCapacity = 32)

    /** While hosting: what guests ask the host's player to do. The playback bridge carries them out. */
    val controlRequests: SharedFlow<ControlRequest> = _controlRequests.asSharedFlow()

    /** Opens the socket. Joining a room is a separate, later step. Does nothing while connected or connecting. */
    fun connect() {
        if (pump == null) {
            // Undispatched, so the collector is listening before connect() below: a transport may
            // report Connected at once, and a SharedFlow keeps nothing for a late subscriber.
            pump = launch(start = CoroutineStart.UNDISPATCHED) { client.events.collect(::onEvent) }
        }
        // A second connect() used to set Connecting over a live connection. The transport, already
        // started, then reported nothing new, and the screen showed "Connecting" for good with the
        // Create and Join buttons disabled.
        val now = _state.value.connection
        if (now is ConnectionState.Connected || now is ConnectionState.Connecting) return
        _state.update { it.copy(connection = ConnectionState.Connecting, error = null) }
        client.connect()
    }

    fun disconnect() {
        client.disconnect()
        _state.value = ListenTogetherState()
    }

    fun createRoom(username: String) =
        inOrder {
            pendingUsername = username.trim()
            client.send(MessageTypes.CREATE_ROOM, CreateRoomPayload(username = pendingUsername))
        }

    /** How the room is reached right now: relays, direct links (see [RoomTransport.links]). */
    val links: StateFlow<RoomLinks> get() = client.links

    /** Rooms hosted on this network whose hosts let people nearby find them (see [RoomTransport.nearby]). */
    val nearby: StateFlow<List<NearbyRoom>> get() = client.nearby

    /** Whether a room hosted here shows up for people on the same network. */
    fun setVisibleNearby(visible: Boolean) = client.setVisibleNearby(visible)

    /**
     * [directHints]: the host's local addresses, from its QR code, so a guest on the same Wi-Fi goes
     * straight to it — which also works with no internet at all.
     */
    fun joinRoom(
        roomCode: String,
        username: String,
        directHints: List<String> = emptyList(),
    ) = inOrder {
        pendingUsername = username.trim()
        val code = roomCode.trim().uppercase()
        _state.update { it.copy(pendingJoinCode = code, error = null) }
        if (directHints.isNotEmpty()) client.hintDirect(code, directHints)
        val sent = client.send(MessageTypes.JOIN_ROOM, JoinRoomPayload(roomCode = code, username = pendingUsername))
        if (!sent) {
            _state.update { it.copy(pendingJoinCode = null, error = "Not connected") }
        }
    }

    /** Gives up on a join that has not been answered. Local only — the server needs no message. */
    fun cancelJoin() = _state.update { it.copy(pendingJoinCode = null) }

    fun leaveRoom() =
        inOrder {
            client.send(MessageTypes.LEAVE_ROOM, LeaveRoomPayload())
            client.forgetSession()
            // The server sends nothing back for leave_room, so the local state is cleared here —
            // waiting for a confirmation that never arrives would leave the room UI on screen.
            _state.update {
                it.copy(
                    roomCode = null,
                    isHost = false,
                    members = emptyList(),
                    joinRequests = emptyList(),
                    suggestions = emptyList(),
                    currentTrack = null,
                    waitingFor = emptyList(),
                    // The next room starts from nothing of this one.
                    queue = emptyList(),
                    isPlaying = false,
                    position = 0L,
                    lastActionServerTime = 0L,
                    guestControl = false,
                )
            }
        }

    fun approveJoin(userId: String) =
        inOrder {
            client.send(MessageTypes.APPROVE_JOIN, ApproveJoinPayload(userId = userId))
            _state.update { s -> s.copy(joinRequests = s.joinRequests.filterNot { it.userId == userId }) }
        }

    fun rejectJoin(userId: String) =
        inOrder {
            client.send(MessageTypes.REJECT_JOIN, RejectJoinPayload(userId = userId))
            _state.update { s -> s.copy(joinRequests = s.joinRequests.filterNot { it.userId == userId }) }
        }

    fun approveSuggestion(suggestionId: String) =
        inOrder {
            client.send(MessageTypes.APPROVE_SUGGESTION, ApproveSuggestionPayload(suggestionId = suggestionId))
            dropSuggestion(suggestionId)
        }

    fun rejectSuggestion(suggestionId: String) =
        inOrder {
            client.send(MessageTypes.REJECT_SUGGESTION, RejectSuggestionPayload(suggestionId = suggestionId))
            dropSuggestion(suggestionId)
        }

    fun kickUser(userId: String) =
        inOrder { client.send(MessageTypes.KICK_USER, KickUserPayload(userId = userId)) }

    fun transferHost(userId: String) =
        inOrder { client.send(MessageTypes.TRANSFER_HOST, TransferHostPayload(newHostId = userId)) }

    fun suggestTrack(track: TrackInfo) =
        inOrder { client.send(MessageTypes.SUGGEST_TRACK, SuggestTrackPayload(trackInfo = track)) }

    /**
     * Publishes one transport command to the room. Host only — the server ignores it from a guest.
     *
     * `capturedAtServerTime` is what lets a late-arriving PLAY still land on the right position:
     * the receiver advances [position] by however long the frame spent in flight, measured on the
     * SERVER's clock rather than its own. Sending 0 (an uncalibrated clock) is safe — the receiver
     * treats it as "unknown" and uses the raw position.
     */
    fun sendPlaybackAction(
        action: String,
        trackId: String,
        position: Long,
        trackInfo: TrackInfo?,
        queue: List<TrackInfo> = emptyList(),
        queueTitle: String = "",
    ) {
        // Read now, when the position was: a send can wait behind the one before it.
        val capturedAt = client.serverNow() ?: 0L
        inOrder { sendPlayback(action, trackId, position, trackInfo, queue, queueTitle, capturedAt) }
    }

    private suspend fun sendPlayback(
        action: String,
        trackId: String,
        position: Long,
        trackInfo: TrackInfo?,
        queue: List<TrackInfo>,
        queueTitle: String,
        capturedAt: Long,
    ) {
        client.send(
            MessageTypes.PLAYBACK_ACTION,
            PlaybackActionPayload(
                action = action,
                trackId = trackId,
                position = position,
                trackInfo = trackInfo,
                // Carried on the SAME message as the track deliberately. Sent separately they are
                // two independent sends with no ordering guarantee, and a queue arriving after the
                // track means the guest has already committed to a one-track queue — it then plays
                // its own next song and the room splits one track later.
                queue = queue,
                queueTitle = queueTitle,
                capturedAtServerTime = capturedAt,
            ),
        )
    }

    /**
     * Asks the room to play, pause, seek or change the track for everyone. A guest's command; the
     * host's player carries it out and the room follows the host as always. Only sent when the room
     * lets guests control playback (see [ListenTogetherState.canControl]).
     */
    fun sendControl(
        action: String,
        position: Long,
        trackInfo: TrackInfo? = null,
    ) {
        val capturedAt = client.serverNow() ?: 0L
        inOrder {
            client.send(
                MessageTypes.CONTROL,
                PlaybackActionPayload(
                    action = action,
                    position = position,
                    trackInfo = trackInfo,
                    capturedAtServerTime = capturedAt,
                ),
            )
        }
    }

    /** Host only: lets guests control playback for everyone, or stops them. */
    fun setGuestControl(enabled: Boolean) =
        inOrder {
            if (_state.value.isHost) client.send(MessageTypes.SET_ROOM_SETTINGS, RoomSettingsPayload(guestControl = enabled))
        }

    /** Publishes the whole queue. Host only; guests take the host's order verbatim. */
    fun sendQueue(
        tracks: List<TrackInfo>,
        queueTitle: String,
    ) {
        val capturedAt = client.serverNow() ?: 0L
        inOrder {
            client.send(
                MessageTypes.PLAYBACK_ACTION,
                PlaybackActionPayload(
                    action = PlaybackActions.SYNC_QUEUE,
                    queue = tracks,
                    queueTitle = queueTitle,
                    capturedAtServerTime = capturedAt,
                ),
            )
        }
    }

    /** See `ServerClock.positionAt` — corrects a room position for time spent in flight. */
    fun positionAt(
        position: Long,
        isPlaying: Boolean,
    ): Long = client.positionAt(position, _state.value.lastActionServerTime, isPlaying)

    /**
     * Asks the server for the room's current state.
     *
     * This is how a guest rejoins the room's timeline after driving its own transport: the server
     * answers `sync_state` with the live position, so pressing play lands where everyone else
     * actually is rather than where this device happened to stop.
     */
    fun requestSync() =
        inOrder {
            client.send(MessageTypes.REQUEST_SYNC, null)
        }

    /** Answers the buffer barrier for [trackId]; until every member does, nobody hears anything. */
    fun reportBufferReady(trackId: String) =
        inOrder { client.send(MessageTypes.BUFFER_READY, BufferReadyPayload(trackId = trackId)) }

    fun clearError() = _state.update { it.copy(error = null) }

    fun release() {
        client.release()
        pump = null
    }

    private fun dropSuggestion(id: String) =
        _state.update { s -> s.copy(suggestions = s.suggestions.filterNot { it.suggestionId == id }) }

    private fun onEvent(event: ListenTogetherEvent) {
        when (event) {
            is ListenTogetherEvent.Connected ->
                _state.update { it.copy(connection = ConnectionState.Connected(event.serverVersion)) }

            is ListenTogetherEvent.ClockReady -> Unit

            is ListenTogetherEvent.Disconnected ->
                _state.update {
                    if (event.willRetry) {
                        // The room is deliberately KEPT while retrying: the server holds the seat
                        // for 15 minutes and the client resumes it with the session token, so
                        // dropping it here would throw the user out over a blip the server forgives.
                        it.copy(connection = ConnectionState.Connecting)
                    } else {
                        // Losing the socket loses the room with it; leaving the room UI up would
                        // offer controls that silently do nothing.
                        ListenTogetherState(connection = ConnectionState.Failed(event.reason ?: "Disconnected"))
                    }
                }

            // Back online, but the server no longer has our seat. The connection itself is fine,
            // so it stays; only the room goes, with a reason the user can act on.
            is ListenTogetherEvent.SeatLost ->
                _state.update { ListenTogetherState(connection = it.connection, error = event.reason) }

            is ListenTogetherEvent.Message -> onMessage(event.type, event.payload)
        }
    }

    private fun onMessage(
        type: String,
        payload: Any?,
    ) {
        when (type) {
            MessageTypes.ROOM_CREATED -> {
                val p = payload as? RoomCreatedPayload ?: return
                _state.update {
                    it.copy(
                        roomCode = p.roomCode,
                        selfUserId = p.userId,
                        isHost = true,
                        // The server sends no member list for a brand-new room: the host is alone
                        // in it, and USER_JOINED carries everyone who arrives afterwards.
                        members = listOf(RoomMember(p.userId, pendingUsername, isHost = true, isConnected = true)),
                    )
                }
                // A new room lets guests control playback only once told so.
                if (guestControlDefault) {
                    inOrder { client.send(MessageTypes.SET_ROOM_SETTINGS, RoomSettingsPayload(guestControl = true)) }
                }
            }

            MessageTypes.JOIN_APPROVED -> {
                val p = payload as? JoinApprovedPayload ?: return
                // Ask for the current state explicitly: JoinApproved carries whatever the server
                // last heard, which is nothing at all if the host has not issued a command yet.
                inOrder { client.send(MessageTypes.REQUEST_SYNC, null) }
                _state.update {
                    it.copy(
                        roomCode = p.roomCode,
                        selfUserId = p.userId,
                        isHost = false,
                        pendingJoinCode = null,
                        members = p.state?.users.orEmpty().map { u -> u.toMember() },
                        queue = p.state?.queue.orEmpty(),
                        currentTrack = p.state?.currentTrack,
                        isPlaying = p.state?.isPlaying ?: false,
                        position = p.state?.position ?: 0L,
                        guestControl = p.state?.guestControl ?: false,
                    )
                }
            }

            MessageTypes.JOIN_REJECTED ->
                _state.update {
                    it.copy(
                        pendingJoinCode = null,
                        error = (payload as? JoinRejectedPayload)?.reason?.ifBlank { null } ?: "The host declined",
                    )
                }

            MessageTypes.JOIN_REQUEST -> {
                val p = payload as? JoinRequestPayload ?: return
                if (autoApproveJoins) {
                    approveJoin(p.userId)
                    return
                }
                _state.update { s ->
                    if (s.joinRequests.any { it.userId == p.userId }) {
                        s
                    } else {
                        s.copy(joinRequests = s.joinRequests + PendingJoin(p.userId, p.username))
                    }
                }
            }

            MessageTypes.USER_JOINED -> {
                val p = payload as? UserJoinedPayload ?: return
                _state.update { s ->
                    if (s.members.any { it.userId == p.userId }) {
                        s
                    } else {
                        s.copy(members = s.members + RoomMember(p.userId, p.username, isHost = false, isConnected = true))
                    }
                }
            }

            MessageTypes.USER_LEFT -> {
                val p = payload as? UserLeftPayload ?: return
                _state.update { s -> s.copy(members = s.members.filterNot { it.userId == p.userId }) }
            }

            MessageTypes.USER_DISCONNECTED -> {
                val p = payload as? UserDisconnectedPayload ?: return
                _state.update { s -> s.copy(members = s.members.map { if (it.userId == p.userId) it.copy(isConnected = false) else it }) }
            }

            MessageTypes.USER_RECONNECTED -> {
                val p = payload as? UserReconnectedPayload ?: return
                _state.update { s -> s.copy(members = s.members.map { if (it.userId == p.userId) it.copy(isConnected = true) else it }) }
            }

            MessageTypes.HOST_CHANGED -> {
                val p = payload as? HostChangedPayload ?: return
                _state.update { s ->
                    s.copy(
                        isHost = p.newHostId == s.selfUserId,
                        members = s.members.map { it.copy(isHost = it.userId == p.newHostId) },
                    )
                }
            }

            MessageTypes.KICKED ->
                _state.value =
                    ListenTogetherState(
                        connection = _state.value.connection,
                        error = (payload as? KickedPayload)?.reason ?: "Removed from the room",
                    )

            MessageTypes.BUFFER_WAIT -> {
                val p = payload as? BufferWaitPayload ?: return
                _state.update { s ->
                    s.copy(
                        waitingFor = p.waitingFor,
                        members = s.members.map { it.copy(isBuffering = it.userId in p.waitingFor) },
                    )
                }
            }

            MessageTypes.BUFFER_COMPLETE ->
                _state.update { s -> s.copy(waitingFor = emptyList(), members = s.members.map { it.copy(isBuffering = false) }) }

            MessageTypes.RECONNECTED -> {
                val p = payload as? ReconnectedPayload ?: return
                val room = p.state
                Logger.i(TAG, "Resumed room ${p.roomCode} as ${if (p.isHost) "host" else "guest"}")
                _state.update {
                    it.copy(
                        roomCode = p.roomCode.ifBlank { it.roomCode },
                        selfUserId = p.userId.ifBlank { it.selfUserId },
                        isHost = p.isHost,
                        members = room?.users?.map { u -> u.toMember() } ?: it.members,
                        // The server re-sends every request and suggestion still pending right after
                        // this message; anything answered while we were away must not linger.
                        joinRequests = emptyList(),
                        suggestions = emptyList(),
                        currentTrack = room?.currentTrack ?: it.currentTrack,
                        isPlaying = room?.isPlaying ?: it.isPlaying,
                        position = room?.position ?: it.position,
                        queue = room?.queue?.ifEmpty { null } ?: it.queue,
                        // The state is live as of lastUpdate, not as of the last command.
                        lastActionServerTime = room?.lastUpdate ?: it.lastActionServerTime,
                        waitingFor = emptyList(),
                        guestControl = room?.guestControl ?: it.guestControl,
                    )
                }
            }

            MessageTypes.SYNC_STATE -> {
                val p = payload as? SyncStatePayload ?: return
                _state.update {
                    it.copy(
                        currentTrack = p.currentTrack,
                        isPlaying = p.isPlaying,
                        position = p.position,
                        // metroserver computes `position` live at `lastUpdate`. Leaving the time of
                        // the previous command here made positionAt() add the whole gap since then a
                        // second time, so a guest re-syncing landed ahead of the room.
                        lastActionServerTime = p.lastUpdate,
                        // Only replace the queue when the server actually sent one — sync_state
                        // with an empty queue means "nothing to say", not "the queue is empty".
                        queue = p.queue.ifEmpty { it.queue },
                        guestControl = p.guestControl,
                    )
                }
            }

            MessageTypes.SYNC_PLAYBACK, MessageTypes.PLAYBACK_ACTION -> {
                val p = payload as? PlaybackActionPayload ?: return
                // Only these say where the room is. A queue change carries position 0 and either no
                // capture time or a later one, and taking them made every guest jump back to where
                // the last play command was (to 0:00 when the host approved a suggestion) each time
                // the host's queue changed, which endless queue does on its own.
                val movesPlayhead = p.action in PLAYHEAD_ACTIONS
                // The room puts a play (and a seek while playing) at the moment it handled it,
                // [PlaybackActionPayload.serverTime], having added the time in flight already;
                // counting from the sender's capture time added that flight time twice.
                val at =
                    if (p.serverTime > 0L && (p.action == PlaybackActions.PLAY || p.action == PlaybackActions.SEEK)) {
                        p.serverTime
                    } else {
                        p.capturedAtServerTime
                    }
                _state.update {
                    it.copy(
                        currentTrack = p.trackInfo?.takeIf { p.action == PlaybackActions.CHANGE_TRACK } ?: it.currentTrack,
                        isPlaying =
                            when (p.action) {
                                PlaybackActions.PAUSE -> false
                                PlaybackActions.PLAY -> true
                                else -> it.isPlaying
                            },
                        position = if (movesPlayhead) p.position else it.position,
                        queue = p.queue.ifEmpty { it.queue },
                        lastActionServerTime = if (movesPlayhead) at else it.lastActionServerTime,
                    )
                }
            }

            MessageTypes.ROOM_SETTINGS -> {
                val p = payload as? RoomSettingsPayload ?: return
                _state.update { it.copy(guestControl = p.guestControl) }
            }

            MessageTypes.CONTROL_REQUEST -> {
                val p = payload as? ControlRequestPayload ?: return
                val action = p.action ?: return
                if (!_state.value.isHost) return
                _controlRequests.tryEmit(ControlRequest(p.userId, p.username, action))
            }

            MessageTypes.SUGGESTION_RECEIVED -> {
                val p = payload as? SuggestionReceivedPayload ?: return
                val track = p.trackInfo ?: return
                if (autoApproveSuggestions) {
                    approveSuggestion(p.suggestionId)
                    return
                }
                _state.update { s ->
                    if (s.suggestions.any { it.suggestionId == p.suggestionId }) {
                        s
                    } else {
                        s.copy(suggestions = s.suggestions + PendingSuggestion(p.suggestionId, p.fromUsername, track))
                    }
                }
            }

            MessageTypes.ERROR -> {
                val p = payload as? ErrorPayload ?: return
                // `rate_limited` is about one message, not the session, and showing it would put an
                // alarming banner up for something the user cannot act on.
                if (p.code != "rate_limited") {
                    Logger.w(TAG, "Server error ${p.code}: ${p.message}")
                    // An error while waiting to be let in ends that wait — most often a bad code.
                    _state.update {
                        it.copy(pendingJoinCode = null, error = p.message.ifBlank { p.code })
                    }
                }
            }
        }
    }

    /**
     * The name the user typed, kept so ROOM_CREATED can name the host.
     *
     * The server echoes the room code and user id back but not the username it was given, and the
     * host has to appear in their own member list like everyone else.
     */
    private var pendingUsername: String = ""
}

/** Playback actions that say where the room's playhead is; the rest leave it where it was. */
private val PLAYHEAD_ACTIONS =
    setOf(PlaybackActions.PLAY, PlaybackActions.PAUSE, PlaybackActions.SEEK, PlaybackActions.CHANGE_TRACK)

private fun UserInfo.toMember() =
    RoomMember(
        userId = userId,
        username = username,
        isHost = isHost,
        isConnected = isConnected,
    )
