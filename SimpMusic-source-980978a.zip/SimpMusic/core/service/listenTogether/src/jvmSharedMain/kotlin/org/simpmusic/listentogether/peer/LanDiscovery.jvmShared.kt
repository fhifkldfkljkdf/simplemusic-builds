package org.simpmusic.listentogether.peer

import com.maxrave.logger.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import kotlin.coroutines.CoroutineContext
import kotlin.time.TimeSource

private const val TAG = "LanDiscovery"

internal actual fun platformLanDiscovery(): LanDiscovery = SocketLanDiscovery()

/**
 * Keeps the platform passing broadcast packets up to the app while rooms are looked for or
 * announced. Android's Wi-Fi driver drops them otherwise (a `WifiManager.MulticastLock`, set by the
 * app at startup); nothing needs holding on Desktop. Returns what releases it.
 */
object LanDiscoveryPlatform {
    @Volatile
    var holdBroadcastReceive: (() -> (() -> Unit))? = null
}

/**
 * [LanDiscovery] over UDP broadcast on [port]: each announcement goes to every interface's
 * broadcast address (and 255.255.255.255) every [ANNOUNCE_MS]; a room not heard for [FORGET_MS] is
 * gone. [targets] and [port] are for tests on loopback.
 */
internal class SocketLanDiscovery(
    private val port: Int = DISCOVERY_PORT,
    private val targets: () -> List<InetAddress> = ::broadcastAddresses,
) : LanDiscovery,
    CoroutineScope {
    override val coroutineContext: CoroutineContext = SupervisorJob() + Dispatchers.IO

    private val _rooms = MutableStateFlow<List<LanRoom>>(emptyList())
    override val rooms: StateFlow<List<LanRoom>> = _rooms.asStateFlow()

    private val lock = Any()
    private var announcement: LanAnnouncement? = null
    private var announceJob: Job? = null
    private var listenJob: Job? = null
    private var listenSocket: DatagramSocket? = null
    private var release: (() -> Unit)? = null
    private val heard = LinkedHashMap<String, Pair<LanRoom, TimeSource.Monotonic.ValueTimeMark>>()

    override fun announce(announcement: LanAnnouncement?) {
        synchronized(lock) {
            this.announcement = announcement
            if (announcement == null) {
                announceJob?.cancel()
                announceJob = null
            } else if (announceJob == null) {
                announceJob = launch { announceLoop() }
            }
            holdIfNeeded()
        }
    }

    override fun listen(enabled: Boolean) {
        synchronized(lock) {
            if (enabled && listenJob == null) {
                listenJob = launch { listenLoop() }
            } else if (!enabled) {
                listenJob?.cancel()
                listenJob = null
                listenSocket?.close()
                listenSocket = null
                synchronized(heard) { heard.clear() }
                _rooms.value = emptyList()
            }
            holdIfNeeded()
        }
    }

    override fun release() {
        listen(false)
        announce(null)
        cancel()
    }

    /** Called under [lock]. */
    private fun holdIfNeeded() {
        val wanted = announceJob != null || listenJob != null
        if (wanted && release == null) {
            release =
                try {
                    LanDiscoveryPlatform.holdBroadcastReceive?.invoke()
                } catch (e: Exception) {
                    Logger.w(TAG, "Cannot hold broadcast reception: ${e.message}")
                    null
                } ?: {}
        } else if (!wanted && release != null) {
            release?.invoke()
            release = null
        }
    }

    private suspend fun announceLoop() {
        val socket =
            try {
                DatagramSocket().apply { broadcast = true }
            } catch (e: IOException) {
                Logger.w(TAG, "Cannot announce: ${e.message}")
                return
            }
        try {
            while (isActive) {
                val current = synchronized(lock) { announcement } ?: break
                val bytes = LanBeacon.encode(current)
                for (address in targets()) {
                    try {
                        socket.send(DatagramPacket(bytes, bytes.size, address, port))
                    } catch (e: IOException) {
                        // That interface is down or refuses broadcast; the others may not.
                    }
                }
                delay(ANNOUNCE_MS)
            }
        } finally {
            socket.close()
        }
    }

    private suspend fun listenLoop() {
        // Read out here: inside `apply` below, a bare `port` is the unbound socket's own (-1).
        val listenPort = port
        val socket =
            try {
                DatagramSocket(null).apply {
                    // Several apps (or several test devices) may listen on the one port.
                    reuseAddress = true
                    broadcast = true
                    soTimeout = RECEIVE_TIMEOUT_MS
                    bind(InetSocketAddress(listenPort))
                }
            } catch (e: Exception) {
                Logger.w(TAG, "Cannot listen for nearby rooms: ${e.message}")
                return
            }
        synchronized(lock) { listenSocket = socket }
        val buffer = ByteArray(MAX_DATAGRAM)
        try {
            while (isActive && !socket.isClosed) {
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                    LanBeacon.decode(packet.data.copyOf(packet.length), packet.address?.hostAddress)?.let { room ->
                        synchronized(heard) { heard[room.tag] = room to TimeSource.Monotonic.markNow() }
                    }
                } catch (e: SocketTimeoutException) {
                    // Nothing heard this second; fall through to forget stale rooms.
                } catch (e: IOException) {
                    if (socket.isClosed) break
                }
                prune()
            }
        } finally {
            socket.close()
        }
    }

    private fun prune() {
        val fresh =
            synchronized(heard) {
                heard.entries.removeAll { it.value.second.elapsedNow().inWholeMilliseconds > FORGET_MS }
                heard.values.map { it.first }
            }
        if (fresh != _rooms.value) _rooms.value = fresh
    }

    companion object {
        const val DISCOVERY_PORT = 45_797
        private const val ANNOUNCE_MS = 2_000L
        private const val FORGET_MS = 7_000L
        private const val RECEIVE_TIMEOUT_MS = 1_000
        private const val MAX_DATAGRAM = 2_048
    }
}

/** Each up interface's IPv4 broadcast address, then the all-networks one. */
internal fun broadcastAddresses(): List<InetAddress> {
    val perInterface =
        try {
            NetworkInterface
                .getNetworkInterfaces()
                ?.toList()
                .orEmpty()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.interfaceAddresses.mapNotNull { a -> a.broadcast } }
        } catch (e: Exception) {
            emptyList()
        }
    return (perInterface + InetAddress.getByName("255.255.255.255")).distinct()
}
