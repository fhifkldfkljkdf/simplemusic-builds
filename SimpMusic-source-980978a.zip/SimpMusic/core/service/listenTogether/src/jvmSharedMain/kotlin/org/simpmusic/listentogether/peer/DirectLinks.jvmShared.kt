package org.simpmusic.listentogether.peer

import com.maxrave.logger.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.coroutines.CoroutineContext

private const val TAG = "DirectLinks"

internal actual fun platformDirectLinks(): DirectLinks = SocketDirectLinks()

/**
 * [DirectLinks] over plain TCP. Each frame is a 4-byte length and that many bytes of UTF-8 (the
 * JSON of one Nostr event); an empty frame is a heartbeat. Both ends open with [MAGIC], so whatever
 * else on the network wanders onto the port is turned away at once.
 *
 * A connection that hears nothing for [READ_TIMEOUT_MS] is dead — heartbeats go every
 * [HEARTBEAT_MS] — which notices a phone that walked out of Wi-Fi range in seconds rather than the
 * minutes TCP takes by itself.
 */
internal class SocketDirectLinks(
    private val localAddresses: () -> List<String> = ::lanAddresses,
) : DirectLinks,
    CoroutineScope {
    override val coroutineContext: CoroutineContext = SupervisorJob() + Dispatchers.IO

    private val _incoming = MutableSharedFlow<String>(extraBufferCapacity = 512)
    override val incoming: SharedFlow<String> = _incoming.asSharedFlow()

    private val _peers = MutableStateFlow(0)
    override val peers: StateFlow<Int> = _peers.asStateFlow()

    private class Peer(
        val socket: Socket,
        /** A guest that connected to this device, as opposed to the host this device dialled. */
        val inbound: Boolean,
        /** The address this device dialled, for an outbound link. */
        val endpoint: String?,
    ) {
        val outbox = Channel<ByteArray>(OUTBOX_SIZE)
    }

    private val connections = CopyOnWriteArraySet<Peer>()
    private val lock = Any()
    private var server: ServerSocket? = null
    private var dialTarget: List<String> = emptyList()
    private var dialJob: Job? = null

    override suspend fun serve(): List<String> =
        withContext(Dispatchers.IO) {
            val listening =
                synchronized(lock) {
                    server ?: try {
                        ServerSocket(0, BACKLOG).also { socket ->
                            server = socket
                            // On this object's scope: a child of withContext would keep serve() from returning.
                            this@SocketDirectLinks.launch { acceptLoop(socket) }
                        }
                    } catch (e: IOException) {
                        Logger.w(TAG, "Cannot listen for direct links: ${e.message}")
                        null
                    }
                }
            listening?.let { socket -> localAddresses().map { "$it:${socket.localPort}" } }.orEmpty()
        }

    override fun stopServing() {
        synchronized(lock) {
            server?.closeQuietly()
            server = null
        }
        connections.filter { it.inbound }.forEach(::hangUp)
    }

    override fun dial(endpoints: List<String>) {
        synchronized(lock) {
            if (endpoints == dialTarget) return
            dialTarget = endpoints
            // Still one of the host's addresses (the list only grew, or was reordered): keep the
            // link; the loop reads the new list the next time it has to dial.
            if (endpoints.isNotEmpty() && dialJob?.isActive == true && connections.any { !it.inbound && it.endpoint in endpoints }) return
            dialJob?.cancel()
            connections.filter { !it.inbound }.forEach(::hangUp)
            dialJob = if (endpoints.isEmpty()) null else launch { dialLoop() }
        }
    }

    /** Whatever is queued (a hand-over, a goodbye) still goes out; then the line is closed. */
    private fun hangUp(peer: Peer) {
        peer.outbox.close()
        launch {
            delay(DRAIN_MS)
            peer.socket.closeQuietly()
        }
    }

    override fun send(text: String): Boolean {
        val bytes = text.encodeToByteArray()
        if (bytes.size > MAX_FRAME) return false
        var sent = false
        for (peer in connections) if (peer.outbox.trySend(bytes).isSuccess) sent = true
        return sent
    }

    override fun release() {
        synchronized(lock) {
            server?.closeQuietly()
            server = null
            dialTarget = emptyList()
        }
        connections.forEach { it.socket.closeQuietly() }
        cancel()
    }

    private suspend fun acceptLoop(listening: ServerSocket) {
        while (isActive && !listening.isClosed) {
            val socket =
                try {
                    listening.accept()
                } catch (e: IOException) {
                    break
                }
            if (connections.count { it.inbound } >= MAX_PEERS) {
                socket.closeQuietly()
                continue
            }
            launch { run(socket, inbound = true, endpoint = null) }
        }
    }

    /** Dials the first endpoint that answers and stays on it; when it drops, dials again. */
    private suspend fun dialLoop() {
        var failures = 0
        while (isActive) {
            val endpoints = synchronized(lock) { dialTarget }
            if (endpoints.isEmpty()) return
            val answered = endpoints.firstNotNullOfOrNull { endpoint -> connectOrNull(endpoint)?.let { endpoint to it } }
            if (answered != null) {
                failures = 0
                run(answered.second, inbound = false, endpoint = answered.first)
            } else {
                failures++
            }
            delay(redialDelayMs(failures))
        }
    }

    private fun connectOrNull(endpoint: String): Socket? {
        val host = endpoint.substringBeforeLast(':', "")
        val port = endpoint.substringAfterLast(':', "").toIntOrNull() ?: return null
        if (host.isEmpty()) return null
        val socket = Socket()
        return try {
            socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            socket
        } catch (e: IOException) {
            socket.closeQuietly()
            null
        }
    }

    /** One connection, from the greeting until either side hangs up. */
    private suspend fun run(
        socket: Socket,
        inbound: Boolean,
        endpoint: String?,
    ) {
        val peer = Peer(socket, inbound, endpoint)
        try {
            socket.tcpNoDelay = true
            socket.soTimeout = READ_TIMEOUT_MS
            val input = DataInputStream(BufferedInputStream(socket.getInputStream()))
            val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))
            output.write(MAGIC)
            output.flush()
            val greeting = ByteArray(MAGIC.size)
            input.readFully(greeting)
            if (!greeting.contentEquals(MAGIC)) return
            connections += peer
            _peers.value = connections.size
            Logger.i(TAG, "Direct link ${if (inbound) "from" else "to"} ${socket.inetAddress?.hostAddress}")
            coroutineScope {
                val writer =
                    launch {
                        try {
                            for (frame in peer.outbox) {
                                output.writeInt(frame.size)
                                output.write(frame)
                                output.flush()
                            }
                        } catch (e: IOException) {
                            // The reader notices too; nothing else to do here.
                        } finally {
                            // Outbox closed and drained (stopServing), or the line broke: hang up.
                            socket.closeQuietly()
                        }
                    }
                val heartbeat =
                    launch {
                        while (isActive) {
                            delay(HEARTBEAT_MS)
                            peer.outbox.trySend(HEARTBEAT)
                        }
                    }
                try {
                    while (true) {
                        val size = input.readInt()
                        if (size < 0 || size > MAX_FRAME) break
                        if (size == 0) continue
                        val bytes = ByteArray(size)
                        input.readFully(bytes)
                        _incoming.emit(bytes.decodeToString())
                    }
                } catch (e: IOException) {
                    // Closed, timed out, or reset: the connection is over.
                } finally {
                    heartbeat.cancel()
                    writer.cancel()
                }
            }
        } catch (e: IOException) {
            Logger.d(TAG, "Direct link failed: ${e.message}")
        } finally {
            if (connections.remove(peer)) {
                _peers.value = connections.size
                Logger.i(TAG, "Direct link ${if (inbound) "from" else "to"} ${socket.inetAddress?.hostAddress} closed")
            }
            socket.closeQuietly()
        }
    }

    companion object {
        private val MAGIC = "SMLT/1\n".encodeToByteArray()
        private val HEARTBEAT = ByteArray(0)
        private const val MAX_FRAME = 1 shl 20
        private const val HEARTBEAT_MS = 4_000L
        private const val READ_TIMEOUT_MS = 12_000
        private const val CONNECT_TIMEOUT_MS = 1_500
        private const val DRAIN_MS = 2_000L
        private const val BACKLOG = 16
        private const val MAX_PEERS = 32
        private const val OUTBOX_SIZE = 256

        /** 1, 2, 4 s, then every 8 s. */
        private fun redialDelayMs(failures: Int): Long = (1_000L shl failures.coerceIn(0, 3))
    }
}

private fun java.io.Closeable.closeQuietly() {
    try {
        close()
    } catch (e: IOException) {
        // Already closed.
    }
}

/**
 * IPv4 addresses other devices might reach this one on: up, not loopback or link-local, and not a
 * container or hypervisor bridge (those exist only inside this machine). Wi-Fi and Ethernet come
 * first; mobile data is left out, since carriers do not let anyone connect in.
 */
internal fun lanAddresses(): List<String> =
    try {
        NetworkInterface
            .getNetworkInterfaces()
            ?.toList()
            .orEmpty()
            .filter { it.isUp && !it.isLoopback && MACHINE_ONLY.none { prefix -> it.name.startsWith(prefix) } }
            .filter { CELLULAR.none { prefix -> it.name.startsWith(prefix) } }
            .sortedBy { iface -> if (LOCAL_FIRST.any { iface.name.startsWith(it) }) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .filter { !it.isLinkLocalAddress && !it.isLoopbackAddress }
            .mapNotNull { it.hostAddress }
            .distinct()
    } catch (e: Exception) {
        emptyList()
    }

private val MACHINE_ONLY = listOf("docker", "br-", "veth", "virbr", "vboxnet", "vmnet", "podman", "cni")
private val CELLULAR = listOf("rmnet", "ccmni", "pdp", "v4-rmnet", "clat")
private val LOCAL_FIRST = listOf("wlan", "eth", "en", "ap", "swlan")
