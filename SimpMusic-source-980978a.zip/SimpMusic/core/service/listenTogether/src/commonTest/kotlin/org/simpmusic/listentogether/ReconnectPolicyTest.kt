package org.simpmusic.listentogether

import org.simpmusic.listentogether.ReconnectPolicy.Decision.GiveUp
import org.simpmusic.listentogether.ReconnectPolicy.Decision.RetryIn
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ReconnectPolicyTest {
    private fun policy() =
        ReconnectPolicy(
            initialDelayMs = 1_000,
            maxDelayMs = 60_000,
            seatMaxDelayMs = 10_000,
            maxAttempts = 5,
            seatGraceMs = 15 * 60_000L,
        )

    @Test
    fun withoutASeatItGivesUpAfterFiveDoublingAttempts() {
        val p = policy()
        val delays = (1..5).map { (p.next(nowMs = 0, holdingSeat = false) as RetryIn).delayMs }
        assertEquals(listOf(1_000L, 2_000L, 4_000L, 8_000L, 16_000L), delays)
        assertEquals(GiveUp(seatExpired = false), p.next(nowMs = 0, holdingSeat = false))
    }

    @Test
    fun holdingASeatItKeepsTryingForTheWholeGracePeriodAtShortIntervals() {
        val p = policy()
        var now = 0L
        var tries = 0
        while (true) {
            val decision = p.next(now, holdingSeat = true)
            if (decision is GiveUp) {
                assertEquals(GiveUp(seatExpired = true), decision)
                break
            }
            val delay = (decision as RetryIn).delayMs
            assertTrue(delay <= 10_000, "a seat retry waited $delay ms")
            now += delay
            tries++
        }
        // Far beyond the old five attempts, and it only stopped once 15 minutes had passed.
        assertTrue(tries > 80, "only $tries tries")
        assertTrue(now >= 15 * 60_000L)
    }

    @Test
    fun theGracePeriodIsCountedFromTheFirstFailureNotFromTheLastRetry() {
        val p = policy()
        p.next(nowMs = 1_000, holdingSeat = true)
        assertEquals(GiveUp(seatExpired = true), p.next(nowMs = 1_000 + 15 * 60_000L, holdingSeat = true))
    }

    @Test
    fun aCompletedHandshakeRefillsBothBudgets() {
        val p = policy()
        repeat(5) { p.next(nowMs = 0, holdingSeat = false) }
        p.next(nowMs = 0, holdingSeat = true)
        p.reset()
        assertEquals(RetryIn(1_000), p.next(nowMs = 0, holdingSeat = false))
        // A new drop long after the first one starts a fresh 15 minutes.
        assertEquals(RetryIn(2_000), p.next(nowMs = 60 * 60_000L, holdingSeat = true))
    }
}
