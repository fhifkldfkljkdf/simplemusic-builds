package com.maxrave.simpmusic.ui.screen.home

import com.maxrave.simpmusic.ui.theme.appCorner
import com.maxrave.simpmusic.ui.component.ThemedIcon
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.materialkolor.PaletteStyle
import com.materialkolor.rememberDynamicColorScheme
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.simpmusic.expect.ui.isWallpaperDynamicColorSupported
import com.maxrave.simpmusic.expect.ui.platformDynamicColorScheme
import com.maxrave.simpmusic.ui.icon.Check
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.LocalIsDarkTheme
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.amoledColorScheme
import com.maxrave.simpmusic.ui.theme.appleMusicColorScheme
import com.maxrave.simpmusic.ui.theme.brutalColorScheme
import com.maxrave.simpmusic.ui.theme.oceanColorScheme
import com.maxrave.simpmusic.ui.theme.parseThemeColorHex
import com.maxrave.simpmusic.ui.theme.retroColorScheme
import com.maxrave.simpmusic.ui.theme.seed
import com.maxrave.simpmusic.ui.theme.spotifyColorScheme
import com.maxrave.simpmusic.ui.theme.swissColorScheme
import com.maxrave.simpmusic.ui.theme.themeFamily
import com.maxrave.simpmusic.ui.theme.typo
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.app_theme
import simpmusic.composeapp.generated.resources.close
import simpmusic.composeapp.generated.resources.theme_color_amoled
import simpmusic.composeapp.generated.resources.theme_color_apple_music
import simpmusic.composeapp.generated.resources.theme_color_brutalism
import simpmusic.composeapp.generated.resources.theme_color_custom
import simpmusic.composeapp.generated.resources.theme_color_default
import simpmusic.composeapp.generated.resources.theme_color_material_you
import simpmusic.composeapp.generated.resources.theme_color_ocean
import simpmusic.composeapp.generated.resources.theme_color_retro
import simpmusic.composeapp.generated.resources.theme_color_spotify
import simpmusic.composeapp.generated.resources.theme_color_swiss

/**
 * Private copy: the app's theme picker. A swatch grid, not a text list — each card shows the
 * theme's background and its two accents, so the palette can be judged before it is applied.
 * Choosing Custom opens the existing colour picker instead of applying anything.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemePickerDialog(
    selectedTheme: String,
    customColorHex: String,
    accentColorHex: String = "",
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val isDark = LocalIsDarkTheme.current
    val customColor = parseThemeColorHex(customColorHex) ?: seed
    val accentOverride = parseThemeColorHex(accentColorHex)
    // The Default card previews the seeded palette; Material You previews the wallpaper's.
    val defaultScheme =
        rememberDynamicColorScheme(
            seedColor = seed,
            isDark = isDark,
            isAmoled = isDark,
            style = PaletteStyle.TonalSpot,
        )
    val materialYouScheme =
        if (isWallpaperDynamicColorSupported()) {
            platformDynamicColorScheme(isDark)
        } else {
            null
        }
    val choices =
        buildList {
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_DEFAULT,
                    label = stringResource(Res.string.theme_color_default),
                    preview = defaultScheme.preview().withAccent(accentOverride),
                ),
            )
            materialYouScheme?.let {
                add(
                    ThemeChoice(
                        id = DataStoreManager.THEME_COLOR_WALLPAPER,
                        label = stringResource(Res.string.theme_color_material_you),
                        preview = it.preview().withAccent(accentOverride),
                    ),
                )
            }
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_SPOTIFY,
                    label = stringResource(Res.string.theme_color_spotify),
                    preview = spotifyColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_APPLE_MUSIC,
                    label = stringResource(Res.string.theme_color_apple_music),
                    preview = appleMusicColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_OCEAN,
                    label = stringResource(Res.string.theme_color_ocean),
                    preview = oceanColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_AMOLED,
                    label = stringResource(Res.string.theme_color_amoled),
                    preview = amoledColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_RETRO,
                    label = stringResource(Res.string.theme_color_retro),
                    preview = retroColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_SWISS,
                    label = stringResource(Res.string.theme_color_swiss),
                    preview = swissColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_BRUTALISM,
                    label = stringResource(Res.string.theme_color_brutalism),
                    preview = brutalColorScheme(isDark).preview().withAccent(accentOverride),
                ),
            )
            add(
                ThemeChoice(
                    id = DataStoreManager.THEME_COLOR_CUSTOM,
                    label = stringResource(Res.string.theme_color_custom),
                    preview =
                        ThemePreview(
                            background = if (isDark) Color(0xFF121212) else Color(0xFFFAFAFA),
                            accent = accentOverride ?: customColor,
                            secondary = (accentOverride ?: customColor).copy(alpha = 0.45f),
                        ),
                ),
            )
        }
    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth().padding(24.dp),
    ) {
        Surface(
            shape = appCorner(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 6.dp,
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    text = stringResource(Res.string.app_theme),
                    style = typo().titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(14.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.heightIn(max = 420.dp),
                ) {
                    items(choices, key = { it.id }) { choice ->
                        ThemeChoiceCard(
                            choice = choice,
                            selected = choice.id == selectedTheme,
                            onClick = { onSelect(choice.id) },
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(text = stringResource(Res.string.close))
                    }
                }
            }
        }
    }
}

/** The selected theme's label, for the Settings row's subtitle. */
@Composable
fun themeLabel(theme: String): String =
    when (theme) {
        DataStoreManager.THEME_COLOR_SPOTIFY -> stringResource(Res.string.theme_color_spotify)
        DataStoreManager.THEME_COLOR_APPLE_MUSIC -> stringResource(Res.string.theme_color_apple_music)
        DataStoreManager.THEME_COLOR_OCEAN -> stringResource(Res.string.theme_color_ocean)
        DataStoreManager.THEME_COLOR_AMOLED -> stringResource(Res.string.theme_color_amoled)
        DataStoreManager.THEME_COLOR_RETRO -> stringResource(Res.string.theme_color_retro)
        DataStoreManager.THEME_COLOR_SWISS -> stringResource(Res.string.theme_color_swiss)
        DataStoreManager.THEME_COLOR_BRUTALISM -> stringResource(Res.string.theme_color_brutalism)
        DataStoreManager.THEME_COLOR_WALLPAPER -> stringResource(Res.string.theme_color_material_you)
        DataStoreManager.THEME_COLOR_CUSTOM -> stringResource(Res.string.theme_color_custom)
        else -> stringResource(Res.string.theme_color_default)
    }

private data class ThemePreview(
    val background: Color,
    val accent: Color,
    val secondary: Color,
)

private data class ThemeChoice(
    val id: String,
    val label: String,
    val preview: ThemePreview,
)

private fun ColorScheme.preview(): ThemePreview = ThemePreview(background = background, accent = primary, secondary = tertiary)

private fun ThemePreview.withAccent(accent: Color?): ThemePreview =
    if (accent == null) {
        this
    } else {
        copy(accent = accent)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ThemeChoiceCard(
    choice: ThemeChoice,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val isDark = LocalIsDarkTheme.current
    Surface(
        onClick = onClick,
        shape = appCorner(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column(Modifier.padding(8.dp)) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(appCorner(9.dp))
                    .background(choice.preview.background),
            ) {
                ThemePreviewArtwork(
                    preview = choice.preview,
                    family = themeFamily(choice.id),
                    isDark = isDark,
                )
                if (selected) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center,
                    ) {
                        ThemedIcon(
                            imageVector = SimpIcons.Check,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(7.dp))
            Text(
                text = choice.label,
                style = typo().titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * The little swatch inside a picker card. Named themes that change more than colour get a drawing
 * of that change: Swiss a white/black page with a red bar and ink rules, Neo-Brutalism a flat
 * colour block with a thick ink border and a hard offset shadow. Every other theme keeps the two
 * accent dots.
 */
@Composable
private fun BoxScope.ThemePreviewArtwork(
    preview: ThemePreview,
    family: AppThemeFamily,
    isDark: Boolean,
) {
    when (family) {
        AppThemeFamily.SWISS -> {
            val ink = if (preview.background.luminance() > 0.5f) Color(0xFF111111) else Color(0xFFF5F5F5)
            Box(Modifier.fillMaxSize().padding(9.dp)) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth(0.44f)
                        .height(5.dp)
                        .background(preview.accent),
                )
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth(0.64f)
                        .height(3.dp)
                        .background(ink),
                )
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(bottom = 8.dp)
                        .fillMaxWidth(0.42f)
                        .height(3.dp)
                        .background(ink.copy(alpha = 0.5f)),
                )
            }
        }
        AppThemeFamily.BRUTALISM -> {
            val ink = if (isDark) Color(0xFFFAFAFA) else Color(0xFF111111)
            Box(Modifier.fillMaxSize().padding(8.dp)) {
                // The hard shadow: a solid rect four dp down-right, no blur.
                Box(Modifier.matchParentSize().offset(x = 4.dp, y = 4.dp).background(ink))
                Box(Modifier.matchParentSize().border(2.dp, ink).background(preview.accent)) {
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .size(18.dp)
                            .background(preview.secondary),
                    )
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 6.dp, bottom = 7.dp)
                            .fillMaxWidth(0.56f)
                            .height(4.dp)
                            .background(ink),
                    )
                }
            }
        }
        else -> {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(9.dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(preview.accent),
            )
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 31.dp, bottom = 12.dp)
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(preview.secondary),
            )
        }
    }
}
