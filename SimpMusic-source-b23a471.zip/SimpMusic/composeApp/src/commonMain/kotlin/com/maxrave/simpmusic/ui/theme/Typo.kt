package com.maxrave.simpmusic.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import org.jetbrains.compose.resources.Font
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.poppins_medium
import simpmusic.composeapp.generated.resources.space_mono_regular
import simpmusic.composeapp.generated.resources.vt323_regular

@Composable
fun fontFamily(): FontFamily =
    FontFamily(
        Font(Res.font.poppins_medium, FontWeight.Normal, FontStyle.Normal),
    )

/** The Retro Pixel theme's display face: a terminal pixel font, loaded from bundled VT323 (OFL). */
@Composable
fun vt323Family(): FontFamily =
    FontFamily(
        Font(Res.font.vt323_regular, FontWeight.Normal, FontStyle.Normal),
    )

/**
 * Retro's body face: Space Mono (OFL, Vietnamese coverage) — a crisp terminal monospace that keeps
 * list copy modern and readable under VT323's pixel headings.
 */
@Composable
fun spaceMonoFamily(): FontFamily =
    FontFamily(
        Font(Res.font.space_mono_regular, FontWeight.Normal, FontStyle.Normal),
    )

/**
 * When true, [typo] keeps the original always-light text colors (pure white titles, #A8A8A8 body)
 * regardless of theme. Immersive screens drawn over dark artwork provide `true` so their text stays
 * readable at light theme. Everything else leaves it false and gets theme-aware colors.
 */
val LocalForceDarkText = staticCompositionLocalOf { false }

/**
 * The active theme's face, provided by [AppTheme]. Null means the app's default Poppins. Read by
 * [typo], so every screen that builds its own type styles follows the theme — not only Material
 * components that read [MaterialTheme.typography].
 *
 * Retro overrides this with VT323 (the display voice) and adds [LocalAppBodyFontFamily] for body
 * copy, so a theme can pair two faces instead of forcing one everywhere.
 */
val LocalAppFontFamily = staticCompositionLocalOf<FontFamily?> { null }

/** Body face paired with [LocalAppFontFamily]; null means body uses the same face. */
val LocalAppBodyFontFamily = staticCompositionLocalOf<FontFamily?> { null }

/** Extra size multiplier for themes whose face has a small x-height (Retro's VT323). */
val LocalAppFontScale = staticCompositionLocalOf { 1f }

/**
 * Extra type treatment layered over the theme's face: Swiss tightens tracking and lifts heading
 * weights, Neo-Brutalism goes to Black. [DEFAULT] leaves every style exactly as it was.
 */
enum class AppTypeStyle { DEFAULT, SWISS, BRUTAL }

/**
 * Provided by [AppTheme]; [typo] reads it when it is not passed a style explicitly (the
 * Material typography is built before the provider exists, so AppTheme passes its style in).
 */
val LocalAppTypeStyle = staticCompositionLocalOf { AppTypeStyle.DEFAULT }

@Composable
fun typo(
    colorScheme: ColorScheme = MaterialTheme.colorScheme,
    forceDark: Boolean = LocalForceDarkText.current,
    // AppTheme passes its theme's face explicitly (the locals are not provided yet at that point);
    // every other caller reads the locals.
    familyOverride: FontFamily? = null,
    bodyFamilyOverride: FontFamily? = null,
    scale: Float = 1f,
    typeStyleOverride: AppTypeStyle? = null,
): Typography {
    val fontFamily = familyOverride ?: LocalAppFontFamily.current ?: fontFamily()
    val bodyFamily = bodyFamilyOverride ?: LocalAppBodyFontFamily.current ?: fontFamily
    val fontScale = if (familyOverride != null) scale else LocalAppFontScale.current
    val typeStyle = typeStyleOverride ?: LocalAppTypeStyle.current

    // Titles were pure white, everything else muted gray (#A8A8A8) in the old dark-only palette.
    // forceDark keeps that; otherwise both come from the scheme (theme-aware light/dark).
    val titleColor = if (forceDark) Color.White else colorScheme.onBackground
    val bodyColor = if (forceDark) Color(0xFFA8A8A8) else colorScheme.onSurfaceVariant

    val typo =
        Typography(
            /***
             * This typo().is use for the title of the Playlist, Artist, Song, Album, etc. in Home, Mood, Genre, Playlist, etc.
             */
            titleSmall =
                TextStyle(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = fontFamily,
                    color = titleColor,
                ),
            titleMedium =
                TextStyle(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = fontFamily,
                    color = titleColor,
                ),
            titleLarge =
                TextStyle(
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = fontFamily,
                    color = titleColor,
                ),
            bodySmall =
                TextStyle(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            bodyMedium =
                TextStyle(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            bodyLarge =
                TextStyle(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            displayLarge =
                TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            headlineMedium =
                TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            headlineLarge =
                TextStyle(
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            labelMedium =
                TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            labelSmall =
                TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = fontFamily,
                    color = bodyColor,
                ),
            // ...
        )
    // Retro's two faces need their own size ramp and no synthetic bold. Its scale is the only one
    // that is not 1f (AppTheme provides 1.1f for VT323), so this branch stays Retro-only.
    val measured =
        if (fontScale != 1f) {
            retroTypography(typo, fontFamily, bodyFamily)
        } else {
            typo
        }
    return when (typeStyle) {
        AppTypeStyle.SWISS -> measured.swissTypography()
        AppTypeStyle.BRUTAL -> measured.brutalTypography()
        AppTypeStyle.DEFAULT -> measured
    }
}

/**
 * Swiss: type does the hierarchy, so headings get heavier and larger while the tracking tightens.
 * Body copy stays at the base sizes and weight; a Swiss page is calm under a strong heading.
 */
private fun Typography.swissTypography(): Typography =
    copy(
        displayLarge = displayLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp),
        headlineLarge =
            headlineLarge.copy(
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.7).sp,
            ),
        headlineMedium = headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
        titleLarge =
            titleLarge.copy(
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
            ),
        titleMedium = titleMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
        titleSmall = titleSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.1).sp),
        labelLarge = labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp),
        labelMedium = labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp),
        labelSmall = labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp),
    )

/**
 * Neo-Brutalism: a heavy display voice — Black headings, ExtraBold supporting titles, Medium
 * body copy — with near-neutral tracking so the blocky frames, not loose letters, carry the style.
 */
private fun Typography.brutalTypography(): Typography =
    copy(
        displayLarge = displayLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.2).sp),
        headlineLarge =
            headlineLarge.copy(
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.2).sp,
            ),
        headlineMedium = headlineMedium.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.1).sp),
        titleLarge =
            titleLarge.copy(
                fontSize = 27.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.2).sp,
            ),
        titleMedium = titleMedium.copy(fontSize = 19.sp, fontWeight = FontWeight.ExtraBold),
        titleSmall = titleSmall.copy(fontWeight = FontWeight.Bold),
        bodyLarge = bodyLarge.copy(fontWeight = FontWeight.Medium),
        bodyMedium = bodyMedium.copy(fontWeight = FontWeight.Medium),
        labelLarge = labelLarge.copy(fontWeight = FontWeight.Black, letterSpacing = 0.4.sp),
        labelMedium = labelMedium.copy(fontWeight = FontWeight.Black, letterSpacing = 0.2.sp),
        labelSmall = labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp),
    )
