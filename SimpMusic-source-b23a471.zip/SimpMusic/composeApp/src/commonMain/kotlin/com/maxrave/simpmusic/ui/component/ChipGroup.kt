package com.maxrave.simpmusic.ui.component

import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LocalMinimumInteractiveComponentSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import com.maxrave.simpmusic.ui.theme.AppChipStyle
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppChipStyle
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily
import com.maxrave.simpmusic.ui.theme.brutalFrame
import com.maxrave.simpmusic.ui.theme.pixelFrame

@Composable
fun Chip(
    isAnimated: Boolean = false,
    isSelected: Boolean = false,
    text: String,
    onClick: () -> Unit,
) {
    // Private copy: some themes fill their filter pills (Spotify, Apple Music, Ocean, Brutalism)
    // and some also square them (AMOLED, Retro, Swiss, Brutalism); Swiss fills only when selected,
    // with the ink colour instead of its red accent. The rest keep the transparent/outline look.
    val chipStyle = LocalAppChipStyle.current
    val chipShape = LocalAppShapes.current.chip
    val swiss = chipStyle == AppChipStyle.SWISS
    val brutal = chipStyle == AppChipStyle.BRUTAL
    val filled = chipStyle == AppChipStyle.FILLED || chipStyle == AppChipStyle.SQUARE || brutal
    val retro = LocalAppThemeFamily.current == AppThemeFamily.RETRO
    val chipContent: @Composable () -> Unit = {
        InfiniteBorderAnimationView(
            // Retro and Brutalism use hard offsets, not a slowly rotating gradient frame.
            isAnimated = isAnimated && isSelected && !retro && !brutal,
            brush = Brush.sweepGradient(listOf(Color.Gray, Color.White)),
            backgroundColor = Color.Transparent,
            contentPadding = 0.dp,
            borderWidth = if (retro || brutal) 0.dp else 1.dp,
            shape = chipShape,
            oneCircleDurationMillis = 2500,
        ) {
            CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides Dp.Unspecified) {
                ElevatedFilterChip(
                    shape = chipShape,
                    // No shadow. An unselected chip has no fill, and a drop shadow under a see-through
                    // shape shows THROUGH it as a dark ring instead of sitting behind it. Naming
                    // `elevation` alone is enough: pressed, focused and hovered all default to it.
                    elevation = FilterChipDefaults.elevatedFilterChipElevation(elevation = 0.dp),
                    colors =
                        FilterChipDefaults.elevatedFilterChipColors(
                            // Unselected chips have no fill in the default theme. They mostly sit over
                            // artwork (Home) where a solid pill reads as a slab punched over the image;
                            // the outline below is what carries the shape there. Filled themes instead
                            // give both states a surface, like their own apps do.
                            containerColor =
                                if (filled) {
                                    MaterialTheme.colorScheme.surfaceVariant
                                } else {
                                    Color.Transparent
                                },
                            // Swiss selection is the ink, not the red accent: a black (light) or
                            // white (dark) block with the opposite on-colour label.
                            selectedContainerColor =
                                if (swiss) {
                                    MaterialTheme.colorScheme.onSurface
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                            labelColor =
                                if (filled) {
                                    MaterialTheme.colorScheme.onSurface
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            // `primary` is a pale #B2C5FF on the dark theme, so the label has to be its
                            // matching `on` token — a hand-picked white would read on one theme and
                            // vanish on the other. Swiss reuses onPrimary for the same reason.
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                    onClick = { onClick.invoke() },
                    label = {
                        Text(text, maxLines = 1)
                    },
                    border =
                        when {
                            // Retro: a 1dp hard edge on both states, then the pixel shadow outside.
                            retro ->
                                FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    selectedBorderColor = MaterialTheme.colorScheme.primary,
                                    borderColor = MaterialTheme.colorScheme.outline,
                                    borderWidth = 1.dp,
                                )
                            // Neo-Brutalism: the thick ink edge is part of the style, both states.
                            brutal ->
                                FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    selectedBorderColor = MaterialTheme.colorScheme.outline,
                                    borderColor = MaterialTheme.colorScheme.outline,
                                    borderWidth = 2.dp,
                                )
                            // Swiss: a 1dp hairline, heavier only because it is the ink when selected.
                            swiss ->
                                FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    selectedBorderColor = MaterialTheme.colorScheme.onSurface,
                                    borderColor = MaterialTheme.colorScheme.outlineVariant,
                                    borderWidth = 1.dp,
                                )
                            filled -> null
                            else ->
                                FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    selectedBorderColor = Color.Transparent,
                                    // outlineVariant, per M3's Aug 2024 chip update: a softer stroke than outline.
                                    borderColor = MaterialTheme.colorScheme.outlineVariant,
                                )
                        },
                    // No check icon. A solid `primary` fill against a fully transparent unselected chip
                    // is already the strongest contrast available, so a second signal adds nothing — and
                    // it cost real usability: the icon made the selected chip ~26dp wider than itself, so
                    // every tap reflowed the rest of the scrolling row sideways under the finger that had
                    // just tapped it. Material ships the tick because its own default selected fill
                    // (`secondaryContainer`) is too faint to stand alone; that is not the case here.
                    // Selection also survives without colour vision, being filled-versus-empty rather
                    // than one hue against another.
                    selected = isSelected,
                )
            }
        }
    }
    if (retro) {
        Box(
            Modifier.pixelFrame(
                selected = isSelected,
                // A selected chip is already filled with primary, so the tick marks are drawn in
                // its on-colour: primary-on-primary would disappear into the fill.
                bracketColor =
                    if (isSelected) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        null
                    },
            ),
        ) {
            chipContent()
        }
    } else if (brutal) {
        Box(Modifier.brutalFrame(selected = isSelected)) {
            chipContent()
        }
    } else {
        chipContent()
    }
}