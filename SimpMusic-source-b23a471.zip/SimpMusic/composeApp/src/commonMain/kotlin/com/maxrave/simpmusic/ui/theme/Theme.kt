package com.maxrave.simpmusic.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.RippleConfiguration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.roundToInt
import com.materialkolor.PaletteStyle
import com.materialkolor.rememberDynamicColorScheme
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.simpmusic.expect.ui.SystemBarAppearanceEffect
import com.maxrave.simpmusic.expect.ui.platformDynamicColorScheme

/**
 * Semantic colors that sit outside the Material 3 ColorScheme.
 * Read them via [LocalAppColors] inside composables.
 */
@Immutable
data class AppColors(
    val favorite: Color,
    val lyricActive: Color,
    val shimmerBackground: Color,
    val shimmerLine: Color,
    val overlay: Color,
    val overlayHeavy: Color,
)

private val DarkAppColors =
    AppColors(
        favorite = favoriteColor,
        lyricActive = lyricActiveColor,
        shimmerBackground = shimmerBackground,
        shimmerLine = shimmerLine,
        overlay = overlay,
        overlayHeavy = blackMoreOverlay,
    )

// Overlays stay dark in both themes: they cover artwork, where content is always light.
private val LightAppColors =
    DarkAppColors.copy(
        shimmerBackground = shimmerBackgroundLight,
        shimmerLine = shimmerLineLight,
    )

val LocalAppColors = staticCompositionLocalOf { DarkAppColors }

/** True in dark theme. Provided by [AppTheme] so platform glass (blur/tint) can adapt reliably. */
val LocalIsDarkTheme = staticCompositionLocalOf { true }

/**
 * Whether liquid-glass surfaces may actually draw glass.
 *
 * Provided by [AppTheme] from the user's setting; the default is true so previews and anything
 * composed outside [AppTheme] keep today's look. The setting row is Android-only, so Desktop always
 * provides true — its capsule player and detail-screen buttons are glass by design, with no switch.
 */
val LocalLiquidGlassEnabled = staticCompositionLocalOf { true }

/**
 * The dark scheme to use for immersive screens while the app itself is on the light theme.
 * Provided by [AppTheme], consumed by [ForceDarkContent]; null only outside of [AppTheme].
 */
val LocalForcedDarkColorScheme = staticCompositionLocalOf<ColorScheme?> { null }

/** Parses "RRGGBB" or "AARRGGBB" (optionally "#"-prefixed) into a [Color]; null if malformed. */
fun parseThemeColorHex(hex: String): Color? {
    val clean = hex.trim().removePrefix("#")
    val argb =
        when (clean.length) {
            6 -> "FF$clean"
            8 -> clean
            else -> return null
        }
    return argb.toLongOrNull(16)?.let { Color(it) }
}

/**
 * Neutral surfaces for the light theme, on a pure neutral-grey ramp (R=G=B, no seed tint);
 * primary/secondary/tertiary stay seed-derived. The page background is #FAFAFA (neutral tone 98,
 * the Material 3 stance) rather than pure white: a full-bleed #FFFFFF expanse glares on a large
 * desktop window, and even Apple — who pins systemBackground to white — puts #F2F2F7 behind
 * list pages. Pure white is kept for surfaceBright/surfaceContainerLowest so cards and sheets
 * still have a brighter-than-page tier to lift onto. Dark stays pure-black AMOLED: black does
 * not glare and saves OLED.
 */
private fun ColorScheme.withNeutralLightSurfaces(): ColorScheme =
    copy(
        background = Color(0xFFFAFAFA),
        onBackground = Color(0xFF1B1B1B),
        surface = Color(0xFFFAFAFA),
        onSurface = Color(0xFF1B1B1B),
        surfaceVariant = Color(0xFFE2E2E2),
        onSurfaceVariant = Color(0xFF474747),
        surfaceTint = primary,
        surfaceBright = Color(0xFFFFFFFF),
        surfaceDim = Color(0xFFDADADA),
        surfaceContainerLowest = Color(0xFFFFFFFF),
        surfaceContainerLow = Color(0xFFF7F7F7),
        surfaceContainer = Color(0xFFF1F1F1),
        surfaceContainerHigh = Color(0xFFECECEC),
        surfaceContainerHighest = Color(0xFFE6E6E6),
        outline = Color(0xFF777777),
        outlineVariant = Color(0xFFC7C7C7),
        inverseSurface = Color(0xFF303030),
        inverseOnSurface = Color(0xFFF1F1F1),
    )

@OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppTheme(
    themeMode: String = DataStoreManager.THEME_MODE_DARK,
    themeColorSource: String = DataStoreManager.THEME_COLOR_DEFAULT,
    customThemeColor: Color? = null,
    accentColor: Color? = null,
    liquidGlassEnabled: Boolean = true,
    content:
        @Composable()
        () -> Unit,
) {
    // Private copy: the named app themes (Spotify, Apple Music, Ocean, AMOLED Black, Retro Pixel)
    // replace the seeded palette and the wallpaper/custom seeds with their own, in both modes.
    val family = themeFamily(themeColorSource)
    val spotifyTheme = family == AppThemeFamily.SPOTIFY
    val isDark = isDarkTheme(themeMode)
    val wallpaperScheme =
        if (themeColorSource == DataStoreManager.THEME_COLOR_WALLPAPER) {
            platformDynamicColorScheme(isDark)
        } else {
            null
        }
    val seedColor =
        if (themeColorSource == DataStoreManager.THEME_COLOR_CUSTOM) {
            customThemeColor ?: seed
        } else {
            seed
        }
    // Symmetric base: dark pins background/surface to pure black via isAmoled; light pins them to
    // pure white with a neutral-grey ramp (the seed otherwise tints the light neutrals warm/cream).
    val colorScheme =
        when (family) {
            AppThemeFamily.SPOTIFY ->
                spotifyColorScheme(isDark)
            AppThemeFamily.APPLE_MUSIC ->
                appleMusicColorScheme(isDark)
            AppThemeFamily.OCEAN ->
                oceanColorScheme(isDark)
            AppThemeFamily.AMOLED ->
                amoledColorScheme(isDark)
            AppThemeFamily.RETRO ->
                retroColorScheme(isDark)
            AppThemeFamily.SWISS ->
                swissColorScheme(isDark)
            AppThemeFamily.BRUTALISM ->
                brutalColorScheme(isDark)
            else ->
                wallpaperScheme
                    ?: rememberDynamicColorScheme(
                        seedColor = seedColor,
                        isDark = isDark,
                        isAmoled = isDark,
                        style = PaletteStyle.TonalSpot,
                        modifyColorScheme = { cs -> if (isDark) cs else cs.withNeutralLightSurfaces() },
                    )
        }
    // Immersive screens stay dark even at light theme (see [ForceDarkContent]). Resolve their scheme
    // once here instead of letting every such subtree build a palette of its own.
    val forcedDarkScheme =
        when (family) {
            AppThemeFamily.SPOTIFY ->
                spotifyColorScheme(true)
            AppThemeFamily.APPLE_MUSIC ->
                appleMusicColorScheme(true)
            AppThemeFamily.OCEAN ->
                oceanColorScheme(true)
            AppThemeFamily.AMOLED ->
                amoledColorScheme(true)
            AppThemeFamily.RETRO ->
                retroColorScheme(true)
            AppThemeFamily.SWISS ->
                swissColorScheme(true)
            AppThemeFamily.BRUTALISM ->
                brutalColorScheme(true)
            else ->
                if (isDark) {
                    colorScheme
                } else {
                    rememberDynamicColorScheme(
                        seedColor = seedColor,
                        isDark = true,
                        isAmoled = true,
                        style = PaletteStyle.TonalSpot,
                    )
                }
        }
    // Private copy: an accent chosen independently of the theme replaces the accent roles only;
    // background, surfaces and the theme's own typography/shapes stay put.
    val accentScheme =
        accentColor?.let {
            rememberDynamicColorScheme(
                seedColor = it,
                isDark = isDark,
                isAmoled = isDark,
                style = PaletteStyle.TonalSpot,
            )
        }
    val accentDarkScheme =
        accentColor?.let {
            if (isDark) {
                accentScheme
            } else {
                rememberDynamicColorScheme(
                    seedColor = it,
                    isDark = true,
                    isAmoled = true,
                    style = PaletteStyle.TonalSpot,
                )
            }
        }
    val resolvedScheme = colorScheme.withAccent(accentScheme)
    val resolvedForcedDarkScheme = forcedDarkScheme.withAccent(accentDarkScheme)
    // Spotify's heart is green and its active lyric line is the reading colour, not yellow.
    // Retro's shimmer comes from its own palette instead of the neutral greys: a grey sweep over
    // neon-green surfaces read as a hole in the theme.
    val appColors =
        when {
            spotifyTheme ->
                (if (isDark) DarkAppColors else LightAppColors).copy(
                    favorite = SpotifyGreen,
                    lyricActive = if (isDark) Color.White else Color(0xFF121212),
                )
            family == AppThemeFamily.RETRO ->
                (if (isDark) DarkAppColors else LightAppColors).copy(
                    shimmerBackground = if (isDark) Color(0x3322C55E) else Color(0xFFE9E0CC),
                    shimmerLine = if (isDark) Color(0xFF1F4A33) else Color(0xFFC7EBCF),
                )
            isDark ->
                DarkAppColors
            else ->
                LightAppColors
        }
    val shapes =
        when (family) {
            AppThemeFamily.SPOTIFY -> SpotifyShapes
            AppThemeFamily.APPLE_MUSIC -> AppleShapes
            AppThemeFamily.OCEAN -> OceanShapes
            AppThemeFamily.AMOLED -> AmoledShapes
            AppThemeFamily.RETRO -> RetroShapes
            AppThemeFamily.SWISS -> SwissShapes
            AppThemeFamily.BRUTALISM -> BrutalShapes
            else -> MaterialTheme.shapes
        }
    val typographyFamily =
        when (family) {
            AppThemeFamily.APPLE_MUSIC, AppThemeFamily.OCEAN, AppThemeFamily.AMOLED,
            AppThemeFamily.SWISS, AppThemeFamily.BRUTALISM -> FontFamily.SansSerif
            AppThemeFamily.RETRO -> vt323Family()
            else -> null
        }
    // Swiss tightens its headings and Neo-Brutalism goes Black; both stay on the system sans.
    val typeStyle =
        when (family) {
            AppThemeFamily.SWISS -> AppTypeStyle.SWISS
            AppThemeFamily.BRUTALISM -> AppTypeStyle.BRUTAL
            else -> AppTypeStyle.DEFAULT
        }
    // Retro pairs the pixel display face with Space Mono body copy; every other theme has one face.
    val bodyTypographyFamily = if (family == AppThemeFamily.RETRO) spaceMonoFamily() else null
    val typographyScale = if (family == AppThemeFamily.RETRO) 1.1f else 1f
    val baseTypography =
        typo(
            colorScheme = resolvedScheme,
            familyOverride = typographyFamily,
            bodyFamilyOverride = bodyTypographyFamily,
            scale = typographyScale,
            typeStyleOverride = typeStyle,
        )
    SystemBarAppearanceEffect(isDark)
    MaterialExpressiveTheme(
        colorScheme = resolvedScheme,
        shapes = shapes,
        content = {
            CompositionLocalProvider(
                LocalRippleConfiguration provides
                    if (family == AppThemeFamily.RETRO) {
                        RetroRippleConfiguration
                    } else {
                        SoftRippleConfiguration
                    },
                LocalContentColor provides resolvedScheme.onSurfaceVariant,
                LocalAppColors provides appColors,
                LocalSpotifyTheme provides spotifyTheme,
                LocalAppThemeFamily provides family,
                LocalAppShapes provides appShapesFor(family),
                LocalAppChipStyle provides chipStyleFor(family),
                LocalAppFontFamily provides typographyFamily,
                LocalAppBodyFontFamily provides bodyTypographyFamily,
                LocalAppFontScale provides typographyScale,
                LocalAppTypeStyle provides typeStyle,
                LocalIsDarkTheme provides isDark,
                LocalForcedDarkColorScheme provides resolvedForcedDarkScheme,
                LocalLiquidGlassEnabled provides liquidGlassEnabled,
            ) {
                // Retro Pixel no longer lays a scanline grid over the whole app: it covered album
                // artwork and body text. Screens opt in on a header/hero surface instead, via
                // Modifier.retroScanlines(), so the texture stays where it reads as a CRT frame.
                content()
            }
        },
        typography = baseTypography,
    )
}

/**
 * Retro Pixel's CRT texture, for a header/hero surface only — never over artwork or body copy.
 *
 * Draws behind the modifier's own content (so a transparent app bar's labels stay crisp) but above
 * whatever sits below it, which is what makes it read as a screen bezel rather than a filter on the
 * whole page. One 1dp line every 3dp at 4.5% (dark) or 3% (light) is texture you notice only when
 * you look for it, and it leaves text contrast untouched.
 */
@Composable
fun Modifier.retroScanlines(
    spacing: Dp = 3.dp,
    alpha: Float? = null,
): Modifier {
    val dark = LocalIsDarkTheme.current
    val color =
        MaterialTheme.colorScheme.onBackground.copy(
            alpha = alpha ?: if (dark) 0.045f else 0.03f,
        )
    return retroScanlines(color, spacing)
}

/**
 * The scanline layer itself: offsets are precomputed in a draw cache, so a frame costs a list walk
 * and some drawLine calls rather than recomputing the whole grid.
 */
private fun Modifier.retroScanlines(
    color: Color,
    spacing: Dp,
): Modifier =
    drawWithCache {
        val step = spacing.toPx()
        val thickness = 1.dp.toPx()
        val offsets = ArrayList<Float>()
        var y = 0f
        while (y < size.height) {
            offsets.add(y)
            y += step
        }
        onDrawBehind {
            for (line in offsets) {
                drawLine(
                    color = color,
                    start = androidx.compose.ui.geometry.Offset(0f, line),
                    end = androidx.compose.ui.geometry.Offset(size.width, line),
                    strokeWidth = thickness,
                )
            }
        }
    }

/**
 * Retro Pixel's dithered ground: a 2×2 ordered-dither checker of hard pixels, drawn behind the
 * modifier's own content so it never sits on artwork or text.
 *
 * One dot is one unit (whole device pixels, about 2dp) and the tile repeats, so a full screen costs
 * a single GPU-tiled shader rather than thousands of drawRect calls. It is intentionally faint —
 * 6% on the dark palette, 5% on the cream one — so it reads as texture, not as noise, and leaves
 * text contrast untouched. Other themes return the modifier untouched.
 */
@Composable
fun Modifier.retroDither(
    alpha: Float? = null,
    cell: Dp = 2.dp,
): Modifier {
    if (LocalAppThemeFamily.current != AppThemeFamily.RETRO) return this
    val dark = LocalIsDarkTheme.current
    val dot =
        MaterialTheme.colorScheme.onBackground.copy(
            alpha = alpha ?: if (dark) 0.06f else 0.05f,
        )
    val cellPx = with(androidx.compose.ui.platform.LocalDensity.current) { cell.toPx() }
    return drawWithCache {
        // One device pixel is the smallest hard unit; 2dp at 2.75× is 6px. The bitmap holds a
        // 2×2 cell tile with the two dots of a checker, then repeats through an ImageShader.
        val unit = cellPx.roundToInt().coerceAtLeast(2)
        val tileSize = unit * 2
        val tile = ImageBitmap(tileSize, tileSize)
        CanvasDrawScope().draw(
            density = Density(1f),
            layoutDirection = LayoutDirection.Ltr,
            canvas = Canvas(tile),
            size = Size(tileSize.toFloat(), tileSize.toFloat()),
        ) {
            drawRect(dot, Offset(0f, 0f), Size(unit.toFloat(), unit.toFloat()))
            drawRect(
                dot,
                Offset(unit.toFloat(), unit.toFloat()),
                Size(unit.toFloat(), unit.toFloat()),
            )
        }
        val shader = ShaderBrush(ImageShader(tile, TileMode.Repeated, TileMode.Repeated))
        onDrawBehind { drawRect(shader) }
    }
}

/**
 * A quieter ripple than the Material default, applied app-wide.
 *
 * Material 3's own alphas are tuned for light surfaces; on the near-black background this app
 * uses they read as a grey flash rather than a touch response. Each value is roughly 40% of
 * the default — enough to register the touch, not enough to wash the surface.
 *
 * The colour is left unspecified on purpose, so the ripple keeps deriving from LocalContentColor
 * and stays correct inside [ForceDarkContent] subtrees, which run a different scheme.
 *
 * This reaches bare `Modifier.clickable` too, not just Material components: MaterialTheme
 * already provides `material3.ripple()` as LocalIndication, and that is the one indication that
 * reads this configuration. Nothing extra has to be provided for it.
 *
 * The (color, rippleAlpha) constructor is deprecated in favour of one that also takes a `focus`,
 * but that three-argument version is internal to material3, and the two public replacements —
 * (color) and (focus, color) — drop rippleAlpha entirely. Adjusting ripple alpha therefore has
 * no non-deprecated path in this version, so the warning is suppressed rather than designed
 * around. Revisit once material3 opens up the full constructor.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Suppress("DEPRECATION")
private val SoftRippleConfiguration =
    RippleConfiguration(
        // Colour is deliberately left alone. Ripple derives it from LocalContentColor, which is
        // light on the dark theme and dark on the light one — always contrasting with what it
        // covers. Pinning a dark grey here instead made the ripple paint *darker* than the black
        // surface underneath, so a tap read as a sooty smudge rather than a highlight.
        // Alpha is the only lever that softens without changing which way the contrast runs.
        rippleAlpha =
            RippleAlpha(
                draggedAlpha = 0.06f,
                focusedAlpha = 0.04f,
                hoveredAlpha = 0.03f,
                pressedAlpha = 0.04f,
            ),
    )

/**
 * Retro's touch response: the faint neutral ripple disappears on the neon surfaces, and the style
 * brief asks for an immediate, visible state change. Alphas are high enough to see, still under a
 * fifth of the surface.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Suppress("DEPRECATION")
private val RetroRippleConfiguration =
    RippleConfiguration(
        rippleAlpha =
            RippleAlpha(
                draggedAlpha = 0.18f,
                focusedAlpha = 0.22f,
                hoveredAlpha = 0.12f,
                pressedAlpha = 0.16f,
            ),
    )

/**
 * Wraps immersive screens — artist, album, playlist, local playlist, podcast and the players — which
 * always draw over dark artwork and must therefore render dark even on the light theme.
 *
 * [LocalForceDarkText] alone is not enough: it only recolors text through [typo]. Icons, buttons and
 * every other Material default read [LocalContentColor] and [MaterialTheme.colorScheme], which at
 * light theme resolve to dark-on-light and turn grey and unreadable over the artwork. Providing the
 * dark scheme here fixes the whole subtree in one place.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun ForceDarkContent(content: @Composable () -> Unit) {
    val darkScheme = LocalForcedDarkColorScheme.current ?: MaterialTheme.colorScheme
    // The theme's face and scale are inherited from AppTheme's locals, so immersive screens keep
    // the theme's typography without rebuilding the mapping here.
    val darkTypography = typo(darkScheme, forceDark = true)
    MaterialExpressiveTheme(
        colorScheme = darkScheme,
        // Carry the active shapes through, so a theme's corners survive on the immersive screens.
        shapes = MaterialTheme.shapes,
        content = {
            CompositionLocalProvider(
                LocalForceDarkText provides true,
                LocalIsDarkTheme provides true,
                LocalContentColor provides darkScheme.onSurfaceVariant,
                LocalAppColors provides DarkAppColors,
                content = content,
            )
        },
        typography = darkTypography,
    )
}

/**
 * Replaces only the accent roles of [this] with [accent]'s. Backgrounds, surfaces and neutrals stay
 * with the selected theme, so an accent override cannot wash out its palette.
 */
private fun ColorScheme.withAccent(accent: ColorScheme?): ColorScheme =
    if (accent == null) {
        this
    } else {
        copy(
            primary = accent.primary,
            onPrimary = accent.onPrimary,
            primaryContainer = accent.primaryContainer,
            onPrimaryContainer = accent.onPrimaryContainer,
            inversePrimary = accent.inversePrimary,
            secondary = accent.secondary,
            onSecondary = accent.onSecondary,
            secondaryContainer = accent.secondaryContainer,
            onSecondaryContainer = accent.onSecondaryContainer,
            tertiary = accent.tertiary,
            onTertiary = accent.onTertiary,
            tertiaryContainer = accent.tertiaryContainer,
            onTertiaryContainer = accent.onTertiaryContainer,
            surfaceTint = accent.primary,
        )
    }

/**
 * Resolves the stored theme mode to a plain boolean.
 *
 * Pulled out of [AppTheme] so chrome living *outside* it can ask the same question — the desktop
 * title bar is drawn before AppTheme is entered, so it has no MaterialTheme to read and would
 * otherwise need its own copy of this `when`.
 */
@Composable
fun isDarkTheme(themeMode: String): Boolean =
    when (themeMode) {
        DataStoreManager.THEME_MODE_LIGHT -> false
        DataStoreManager.THEME_MODE_SYSTEM -> isSystemInDarkTheme()
        else -> true
    }
