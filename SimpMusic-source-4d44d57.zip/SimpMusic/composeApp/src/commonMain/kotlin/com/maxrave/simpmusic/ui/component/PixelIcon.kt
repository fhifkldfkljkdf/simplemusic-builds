package com.maxrave.simpmusic.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily

/**
 * Retro Pixel's icons are rasterised into this grid and then drawn with no smoothing.
 * 16×16 keeps details such as play arrows and queue lines recognisable while still reading as
 * pixel art; the old 12×12 grid lost too much and left soft, anti-aliased edge pixels.
 */
private const val PIXEL_GRID = 16

/** The vector is rendered this many times larger, then reduced to hard on/off pixels. */
private const val SAMPLE_SCALE = 4
private const val SAMPLE_GRID = PIXEL_GRID * SAMPLE_SCALE

/**
 * A cell becomes a solid pixel when this much of it was covered by the vector. Anything less is
 * dropped, which removes the grey anti-aliased fringe that made the old icons look blurry.
 */
private const val PIXEL_COVERAGE = 0.3f

/**
 * Private copy: every icon under the Retro Pixel theme is drawn as a coarse pixel grid instead of
 * a smooth vector, the way an 8-bit icon set would look. Other themes get the normal Material icon.
 * The pixel grid is cached per vector; tinting and scaling stay at draw time.
 */
@Composable
fun ThemedIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    if (LocalAppThemeFamily.current == AppThemeFamily.RETRO) {
        PixelIcon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    } else {
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    }
}

@Composable
private fun PixelIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier,
    tint: Color,
) {
    val painter = rememberVectorPainter(imageVector)
    val pixelated = remember(imageVector, painter) { pixelate(painter) }
    // Material's Icon only applies its 24dp default when the caller gave no size of its own.
    val defaultSize = if (modifier == Modifier) Modifier.size(24.dp) else Modifier
    Image(
        bitmap = pixelated,
        contentDescription = contentDescription,
        modifier = modifier.then(defaultSize),
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.tint(tint),
        filterQuality = FilterQuality.None,
    )
}

/**
 * Render the vector large, measure how much of each grid cell it covers, and paint a fresh bitmap
 * with fully opaque or fully transparent pixels. The result has no soft edges for the upscaler to
 * smear, so an icon stays crisp at every size.
 */
private fun pixelate(painter: Painter): ImageBitmap {
    val sample = ImageBitmap(SAMPLE_GRID, SAMPLE_GRID)
    CanvasDrawScope().draw(
        density = Density(1f),
        layoutDirection = LayoutDirection.Ltr,
        canvas = Canvas(sample),
        size = Size(SAMPLE_GRID.toFloat(), SAMPLE_GRID.toFloat()),
    ) {
        with(painter) {
            draw(Size(SAMPLE_GRID.toFloat(), SAMPLE_GRID.toFloat()))
        }
    }
    val source = sample.toPixelMap()
    val cell = SAMPLE_GRID / PIXEL_GRID
    val pixels = ImageBitmap(PIXEL_GRID, PIXEL_GRID)
    CanvasDrawScope().draw(
        density = Density(1f),
        layoutDirection = LayoutDirection.Ltr,
        canvas = Canvas(pixels),
        size = Size(PIXEL_GRID.toFloat(), PIXEL_GRID.toFloat()),
    ) {
        for (y in 0 until PIXEL_GRID) {
            for (x in 0 until PIXEL_GRID) {
                var alpha = 0f
                for (sampleY in 0 until cell) {
                    for (sampleX in 0 until cell) {
                        alpha += source[x * cell + sampleX, y * cell + sampleY].alpha
                    }
                }
                alpha /= (cell * cell).toFloat()
                if (alpha >= PIXEL_COVERAGE) {
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(x.toFloat(), y.toFloat()),
                        size = Size(1f, 1f),
                    )
                }
            }
        }
    }
    return pixels
}
