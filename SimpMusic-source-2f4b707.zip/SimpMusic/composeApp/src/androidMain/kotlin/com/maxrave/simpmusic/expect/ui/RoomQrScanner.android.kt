package com.maxrave.simpmusic.expect.ui

import com.maxrave.simpmusic.ui.component.ThemedIcon
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.maxrave.simpmusic.extension.findActivity
import com.maxrave.simpmusic.ui.component.QrScanner
import com.maxrave.simpmusic.ui.component.rememberSurfaceDarkColors
import com.maxrave.simpmusic.ui.icon.Close
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.seed
import com.maxrave.simpmusic.ui.theme.typo
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.cancel
import simpmusic.composeapp.generated.resources.login_sync_allow_camera
import simpmusic.composeapp.generated.resources.login_sync_open_settings
import simpmusic.composeapp.generated.resources.lt_camera_blocked
import simpmusic.composeapp.generated.resources.lt_camera_needed
import simpmusic.composeapp.generated.resources.lt_no_camera
import simpmusic.composeapp.generated.resources.lt_scan_hint
import simpmusic.composeapp.generated.resources.lt_scan_not_a_room
import simpmusic.composeapp.generated.resources.lt_scan_qr

private enum class CameraState { SCANNING, NEEDS_PERMISSION, BLOCKED, NO_CAMERA }

/**
 * The same sheet, camera flow and viewfinder as "Send sign-ins to desktop" (LoginSync.android.kt), cut
 * down to one job: read a room code. The permission states are identical — ask, and once denied
 * with "don't ask again", send the user to Settings and re-check on the way back.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
actual fun RoomQrScannerSheet(
    onScanned: (String) -> Boolean,
    onDismiss: () -> Unit,
    title: String?,
    hint: String?,
    rejectedHint: String?,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val colors = rememberSurfaceDarkColors()

    fun hasCamera() = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    var state by remember { mutableStateOf(if (hasCamera()) CameraState.SCANNING else CameraState.NEEDS_PERMISSION) }
    // The camera reports the same code on every frame; remembering the last one keeps a wrong code
    // from being judged — and the hint from flickering — thirty times a second.
    var lastRejected by remember { mutableStateOf<String?>(null) }
    // Frames keep arriving while the sheet animates away; one accepted code must mean one join.
    var accepted by remember { mutableStateOf(false) }

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            // Rationale is false after a denial only when the system will not ask again.
            val blocked = !granted && !context.findActivity().shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
            state =
                when {
                    granted -> CameraState.SCANNING
                    blocked -> CameraState.BLOCKED
                    else -> CameraState.NEEDS_PERMISSION
                }
        }
    // Back from the system settings page with the camera now allowed.
    LifecycleResumeEffect(state) {
        if (state == CameraState.BLOCKED && hasCamera()) state = CameraState.SCANNING
        onPauseOrDispose { }
    }

    fun close() {
        scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.Transparent,
        contentColor = Color.Transparent,
        dragHandle = null,
        scrimColor = Color.Black.copy(alpha = .5f),
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) },
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors().copy(containerColor = colors.container),
        ) {
            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .navigationBarsPadding()
                        .padding(bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier
                        .width(60.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(colors.handle),
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = title ?: stringResource(Res.string.lt_scan_qr),
                        style = typo().titleMedium,
                        color = colors.content,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = ::close) {
                        ThemedIcon(imageVector = SimpIcons.Close, contentDescription = stringResource(Res.string.cancel), tint = colors.content)
                    }
                }
                Text(
                    text =
                        if (lastRejected != null) {
                            rejectedHint ?: stringResource(Res.string.lt_scan_not_a_room)
                        } else {
                            hint ?: stringResource(Res.string.lt_scan_hint)
                        },
                    style = typo().bodySmall,
                    color = colors.subtitle,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                )
                Spacer(Modifier.height(20.dp))
                Box(
                    modifier =
                        Modifier
                            .padding(horizontal = 24.dp)
                            .widthIn(max = 340.dp)
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(if (state == CameraState.SCANNING) Color.Black else colors.disabled.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) {
                    when (state) {
                        CameraState.SCANNING -> {
                            QrScanner(
                                onResult = { text ->
                                    if (!accepted && text != lastRejected) {
                                        if (onScanned(text)) {
                                            accepted = true
                                            close()
                                        } else {
                                            lastRejected = text
                                        }
                                    }
                                },
                                onCameraUnavailable = { state = CameraState.NO_CAMERA },
                                modifier = Modifier.fillMaxSize(),
                            )
                            ViewfinderCorners(Modifier.fillMaxSize().padding(20.dp))
                        }

                        CameraState.NEEDS_PERMISSION -> {
                            Status(stringResource(Res.string.lt_camera_needed)) {
                                SheetButton(stringResource(Res.string.login_sync_allow_camera)) {
                                    permissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            }
                        }

                        CameraState.BLOCKED -> {
                            Status(stringResource(Res.string.lt_camera_blocked)) {
                                SheetButton(stringResource(Res.string.login_sync_open_settings)) { context.openAppSettings() }
                            }
                        }

                        CameraState.NO_CAMERA -> {
                            Status(stringResource(Res.string.lt_no_camera))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Status(
    text: String,
    action: (@Composable () -> Unit)? = null,
) {
    Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = text,
            style = typo().bodyMedium,
            color = rememberSurfaceDarkColors().content,
            textAlign = TextAlign.Center,
        )
        action?.invoke()
    }
}

@Composable
private fun SheetButton(
    text: String,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = seed),
    ) {
        Text(
            text = text,
            style = typo().labelSmall,
            color = rememberSurfaceDarkColors().content,
            modifier = Modifier.padding(vertical = 4.dp),
        )
    }
}

/** Four corner brackets marking where the code should sit. */
@Composable
private fun ViewfinderCorners(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val arm = size.minDimension * 0.14f
        val stroke = 4.dp.toPx()
        val corners =
            listOf(
                Offset(0f, 0f) to Offset(1f, 1f),
                Offset(size.width, 0f) to Offset(-1f, 1f),
                Offset(0f, size.height) to Offset(1f, -1f),
                Offset(size.width, size.height) to Offset(-1f, -1f),
            )
        corners.forEach { (corner, direction) ->
            drawLine(Color.White, corner, corner + Offset(direction.x * arm, 0f), stroke, StrokeCap.Round)
            drawLine(Color.White, corner, corner + Offset(0f, direction.y * arm), stroke, StrokeCap.Round)
        }
    }
}
