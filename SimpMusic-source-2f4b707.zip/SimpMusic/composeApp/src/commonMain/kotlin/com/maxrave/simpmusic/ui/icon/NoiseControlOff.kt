package com.maxrave.simpmusic.ui.icon

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

@Suppress("CheckReturnValue")
val SimpIcons.NoiseControlOff: ImageVector
  get() {
    if (_NoiseControlOff != null) {
      return _NoiseControlOff!!
    }
    _NoiseControlOff =
      ImageVector.Builder(
          name = "NoiseControlOff",
          defaultWidth = 24.dp,
          defaultHeight = 24.dp,
          viewportWidth = 24f,
          viewportHeight = 24f,
        )
        .apply {
          path(
            fill = SolidColor(Color.Black),
            fillAlpha = 1f,
            stroke = null,
            strokeAlpha = 1f,
            strokeLineWidth = 1f,
            strokeLineCap = StrokeCap.Butt,
            strokeLineJoin = StrokeJoin.Bevel,
            strokeLineMiter = 1f,
            pathFillType = PathFillType.Companion.NonZero,
          ) {
            moveTo(9.75f, 21.76f)
            quadTo(8.75f, 21.53f, 7.83f, 21.1f)
            quadTo(7.43f, 20.9f, 7.28f, 20.49f)
            reflectiveQuadTo(7.33f, 19.7f)
            reflectiveQuadTo(7.95f, 19.24f)
            reflectiveQuadToRelative(0.83f, 0.09f)
            quadToRelative(0.75f, 0.32f, 1.55f, 0.5f)
            reflectiveQuadTo(12f, 20f)
            reflectiveQuadToRelative(1.68f, -0.18f)
            reflectiveQuadToRelative(1.55f, -0.5f)
            quadToRelative(0.4f, -0.18f, 0.82f, -0.09f)
            reflectiveQuadToRelative(0.63f, 0.46f)
            reflectiveQuadToRelative(0.05f, 0.79f)
            reflectiveQuadTo(16.18f, 21.1f)
            quadToRelative(-0.93f, 0.42f, -1.93f, 0.66f)
            reflectiveQuadTo(12f, 22f)
            reflectiveQuadTo(9.75f, 21.76f)
            close()
            moveTo(4.18f, 13.68f)
            quadToRelative(0.18f, 0.8f, 0.5f, 1.55f)
            quadToRelative(0.18f, 0.4f, 0.09f, 0.83f)
            reflectiveQuadTo(4.3f, 16.68f)
            reflectiveQuadTo(3.51f, 16.73f)
            reflectiveQuadTo(2.9f, 16.18f)
            quadTo(2.48f, 15.25f, 2.24f, 14.25f)
            reflectiveQuadTo(2f, 12f)
            reflectiveQuadTo(2.24f, 9.75f)
            reflectiveQuadTo(2.9f, 7.82f)
            quadTo(3.1f, 7.43f, 3.51f, 7.27f)
            quadTo(3.93f, 7.13f, 4.3f, 7.32f)
            quadToRelative(0.38f, 0.2f, 0.46f, 0.63f)
            reflectiveQuadTo(4.68f, 8.77f)
            quadTo(4.35f, 9.52f, 4.18f, 10.33f)
            reflectiveQuadTo(4f, 12f)
            reflectiveQuadToRelative(0.17f, 1.67f)
            close()
            moveTo(20f, 12f)
            quadToRelative(0f, -0.88f, -0.17f, -1.68f)
            reflectiveQuadTo(19.33f, 8.77f)
            quadTo(19.15f, 8.38f, 19.24f, 7.95f)
            reflectiveQuadTo(19.7f, 7.32f)
            reflectiveQuadTo(20.49f, 7.27f)
            quadTo(20.9f, 7.43f, 21.1f, 7.82f)
            quadToRelative(0.43f, 0.93f, 0.66f, 1.93f)
            reflectiveQuadTo(22f, 12f)
            reflectiveQuadToRelative(-0.24f, 2.25f)
            reflectiveQuadTo(21.1f, 16.18f)
            quadToRelative(-0.2f, 0.4f, -0.61f, 0.55f)
            reflectiveQuadTo(19.7f, 16.68f)
            reflectiveQuadTo(19.24f, 16.05f)
            reflectiveQuadToRelative(0.09f, -0.83f)
            quadToRelative(0.32f, -0.75f, 0.5f, -1.55f)
            quadTo(20f, 12.88f, 20f, 12f)
            close()
            moveTo(12f, 4f)
            quadTo(11.13f, 4f, 10.33f, 4.17f)
            reflectiveQuadTo(8.78f, 4.67f)
            quadTo(8.38f, 4.85f, 7.95f, 4.76f)
            quadTo(7.53f, 4.67f, 7.33f, 4.3f)
            reflectiveQuadTo(7.28f, 3.51f)
            reflectiveQuadTo(7.83f, 2.9f)
            quadTo(8.75f, 2.47f, 9.75f, 2.24f)
            reflectiveQuadTo(12f, 2f)
            reflectiveQuadToRelative(2.25f, 0.24f)
            reflectiveQuadTo(16.18f, 2.9f)
            quadToRelative(0.4f, 0.2f, 0.55f, 0.61f)
            quadTo(16.88f, 3.92f, 16.68f, 4.3f)
            reflectiveQuadTo(16.05f, 4.76f)
            reflectiveQuadTo(15.23f, 4.67f)
            quadTo(14.48f, 4.35f, 13.68f, 4.17f)
            reflectiveQuadTo(12f, 4f)
            close()
            moveToRelative(0.98f, 14f)
            quadTo(12f, 18f, 11.23f, 17.4f)
            reflectiveQuadTo(10.1f, 15.85f)
            quadTo(10.03f, 15.65f, 9.94f, 15.46f)
            reflectiveQuadTo(9.7f, 15.13f)
            lineTo(8.45f, 13.85f)
            quadTo(7.8f, 13.2f, 7.4f, 12.35f)
            reflectiveQuadTo(7f, 10.55f)
            quadTo(7f, 8.67f, 8.31f, 7.34f)
            reflectiveQuadTo(11.5f, 6f)
            quadToRelative(1.3f, 0f, 2.39f, 0.69f)
            reflectiveQuadToRelative(1.66f, 1.86f)
            quadToRelative(0.25f, 0.5f, -0.04f, 0.97f)
            reflectiveQuadTo(14.65f, 10f)
            quadToRelative(-0.3f, 0f, -0.54f, -0.16f)
            reflectiveQuadTo(13.75f, 9.4f)
            quadTo(13.43f, 8.75f, 12.83f, 8.38f)
            reflectiveQuadTo(11.5f, 8f)
            quadTo(10.45f, 8f, 9.73f, 8.73f)
            reflectiveQuadTo(9f, 10.5f)
            quadToRelative(0f, 0.52f, 0.19f, 1f)
            reflectiveQuadToRelative(0.56f, 0.85f)
            lineToRelative(1.38f, 1.35f)
            quadToRelative(0.35f, 0.35f, 0.56f, 0.76f)
            reflectiveQuadToRelative(0.36f, 0.86f)
            quadToRelative(0.13f, 0.3f, 0.38f, 0.49f)
            reflectiveQuadTo(13f, 16f)
            quadToRelative(0.28f, 0f, 0.51f, -0.14f)
            quadToRelative(0.24f, -0.14f, 0.36f, -0.39f)
            quadTo(14f, 15.25f, 14.23f, 15.13f)
            reflectiveQuadTo(14.73f, 15f)
            quadToRelative(0.57f, 0f, 0.88f, 0.47f)
            reflectiveQuadToRelative(0.02f, 0.97f)
            quadToRelative(-0.4f, 0.73f, -1.11f, 1.14f)
            reflectiveQuadTo(12.98f, 18f)
            close()
            moveToRelative(1.59f, -4.44f)
            quadTo(15f, 13.13f, 15f, 12.5f)
            reflectiveQuadTo(14.56f, 11.44f)
            reflectiveQuadTo(13.5f, 11f)
            reflectiveQuadToRelative(-1.06f, 0.44f)
            reflectiveQuadTo(12f, 12.5f)
            reflectiveQuadToRelative(0.44f, 1.06f)
            reflectiveQuadTo(13.5f, 14f)
            reflectiveQuadToRelative(1.06f, -0.44f)
            close()
          }
        }
        .buildSimpIcon()
    return _NoiseControlOff!!
  }

private var _NoiseControlOff: ImageVector? = null
