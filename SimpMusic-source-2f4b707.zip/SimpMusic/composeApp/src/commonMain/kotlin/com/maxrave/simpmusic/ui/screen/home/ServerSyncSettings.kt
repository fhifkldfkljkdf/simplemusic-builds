package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maxrave.domain.data.model.serversync.ServerSyncState
import com.maxrave.domain.repository.ServerSyncRepository
import com.maxrave.simpmusic.expect.ui.RoomQrScannerSheet
import com.maxrave.simpmusic.ui.component.SettingGroup
import com.maxrave.simpmusic.ui.component.SettingItem
import kotlinx.coroutines.launch
import kotlinx.datetime.Instant
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.server_sync
import simpmusic.composeapp.generated.resources.server_sync_cancel
import simpmusic.composeapp.generated.resources.server_sync_error
import simpmusic.composeapp.generated.resources.server_sync_last
import simpmusic.composeapp.generated.resources.server_sync_never
import simpmusic.composeapp.generated.resources.server_sync_not_paired
import simpmusic.composeapp.generated.resources.server_sync_now
import simpmusic.composeapp.generated.resources.server_sync_pair
import simpmusic.composeapp.generated.resources.server_sync_pair_action
import simpmusic.composeapp.generated.resources.server_sync_pair_subtitle
import simpmusic.composeapp.generated.resources.server_sync_pair_title
import simpmusic.composeapp.generated.resources.server_sync_paired_to
import simpmusic.composeapp.generated.resources.server_sync_scan_hint
import simpmusic.composeapp.generated.resources.server_sync_scan_not_a_code
import simpmusic.composeapp.generated.resources.server_sync_scan_qr
import simpmusic.composeapp.generated.resources.server_sync_status
import simpmusic.composeapp.generated.resources.server_sync_syncing
import simpmusic.composeapp.generated.resources.server_sync_token
import simpmusic.composeapp.generated.resources.server_sync_token_hint
import simpmusic.composeapp.generated.resources.server_sync_unpair
import simpmusic.composeapp.generated.resources.server_sync_url
import simpmusic.composeapp.generated.resources.server_sync_url_hint

/**
 * Settings → "Web server sync".
 *
 * Pairing is either the web UI's QR code (`simpmusic://server-sync?u=…&t=…`, read by the same
 * scanner Listen Together and Friends use) or a typed address and token. The status line is the
 * repository's own state, so a background sync updates it without this screen doing anything.
 */
@Composable
fun ServerSyncSettingsGroup(
    repository: ServerSyncRepository = koinInject(),
    openPairing: Boolean = false,
) {
    val state by repository.state.collectAsStateWithLifecycle()
    var pairing by rememberSaveable { mutableStateOf(openPairing) }
    var scanning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(openPairing) { if (openPairing) pairing = true }

    SettingGroup(title = stringResource(Res.string.server_sync)) {
        SettingItem(
            title = stringResource(Res.string.server_sync_pair),
            subtitle =
                if (state.paired) {
                    stringResource(Res.string.server_sync_paired_to, state.serverUrl.orEmpty())
                } else {
                    stringResource(Res.string.server_sync_pair_subtitle)
                },
            onClick = { pairing = true },
        )
        SettingItem(
            title = stringResource(Res.string.server_sync_status),
            subtitle = statusText(state),
        )
        SettingItem(
            title =
                if (state.syncing) {
                    stringResource(Res.string.server_sync_syncing)
                } else {
                    stringResource(Res.string.server_sync_now)
                },
            subtitle = state.serverName ?: state.serverUrl.orEmpty(),
            isEnable = state.paired && !state.syncing,
            onClick = { scope.launch { repository.syncNow() } },
        )
        if (state.paired) {
            SettingItem(
                title = stringResource(Res.string.server_sync_unpair),
                subtitle = stringResource(Res.string.server_sync_not_paired),
                onClick = { scope.launch { repository.unpair() } },
            )
        }
    }

    if (pairing) {
        ServerSyncPairingDialog(
            initialUrl = state.serverUrl.orEmpty(),
            onScan = { scanning = true },
            onDismiss = { pairing = false },
            onPair = { url, token ->
                scope.launch {
                    repository.pair(url, token)
                    pairing = false
                }
            },
        )
    }

    if (scanning) {
        RoomQrScannerSheet(
            onScanned = { text ->
                val code = parseServerSyncLink(text)
                if (code == null) {
                    false
                } else {
                    scanning = false
                    scope.launch {
                        repository.pair(code.first, code.second).onSuccess { pairing = false }
                    }
                    true
                }
            },
            onDismiss = { scanning = false },
            title = stringResource(Res.string.server_sync_scan_qr),
            hint = stringResource(Res.string.server_sync_scan_hint),
            rejectedHint = stringResource(Res.string.server_sync_scan_not_a_code),
        )
    }
}

@Composable
private fun statusText(state: ServerSyncState): String {
    val error = state.error
    if (error != null) return stringResource(Res.string.server_sync_error, error)
    val last = state.lastSyncAt ?: return stringResource(Res.string.server_sync_never)
    return stringResource(Res.string.server_sync_last, formatSyncTime(last))
}

@Composable
private fun ServerSyncPairingDialog(
    initialUrl: String,
    onScan: () -> Unit,
    onDismiss: () -> Unit,
    onPair: (String, String) -> Unit,
) {
    var url by rememberSaveable { mutableStateOf(initialUrl) }
    var token by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(Res.string.server_sync_pair_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text(stringResource(Res.string.server_sync_url)) },
                    placeholder = { Text(stringResource(Res.string.server_sync_url_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it },
                    label = { Text(stringResource(Res.string.server_sync_token)) },
                    placeholder = { Text(stringResource(Res.string.server_sync_token_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = onScan,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                ) { Text(stringResource(Res.string.server_sync_scan_qr)) }
            }
        },
        confirmButton = {
            TextButton(onClick = { onPair(url, token) }) {
                Text(stringResource(Res.string.server_sync_pair_action))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(Res.string.server_sync_cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
    )
}

/** `simpmusic://server-sync?u=<base url>&t=<token>`, from the web UI's QR code. */
fun parseServerSyncLink(text: String): Pair<String, String>? {
    if (!text.contains("server-sync", ignoreCase = true)) return null
    val query = text.substringAfter('?', "")
    if (query.isEmpty()) return null
    val params =
        query.split('&').mapNotNull { part ->
            val key = part.substringBefore('=', "")
            if (key != "u" && key != "t") return@mapNotNull null
            key to decodeQuery(part.substringAfter('=', ""))
        }.toMap()
    val url = params["u"]?.takeIf { it.isNotBlank() } ?: return null
    val token = params["t"]?.takeIf { it.isNotBlank() } ?: return null
    return url to token
}

/** Percent-decoding only; a `+` is left alone because tokens may legitimately contain one. */
private fun decodeQuery(value: String): String =
    buildString {
        var i = 0
        while (i < value.length) {
            val c = value[i]
            if (c == '%' && i + 2 < value.length) {
                val code = value.substring(i + 1, i + 3).toIntOrNull(16)
                if (code != null) {
                    append(code.toChar())
                    i += 3
                    continue
                }
            }
            append(c)
            i++
        }
    }

private fun formatSyncTime(epochMillis: Long): String {
    val dt = Instant.fromEpochMilliseconds(epochMillis).toLocalDateTime(TimeZone.currentSystemDefault())
    fun two(n: Int) = n.toString().padStart(2, '0')
    return "${dt.year}-${two(dt.month.ordinal + 1)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}"
}
