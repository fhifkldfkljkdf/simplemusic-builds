package com.maxrave.simpmusic.ui.screen.home

import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.appCorner
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.kmpalette.loader.rememberNetworkLoader
import com.kmpalette.rememberDominantColorState
import com.maxrave.common.Config
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.data.model.home.HomeItem
import com.maxrave.domain.data.model.home.HomeShelfStyle
import com.maxrave.domain.data.model.home.chart.Chart
import com.maxrave.domain.data.model.home.chart.isVideoChart
import com.maxrave.domain.data.model.mood.Mood
import com.maxrave.domain.extension.now
import com.maxrave.domain.mediaservice.handler.PlaylistType
import com.maxrave.domain.mediaservice.handler.QueueData
import com.maxrave.domain.utils.toSongEntity
import com.maxrave.domain.utils.toTrack
import com.maxrave.logger.Logger
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.ui.HorizontalScrollBar
import com.maxrave.simpmusic.expect.ui.layerBackdrop
import com.maxrave.simpmusic.expect.ui.rememberBackdrop
import com.maxrave.simpmusic.extension.angledGradientBackground
import com.maxrave.simpmusic.extension.artworkScrimBrush
import com.maxrave.simpmusic.extension.getScreenSizeInfo
import com.maxrave.simpmusic.extension.isScrollingUp
import com.maxrave.simpmusic.extension.mouseDragScroll
import com.maxrave.simpmusic.extension.rgbFactor
import com.maxrave.simpmusic.extension.ultraThinBarStyle
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.component.CenterLoadingBox
import com.maxrave.simpmusic.ui.component.Chip
import com.maxrave.simpmusic.ui.component.EndOfPage
import com.maxrave.simpmusic.ui.component.CreateActions
import com.maxrave.simpmusic.ui.component.DropdownButton
import com.maxrave.simpmusic.ui.component.ExpandableChip
import com.maxrave.simpmusic.ui.component.HomeDiscoverSection
import com.maxrave.simpmusic.ui.component.HomeItem
import com.maxrave.simpmusic.ui.component.HomeItemContentPlaylist
import com.maxrave.simpmusic.ui.component.HomeShimmer
import com.maxrave.simpmusic.ui.component.ItemArtistChart
import com.maxrave.simpmusic.ui.component.ListenTogetherIconButton
import com.maxrave.simpmusic.ui.component.MoodMomentAndGenreHomeItem
import com.maxrave.simpmusic.ui.component.NowPlayingBottomSheet
import com.maxrave.simpmusic.ui.component.OfflineErrorState
import com.maxrave.simpmusic.ui.component.QuickPicksItem
import com.maxrave.simpmusic.ui.component.RippleIconButton
import com.maxrave.simpmusic.ui.component.SectionHeaderButton
import com.maxrave.simpmusic.ui.component.homeCardAspectRatio
import com.maxrave.simpmusic.ui.component.rememberHolderPainter
import com.maxrave.simpmusic.ui.icon.Notifications
import com.maxrave.simpmusic.ui.icon.Person
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.navigation.destination.home.HomeDestination
import com.maxrave.simpmusic.ui.navigation.destination.home.MoodDestination
import com.maxrave.simpmusic.ui.navigation.destination.home.NotificationDestination
import com.maxrave.simpmusic.ui.navigation.destination.home.SettingsDestination
import com.maxrave.simpmusic.ui.navigation.destination.login.LoginDestination
import com.maxrave.simpmusic.ui.navigation.destination.library.LibraryDynamicPlaylistDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.PodcastDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.PlaylistDestination
import com.maxrave.simpmusic.ui.screen.library.LibraryDynamicPlaylistType
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalSpotifyTheme
import com.maxrave.simpmusic.ui.theme.LocalLiquidGlassEnabled
import com.maxrave.simpmusic.ui.theme.desktopPanelDark
import com.maxrave.simpmusic.ui.theme.retroScanlines
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.ui.theme.usesThemedShell
import com.maxrave.simpmusic.viewModel.HomeViewModel
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_COMMUTE
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_ENERGIZE
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_FEEL_GOOD
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_FOCUS
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_PARTY
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_RELAX
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_ROMANCE
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_SAD
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_SLEEP
import com.maxrave.simpmusic.viewModel.HomeViewModel.Companion.HOME_PARAMS_WORKOUT
import com.maxrave.simpmusic.viewModel.ListState
import com.maxrave.simpmusic.viewModel.SharedViewModel
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.http.Url
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.all
import simpmusic.composeapp.generated.resources.app_name
import simpmusic.composeapp.generated.resources.chart
import simpmusic.composeapp.generated.resources.commute
import simpmusic.composeapp.generated.resources.energize
import simpmusic.composeapp.generated.resources.feel_good
import simpmusic.composeapp.generated.resources.focus
import simpmusic.composeapp.generated.resources.good_afternoon
import simpmusic.composeapp.generated.resources.good_evening
import simpmusic.composeapp.generated.resources.good_morning
import simpmusic.composeapp.generated.resources.good_night
import simpmusic.composeapp.generated.resources.guest
import simpmusic.composeapp.generated.resources.let_s_pick_a_playlist_for_you
import simpmusic.composeapp.generated.resources.let_s_start_with_a_radio
import simpmusic.composeapp.generated.resources.listen_again
import simpmusic.composeapp.generated.resources.log_in_to_YouTube
import simpmusic.composeapp.generated.resources.mood
import simpmusic.composeapp.generated.resources.notification
import simpmusic.composeapp.generated.resources.party
import simpmusic.composeapp.generated.resources.play_all
import simpmusic.composeapp.generated.resources.quick_picks
import simpmusic.composeapp.generated.resources.relax
import simpmusic.composeapp.generated.resources.romance
import simpmusic.composeapp.generated.resources.sad
import simpmusic.composeapp.generated.resources.sleep
import simpmusic.composeapp.generated.resources.top_artists
import simpmusic.composeapp.generated.resources.top_picks
import simpmusic.composeapp.generated.resources.welcome_back
import simpmusic.composeapp.generated.resources.what_is_best_choice_today
import simpmusic.composeapp.generated.resources.workout

// The height the first item lost with the old app bar (64dp + the 50dp chip row, now one 56dp row) and
// the Welcome back row (81dp), which Home's top glow still has to cover.
private val HomeGlowOverflow = 140.dp

// The moods behind the Mood chip, each with the Home params it loads.
private val homeMoods =
    listOf(
        Res.string.relax to HOME_PARAMS_RELAX,
        Res.string.sleep to HOME_PARAMS_SLEEP,
        Res.string.energize to HOME_PARAMS_ENERGIZE,
        Res.string.sad to HOME_PARAMS_SAD,
        Res.string.romance to HOME_PARAMS_ROMANCE,
        Res.string.feel_good to HOME_PARAMS_FEEL_GOOD,
        Res.string.workout to HOME_PARAMS_WORKOUT,
        Res.string.party to HOME_PARAMS_PARTY,
        Res.string.commute to HOME_PARAMS_COMMUTE,
        Res.string.focus to HOME_PARAMS_FOCUS,
    )

@OptIn(ExperimentalMaterial3Api::class)
@ExperimentalFoundationApi
@Composable
fun HomeScreen(
    onScrolling: (onTop: Boolean) -> Unit = {},
    viewModel: HomeViewModel =
        koinViewModel(),
    sharedViewModel: SharedViewModel =
        koinInject(),
    navController: NavController,
) {
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberLazyListState()
    val isScrollingUp by scrollState.isScrollingUp()
    val accountInfo by viewModel.accountInfo.collectAsStateWithLifecycle()
    val homeData by viewModel.homeItemList.collectAsStateWithLifecycle()
    // Any shelf YouTube heads with the listener's own avatar over its title (Listen again is one of
    // several). Home's header already shows the avatar, so those shelves drop it and keep their name
    // and title. Matched on the name rather than on any shelf title, the way the old Welcome back row did.
    val homeShelves =
        remember(homeData, accountInfo) {
            val accountName = accountInfo?.first
            if (accountName.isNullOrBlank()) {
                homeData
            } else {
                homeData.map {
                    if (it.subtitle.equals(accountName, ignoreCase = true)) it.copy(thumbnail = null) else it
                }
            }
        }
    val newRelease by viewModel.newRelease.collectAsStateWithLifecycle()
    val chart by viewModel.chart.collectAsStateWithLifecycle()
    val moodMomentAndGenre by viewModel.exploreMoodItem.collectAsStateWithLifecycle()
    val chartLoading by viewModel.loadingChart.collectAsStateWithLifecycle()
    val loading by viewModel.loading.collectAsStateWithLifecycle()
    val reloadDestination by sharedViewModel.reloadDestination.collectAsStateWithLifecycle()
    val pullToRefreshState = rememberPullToRefreshState()
    var isRefreshing by remember { mutableStateOf(false) }
    val chipRowState = rememberScrollState()
    val params by viewModel.params.collectAsStateWithLifecycle()
    val homeListState by viewModel.homeListState.collectAsStateWithLifecycle()
    val continuation by viewModel.continuation.collectAsStateWithLifecycle()
    val continueSession by viewModel.continueSession.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshWebSession() }

    // Private copy: each named theme gets a Home touch — Spotify's quick-access grid, Apple Music's
    // editorial Top Picks, Ocean's tinted header, and flat headers for the Spotify/AMOLED/Retro
    // themes. The app's default themes keep the existing artwork gradient and account row.
    val family = LocalAppThemeFamily.current
    val spotifyTheme = family == AppThemeFamily.SPOTIFY
    val nowPlayingId by viewModel.nowPlayingVideoId.collectAsStateWithLifecycle()
    val listenAgainTitle = stringResource(Res.string.listen_again)
    val themeSongs =
        remember(homeData, family, listenAgainTitle) {
            if (family != AppThemeFamily.SPOTIFY && family != AppThemeFamily.APPLE_MUSIC) {
                emptyList()
            } else {
                val shelf =
                    homeData.firstOrNull { it.title == listenAgainTitle }
                        ?: homeData.firstOrNull { candidate -> candidate.contents.any { !it?.videoId.isNullOrBlank() } }
                shelf
                    ?.contents
                    ?.filterNotNull()
                    ?.filter { !it.videoId.isNullOrBlank() }
                    ?.take(9)
                    .orEmpty()
            }
        }
    val spotifySongs = if (spotifyTheme) themeSongs.take(6) else emptyList()
    val appleSongs = if (family == AppThemeFamily.APPLE_MUSIC) themeSongs else emptyList()
    val hasThemeTopItem = spotifySongs.isNotEmpty() || appleSongs.isNotEmpty()
    val flatHeader =
        family == AppThemeFamily.SPOTIFY ||
            family == AppThemeFamily.AMOLED ||
            family == AppThemeFamily.RETRO ||
            family == AppThemeFamily.SWISS ||
            family == AppThemeFamily.BRUTALISM

    val backgroundColor = MaterialTheme.colorScheme.background
    val isLightTheme = backgroundColor.luminance() > 0.5f
    // What is ACTUALLY painted behind this screen. The desktop shell wraps content in a rounded
    // panel (App.kt: surfaceContainer on light, desktopPanelDark on dark) — deliberately not
    // colorScheme.background — so a gradient tail aimed at colorScheme.background ends on the
    // wrong colour and draws a seam where the first item stops. Same light check as App.kt's
    // isLightScheme.
    val pageBackground =
        if (getPlatform() == Platform.Desktop) {
            if (isLightTheme) {
                MaterialTheme.colorScheme.surfaceContainer
            } else if (family.usesThemedShell()) {
                MaterialTheme.colorScheme.surfaceContainerLow
            } else {
                desktopPanelDark
            }
        } else {
            backgroundColor
        }
    var topHeaderColor by remember {
        mutableStateOf(backgroundColor)
    }
    val animatedColor by animateColorAsState(
        topHeaderColor,
        // Retro swaps the header tint in one step; a 500ms cross-fade is a Material gesture.
        if (family == AppThemeFamily.RETRO) snap() else tween(500),
    )
    // Ocean's signature is a cool tinted header instead of the artwork-derived one.
    val headerTint =
        if (family == AppThemeFamily.OCEAN) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            animatedColor
        }
    val mainHomeThumbnail by viewModel.mainHomeThumbnail.collectAsStateWithLifecycle()
    // YouTube's Home backdrop, drawn over the tint taken from the first card's artwork. A response
    // that carries none keeps the tint alone, and a failed load drops the image and its scrim,
    // leaving the tint as it was.
    val headerImage by viewModel.homeBackground.collectAsStateWithLifecycle()
    var headerImageFailed by remember(headerImage) { mutableStateOf(false) }
    val networkLoader = rememberNetworkLoader(HttpClient(CIO))
    val dominantColorState =
        rememberDominantColorState(
            defaultColor = backgroundColor,
            defaultOnColor = backgroundColor,
            loader = networkLoader,
        )

    LaunchedEffect(mainHomeThumbnail) {
        mainHomeThumbnail?.let {
            dominantColorState.updateFrom(Url(it))
        }
    }

    LaunchedEffect(dominantColorState, isLightTheme) {
        snapshotFlow { dominantColorState.color }.collect {
            // Light theme: pull the artwork color toward white for a soft pastel header;
            // dark theme keeps the original darkened tone.
            topHeaderColor = if (isLightTheme) lerp(it, Color.White, 0.85f) else it.rgbFactor(0.3f)
        }
    }

    var topAppBarHeightPx by rememberSaveable {
        mutableIntStateOf(0)
    }

    var moodExpanded by rememberSaveable {
        mutableStateOf(false)
    }
    // Derived, so scrolling recomposes only when the page reaches or leaves its very top.
    val atTop by remember {
        derivedStateOf { scrollState.firstVisibleItemIndex == 0 && scrollState.firstVisibleItemScrollOffset == 0 }
    }
    val hazeState =
        rememberHazeState()
    // The floating chip row refracts the page scrolling under it, so the page is the glass source and
    // the row its sibling (nesting the row inside the source is the RuntimeShader feedback loop).
    val chipBackdrop = rememberBackdrop(MaterialTheme.colorScheme.background)

    LaunchedEffect(scrollState) {
        snapshotFlow { scrollState.firstVisibleItemIndex }
            .collect {
                if (it <= 1) {
                    onScrolling.invoke(true)
                } else {
                    onScrolling.invoke(isScrollingUp)
                }
            }
    }

    val onRefresh: () -> Unit = {
        isRefreshing = true
        viewModel.getHomeItemList(params)
        Logger.w("HomeScreen", "onRefresh")
    }
    LaunchedEffect(key1 = reloadDestination) {
        if (reloadDestination == HomeDestination::class) {
            if (scrollState.firstVisibleItemIndex > 1) {
                Logger.w("HomeScreen", "scrollState.firstVisibleItemIndex: ${scrollState.firstVisibleItemIndex}")
                scrollState.animateScrollToItem(0)
                sharedViewModel.reloadDestinationDone()
            } else {
                Logger.w("HomeScreen", "scrollState.firstVisibleItemIndex: ${scrollState.firstVisibleItemIndex}")
                onRefresh.invoke()
            }
        }
    }
    LaunchedEffect(key1 = loading) {
        if (!loading) {
            isRefreshing = false
            sharedViewModel.reloadDestinationDone()
            coroutineScope.launch {
                pullToRefreshState.animateToHidden()
            }
        }
    }
    val shouldStartPaginate =
        remember {
            derivedStateOf {
                homeListState != ListState.PAGINATION_EXHAUST &&
                    (
                        scrollState.layoutInfo.visibleItemsInfo
                            .lastOrNull()
                            ?.index ?: -9
                    ) >= (scrollState.layoutInfo.totalItemsCount - 1)
            }
        }

    LaunchedEffect(key1 = shouldStartPaginate.value) {
        Logger.d("HomeScreen", "shouldStartPaginate: ${shouldStartPaginate.value}")
        Logger.d("HomeScreen", "homeListState: $homeListState")
        Logger.d("HomeScreen", "Continuation: $continuation")
        if (shouldStartPaginate.value && homeListState == ListState.IDLE) {
            viewModel.getContinueHomeItem(
                continuation,
            )
        }
    }

//    if (shouldShowGetDataSyncIdBottomSheet) {
//        GetDataSyncIdBottomSheet(
//            cookie = youTubeCookie,
//            onDismissRequest = {
//                shouldShowGetDataSyncIdBottomSheet = false
//            },
//        )
//    }

    Box {
        PullToRefreshBox(
            modifier =
                Modifier
                    .then(if (LocalLiquidGlassEnabled.current) Modifier.layerBackdrop(chipBackdrop) else Modifier)
                    .hazeSource(hazeState),
            state = pullToRefreshState,
            onRefresh = onRefresh,
            isRefreshing = isRefreshing,
            indicator = {
                PullToRefreshDefaults.Indicator(
                    state = pullToRefreshState,
                    isRefreshing = isRefreshing,
                    modifier =
                        Modifier
                            .align(Alignment.TopCenter)
                            .padding(
                                top =
                                    with(LocalDensity.current) {
                                        topAppBarHeightPx.toDp()
                                    },
                            ),
                    containerColor = PullToRefreshDefaults.indicatorContainerColor,
                    color = PullToRefreshDefaults.indicatorColor,
                    maxDistance = PullToRefreshDefaults.PositionalThreshold,
                )
            },
        ) {
            Crossfade(targetState = loading, label = "Home Shimmer") { loading ->
                if (!loading) {
                    if (homeData.isEmpty()) {
                        OfflineErrorState(
                            onRetry = onRefresh,
                            onOpenDownloaded = {
                                navController.navigate(
                                    LibraryDynamicPlaylistDestination(
                                        type = LibraryDynamicPlaylistType.Downloaded.toStringParams(),
                                    ),
                                )
                            },
                        )
                        return@Crossfade
                    }
                    LazyColumn(
                        state = scrollState,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (spotifySongs.isNotEmpty()) {
                            item(key = "spotify-quick-access") {
                                Column {
                                    Spacer(
                                        Modifier.height(
                                            with(LocalDensity.current) { topAppBarHeightPx.toDp() },
                                        ),
                                    )
                                    SpotifyQuickAccessGrid(
                                        items = spotifySongs,
                                        nowPlayingId = nowPlayingId,
                                        viewModel = viewModel,
                                        modifier =
                                            Modifier
                                                .padding(horizontal = 15.dp)
                                                .padding(top = 8.dp, bottom = 4.dp),
                                    )
                                }
                            }
                        }
                        if (appleSongs.isNotEmpty()) {
                            // Apple Music's Home touch: one editorial Top Picks row, its feature
                            // card over the next songs.
                            item(key = "apple-top-picks") {
                                Column {
                                    Spacer(
                                        Modifier.height(
                                            with(LocalDensity.current) { topAppBarHeightPx.toDp() },
                                        ),
                                    )
                                    Box(Modifier.padding(horizontal = 15.dp)) {
                                        FeatureSongRow(
                                            data =
                                                HomeItem(
                                                    contents = appleSongs.drop(1).take(8),
                                                    title = stringResource(Res.string.top_picks),
                                                    format = HomeShelfStyle.FEATURE,
                                                    feature = appleSongs.first(),
                                                ),
                                            navController = navController,
                                            viewModel = viewModel,
                                        )
                                    }
                                }
                            }
                        }
                        continueSession?.let { session ->
                            item(key = "server-sync-continue") {
                                ContinueFromWebCard(
                                    session = session,
                                    onResume = {
                                        sharedViewModel.resumeFromServerSync(session)
                                        viewModel.dismissWebSession()
                                    },
                                    onDismiss = viewModel::dismissWebSession,
                                )
                            }
                        }
                        itemsIndexed(homeShelves, key = { _, item ->
                            item.hashCode().toString() + (mainHomeThumbnail ?: "nothumb")
                        }) { index, item ->
                            Box {
                                // Spotify, AMOLED and Retro are flat: no artwork gradient behind
                                // their first shelf. Ocean's is tinted instead of artwork-derived.
                                if (index == 0 && !flatHeader) {
                                    Box(
                                        modifier =
                                            Modifier
                                                // matchParentSize, not height(300.dp): 300 is the
                                                // height of this shelf ON A PHONE. On a desktop
                                                // window the first item is taller, the gradient
                                                // stopped mid-item and everything below it fell
                                                // back to the flat background — a hard colour seam
                                                // straight across Home. Sized by the item, the
                                                // bottom scrim always lands on the item's edge.
                                                .matchParentSize()
                                                // The glow used to reach down past the old app bar and
                                                // the Welcome back row, both gone with the Spotify
                                                // header. It keeps that reach by running on below the
                                                // first item instead of making the item taller; what
                                                // runs over is the scrim's tail, already faded out.
                                                .layout { measurable, constraints ->
                                                    val height = constraints.maxHeight + HomeGlowOverflow.roundToPx()
                                                    val placeable =
                                                        measurable.measure(constraints.copy(minHeight = height, maxHeight = height))
                                                    layout(constraints.maxWidth, constraints.maxHeight) { placeable.place(0, 0) }
                                                }.angledGradientBackground(listOf(headerTint, pageBackground), 25f),
                                    ) {
                                        if (headerImage != null && !headerImageFailed) {
                                            AsyncImage(
                                                model =
                                                    ImageRequest
                                                        .Builder(LocalPlatformContext.current)
                                                        .data(headerImage)
                                                        .crossfade(550)
                                                        .build(),
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                onError = { headerImageFailed = true },
                                                modifier = Modifier.fillMaxSize(),
                                            )
                                            // Always over the image, which can be very bright: a layer of the
                                            // page's own colour tones it down in either theme and fades it
                                            // into the page along the tint's own 25° line, not in a flat
                                            // band at the bottom.
                                            Box(
                                                Modifier
                                                    .fillMaxSize()
                                                    .angledGradientBackground(listOf(pageBackground.copy(alpha = 0.6f), pageBackground), 25f),
                                            )
                                        }
                                        Box(
                                            modifier =
                                                Modifier
                                                    .fillMaxWidth()
                                                    // A share of the glow, not a fixed 180dp: on a glow
                                                    // ~560dp tall, 180dp made a long flat field that
                                                    // dropped off in one short step.
                                                    .fillMaxHeight(0.6f)
                                                    .align(Alignment.BottomCenter)
                                                    .background(artworkScrimBrush(pageBackground)),
                                        )
                                    }
                                }
                                Column(
                                    modifier =
                                        Modifier
                                            .padding(horizontal = 15.dp),
                                ) {
                                    // With a theme's top item above, it already cleared the app bar;
                                    // the shelves then start straight below it.
                                    if (index == 0 && !hasThemeTopItem) {
                                        Spacer(
                                            Modifier.height(
                                                with(LocalDensity.current) { topAppBarHeightPx.toDp() } + 8.dp,
                                            ),
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    if (item.title == stringResource(Res.string.quick_picks)) {
                                        AnimatedVisibility(
                                            visible =
                                                homeData.find {
                                                    it.title ==
                                                        stringResource(
                                                            Res.string.quick_picks,
                                                        )
                                                } != null,
                                        ) {
                                            QuickPicks(
                                                homeItem =
                                                    (
                                                        homeData.find {
                                                            it.title ==
                                                                stringResource(
                                                                    Res.string.quick_picks,
                                                                )
                                                        } ?: return@AnimatedVisibility
                                                    ).let { content ->
                                                        content.copy(
                                                            contents =
                                                                content.contents.mapNotNull { ct ->
                                                                    ct?.copy(
                                                                        artists =
                                                                            ct.artists?.let { art ->
                                                                                if (art.size > 1) {
                                                                                    art.dropLast(1)
                                                                                } else {
                                                                                    art
                                                                                }
                                                                            },
                                                                    )
                                                                },
                                                        )
                                                    },
                                                navController = navController,
                                                viewModel = viewModel,
                                            )
                                        }
                                    } else if (item.topArtists != null) {
                                        // Private copy: the "Top artists" row, now in the feed near
                                        // the top instead of the Charts block at the bottom.
                                        TopArtistsRow(data = item, navController = navController)
                                    } else if (item.moodItems.isNotEmpty()) {
                                        // Private copy: the "Recommended genres" row, drawn as the
                                        // same stripe cards the Moods & Genres grid uses.
                                        RecommendedGenresRow(data = item, navController = navController)
                                    } else if (item.format != null) {
                                        // Private copy: each app-built song row has its own shape, so
                                        // Home's rows do not all read as the same carousel.
                                        when (item.format) {
                                            HomeShelfStyle.FEATURE ->
                                                FeatureSongRow(data = item, navController = navController, viewModel = viewModel)

                                            HomeShelfStyle.WIDE ->
                                                WideSongRow(data = item, navController = navController, viewModel = viewModel)

                                            HomeShelfStyle.TOP_LIST ->
                                                TopSongsListRow(data = item, navController = navController, viewModel = viewModel)

                                            null -> Unit
                                        }
                                    } else if (item.isSongCardShelf()) {
                                        HomeDiscoverSection(
                                            data = item,
                                            navController = navController,
                                            homeViewModel = viewModel,
                                        )
                                    } else {
                                        HomeItem(
                                            navController = navController,
                                            data = item,
                                        )
                                    }
                                }
                            }
                        }
                        item {
                            AnimatedVisibility(
                                homeListState == ListState.PAGINATING,
                                enter = expandVertically() + expandVertically(),
                                exit = fadeOut() + shrinkVertically(),
                            ) {
                                CenterLoadingBox(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .height(200.dp),
                                )
                            }
                        }
                        if (homeListState == ListState.PAGINATION_EXHAUST) {
                            // The app's own "New releases" and "Music videos" shelves used to be
                            // drawn here, above Moods & Moments; the home feed carries a
                            // new-release row of its own (which the repository ranks by this
                            // phone's artists), so these two were only a duplicate.
                            item {
                                AnimatedVisibility(
                                    visible = moodMomentAndGenre != null,
                                ) {
                                    Box(
                                        modifier =
                                            Modifier
                                                .padding(horizontal = 15.dp),
                                    ) {
                                        moodMomentAndGenre?.let {
                                            MoodMomentAndGenre(
                                                mood = it,
                                                navController = navController,
                                            )
                                        }
                                    }
                                }
                            }
                            // Private copy: the video chart row is hidden, Top artists moved
                            // into the feed, and the country selector is gone — so the whole
                            // block disappears when it has no row left to show.
                            val chartRows = chart?.listChartItem?.filterNot { it.isVideoChart() }.orEmpty()
                            if (chartRows.isNotEmpty() || chart?.podcasts != null) {
                                item {
                                    Column(
                                        Modifier
                                            .padding(vertical = 10.dp)
                                            .padding(horizontal = 15.dp),
                                        verticalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Crossfade(
                                            targetState = chartLoading,
                                            label = "Chart",
                                        ) { loading ->
                                            if (!loading) {
                                                chart?.let {
                                                    ChartData(
                                                        chart = it,
                                                        navController = navController,
                                                    )
                                                }
                                            } else {
                                                CenterLoadingBox(
                                                    modifier =
                                                        Modifier
                                                            .fillMaxWidth()
                                                            .height(400.dp),
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            EndOfPage()
                        }
                    }
                } else {
                    Column {
                        Spacer(
                            Modifier.height(
                                with(LocalDensity.current) {
                                    topAppBarHeightPx.toDp()
                                } + 8.dp,
                            ),
                        )
                        HomeShimmer()
                    }
                }
            }
        }
        // Spotify's header: the avatar, the chips and Create on one row, with no app bar. At the
        // top of the page it sits straight on the artwork glow; once the page scrolls under it, the blurred
        // bar fades in behind it.
        AnimatedContent(
            targetState = atTop,
            transitionSpec = {
                // Retro has no cross-fade: the bar is either there or not.
                val spec: FiniteAnimationSpec<Float> = if (family == AppThemeFamily.RETRO) snap() else tween(300)
                fadeIn(spec).togetherWith(fadeOut(spec))
            },
        ) { target ->
            Column(
                modifier =
                    Modifier
                        .align(Alignment.TopCenter)
                        .then(
                            if (target) {
                                Modifier.background(Color.Transparent)
                            } else {
                                Modifier
                                    .hazeBlur(HazeInput.Sources(hazeState), ultraThinBarStyle())
                            },
                        )
                        // Retro's CRT texture lives on this header surface only. It is drawn
                        // behind the bar's own labels/chips, so list artwork and body copy below
                        // stay clean.
                        .then(if (family == AppThemeFamily.RETRO) Modifier.retroScanlines() else Modifier)
                        .onGloballyPositioned { coordinates ->
                            topAppBarHeightPx = coordinates.size.height
                        },
            ) {
                Spacer(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .windowInsetsPadding(
                                WindowInsets.statusBars,
                            ),
                )
                // The avatar stays put and the chips scroll only to its right, clipped there instead of
                // passing over it, each end faded while chips wait past that edge. On a phone held
                // upright Create rides at the end of the chip row: the row is at least as wide as its
                // strip, so at rest Create sits at the right edge, and a Mood that opens wide pushes it
                // along instead of sliding under it. On Desktop and in landscape Create stays put at the
                // right edge, like the avatar.
                val createPinned = getPlatform() == Platform.Desktop || getScreenSizeInfo().let { it.wDP >= it.hDP }
                val chipHeadFade by animateFloatAsState(if (chipRowState.canScrollBackward) 1f else 0f)
                val chipTailFade by animateFloatAsState(if (chipRowState.canScrollForward) 1f else 0f)
                // Notifications moved into the avatar menu, Listen Together into the Create sheet.
                val createActions: @Composable () -> Unit = {
                    CreateActions(
                        backdrop = chipBackdrop,
                        navController = navController,
                        onSettings = { navController.navigate(SettingsDestination()) },
                    )
                }
                Row(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.padding(start = 16.dp, end = 8.dp)) {
                        HomeAccountButton(
                            accountName = accountInfo?.first,
                            thumbnailUrl = accountInfo?.second,
                            navController = navController,
                        )
                    }
                    BoxWithConstraints(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    ) {
                        Row(
                            modifier =
                                Modifier
                                    .fillMaxHeight()
                                    .chipStripEdgeFades(32.dp, start = { chipHeadFade }, end = { chipTailFade })
                                    .mouseDragScroll(chipRowState)
                                    .horizontalScroll(chipRowState)
                                    .widthIn(min = maxWidth)
                                    .padding(end = if (createPinned) 0.dp else 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Chip(
                                    isAnimated = loading,
                                    isSelected = params == null && !moodExpanded,
                                    text = stringResource(Res.string.all),
                                    backdrop = chipBackdrop,
                                ) {
                                    moodExpanded = false
                                    viewModel.setParams(null)
                                }
                                ExpandableChip(
                                    text = stringResource(Res.string.mood),
                                    options = homeMoods.map { stringResource(it.first) },
                                    selectedIndex = homeMoods.indexOfFirst { it.second == params }.takeIf { it >= 0 },
                                    expanded = moodExpanded,
                                    onExpandedChange = { moodExpanded = it },
                                    onSelect = { index ->
                                        moodExpanded = false
                                        viewModel.setParams(homeMoods[index].second)
                                    },
                                    isAnimated = loading,
                                    backdrop = chipBackdrop,
                                )
                            }
                            if (!createPinned) {
                                Box(Modifier.padding(start = 8.dp)) { createActions() }
                            }
                        }
                    }
                    if (createPinned) {
                        Box(Modifier.padding(start = 8.dp, end = 16.dp)) { createActions() }
                    }
                }
            }
        }
    }
}

/**
 * Fades each end of the chip strip out (a DstIn mask) while chips wait past that edge, so the row
 * reads as running on rather than cut off. [start] and [end] ease each fade in and out and are read
 * at draw time. Smoothstep, like every fade in the app: a linear ramp shows a line where it begins.
 */
internal fun Modifier.chipStripEdgeFades(
    width: Dp,
    start: () -> Float,
    end: () -> Float,
): Modifier =
    graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val fadePx = width.toPx().coerceAtMost(size.width / 2f)
            val startFade = start()
            if (startFade > 0f) {
                drawRect(
                    brush = Brush.horizontalGradient(colorStops = chipFadeStops(startFade, fadingOut = false), startX = 0f, endX = fadePx),
                    blendMode = BlendMode.DstIn,
                )
            }
            val endFade = end()
            if (endFade > 0f) {
                drawRect(
                    brush =
                        Brush.horizontalGradient(
                            colorStops = chipFadeStops(endFade, fadingOut = true),
                            startX = size.width - fadePx,
                            endX = size.width,
                        ),
                    blendMode = BlendMode.DstIn,
                )
            }
        }

// Opaque → transparent left to right when [fadingOut], the other way round otherwise; [fade] scales
// how far towards transparent the far end goes.
private fun chipFadeStops(
    fade: Float,
    fadingOut: Boolean,
): Array<Pair<Float, Color>> =
    Array(CHIP_FADE_STEPS + 1) { i ->
        val t = i / CHIP_FADE_STEPS.toFloat()
        val ramp = t * t * (3f - 2f * t)
        t to Color.Black.copy(alpha = 1f - fade * (if (fadingOut) ramp else 1f - ramp))
    }

private const val CHIP_FADE_STEPS = 24

/**
 * The avatar at the start of Home's header. It opens a menu showing who is signed in and the
 * greeting the old app bar used to show. Signed out, the avatar is a person glyph and the menu
 * offers the log-in.
 */
@Composable
private fun HomeAccountButton(
    accountName: String?,
    thumbnailUrl: String?,
    navController: NavController,
) {
    var menuOpen by remember { mutableStateOf(false) }
    // Sign-out blanks the stored account name, so a blank name is the signed-out state.
    val signedIn = !accountName.isNullOrBlank()
    val displayName = if (signedIn) accountName.orEmpty() else stringResource(Res.string.guest)
    val hour = remember { now().time.hour }
    val greeting =
        stringResource(
            when (hour) {
                in 6..12 -> Res.string.good_morning
                in 13..17 -> Res.string.good_afternoon
                in 18..23 -> Res.string.good_evening
                else -> Res.string.good_night
            },
        )
    Box {
        AccountAvatar(
            signedIn = signedIn,
            thumbnailUrl = thumbnailUrl,
            // The Create pill's height, as Apple sizes an avatar like the glass buttons beside it.
            size = 44.dp,
            contentDescription = displayName,
            modifier = Modifier.clickable { menuOpen = true },
        )
        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = { menuOpen = false },
            // The draft's 280dp (also Material's widest menu item) instead of wrapping its content,
            // which left the menu as narrow as its longest row. Capped, not fixed: a window narrower
            // than that gets a menu as wide as the window instead of one that runs off it.
            modifier =
                Modifier
                    .widthIn(max = 280.dp)
                    .fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                AccountAvatar(
                    signedIn = signedIn,
                    thumbnailUrl = thumbnailUrl,
                    size = 40.dp,
                    contentDescription = null,
                )
                Column {
                    Text(text = displayName, style = typo().titleSmall, maxLines = 1)
                    Text(text = greeting, style = typo().bodySmall)
                }
            }
            DropdownMenuItem(
                text = { Text(stringResource(Res.string.notification), style = typo().bodyMedium) },
                leadingIcon = { Icon(SimpIcons.Notifications, contentDescription = null) },
                onClick = {
                    menuOpen = false
                    navController.navigate(NotificationDestination)
                },
            )
            if (!signedIn) {
                Button(
                    onClick = {
                        menuOpen = false
                        navController.navigate(LoginDestination)
                    },
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                ) {
                    Text(stringResource(Res.string.log_in_to_YouTube), color = LocalContentColor.current)
                }
            }
        }
    }
}

@Composable
private fun AccountAvatar(
    signedIn: Boolean,
    thumbnailUrl: String?,
    size: Dp,
    contentDescription: String?,
    modifier: Modifier = Modifier,
) {
    val avatarModifier =
        Modifier
            .size(size)
            .clip(CircleShape)
            .then(modifier)
    if (signedIn && !thumbnailUrl.isNullOrBlank()) {
        AsyncImage(
            model =
                ImageRequest
                    .Builder(LocalPlatformContext.current)
                    .data(thumbnailUrl)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .diskCacheKey(thumbnailUrl)
                    .crossfade(true)
                    .build(),
            placeholder = rememberHolderPainter(),
            error = rememberHolderPainter(),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = avatarModifier,
        )
    } else {
        Box(
            modifier = avatarModifier.background(MaterialTheme.colorScheme.surfaceContainerHighest),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = SimpIcons.Person,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(size * 0.6f),
            )
        }
    }
}

// Portrait fills the width with one column (the next one peeking in). On a landscape window that one
// column stretched across the whole screen, so every row there is capped instead.
private val LandscapeGridItemMaxWidth = 400.dp

// A card shelf of songs only that leads to no page of its own ("Your daily discover"). List shelves
// (Quick picks, Heard in Shorts) carry itemsPerColumn and keep their own look; a shelf with a More
// page (Listen again can be all songs) keeps its cards; videos draw as wide cards, so never match.
private fun HomeItem.isSongCardShelf(): Boolean =
    itemsPerColumn == null &&
        moreEndpoint == null &&
        contents.isNotEmpty() &&
        contents.all { it != null && !it.videoId.isNullOrEmpty() && it.homeCardAspectRatio() == 1f }

@ExperimentalFoundationApi
@Composable
fun QuickPicks(
    homeItem: HomeItem,
    navController: NavController,
    viewModel: HomeViewModel = koinViewModel(),
) {
    val lazyListState = rememberLazyGridState()
    val snapperFlingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyGridState = lazyListState, snapPosition = SnapPosition.Start))
    val isPortrait = getScreenSizeInfo().let { it.wDP < it.hDP }
    val density = LocalDensity.current
    var widthDp by remember {
        mutableStateOf(0.dp)
    }
    var bottomSheetShow by remember { mutableStateOf(false) }
    var track by remember { mutableStateOf<Track?>(null) }

    if (bottomSheetShow) {
        NowPlayingBottomSheet(
            onDismiss = { bottomSheetShow = false },
            song = track?.toSongEntity(),
            navController = navController,
        )
    }

    Column(
        Modifier
            .padding(vertical = 8.dp)
            .onGloballyPositioned { coordinates ->
                with(density) {
                    widthDp = (coordinates.size.width).toDp()
                }
            },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = stringResource(Res.string.let_s_start_with_a_radio),
                    style = typo().bodySmall,
                )
                Text(
                    text = stringResource(Res.string.quick_picks),
                    style = typo().headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                )
            }
            if (homeItem.playAllEndpoint != null) {
                SectionHeaderButton(
                    text = stringResource(Res.string.play_all),
                    onClick = { viewModel.playAll(homeItem) },
                )
            }
        }
        LazyHorizontalGrid(
            rows = GridCells.Fixed(4),
            modifier = Modifier.height(256.dp).mouseDragScroll(lazyListState, snapperFlingBehavior),
            state = lazyListState,
            flingBehavior = snapperFlingBehavior,
        ) {
            items(homeItem.contents, key = { it.hashCode() }) {
                if (it != null) {
                    QuickPicksItem(
                        onClick = {
                            val firstQueue: Track = it.toTrack()
                            viewModel.setQueueData(
                                QueueData.Data(
                                    listTracks = arrayListOf(firstQueue),
                                    firstPlayedTrack = firstQueue,
                                    playlistId = "RDAMVM${it.videoId}",
                                    playlistName = "\"${it.title}\" Radio",
                                    playlistType = PlaylistType.RADIO,
                                    continuation = null,
                                ),
                            )
                            viewModel.loadMediaItem(
                                firstQueue,
                                type = Config.SONG_CLICK,
                            )
                        },
                        onLongClick = {
                            track = it.toTrack()
                            bottomSheetShow = true
                        },
                        data = it,
                        widthDp = if (isPortrait) widthDp else minOf(widthDp, LandscapeGridItemMaxWidth + 30.dp),
                    )
                }
            }
        }
        HorizontalScrollBar(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            scrollState = lazyListState,
            flingBehavior = snapperFlingBehavior,
        )
    }
}

@Composable
fun MoodMomentAndGenre(
    mood: Mood,
    navController: NavController,
) {
    Column(
        Modifier
            .padding(vertical = 8.dp),
    ) {
        Text(
            text = stringResource(Res.string.let_s_pick_a_playlist_for_you),
            style = typo().bodyMedium,
        )
        // One block per section YouTube returned, headed by ITS OWN title. Hard-coding
        // "Moods & moment" / "Genre" here (and reading mood.moodsMoments / mood.genres by
        // index) mislabelled every row as soon as a signed-in account got an extra
        // "For you" section, and hid the real Genres section altogether.
        mood.sections.forEach { section ->
            val gridState = rememberLazyGridState()
            val flingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyGridState = gridState))
            Text(
                text = section.title,
                style = typo().headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
            )
            LazyHorizontalGrid(
                rows = GridCells.Fixed(3),
                modifier = Modifier.height(210.dp).mouseDragScroll(gridState, flingBehavior),
                state = gridState,
                flingBehavior = flingBehavior,
            ) {
                items(section.items, key = { it.params }) { item ->
                    MoodMomentAndGenreHomeItem(
                        title = item.title,
                        stripeColor = item.stripeColor,
                    ) {
                        navController.navigate(
                            MoodDestination(
                                item.params,
                            ),
                        )
                    }
                }
            }
            HorizontalScrollBar(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                scrollState = gridState,
                flingBehavior = flingBehavior,
            )
        }
    }
}

@Composable
fun ChartTitle() {
    Column {
        Text(
            text = stringResource(Res.string.what_is_best_choice_today),
            style = typo().bodyMedium,
        )
        Text(
            text = stringResource(Res.string.chart),
            style = typo().headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp),
        )
    }
}

@Composable
fun ChartData(
    chart: Chart,
    navController: NavController,
) {
    var gridWidthDp by remember {
        mutableStateOf(0.dp)
    }
    val density = LocalDensity.current

    val isPortrait = getScreenSizeInfo().let { it.wDP < it.hDP }
    // Private copy: YouTube's "Video charts" row is hidden; every other chart row stays.
    val chartRows = chart.listChartItem.filterNot { it.isVideoChart() }

    Column(
        Modifier.onGloballyPositioned { coordinates ->
            with(density) {
                gridWidthDp = (coordinates.size.width).toDp()
            }
        },
    ) {
        if (chartRows.isNotEmpty()) {
            ChartTitle()
        }
        chartRows.forEach { item ->
            Text(
                text = item.title,
                style = typo().headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
            )
            val lazyListState = rememberLazyListState()
            val snapperFlingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyListState = lazyListState))
            LazyRow(
                modifier = Modifier.mouseDragScroll(lazyListState, snapperFlingBehavior),
                state = lazyListState,
                flingBehavior = snapperFlingBehavior,
            ) {
                items(item.playlists.size, key = { index ->
                    val data = item.playlists[index]
                    data.id + data.title + index
                }) {
                    HomeItemContentPlaylist(
                        onClick = {
                            navController.navigate(
                                PlaylistDestination(
                                    playlistId = item.playlists[it].id,
                                    isYourYouTubePlaylist = false,
                                ),
                            )
                        },
                        data = item.playlists[it],
                    )
                }
            }
        }
        // Ranked podcast shows, laid out exactly like the artist chart used to be.
        chart.podcasts?.let { podcasts ->
            Text(
                text = podcasts.title,
                style = typo().headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
            )
            val podcastGridState = rememberLazyGridState()
            val podcastFlingBehavior =
                rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyGridState = podcastGridState, snapPosition = SnapPosition.Start))
            LazyHorizontalGrid(
                rows = GridCells.Fixed(3),
                modifier = Modifier.height(240.dp).mouseDragScroll(podcastGridState, podcastFlingBehavior),
                state = podcastGridState,
                flingBehavior = podcastFlingBehavior,
            ) {
                items(podcasts.shows.size, key = { index -> podcasts.shows[index].browseId + index }) {
                    val data = podcasts.shows[it]
                    ItemArtistChart(
                        onClick = { navController.navigate(PodcastDestination(podcastId = data.browseId)) },
                        data = data,
                        widthDp = if (isPortrait) gridWidthDp else minOf(gridWidthDp, LandscapeGridItemMaxWidth),
                        thumbnailShape = appCorner(8.dp),
                        subtitle = data.subscribers,
                    )
                }
            }
            HorizontalScrollBar(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                scrollState = podcastGridState,
                flingBehavior = podcastFlingBehavior,
            )
        }
    }
}