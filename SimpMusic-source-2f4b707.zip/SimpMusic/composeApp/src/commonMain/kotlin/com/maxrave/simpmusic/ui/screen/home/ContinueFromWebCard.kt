package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.maxrave.domain.data.model.serversync.ServerSyncSession
import com.maxrave.simpmusic.ui.theme.appCorner
import com.maxrave.simpmusic.ui.theme.typo
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.server_sync_continue_action
import simpmusic.composeapp.generated.resources.server_sync_continue_body
import simpmusic.composeapp.generated.resources.server_sync_continue_title
import simpmusic.composeapp.generated.resources.server_sync_never
import simpmusic.composeapp.generated.resources.server_sync_not_now

/**
 * Home's handoff card: the web server has a session from another device (the web UI or another
 * phone). Tapping Resume loads that queue on this device and seeks to the position it reports.
 */
@Composable
fun ContinueFromWebCard(
    session: ServerSyncSession,
    onResume: () -> Unit,
    onDismiss: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 4.dp),
        shape = appCorner(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = stringResource(Res.string.server_sync_continue_title),
                style = typo().titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text =
                    if (session.videoId.isBlank()) {
                        stringResource(Res.string.server_sync_never)
                    } else {
                        stringResource(Res.string.server_sync_continue_body, session.deviceName)
                    },
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(Res.string.server_sync_not_now), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = onResume) {
                    Text(stringResource(Res.string.server_sync_continue_action))
                }
            }
        }
    }
}
