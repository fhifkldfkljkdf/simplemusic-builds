package com.maxrave.simpmusic.ui.navigation.destination.home

import kotlinx.serialization.Serializable

/**
 * [openServerSync] opens the "Web server sync" pairing dialog on arrival; the
 * `simpmusic://server-sync` deep link uses that.
 */
@Serializable
data class SettingsDestination(
    val openServerSync: Boolean = false,
)
