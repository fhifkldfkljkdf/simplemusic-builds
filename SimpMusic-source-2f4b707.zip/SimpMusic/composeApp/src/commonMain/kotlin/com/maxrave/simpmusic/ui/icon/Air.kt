package com.maxrave.simpmusic.ui.icon

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

@Suppress("CheckReturnValue")
val SimpIcons.Air: ImageVector
  get() {
    if (_Air != null) {
      return _Air!!
    }
    _Air =
      ImageVector.Builder(
          name = "Air",
          defaultWidth = 24.dp,
          defaultHeight = 24.dp,
          viewportWidth = 24f,
          viewportHeight = 24f,
        )
        .apply {
          path(
            fill = SolidColor(Color.Black),
            fillAlpha = 1f,
            stroke = null,
            strokeAlpha = 1f,
            strokeLineWidth = 1f,
            strokeLineCap = StrokeCap.Butt,
            strokeLineJoin = StrokeJoin.Bevel,
            strokeLineMiter = 1f,
            pathFillType = PathFillType.Companion.NonZero,
          ) {
            moveTo(11.5f, 20f)
            quadToRelative(-0.8f, 0f, -1.49f, -0.4f)
            reflectiveQuadTo(8.9f, 18.5f)
            quadTo(8.63f, 18f, 8.89f, 17.5f)
            reflectiveQuadTo(9.7f, 17f)
            quadToRelative(0.32f, 0f, 0.57f, 0.2f)
            reflectiveQuadToRelative(0.45f, 0.45f)
            quadToRelative(0.13f, 0.18f, 0.34f, 0.26f)
            quadTo(11.28f, 18f, 11.5f, 18f)
            quadToRelative(0.43f, 0f, 0.71f, -0.29f)
            quadTo(12.5f, 17.43f, 12.5f, 17f)
            reflectiveQuadTo(12.21f, 16.29f)
            reflectiveQuadTo(11.5f, 16f)
            horizontalLineTo(3f)
            quadTo(2.58f, 16f, 2.29f, 15.71f)
            reflectiveQuadTo(2f, 15f)
            reflectiveQuadTo(2.29f, 14.29f)
            reflectiveQuadTo(3f, 14f)
            horizontalLineToRelative(8.5f)
            quadToRelative(1.25f, 0f, 2.13f, 0.88f)
            reflectiveQuadTo(14.5f, 17f)
            reflectiveQuadToRelative(-0.88f, 2.13f)
            reflectiveQuadTo(11.5f, 20f)
            close()
            moveTo(3f, 10f)
            quadTo(2.58f, 10f, 2.29f, 9.71f)
            reflectiveQuadTo(2f, 9f)
            quadTo(2f, 8.57f, 2.29f, 8.29f)
            reflectiveQuadTo(3f, 8f)
            horizontalLineTo(15.5f)
            quadToRelative(0.63f, 0f, 1.06f, -0.44f)
            reflectiveQuadTo(17f, 6.5f)
            reflectiveQuadTo(16.56f, 5.44f)
            reflectiveQuadTo(15.5f, 5f)
            quadTo(15.1f, 5f, 14.75f, 5.19f)
            reflectiveQuadTo(14.2f, 5.72f)
            quadToRelative(-0.18f, 0.3f, -0.43f, 0.54f)
            reflectiveQuadTo(13.18f, 6.5f)
            quadToRelative(-0.5f, 0f, -0.81f, -0.38f)
            reflectiveQuadTo(12.2f, 5.32f)
            quadTo(12.55f, 4.27f, 13.46f, 3.64f)
            reflectiveQuadTo(15.5f, 3f)
            quadToRelative(1.45f, 0f, 2.48f, 1.02f)
            reflectiveQuadTo(19f, 6.5f)
            reflectiveQuadTo(17.98f, 8.98f)
            reflectiveQuadTo(15.5f, 10f)
            horizontalLineTo(3f)
            close()
            moveToRelative(16.95f, 7.7f)
            quadToRelative(-0.5f, 0.23f, -0.98f, -0.06f)
            reflectiveQuadTo(18.5f, 16.8f)
            quadToRelative(0f, -0.35f, 0.24f, -0.59f)
            quadToRelative(0.24f, -0.24f, 0.54f, -0.41f)
            quadToRelative(0.35f, -0.2f, 0.54f, -0.55f)
            reflectiveQuadTo(20f, 14.5f)
            quadToRelative(0f, -0.63f, -0.44f, -1.06f)
            reflectiveQuadTo(18.5f, 13f)
            horizontalLineTo(3f)
            quadTo(2.58f, 13f, 2.29f, 12.71f)
            quadTo(2f, 12.43f, 2f, 12f)
            reflectiveQuadTo(2.29f, 11.29f)
            reflectiveQuadTo(3f, 11f)
            horizontalLineTo(18.5f)
            quadToRelative(1.45f, 0f, 2.48f, 1.02f)
            reflectiveQuadTo(22f, 14.5f)
            quadToRelative(0f, 1.05f, -0.55f, 1.91f)
            quadToRelative(-0.55f, 0.86f, -1.5f, 1.29f)
            close()
          }
        }
        .buildSimpIcon()
    return _Air!!
  }

private var _Air: ImageVector? = null
