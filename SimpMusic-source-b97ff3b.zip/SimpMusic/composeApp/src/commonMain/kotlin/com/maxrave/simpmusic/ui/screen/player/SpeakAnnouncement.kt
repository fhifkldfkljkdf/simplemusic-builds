package com.maxrave.simpmusic.ui.screen.player

import kotlinx.coroutines.flow.StateFlow

/**
 * Reads [text] out loud where the platform can (Android's TextToSpeech). A no-op elsewhere, so a
 * caller never needs to know which platform it runs on; it must never throw.
 */
expect fun speakAnnouncement(text: String)

/**
 * Announces a new noise-cancelling strength, 0..100. Android plays a bundled, pre-rendered neural
 * voice clip for [percent]; [fallbackText] is what it says through the system text-to-speech
 * engine when those clips are missing or cannot be played. A no-op elsewhere, so a caller never
 * needs to know which platform it runs on; it must never throw.
 */
expect fun announceAncStrength(
    percent: Int,
    fallbackText: String,
)

/**
 * Whether [speakAnnouncement] can actually be heard: `null` while that is not known yet, `true`
 * when a text-to-speech engine with voice data is there, `false` when there is none. The first call
 * kicks off a cheap probe; it must never throw.
 */
expect fun speechAvailability(): StateFlow<Boolean?>
