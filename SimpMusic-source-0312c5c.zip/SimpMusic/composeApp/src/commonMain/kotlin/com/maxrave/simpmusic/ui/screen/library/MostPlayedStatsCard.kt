package com.maxrave.simpmusic.ui.screen.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maxrave.domain.data.model.library.MostPlayedStats
import com.maxrave.simpmusic.ui.component.taste.libraryCardColor
import com.maxrave.simpmusic.ui.theme.appCorner
import com.maxrave.simpmusic.ui.theme.typo
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.artists
import simpmusic.composeapp.generated.resources.lower_plays
import simpmusic.composeapp.generated.resources.most_played_listening_time
import simpmusic.composeapp.generated.resources.most_played_plays
import simpmusic.composeapp.generated.resources.most_played_top_artist

/**
 * The figures above the Most played list: plays, listening time and artists, then the artist the
 * list leans on most. Read from the list's own rows (see [MostPlayedStats]), so it always agrees
 * with what is shown below it.
 */
@Composable
internal fun MostPlayedStatsCard(
    stats: MostPlayedStats,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .background(libraryCardColor(), appCorner(20.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            StatColumn(stats.plays.toString(), stringResource(Res.string.most_played_plays), Modifier.weight(1f))
            StatColumn(
                "≈ ${listeningTimeText(stats.approxSeconds)}",
                stringResource(Res.string.most_played_listening_time),
                Modifier.weight(1.4f),
            )
            StatColumn(stats.artists.toString(), stringResource(Res.string.artists), Modifier.weight(1f))
        }
        stats.topArtist?.let { artist ->
            Text(
                text =
                    "${stringResource(Res.string.most_played_top_artist, artist)} · " +
                        "${stats.topArtistPlays} ${stringResource(Res.string.lower_plays)}",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun StatColumn(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.Start) {
        Text(
            text = value,
            style = typo().titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
        Text(
            text = label,
            style = typo().bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** "38 h 12 m", or "45 m" under an hour. */
internal fun listeningTimeText(seconds: Long): String {
    val minutes = seconds / 60
    val hours = minutes / 60
    return if (hours > 0) "$hours h ${minutes % 60} m" else "$minutes m"
}
