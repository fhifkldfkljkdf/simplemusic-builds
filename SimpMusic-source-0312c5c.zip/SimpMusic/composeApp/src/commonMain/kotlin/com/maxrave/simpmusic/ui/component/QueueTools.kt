package com.maxrave.simpmusic.ui.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.mediaservice.handler.MediaPlayerHandler
import com.maxrave.domain.mediaservice.handler.QueueData
import com.maxrave.domain.mediaservice.handler.RadioCurator
import com.maxrave.domain.mediaservice.handler.RadioFeedback
import com.maxrave.domain.mediaservice.handler.RadioFeedbackAction
import com.maxrave.domain.mediaservice.handler.RadioRecap
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.icon.ThumbDownOutline
import com.maxrave.simpmusic.viewModel.SharedViewModel
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.close
import simpmusic.composeapp.generated.resources.error
import simpmusic.composeapp.generated.resources.liked
import simpmusic.composeapp.generated.resources.queue_restore_previous
import simpmusic.composeapp.generated.resources.queue_undo
import simpmusic.composeapp.generated.resources.radio_feedback_artist
import simpmusic.composeapp.generated.resources.radio_feedback_body
import simpmusic.composeapp.generated.resources.radio_feedback_hide
import simpmusic.composeapp.generated.resources.radio_feedback_song
import simpmusic.composeapp.generated.resources.radio_feedback_title
import simpmusic.composeapp.generated.resources.radio_recap_finished
import simpmusic.composeapp.generated.resources.radio_recap_played
import simpmusic.composeapp.generated.resources.radio_recap_save
import simpmusic.composeapp.generated.resources.radio_recap_saved
import simpmusic.composeapp.generated.resources.radio_recap_skipped
import simpmusic.composeapp.generated.resources.radio_recap_summary
import simpmusic.composeapp.generated.resources.radio_recap_title
import kotlin.time.Clock

@Composable
internal fun QueueTools(
    handler: MediaPlayerHandler,
    modifier: Modifier = Modifier,
    viewModel: SharedViewModel = koinInject(),
) {
    val queue by handler.queueData.collectAsState()
    val edit by handler.queueHistory.edit.collectAsState()
    val previous by handler.queueHistory.previous.collectAsState()
    val songs by handler.radioRecap.songs.collectAsState()
    val ready = queue?.queueState == QueueData.StateSource.STATE_INITIALIZED
    val canUndo = ready && edit?.matches(queue?.data?.listTracks.orEmpty()) == true
    val canRestore = ready && previous?.let { it.replacementId == queue?.data?.playlistId } == true
    var showRecap by remember { mutableStateOf(false) }
    if (canUndo || canRestore || songs.isNotEmpty()) {
        FlowRow(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (canUndo) TextButton(onClick = handler::undoQueueEdit) { Text(stringResource(Res.string.queue_undo)) }
            if (canRestore) TextButton(onClick = handler::restorePreviousQueue) { Text(stringResource(Res.string.queue_restore_previous)) }
            if (songs.isNotEmpty()) TextButton(onClick = { showRecap = true }) { Text(stringResource(Res.string.radio_recap_title)) }
        }
    }
    if (showRecap) RadioRecapDialog(songs, viewModel::saveRadioRecapPlaylist, onDismiss = { showRecap = false })
}

@Composable
internal fun RadioFeedbackButton(
    track: Track,
    dataStoreManager: DataStoreManager = koinInject(),
) {
    var showing by remember(track) { mutableStateOf(false) }
    ActionButton(icon = SimpIcons.ThumbDownOutline, text = Res.string.radio_feedback_title) { showing = true }
    if (!showing) return
    val feedback by dataStoreManager.radioFeedback.collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    val now = Clock.System.now().epochSeconds
    AlertDialog(
        onDismissRequest = { showing = false },
        title = { Text(stringResource(Res.string.radio_feedback_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(track.title, style = MaterialTheme.typography.titleSmall)
                Text(stringResource(Res.string.radio_feedback_body))
                val options = listOf(
                    RadioFeedbackAction.LESS_SONG to Res.string.radio_feedback_song,
                    RadioFeedbackAction.COOL_DOWN_ARTIST to Res.string.radio_feedback_artist,
                    RadioFeedbackAction.HIDE_VERSION to Res.string.radio_feedback_hide,
                )
                options.forEach { (action, label) ->
                    if (action != RadioFeedbackAction.COOL_DOWN_ARTIST || RadioCurator.artistKey(track).isNotBlank()) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(stringResource(label), modifier = Modifier.weight(1f))
                            Switch(
                                checked = (feedback ?: RadioFeedback()).has(track, action, now),
                                enabled = feedback != null,
                                onCheckedChange = { scope.launch { dataStoreManager.toggleRadioFeedback(track, action, Clock.System.now().epochSeconds) } },
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showing = false }) { Text(stringResource(Res.string.close)) } },
    )
}

@Composable
private fun RadioRecapDialog(
    songs: List<RadioRecap.Entry>,
    onSave: suspend (List<RadioRecap.Entry>) -> Boolean,
    onDismiss: () -> Unit,
) {
    var saving by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf<Boolean?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(Res.string.radio_recap_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    stringResource(
                        Res.string.radio_recap_summary,
                        songs.count { it.outcome == RadioRecap.Outcome.FINISHED },
                        songs.count { it.liked },
                        songs.count { it.outcome == RadioRecap.Outcome.SKIPPED },
                    ),
                )
                songs.forEach { song ->
                    Column {
                        Text(song.track.title, style = MaterialTheme.typography.titleSmall)
                        val outcome = when (song.outcome) {
                            RadioRecap.Outcome.FINISHED -> Res.string.radio_recap_finished
                            RadioRecap.Outcome.PLAYED -> Res.string.radio_recap_played
                            RadioRecap.Outcome.SKIPPED -> Res.string.radio_recap_skipped
                        }
                        val status = stringResource(outcome)
                        Text(if (song.liked) "$status · ${stringResource(Res.string.liked)}" else status)
                    }
                }
                saved?.let { Text(stringResource(if (it) Res.string.radio_recap_saved else Res.string.error)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(Res.string.close)) } },
        dismissButton = {
            if (songs.any { it.liked }) {
                TextButton(
                    enabled = !saving && saved != true,
                    onClick = {
                        saving = true
                        scope.launch {
                            try {
                                saved = onSave(songs)
                            } finally {
                                saving = false
                            }
                        }
                    },
                ) { Text(stringResource(Res.string.radio_recap_save)) }
            }
        },
    )
}
