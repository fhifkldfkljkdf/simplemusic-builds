package com.maxrave.simpmusic.ui.screen.player

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Desktop has no voice to speak with, so there is never an announcement to hear. */
private val NO_SPEECH: StateFlow<Boolean?> = MutableStateFlow<Boolean?>(false)

actual fun speakAnnouncement(text: String) = Unit

actual fun announceAncStrength(
    percent: Int,
    fallbackText: String,
) = Unit

actual fun speechAvailability(): StateFlow<Boolean?> = NO_SPEECH
