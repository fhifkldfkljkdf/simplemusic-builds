"use client";

import React from "react";
import Link from "next/link";
import { Icon } from "./Icons";
import { LikeButton } from "./LikeButton";
import { usePlayer } from "./player/PlayerProvider";
import type { Card, Shelf } from "@/lib/types";

export function cardHref(card: Card): string | null {
  switch (card.kind) {
    case "album":
      return `/album/${encodeURIComponent(card.id)}`;
    case "artist":
      return `/artist/${encodeURIComponent(card.id)}`;
    case "playlist":
      return `/playlist/${encodeURIComponent(card.id)}`;
    case "genre":
      return `/browse?browseId=${encodeURIComponent(card.id)}&params=${encodeURIComponent(card.params ?? "")}&title=${encodeURIComponent(card.title)}`;
    default:
      return null;
  }
}

export function MediaCard({ card, circular = false }: { card: Card; circular?: boolean }) {
  const href = cardHref(card);
  const content = (
    <div className="group w-full">
      <div
        className={`relative mb-3 aspect-square w-full overflow-hidden bg-elevated ${circular ? "rounded-full" : "rounded-lg"}`}
      >
        {card.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={card.thumbnail}
            alt=""
            loading="lazy"
            className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-muted">
            <Icon name={card.kind === "artist" ? "music" : "queue"} size={32} />
          </div>
        )}
      </div>
      <p className="truncate text-sm font-medium text-white" title={card.title}>
        {card.title}
      </p>
      {card.subtitle ? (
        <p className="truncate text-xs text-muted" title={card.subtitle}>
          {card.subtitle}
        </p>
      ) : null}
    </div>
  );
  return href ? (
    <Link href={href} className="block">
      {content}
    </Link>
  ) : (
    content
  );
}

export function SongCard({ card }: { card: Card }) {
  const { playTrack, current, playNext, addToQueue, endlessQueue } = usePlayer();
  const track = card.track;
  if (!track) return null;
  const active = current?.videoId === track.videoId;
  return (
    <div className="group w-full">
      <div className="relative mb-3 aspect-square w-full overflow-hidden rounded-lg bg-elevated">
        {card.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={card.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <div className="grid h-full w-full place-items-center text-muted">
            <Icon name="music" size={32} />
          </div>
        )}
        <button
          type="button"
          aria-label={`Play ${track.title}`}
          className="absolute bottom-2 right-2 grid h-10 w-10 place-items-center rounded-full bg-accent text-white opacity-0 shadow-lg transition group-hover:opacity-100 focus:opacity-100"
          onClick={() => playTrack(track)}
        >
          <Icon name="play" size={20} />
        </button>
        <div className="absolute right-2 top-2 flex items-center gap-1 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:focus-within:opacity-100">
          <button
            type="button"
            className="icon-btn h-8 w-8 bg-black/55"
            title="Play next"
            aria-label="Play next"
            onClick={(event) => {
              event.stopPropagation();
              playNext(track);
            }}
          >
            <Icon name="queue_play_next" size={16} />
          </button>
          {!endlessQueue ? (
            <button
              type="button"
              className="icon-btn h-8 w-8 bg-black/55"
              title="Add to queue"
              aria-label="Add to queue"
              onClick={(event) => {
                event.stopPropagation();
                addToQueue(track);
              }}
            >
              <Icon name="queue_add" size={16} />
            </button>
          ) : null}
        </div>
        <div className="absolute left-1 top-1 opacity-0 transition group-hover:opacity-100">
          <LikeButton track={track} size={16} className="bg-black/50" />
        </div>
      </div>
      <p className={`truncate text-sm font-medium ${active ? "text-accent" : "text-white"}`} title={track.title}>
        {track.title}
      </p>
      <p className="truncate text-xs text-muted">{card.subtitle ?? ""}</p>
    </div>
  );
}

export function CardItem({ card }: { card: Card }) {
  if ((card.kind === "song" || card.kind === "video") && card.track) return <SongCard card={card} />;
  return <MediaCard card={card} circular={card.kind === "artist"} />;
}

export function CardGrid({ items }: { items: Card[] }) {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-6 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
      {items.map((card, index) => (
        <CardItem key={`${card.kind}-${card.id}-${index}`} card={card} />
      ))}
    </div>
  );
}

export function ShelfRow({ shelf }: { shelf: Shelf }) {
  if (!shelf.items.length) return null;
  return (
    <section className="mb-9">
      {shelf.title ? <h2 className="mb-4 text-xl font-bold text-white">{shelf.title}</h2> : null}
      <div className="-mx-1 flex gap-4 overflow-x-auto px-1 pb-2 [scrollbar-width:thin]">
        {shelf.items.map((card, index) => (
          <div key={`${card.kind}-${card.id}-${index}`} className="w-36 shrink-0 sm:w-40 lg:w-44">
            <CardItem card={card} />
          </div>
        ))}
      </div>
    </section>
  );
}
