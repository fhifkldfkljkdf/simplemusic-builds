package com.maxrave.simpmusic.ui.screen.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maxrave.domain.data.model.headset.AntiWindMode
import com.maxrave.domain.data.model.headset.HeadsetBattery
import com.maxrave.domain.data.model.headset.HeadsetConnection
import com.maxrave.domain.data.model.headset.HeadsetState
import com.maxrave.domain.data.model.headset.NoiseLevel
import com.maxrave.domain.data.model.headset.NoiseMode
import com.maxrave.domain.repository.HeadsetRepository
import com.maxrave.simpmusic.expect.ui.rememberBluetoothPermission
import com.maxrave.simpmusic.ui.component.rememberSurfaceDarkColors
import com.maxrave.simpmusic.ui.icon.Air
import com.maxrave.simpmusic.ui.icon.Headphones
import com.maxrave.simpmusic.ui.icon.NoiseAware
import com.maxrave.simpmusic.ui.icon.NoiseControlOff
import com.maxrave.simpmusic.ui.icon.NoiseControlOn
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.typo
import kotlinx.coroutines.delay
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.headset_adaptive
import simpmusic.composeapp.generated.resources.headset_adaptive_anc
import simpmusic.composeapp.generated.resources.headset_adaptive_description
import simpmusic.composeapp.generated.resources.headset_anc
import simpmusic.composeapp.generated.resources.headset_anc_off
import simpmusic.composeapp.generated.resources.headset_battery
import simpmusic.composeapp.generated.resources.headset_anc_description
import simpmusic.composeapp.generated.resources.headset_no_noise_control
import simpmusic.composeapp.generated.resources.headset_level_voice_boost
import simpmusic.composeapp.generated.resources.headset_level_dynamic
import simpmusic.composeapp.generated.resources.headset_level_ultra
import simpmusic.composeapp.generated.resources.headset_level_normal
import simpmusic.composeapp.generated.resources.headset_level_comfort
import simpmusic.composeapp.generated.resources.headset_battery_case
import simpmusic.composeapp.generated.resources.headset_battery_right
import simpmusic.composeapp.generated.resources.headset_battery_left
import simpmusic.composeapp.generated.resources.headset_change_failed
import simpmusic.composeapp.generated.resources.headset_charging
import simpmusic.composeapp.generated.resources.headset_connecting
import simpmusic.composeapp.generated.resources.headset_failed
import simpmusic.composeapp.generated.resources.headset_noise_control
import simpmusic.composeapp.generated.resources.headset_off
import simpmusic.composeapp.generated.resources.headset_off_description
import simpmusic.composeapp.generated.resources.headset_permission_allow
import simpmusic.composeapp.generated.resources.headset_permission_denied
import simpmusic.composeapp.generated.resources.headset_permission_description
import simpmusic.composeapp.generated.resources.headset_permission_title
import simpmusic.composeapp.generated.resources.headset_retry
import simpmusic.composeapp.generated.resources.headset_strength
import simpmusic.composeapp.generated.resources.headset_transparency
import simpmusic.composeapp.generated.resources.headset_transparency_description
import simpmusic.composeapp.generated.resources.headset_transparent_short
import simpmusic.composeapp.generated.resources.headset_wind
import simpmusic.composeapp.generated.resources.headset_wind_auto
import simpmusic.composeapp.generated.resources.headset_wind_max
import simpmusic.composeapp.generated.resources.headset_wind_off
import kotlin.math.roundToInt

/** What the player's headset pill shows. Private copy. */
@Immutable
data class HeadsetBadge(
    val label: String,
    val icon: ImageVector,
    /** Not connected (yet): drawn dimmer. */
    val inactive: Boolean,
)

/** The pill for [state], or null when no supported headphones are the audio output. */
@Composable
fun rememberHeadsetBadge(state: HeadsetState): HeadsetBadge? {
    val name = state.name ?: return null
    if (state.connection == HeadsetConnection.NONE) return null
    if (state.connection != HeadsetConnection.CONNECTED) return HeadsetBadge(name, SimpIcons.Headphones, inactive = true)
    // Earbuds without noise control the app can change still show their battery.
    val noise = state.noise ?: return HeadsetBadge(batteryText(state.battery, withCase = false) ?: name, SimpIcons.Headphones, false)
    val mode = state.pendingMode ?: noise.mode
    // While a switch is under way, the strength and step are still the old mode's: leave them out.
    val settled = mode == noise.mode
    val level = noise.level?.takeIf { settled }
    return when (mode) {
        NoiseMode.ANC -> {
            val anc = stringResource(Res.string.headset_anc)
            val detail =
                when {
                    noise.strength != null && settled -> "${noise.strength}%"
                    level != null -> levelLabel(level)
                    else -> null
                }
            HeadsetBadge(if (detail != null) "$anc $detail" else anc, SimpIcons.NoiseControlOn, false)
        }
        NoiseMode.ADAPTIVE -> HeadsetBadge(stringResource(Res.string.headset_adaptive_anc), SimpIcons.NoiseControlOn, false)
        NoiseMode.TRANSPARENCY ->
            HeadsetBadge(
                if (level == NoiseLevel.VOICE_BOOST) levelLabel(level) else stringResource(Res.string.headset_transparency),
                SimpIcons.NoiseAware,
                false,
            )
        NoiseMode.OFF -> HeadsetBadge(stringResource(Res.string.headset_anc_off), SimpIcons.NoiseControlOff, false)
    }
}

/** "L 80% · R 75% · Case 40%" for earbuds, "80%" for one value; null when nothing is known. */
@Composable
private fun batteryText(
    battery: HeadsetBattery,
    withCase: Boolean,
): String? {
    val parts =
        if (battery.left != null || battery.right != null) {
            listOfNotNull(
                battery.left?.let { stringResource(Res.string.headset_battery_left, "$it%") },
                battery.right?.let { stringResource(Res.string.headset_battery_right, "$it%") },
                battery.case?.takeIf { withCase }?.let { stringResource(Res.string.headset_battery_case, "$it%") },
            )
        } else {
            listOfNotNull(battery.percent?.let { "$it%" })
        }
    return parts.takeIf { it.isNotEmpty() }?.joinToString(" · ")
}

@Composable
private fun levelLabel(level: NoiseLevel): String =
    stringResource(
        when (level) {
            NoiseLevel.COMFORT -> Res.string.headset_level_comfort
            NoiseLevel.NORMAL -> Res.string.headset_level_normal
            NoiseLevel.ULTRA -> Res.string.headset_level_ultra
            NoiseLevel.DYNAMIC -> Res.string.headset_level_dynamic
            NoiseLevel.VOICE_BOOST -> Res.string.headset_level_voice_boost
        },
    )

/** A small translucent pill in the style of the source pill beside it. */
@Composable
internal fun HeadsetPill(
    badge: HeadsetBadge,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundAlpha: Float = 0.14f,
) {
    val tint = contentColor.copy(alpha = if (badge.inactive) 0.6f else 0.9f)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .clip(RoundedCornerShape(9.dp))
                .background(contentColor.copy(alpha = backgroundAlpha))
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Icon(imageVector = badge.icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = badge.label,
            style = typo().labelSmall.copy(color = tint),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * Noise control of the connected headphones: the modes they have, the cancelling strength or its
 * steps, wind noise reduction where there is one, and the battery. Private copy.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeadsetSheet(
    onDismiss: () -> Unit,
    headsetRepository: HeadsetRepository = koinInject(),
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val state by headsetRepository.state.collectAsStateWithLifecycle()
    val colors = rememberSurfaceDarkColors()
    var permissionDenied by remember { mutableStateOf(false) }
    val requestPermission =
        rememberBluetoothPermission { granted ->
            permissionDenied = !granted
            if (granted) headsetRepository.retry()
        }
    // A headset that disconnects while the sheet is open takes the sheet with it.
    LaunchedEffect(state.connection) {
        if (state.connection == HeadsetConnection.NONE) onDismiss()
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.Transparent,
        contentColor = Color.Transparent,
        dragHandle = {},
        scrimColor = Color.Black.copy(alpha = .5f),
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) },
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors().copy(containerColor = colors.container),
        ) {
            Column(
                modifier =
                    Modifier
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp)
                        .padding(top = 20.dp, bottom = 16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(SimpIcons.Headphones, contentDescription = null, tint = colors.content, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = state.name.orEmpty(),
                        style = typo().titleMedium,
                        color = colors.content,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    batteryText(state.battery, withCase = true)?.let { battery ->
                        val charging = if (state.battery.charging == true) " · ${stringResource(Res.string.headset_charging)}" else ""
                        Text(
                            text = stringResource(Res.string.headset_battery, battery) + charging,
                            style = typo().bodySmall,
                            color = colors.subtitle,
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                when (state.connection) {
                    HeadsetConnection.CONNECTED ->
                        if (state.noise != null) {
                            NoiseControls(state, headsetRepository)
                        } else {
                            Description(stringResource(Res.string.headset_no_noise_control))
                        }
                    HeadsetConnection.NEEDS_PERMISSION -> {
                        Text(
                            text = stringResource(Res.string.headset_permission_title, state.name.orEmpty()),
                            style = typo().labelMedium,
                            color = colors.content,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text =
                                stringResource(
                                    if (permissionDenied) Res.string.headset_permission_denied else Res.string.headset_permission_description,
                                ),
                            style = typo().bodySmall,
                            color = colors.subtitle,
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = requestPermission) { Text(stringResource(Res.string.headset_permission_allow)) }
                    }
                    HeadsetConnection.FAILED -> {
                        Text(text = stringResource(Res.string.headset_failed), style = typo().bodySmall, color = colors.subtitle)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { headsetRepository.retry() }) { Text(stringResource(Res.string.headset_retry)) }
                    }
                    HeadsetConnection.CONNECTING, HeadsetConnection.NONE ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = colors.content)
                            Spacer(Modifier.width(12.dp))
                            Text(text = stringResource(Res.string.headset_connecting), style = typo().bodySmall, color = colors.subtitle)
                        }
                }
            }
        }
    }
}

@Composable
private fun NoiseControls(
    state: HeadsetState,
    repository: HeadsetRepository,
) {
    val colors = rememberSurfaceDarkColors()
    val noise = state.noise ?: return
    val mode = state.pendingMode ?: noise.mode

    Text(text = stringResource(Res.string.headset_noise_control), style = typo().labelMedium, color = colors.subtitle)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        for (option in noise.modes) {
            ModeTile(
                icon =
                    when (option) {
                        NoiseMode.ANC, NoiseMode.ADAPTIVE -> SimpIcons.NoiseControlOn
                        NoiseMode.TRANSPARENCY -> SimpIcons.NoiseAware
                        NoiseMode.OFF -> SimpIcons.NoiseControlOff
                    },
                label =
                    stringResource(
                        when (option) {
                            NoiseMode.ANC -> Res.string.headset_anc
                            NoiseMode.ADAPTIVE -> Res.string.headset_adaptive
                            NoiseMode.TRANSPARENCY -> Res.string.headset_transparent_short
                            NoiseMode.OFF -> Res.string.headset_off
                        },
                    ),
                selected = mode == option,
                busy = state.pendingMode == option,
                onClick = { if (mode != option) repository.setMode(option) },
                modifier = Modifier.weight(1f),
            )
        }
    }
    Spacer(Modifier.height(16.dp))

    // Steps belong to the mode the headphones report, not to one still being switched to.
    val levels = if (mode == noise.mode) noise.levels else emptyList()
    val strength = noise.strength
    when {
        mode == NoiseMode.ANC && strength != null -> {
            // The slider keeps the value being dragged until the headset reports it back, so it
            // does not jump to the old strength between the drag and the headset's answer.
            var dragged by remember { mutableStateOf<Float?>(null) }
            LaunchedEffect(strength, dragged) {
                val target = dragged ?: return@LaunchedEffect
                if (target.roundToInt() == strength) {
                    dragged = null
                } else {
                    delay(2_000)
                    dragged = null
                }
            }
            val value = dragged ?: strength.toFloat()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(Res.string.headset_strength),
                    style = typo().labelMedium,
                    color = colors.content,
                    modifier = Modifier.weight(1f),
                )
                Text(text = "${value.roundToInt()}%", style = typo().bodySmall, color = colors.subtitle)
            }
            Slider(
                value = value,
                onValueChange = {
                    dragged = it
                    repository.setStrength(it.roundToInt())
                },
                valueRange = 0f..100f,
                colors =
                    SliderDefaults.colors(
                        thumbColor = colors.content,
                        activeTrackColor = colors.content,
                        inactiveTrackColor = colors.content.copy(alpha = 0.2f),
                    ),
            )
        }
        levels.isNotEmpty() -> {
            Text(
                text = stringResource(if (mode == NoiseMode.ANC) Res.string.headset_strength else Res.string.headset_transparency),
                style = typo().labelMedium,
                color = colors.content,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for (option in levels) {
                    ChoiceChip(
                        label = levelLabel(option),
                        selected = noise.level == option,
                        onClick = { if (noise.level != option) repository.setLevel(option) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            if (noise.level == NoiseLevel.DYNAMIC) {
                Spacer(Modifier.height(8.dp))
                Description(stringResource(Res.string.headset_adaptive_description))
            }
        }
        mode == NoiseMode.ANC -> Description(stringResource(Res.string.headset_anc_description))
        mode == NoiseMode.ADAPTIVE -> Description(stringResource(Res.string.headset_adaptive_description))
        mode == NoiseMode.TRANSPARENCY -> Description(stringResource(Res.string.headset_transparency_description))
        else -> Description(stringResource(Res.string.headset_off_description))
    }

    val antiWind = noise.antiWind
    if (antiWind != null && mode != NoiseMode.OFF) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(SimpIcons.Air, contentDescription = null, tint = colors.subtitle, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(text = stringResource(Res.string.headset_wind), style = typo().labelMedium, color = colors.subtitle)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            for ((option, label) in
                listOf(
                    AntiWindMode.OFF to stringResource(Res.string.headset_wind_off),
                    AntiWindMode.MAXIMUM to stringResource(Res.string.headset_wind_max),
                    AntiWindMode.AUTOMATIC to stringResource(Res.string.headset_wind_auto),
                )) {
                ChoiceChip(
                    label = label,
                    selected = antiWind == option,
                    onClick = { if (antiWind != option) repository.setAntiWind(option) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    if (state.actionFailed) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(Res.string.headset_change_failed),
            style = typo().bodySmall,
            color = MaterialTheme.colorScheme.error,
        )
    }
}

@Composable
private fun Description(text: String) {
    Text(text = text, style = typo().bodySmall, color = rememberSurfaceDarkColors().subtitle)
}

@Composable
private fun ModeTile(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = rememberSurfaceDarkColors()
    val foreground = if (selected) colors.container else colors.content
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier =
            modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) colors.content else colors.content.copy(alpha = 0.08f))
                .clickable(onClick = onClick)
                .padding(vertical = 12.dp, horizontal = 4.dp),
    ) {
        Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = foreground)
            } else {
                Icon(icon, contentDescription = null, tint = foreground, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            style = typo().labelSmall,
            color = foreground,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ChoiceChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = rememberSurfaceDarkColors()
    Box(
        contentAlignment = Alignment.Center,
        modifier =
            modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (selected) colors.content else colors.content.copy(alpha = 0.08f))
                .clickable(onClick = onClick)
                .padding(vertical = 10.dp),
    ) {
        Text(
            text = label,
            style = typo().labelSmall,
            color = if (selected) colors.container else colors.content,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
