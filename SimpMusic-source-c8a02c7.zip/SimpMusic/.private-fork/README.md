# Private copy of SimpMusic

This repository is a private copy of [maxrave-dev/SimpMusic](https://github.com/maxrave-dev/SimpMusic)
and of its `core` submodule, [maxrave-dev/core](https://github.com/maxrave-dev/core).
It is not a GitHub fork (forks of public repositories cannot be private), and it
never sends pull requests or pushes to the original repositories.

## Branches

| Branch          | What it is                                                                 |
|-----------------|----------------------------------------------------------------------------|
| `main`          | This copy. Upstream updates are merged in here; your own changes go here.  |
| `upstream-main` | Read-only mirror of upstream `main`. Only `sync-upstream.sh` updates it.    |
| `core-main`     | This copy's `core`. The `core` submodule of `main` is cloned from here.    |
| `core-upstream` | Read-only mirror of maxrave-dev/core `multiplatform`. Only the script.      |

`upstream-main` is upstream `main` with `.github/workflows/` removed from every
commit. Everything else, including the commit history, matches upstream.
Upstream's workflows build and sign release APKs with the maintainer's secrets,
so they could not run here anyway.

## Getting the latest upstream code

```sh
.private-fork/sync-upstream.sh            # fetch, filter, merge into main, push
.private-fork/sync-upstream.sh --no-push  # same, but only show what would change
```

The script merges `core-upstream` into `core-main` and points `main`'s `core`
submodule at the result. It stops without pushing `main` or `core-main` if a merge
conflicts or if either mirror no longer lines up with its upstream.

## Working on `core`

`.gitmodules` points the submodule at this same repository (`../simplemusic.git`,
branch `core-main`), so it needs no extra access. After cloning:

```sh
git submodule update --init core   # shallow (see .gitmodules): one snapshot, not the app history
```

To change `core`: commit inside `core/` on `core-main`, push it
(`git -C core push origin HEAD:core-main`), then commit the new `core` pointer in
the main repository.
