#!/usr/bin/env bash
# Pull the latest maxrave-dev/SimpMusic and maxrave-dev/core code into this private copy.
#
#   SimpMusic main --(strip .github/workflows/)--> upstream-main --(merge)--> main
#   core multiplatform ---------------------------> core-upstream --(merge)--> core-main
#   main's `core` submodule always points at the tip of core-main
#
# upstream-main is a read-only mirror of upstream with the CI workflow files
# removed from every commit (the push token we use cannot write workflow files,
# and upstream's release workflows need the maintainer's secrets anyway).
# The filter is deterministic for a pinned git-filter-repo version, so each run
# re-creates the same commit IDs and upstream-main only ever fast-forwards.
#
# core-upstream is an unfiltered mirror of maxrave-dev/core (it has no workflow
# files). core-main is this copy's own core; the `core` submodule of main is
# cloned from core-main of this same repository (see .gitmodules).
#
# Nothing is ever pushed to maxrave-dev/SimpMusic or maxrave-dev/core.
#
# Usage: .private-fork/sync-upstream.sh [--no-push]
set -euo pipefail

UPSTREAM_URL=https://github.com/maxrave-dev/SimpMusic.git
UPSTREAM_BRANCH=main
MIRROR_BRANCH=upstream-main
TARGET_BRANCH=main
CORE_UPSTREAM_URL=https://github.com/maxrave-dev/core.git
CORE_UPSTREAM_BRANCH=multiplatform
CORE_MIRROR_BRANCH=core-upstream
CORE_BRANCH=core-main
FILTER_REPO_VERSION=2.47.0  # changing this can change commit IDs; see guard below

push=1
[ "${1:-}" = "--no-push" ] && push=0

repo=$(git rev-parse --show-toplevel)
work=$(mktemp -d)
cleanup() {
  git -C "$repo" worktree remove --force "$work/main" 2>/dev/null || true
  git -C "$repo" worktree remove --force "$work/core" 2>/dev/null || true
  rm -rf "$work"
}
trap cleanup EXIT

# Pushes the two read-only mirrors, so a human can finish a failed merge by hand.
push_mirrors() {
  if [ "$push" = 1 ]; then
    git -C "$repo" push --atomic origin "$new:refs/heads/$MIRROR_BRANCH" "$core_new:refs/heads/$CORE_MIRROR_BRANCH"
  fi
}

echo "==> Installing git-filter-repo $FILTER_REPO_VERSION"
# Prefer a git-filter-repo already on the machine (or in ~/.local/bin): the container's
# python3 has no ensurepip, so the venv below cannot be built there. The mirror guard after
# the filtering catches a wrong version: its commit IDs would not contain the old mirror.
filter_repo=$(command -v git-filter-repo || true)
if [ -z "$filter_repo" ] && [ -x "$HOME/.local/bin/git-filter-repo" ]; then
  filter_repo="$HOME/.local/bin/git-filter-repo"
fi
if [ -z "$filter_repo" ]; then
  python3 -m venv "$work/venv"
  "$work/venv/bin/pip" install --quiet "git-filter-repo==$FILTER_REPO_VERSION"
  filter_repo="$work/venv/bin/git-filter-repo"
fi

echo "==> Fetching $UPSTREAM_URL $UPSTREAM_BRANCH and $CORE_UPSTREAM_URL $CORE_UPSTREAM_BRANCH"
git -C "$repo" fetch --no-tags "$UPSTREAM_URL" "+$UPSTREAM_BRANCH:refs/sync/upstream-src"
git -C "$repo" fetch --no-tags "$CORE_UPSTREAM_URL" "+$CORE_UPSTREAM_BRANCH:refs/sync/core-src"
git -C "$repo" fetch --no-tags origin \
  "+refs/heads/$MIRROR_BRANCH:refs/remotes/origin/$MIRROR_BRANCH" \
  "+refs/heads/$TARGET_BRANCH:refs/remotes/origin/$TARGET_BRANCH" \
  "+refs/heads/$CORE_MIRROR_BRANCH:refs/remotes/origin/$CORE_MIRROR_BRANCH" \
  "+refs/heads/$CORE_BRANCH:refs/remotes/origin/$CORE_BRANCH"
upstream_sha=$(git -C "$repo" rev-parse refs/sync/upstream-src)

echo "==> Stripping .github/workflows/ from upstream history"
git init --bare --quiet "$work/filtered.git"
git -C "$work/filtered.git" fetch --quiet --no-tags "$repo" "refs/sync/upstream-src:refs/heads/main"
(cd "$work/filtered.git" && "$filter_repo" \
  --path .github/workflows/ --invert-paths --preserve-commit-hashes --force --quiet >/dev/null)
git -C "$repo" fetch --quiet --no-tags "$work/filtered.git" "+main:refs/sync/upstream-filtered"
new=$(git -C "$repo" rev-parse refs/sync/upstream-filtered)
old=$(git -C "$repo" rev-parse "origin/$MIRROR_BRANCH")
core_new=$(git -C "$repo" rev-parse refs/sync/core-src)
core_old=$(git -C "$repo" rev-parse "origin/$CORE_MIRROR_BRANCH")

# Both mirrors may only fast-forward. Anything else means upstream rewrote
# history (or the filter produced different IDs), and merging would duplicate it.
if ! git -C "$repo" merge-base --is-ancestor "$old" "$new"; then
  echo "ERROR: filtered upstream ($new) does not contain $MIRROR_BRANCH ($old)." >&2
  exit 1
fi
if ! git -C "$repo" merge-base --is-ancestor "$core_old" "$core_new"; then
  echo "ERROR: upstream core ($core_new) does not contain $CORE_MIRROR_BRANCH ($core_old)." >&2
  exit 1
fi
echo "==> $MIRROR_BRANCH: $(git -C "$repo" rev-list --count "$old..$new") new commits"
echo "==> $CORE_MIRROR_BRANCH: $(git -C "$repo" rev-list --count "$core_old..$core_new") new commits"

# The core commit upstream SimpMusic pins must be part of what we merge into
# core-main, or main would build against an older core than upstream expects.
wanted_core=$(git -C "$repo" rev-parse "$new:core")
if ! git -C "$repo" merge-base --is-ancestor "$wanted_core" "$core_new" 2>/dev/null; then
  echo "ERROR: upstream pins core at $wanted_core, which is not on $CORE_UPSTREAM_BRANCH ($core_new)." >&2
  exit 1
fi

echo "==> Merging $CORE_MIRROR_BRANCH into $CORE_BRANCH"
git -C "$repo" worktree add --quiet --detach "$work/core" "origin/$CORE_BRANCH"
if git -C "$work/core" merge-base --is-ancestor "$core_new" HEAD; then
  echo "==> $CORE_BRANCH already contains maxrave-dev/core@${core_new:0:12}"
elif ! git -C "$work/core" merge --no-edit --no-ff \
    -m "Merge upstream maxrave-dev/core@${core_new:0:12} into $CORE_BRANCH" "$core_new"; then
  git -C "$work/core" merge --abort
  push_mirrors
  echo "ERROR: merge conflict in core. $CORE_MIRROR_BRANCH was updated; merge it into $CORE_BRANCH by hand." >&2
  exit 1
fi
core_merged=$(git -C "$work/core" rev-parse HEAD)

echo "==> Merging into $TARGET_BRANCH"
git -C "$repo" worktree add --quiet --detach "$work/main" "origin/$TARGET_BRANCH"
if ! git -C "$work/main" merge-base --is-ancestor "$new" HEAD; then
  # --no-commit so the submodule pointer can be fixed up before committing: upstream
  # moves `core` to an upstream core commit, and this copy moves it to core-main,
  # so the two sides disagree on it every time upstream bumps core.
  git -C "$work/main" merge --no-commit --no-ff "$new" >/dev/null 2>&1 || true
  if ! git -C "$work/main" rev-parse -q --verify MERGE_HEAD >/dev/null; then
    echo "ERROR: could not start merging $MIRROR_BRANCH into $TARGET_BRANCH." >&2
    exit 1
  fi
  conflicts=$(git -C "$work/main" diff --name-only --diff-filter=U | grep -vx core || true)
  if [ -n "$conflicts" ]; then
    git -C "$work/main" merge --abort
    push_mirrors
    echo "ERROR: merge conflict in: $conflicts" >&2
    echo "       $MIRROR_BRANCH was updated; merge it into $TARGET_BRANCH by hand." >&2
    exit 1
  fi
  git -C "$work/main" update-index --cacheinfo "160000,$core_merged,core"
  git -C "$work/main" commit --quiet --no-edit \
    -m "Merge upstream maxrave-dev/SimpMusic@${upstream_sha:0:12} into $TARGET_BRANCH"
elif [ "$(git -C "$work/main" rev-parse HEAD:core)" != "$core_merged" ]; then
  echo "==> $TARGET_BRANCH already contains upstream $upstream_sha; only moving core"
  git -C "$work/main" update-index --cacheinfo "160000,$core_merged,core"
  git -C "$work/main" commit --quiet -m "Point core at $CORE_BRANCH@${core_merged:0:12}"
else
  echo "==> $TARGET_BRANCH already contains upstream $upstream_sha and $CORE_BRANCH"
fi
merged=$(git -C "$work/main" rev-parse HEAD)

if [ "$push" = 1 ]; then
  git -C "$repo" push --atomic origin \
    "$new:refs/heads/$MIRROR_BRANCH" \
    "$core_new:refs/heads/$CORE_MIRROR_BRANCH" \
    "$core_merged:refs/heads/$CORE_BRANCH" \
    "$merged:refs/heads/$TARGET_BRANCH"
  echo "==> Pushed. $TARGET_BRANCH is at $merged, $CORE_BRANCH at $core_merged"
  echo "    Run 'git submodule update core' in your checkout to follow it."
else
  echo "==> --no-push: $MIRROR_BRANCH would be $new, $CORE_MIRROR_BRANCH $core_new,"
  echo "    $CORE_BRANCH $core_merged, $TARGET_BRANCH $merged"
fi
