package com.maxrave.simpmusic.ui.navigation.destination.podcast

import kotlinx.serialization.Serializable

/** Private copy: the Podcasts tab — podcasts followed by their feeds, their newest episodes, and suggestions. */
@Serializable
data object PodcastsDestination

/**
 * One followed podcast's page, or — with [feedUrl] and no [podcastId] — a podcast's feed read
 * before it is followed (a suggestion being looked at).
 */
@Serializable
data class PodcastFeedDestination(
    val podcastId: String? = null,
    val feedUrl: String? = null,
)
