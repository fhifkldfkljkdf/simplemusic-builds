package com.maxrave.simpmusic.ui.component

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.compose.AsyncImagePainter
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily

/**
 * Album/song/playlist/artist artwork with a Retro Pixel rendering mode.
 *
 * Every theme but Retro gets exactly the same draw as [AsyncImage] with Coil's default
 * [FilterQuality.Low]. Under Retro the request asks Coil for a tiny bitmap ([pixelLongSide] on its
 * long side, 48dp for list rows and 96dp for hero/Now Playing art) and the painter upscales it with
 * [FilterQuality.None], so the result is chunky hard pixels instead of a blurry photo. The source
 * URL and the caller's disk-cache key are untouched; only the request's decode size differs, which
 * is part of Coil's memory-cache key, so the full-size and pixelated versions never collide.
 *
 * Drop-in replacement for `AsyncImage` in artwork call sites: same named parameters, same defaults.
 */
@Composable
fun ArtworkImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    placeholder: Painter? = null,
    error: Painter? = null,
    fallback: Painter? = error,
    onLoading: ((AsyncImagePainter.State.Loading) -> Unit)? = null,
    onSuccess: ((AsyncImagePainter.State.Success) -> Unit)? = null,
    onError: ((AsyncImagePainter.State.Error) -> Unit)? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    alpha: Float = 1f,
    colorFilter: ColorFilter? = null,
    clipToBounds: Boolean = true,
    pixelLongSide: Dp = 48.dp,
) {
    val retro = LocalAppThemeFamily.current == AppThemeFamily.RETRO
    val density = LocalDensity.current
    val context = LocalPlatformContext.current
    val targetPx = remember(pixelLongSide, density) { with(density) { pixelLongSide.roundToPx() } }
    // Only the Retro request is rebuilt: other themes hand Coil the very same model they used to.
    val pixelModel =
        remember(model, retro, targetPx, context) {
            if (!retro) {
                model
            } else {
                when (model) {
                    is ImageRequest -> model.newBuilder().size(targetPx.coerceAtLeast(8)).build()
                    is String ->
                        ImageRequest
                            .Builder(context)
                            .data(model)
                            .size(targetPx.coerceAtLeast(8))
                            .build()
                    else -> model
                }
            }
        }
    AsyncImage(
        model = pixelModel,
        contentDescription = contentDescription,
        modifier = modifier,
        placeholder = placeholder,
        error = error,
        fallback = fallback,
        onLoading = onLoading,
        onSuccess = onSuccess,
        onError = onError,
        alignment = alignment,
        contentScale = contentScale,
        alpha = alpha,
        colorFilter = colorFilter,
        // Low is Coil's own AsyncImage default; Retro asks for no interpolation at all.
        filterQuality = if (retro) FilterQuality.None else FilterQuality.Low,
        clipToBounds = clipToBounds,
    )
}
