package com.maxrave.simpmusic.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxrave.data.listentogether.ListenTogetherPlaybackBridge
import com.maxrave.data.listentogether.ListenTogetherPrefs
import com.maxrave.domain.data.model.listentogether.ListenTogetherRoom
import com.maxrave.domain.data.model.listentogether.NearbyListenRoom
import com.maxrave.domain.data.model.listentogether.RoomConnection
import com.maxrave.domain.repository.ListenTogetherRepository
import com.maxrave.domain.manager.DataStoreManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn

/**
 * Screen state for Listen Together.
 *
 * The session owns everything the server says; this holds only what the user has typed but not yet
 * sent, so a half-filled room code survives a recomposition without being confused for room state.
 */
class ListenTogetherViewModel(
    private val repository: ListenTogetherRepository,
    private val dataStore: DataStoreManager,
    bridge: ListenTogetherPlaybackBridge,
) : ViewModel() {
    /**
     * Whether this screen opened the connection, so closing it can close an unused one again.
     * Declared ahead of the init block that sets it: a property declared after it would be reset.
     */
    private var connectedHere = false

    init {
        // The bridge is a singleton that outlives this screen; starting it here is simply the
        // first moment anything asks for it. Koin's `createdAtStart` does not fire for modules
        // added with loadKoinModules, so without an explicit injection it is never constructed
        // at all — and then a room syncs membership while no audio follows anyone.
        bridge.start()

        // Host conveniences live in settings but are applied by the session, so they are mirrored
        // onto it for as long as this screen exists.
        viewModelScope.launch {
            dataStore.getString(ListenTogetherPrefs.AUTO_APPROVE_JOINS).collect {
                repository.autoApproveJoins = it == ListenTogetherPrefs.TRUE
            }
        }
        viewModelScope.launch {
            dataStore.getString(ListenTogetherPrefs.AUTO_APPROVE_SUGGESTIONS).collect {
                repository.autoApproveSuggestions = it == ListenTogetherPrefs.TRUE
            }
        }
        viewModelScope.launch {
            dataStore.getString(ListenTogetherPrefs.VISIBLE_NEARBY).collect {
                repository.setVisibleNearby(it != ListenTogetherPrefs.FALSE)
            }
        }
        viewModelScope.launch {
            dataStore.getString(ListenTogetherPrefs.GUEST_CONTROL).collect {
                repository.guestControlDefault = it != ListenTogetherPrefs.FALSE
            }
        }

        // Connected the moment the screen opens: nearby rooms show up at once and Create and Join
        // work straight away, with nothing to tap first.
        ensureConnected()
    }

    private fun ensureConnected() {
        val connection = repository.room.value.connection
        if (connection is RoomConnection.Disconnected || connection is RoomConnection.Failed) {
            connectedHere = true
            repository.connect()
        }
    }

    override fun onCleared() {
        // Left without a room: nothing needs the relays or the network any more. A room, or a join
        // waiting for the host, keeps the connection however the screen was left.
        val room = repository.room.value
        if (connectedHere && !room.inRoom && room.pendingJoinCode == null) repository.disconnect()
        super.onCleared()
    }

    val state: StateFlow<ListenTogetherRoom> =
        repository.room.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ListenTogetherRoom())

    /** Rooms hosted on the same Wi-Fi, found by themselves: joined with one tap, no code to type. */
    val nearbyRooms: StateFlow<List<NearbyListenRoom>> =
        repository.nearbyRooms.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** The "share what I play" setting; the playback bridge reads the same key. */
    val shareNowPlaying: StateFlow<Boolean> =
        dataStore
            .getString(ListenTogetherPrefs.SHARE_NOW_PLAYING)
            .map { it == ListenTogetherPrefs.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private val _displayName = MutableStateFlow("")
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    private val _roomCodeInput = MutableStateFlow("")
    val roomCodeInput: StateFlow<String> = _roomCodeInput.asStateFlow()

    /** Why a room reached by QR code or link was not joined straight away; null when nothing is pending. */
    private val _inviteNotice = MutableStateFlow<InviteNotice?>(null)
    val inviteNotice: StateFlow<InviteNotice?> = _inviteNotice.asStateFlow()

    enum class InviteNotice { ENTER_NAME, LEAVE_FIRST }

    init {
        // The last name used, so a scanned code can join without typing anything.
        viewModelScope.launch {
            val saved = dataStore.getString(ListenTogetherPrefs.DISPLAY_NAME).first().orEmpty()
            if (_displayName.value.isEmpty() && saved.isNotBlank()) _displayName.value = saved
        }
    }

    fun onDisplayNameChange(value: String) {
        // metroserver caps usernames at 50; trimming here means the server never has to reject it.
        _displayName.value = value.take(MAX_USERNAME_LENGTH)
        if (value.isNotBlank() && _inviteNotice.value == InviteNotice.ENTER_NAME) _inviteNotice.value = null
    }

    fun onRoomCodeChange(value: String) {
        _roomCodeInput.value =
            value.uppercase().filter { it.isLetterOrDigit() }.take(ROOM_CODE_LENGTH)
    }

    fun connect() = repository.connect()

    /**
     * Host only: whether guests may play, pause, seek and change the song for everyone. Also kept
     * as the starting point for the next room created here.
     */
    fun setGuestControl(enabled: Boolean) {
        repository.setGuestControl(enabled)
        repository.guestControlDefault = enabled
        viewModelScope.launch {
            dataStore.putString(ListenTogetherPrefs.GUEST_CONTROL, if (enabled) ListenTogetherPrefs.TRUE else ListenTogetherPrefs.FALSE)
        }
    }

    fun disconnect() = repository.disconnect()

    fun createRoom() {
        rememberName()
        ensureConnected()
        repository.createRoom(_displayName.value)
    }

    /** The host's local addresses from the invite being joined, if it carried any. */
    private var inviteDirect: Pair<String, List<String>>? = null

    fun joinRoom() {
        _inviteNotice.value = null
        rememberName()
        val code = _roomCodeInput.value
        val direct = inviteDirect?.takeIf { it.first == code }?.second.orEmpty()
        ensureConnected()
        repository.joinRoom(code, _displayName.value, direct)
    }

    /**
     * A code from a QR scan. Answers whether it was a Listen Together room at all, so the scanner
     * can keep looking when it was not.
     */
    fun joinFromQr(text: String): Boolean {
        val code = parseRoomCode(text) ?: return false
        joinByInvite(code, parseDirectHints(text))
        return true
    }

    /**
     * Joins [code] with as few taps as possible: connects if needed and asks to join under the
     * remembered name. Without a name it stops at a filled-in form; inside another room it asks the
     * user to leave that one first rather than doing it for them.
     */
    fun joinByInvite(
        code: String,
        directHints: List<String> = emptyList(),
    ) {
        if (directHints.isNotEmpty()) inviteDirect = code to directHints
        val room = repository.room.value
        if (room.roomCode == code || room.pendingJoinCode == code) return
        if (room.inRoom) {
            _inviteNotice.value = InviteNotice.LEAVE_FIRST
            return
        }
        onRoomCodeChange(code)
        if (_displayName.value.isBlank()) {
            _inviteNotice.value = InviteNotice.ENTER_NAME
            return
        }
        _inviteNotice.value = null
        viewModelScope.launch {
            if (!repository.room.value.isConnected) repository.connect()
            val ready =
                withTimeoutOrNull(CONNECT_FOR_INVITE_MS) {
                    repository.room.first { it.isConnected || it.connection is RoomConnection.Failed }
                }
            if (ready?.isConnected == true) joinRoom()
        }
    }

    fun clearInviteNotice() {
        _inviteNotice.value = null
    }

    private fun rememberName() {
        val name = _displayName.value.trim()
        if (name.isBlank()) return
        viewModelScope.launch { dataStore.putString(ListenTogetherPrefs.DISPLAY_NAME, name) }
    }

    fun leaveRoom() {
        repository.leaveRoom()
        _roomCodeInput.value = ""
    }

    fun approveJoin(userId: String) {
        repository.approveJoin(userId)
    }

    fun rejectJoin(userId: String) {
        repository.rejectJoin(userId)
    }

    fun approveSuggestion(id: String) {
        repository.approveSuggestion(id)
    }

    fun rejectSuggestion(id: String) {
        repository.rejectSuggestion(id)
    }

    fun kickUser(userId: String) {
        repository.kickUser(userId)
    }

    /**
     * Blocks by NAME and then kicks.
     *
     * The protocol has no ban and the server mints a new user id per connection, so the id cannot
     * be blocked on — the name is the only thing that survives a reconnect, and it is changeable.
     * A convenience, not a security control.
     */
    fun blockAndKick(
        userId: String,
        username: String,
    ) {
        viewModelScope.launch {
            val current =
                dataStore
                    .getString(ListenTogetherPrefs.BLOCKLIST)
                    .first()
                    .orEmpty()
                    .split(ListenTogetherPrefs.BLOCKLIST_SEPARATOR)
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
            if (current.none { it.equals(username, ignoreCase = true) }) {
                dataStore.putString(
                    ListenTogetherPrefs.BLOCKLIST,
                    (current + username).joinToString(ListenTogetherPrefs.BLOCKLIST_SEPARATOR),
                )
            }
            repository.kickUser(userId)
        }
    }

    fun transferHost(userId: String) {
        repository.transferHost(userId)
    }

    fun listenOnMyOwn() = repository.listenOnMyOwn()

    fun backToRoom() = repository.backToRoom()

    fun setShareNowPlaying(enabled: Boolean) {
        viewModelScope.launch {
            dataStore.putString(
                ListenTogetherPrefs.SHARE_NOW_PLAYING,
                if (enabled) ListenTogetherPrefs.TRUE else ListenTogetherPrefs.FALSE,
            )
        }
    }

    fun cancelJoin() = repository.cancelJoin()

    fun clearError() = repository.clearError()

    companion object {
        const val ROOM_CODE_LENGTH = 8
        private const val MAX_USERNAME_LENGTH = 50
        private const val CONNECT_FOR_INVITE_MS = 20_000L

        /**
         * What a room's QR code holds. A `simpmusic://` link rather than the bare code, so a phone's
         * own camera app opens SimpMusic on it too; App.kt routes it to this screen.
         */
        fun inviteLink(
            code: String,
            direct: List<String> = emptyList(),
        ): String =
            buildString {
                append("simpmusic://listen-together?code=").append(code)
                // The host's local addresses: a guest on the same Wi-Fi connects straight to it,
                // with no internet needed at all.
                if (direct.isNotEmpty()) append("&lan=").append(direct.joinToString(","))
            }

        private val LAN_PARAM = Regex("""[?&]lan=([^&#\s]+)""")
        private val ENDPOINT = Regex("""^\d{1,3}(\.\d{1,3}){3}:\d{1,5}$""")

        /** The host's local addresses in an invite link, if it has them. */
        fun parseDirectHints(text: String): List<String> =
            LAN_PARAM
                .find(text)
                ?.groupValues
                ?.get(1)
                ?.split(',')
                ?.filter { ENDPOINT.matches(it) }
                ?.take(8)
                .orEmpty()

        private val CODE_PARAM = Regex("""[?&]code=([A-Za-z0-9]{$ROOM_CODE_LENGTH})(?:[&#]|$)""")
        private val BARE_CODE = Regex("""^[A-Za-z0-9]{$ROOM_CODE_LENGTH}$""")

        /**
         * The room code in [text]: the invite link (either scheme — Desktop rewrites `simpmusic://`
         * to `https://simpmusic.org/app/...` before App.kt sees it) or a code on its own. Anything
         * else, including other SimpMusic links, is not a room.
         */
        fun parseRoomCode(text: String): String? {
            val trimmed = text.trim()
            val fromLink =
                if (trimmed.contains("listen-together", ignoreCase = true)) CODE_PARAM.find(trimmed)?.groupValues?.get(1) else null
            val code = fromLink ?: trimmed.takeIf { BARE_CODE.matches(it) }
            return code?.uppercase()
        }
    }
}
