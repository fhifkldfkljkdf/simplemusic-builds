package com.maxrave.simpmusic.ui.icon

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

@Suppress("CheckReturnValue")
val SimpIcons.NoiseControlOn: ImageVector
  get() {
    if (_NoiseControlOn != null) {
      return _NoiseControlOn!!
    }
    _NoiseControlOn =
      ImageVector.Builder(
          name = "NoiseControlOn",
          defaultWidth = 24.dp,
          defaultHeight = 24.dp,
          viewportWidth = 24f,
          viewportHeight = 24f,
        )
        .apply {
          path(
            fill = SolidColor(Color.Black),
            fillAlpha = 1f,
            stroke = null,
            strokeAlpha = 1f,
            strokeLineWidth = 1f,
            strokeLineCap = StrokeCap.Butt,
            strokeLineJoin = StrokeJoin.Bevel,
            strokeLineMiter = 1f,
            pathFillType = PathFillType.Companion.NonZero,
          ) {
            moveTo(12f, 22f)
            quadTo(9.93f, 22f, 8.1f, 21.21f)
            quadTo(6.28f, 20.43f, 4.93f, 19.08f)
            quadTo(3.58f, 17.73f, 2.79f, 15.9f)
            reflectiveQuadTo(2f, 12f)
            quadTo(2f, 9.92f, 2.79f, 8.1f)
            quadTo(3.58f, 6.27f, 4.93f, 4.93f)
            quadTo(6.28f, 3.57f, 8.1f, 2.79f)
            quadTo(9.93f, 2f, 12f, 2f)
            reflectiveQuadToRelative(3.9f, 0.79f)
            reflectiveQuadToRelative(3.17f, 2.14f)
            quadToRelative(1.35f, 1.35f, 2.14f, 3.17f)
            quadTo(22f, 9.92f, 22f, 12f)
            reflectiveQuadToRelative(-0.79f, 3.9f)
            reflectiveQuadToRelative(-2.14f, 3.17f)
            quadToRelative(-1.35f, 1.35f, -3.17f, 2.14f)
            reflectiveQuadTo(12f, 22f)
            close()
            moveToRelative(0f, -2f)
            quadToRelative(3.35f, 0f, 5.68f, -2.32f)
            reflectiveQuadTo(20f, 12f)
            reflectiveQuadTo(17.68f, 6.32f)
            reflectiveQuadTo(12f, 4f)
            reflectiveQuadTo(6.33f, 6.32f)
            reflectiveQuadTo(4f, 12f)
            reflectiveQuadToRelative(2.33f, 5.68f)
            reflectiveQuadTo(12f, 20f)
            close()
            moveToRelative(0.98f, -2f)
            quadTo(12f, 18f, 11.23f, 17.4f)
            reflectiveQuadTo(10.1f, 15.85f)
            quadTo(10.03f, 15.65f, 9.94f, 15.46f)
            reflectiveQuadTo(9.7f, 15.13f)
            lineTo(8.45f, 13.85f)
            quadTo(7.8f, 13.2f, 7.4f, 12.35f)
            reflectiveQuadTo(7f, 10.55f)
            quadTo(7f, 8.67f, 8.31f, 7.34f)
            reflectiveQuadTo(11.5f, 6f)
            quadToRelative(1.3f, 0f, 2.39f, 0.69f)
            reflectiveQuadToRelative(1.66f, 1.86f)
            quadToRelative(0.25f, 0.5f, -0.04f, 0.97f)
            reflectiveQuadTo(14.65f, 10f)
            quadToRelative(-0.3f, 0f, -0.54f, -0.16f)
            reflectiveQuadTo(13.75f, 9.4f)
            quadTo(13.43f, 8.75f, 12.83f, 8.38f)
            reflectiveQuadTo(11.5f, 8f)
            quadTo(10.45f, 8f, 9.73f, 8.73f)
            reflectiveQuadTo(9f, 10.5f)
            quadToRelative(0f, 0.52f, 0.19f, 1f)
            reflectiveQuadToRelative(0.56f, 0.85f)
            lineToRelative(1.38f, 1.35f)
            quadToRelative(0.35f, 0.35f, 0.56f, 0.76f)
            reflectiveQuadToRelative(0.36f, 0.86f)
            quadToRelative(0.13f, 0.3f, 0.38f, 0.49f)
            reflectiveQuadTo(13f, 16f)
            quadToRelative(0.28f, 0f, 0.51f, -0.14f)
            quadToRelative(0.24f, -0.14f, 0.36f, -0.39f)
            quadTo(14f, 15.25f, 14.23f, 15.13f)
            reflectiveQuadTo(14.73f, 15f)
            quadToRelative(0.57f, 0f, 0.88f, 0.47f)
            reflectiveQuadToRelative(0.02f, 0.97f)
            quadToRelative(-0.4f, 0.73f, -1.11f, 1.14f)
            reflectiveQuadTo(12.98f, 18f)
            close()
            moveToRelative(1.59f, -4.44f)
            quadTo(15f, 13.13f, 15f, 12.5f)
            reflectiveQuadTo(14.56f, 11.44f)
            reflectiveQuadTo(13.5f, 11f)
            reflectiveQuadToRelative(-1.06f, 0.44f)
            reflectiveQuadTo(12f, 12.5f)
            reflectiveQuadToRelative(0.44f, 1.06f)
            reflectiveQuadTo(13.5f, 14f)
            reflectiveQuadToRelative(1.06f, -0.44f)
            close()
          }
        }
        .build()
    return _NoiseControlOn!!
  }

private var _NoiseControlOn: ImageVector? = null
