package com.maxrave.simpmusic.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Private copy: the Spotify theme. It is one of Home's "Theme color" choices, not a separate
 * switch: [AppTheme] builds [spotifyColorScheme] instead of the seeded palette and provides
 * [LocalSpotifyTheme], which Home and the chips read for the few shapes the palette alone cannot
 * give (the greeting header, the pills, the quick-access grid).
 */
val LocalSpotifyTheme = staticCompositionLocalOf { false }

/** Spotify's green. The bright variant is the "now playing" green it uses for the current track. */
val SpotifyGreen = Color(0xFF1DB954)
val SpotifyGreenBright = Color(0xFF1ED760)

/** Spotify's rounded shape language, a step rounder than Material's default. */
val SpotifyShapes =
    Shapes(
        extraSmall = RoundedCornerShape(6.dp),
        small = RoundedCornerShape(8.dp),
        medium = RoundedCornerShape(12.dp),
        large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(28.dp),
    )

/**
 * Spotify's palette in both modes: #121212 / #181818 surfaces with green controls in the dark,
 * white with the same green in the light. Green buttons take black labels, as Spotify's do.
 */
fun spotifyColorScheme(isDark: Boolean): ColorScheme =
    if (isDark) {
        darkColorScheme(
            primary = SpotifyGreen,
            onPrimary = Color(0xFF000000),
            primaryContainer = Color(0xFF0F3D22),
            onPrimaryContainer = Color(0xFFB7F7C8),
            inversePrimary = SpotifyGreenBright,
            secondary = Color(0xFFB3B3B3),
            onSecondary = Color(0xFF000000),
            secondaryContainer = Color(0xFF242424),
            onSecondaryContainer = Color(0xFFE0E0E0),
            tertiary = SpotifyGreenBright,
            onTertiary = Color(0xFF000000),
            tertiaryContainer = Color(0xFF123B23),
            onTertiaryContainer = Color(0xFFC8F7D8),
            background = Color(0xFF121212),
            onBackground = Color(0xFFFFFFFF),
            surface = Color(0xFF121212),
            onSurface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFF282828),
            onSurfaceVariant = Color(0xFFB3B3B3),
            surfaceTint = SpotifyGreen,
            surfaceBright = Color(0xFF2A2A2A),
            surfaceDim = Color(0xFF0D0D0D),
            surfaceContainerLowest = Color(0xFF0D0D0D),
            surfaceContainerLow = Color(0xFF181818),
            surfaceContainer = Color(0xFF1A1A1A),
            surfaceContainerHigh = Color(0xFF242424),
            surfaceContainerHighest = Color(0xFF2E2E2E),
            outline = Color(0xFF7A7A7A),
            outlineVariant = Color(0xFF333333),
            error = Color(0xFFF15E6C),
            onError = Color(0xFF000000),
            errorContainer = Color(0xFF4A1F24),
            onErrorContainer = Color(0xFFFFD9DD),
            inverseSurface = Color(0xFFFFFFFF),
            inverseOnSurface = Color(0xFF121212),
            scrim = Color(0xFF000000),
        )
    } else {
        lightColorScheme(
            primary = SpotifyGreen,
            onPrimary = Color(0xFF000000),
            primaryContainer = Color(0xFFB7F7C8),
            onPrimaryContainer = Color(0xFF06240F),
            inversePrimary = Color(0xFF0F7A34),
            secondary = Color(0xFF5A5A5A),
            onSecondary = Color(0xFFFFFFFF),
            secondaryContainer = Color(0xFFE8E8E8),
            onSecondaryContainer = Color(0xFF1B1B1B),
            tertiary = SpotifyGreenBright,
            onTertiary = Color(0xFF000000),
            tertiaryContainer = Color(0xFFC8F7D8),
            onTertiaryContainer = Color(0xFF06240F),
            background = Color(0xFFFFFFFF),
            onBackground = Color(0xFF121212),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF121212),
            surfaceVariant = Color(0xFFE8E8E8),
            onSurfaceVariant = Color(0xFF5A5A5A),
            surfaceTint = SpotifyGreen,
            surfaceBright = Color(0xFFFFFFFF),
            surfaceDim = Color(0xFFDADADA),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFF7F7F7),
            surfaceContainer = Color(0xFFF0F0F0),
            surfaceContainerHigh = Color(0xFFE8E8E8),
            surfaceContainerHighest = Color(0xFFE0E0E0),
            outline = Color(0xFF7A7A7A),
            outlineVariant = Color(0xFFD6D6D6),
            error = Color(0xFFB3261E),
            onError = Color(0xFFFFFFFF),
            errorContainer = Color(0xFFFFDAD6),
            onErrorContainer = Color(0xFF410002),
            inverseSurface = Color(0xFF303030),
            inverseOnSurface = Color(0xFFF1F1F1),
            scrim = Color(0xFF000000),
        )
    }
