package com.maxrave.simpmusic.ui.component

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maxrave.simpmusic.ui.theme.typo
import kotlin.math.roundToInt

/**
 * A download on its way, as a ring that fills with it and its percentage inside. Private copy.
 * [fraction] null (queued, or its size not known yet) spins instead.
 */
@Composable
fun DownloadProgressRing(
    fraction: Float?,
    color: Color,
    modifier: Modifier = Modifier,
    size: Dp = 30.dp,
) {
    val trackColor = color.copy(alpha = 0.2f)
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        if (fraction == null) {
            CircularProgressIndicator(
                modifier = Modifier.fillMaxSize(),
                color = color,
                strokeWidth = RING_STROKE,
                trackColor = trackColor,
                strokeCap = StrokeCap.Round,
            )
        } else {
            val shown by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), label = "download progress")
            CircularProgressIndicator(
                progress = { shown },
                modifier = Modifier.fillMaxSize(),
                color = color,
                strokeWidth = RING_STROKE,
                trackColor = trackColor,
                strokeCap = StrokeCap.Round,
            )
            Text(
                text = "${(fraction.coerceIn(0f, 1f) * 100).roundToInt()}%",
                style = typo().labelSmall.copy(fontSize = 8.sp, lineHeight = 8.sp),
                color = color,
                textAlign = TextAlign.Center,
                maxLines = 1,
            )
        }
    }
}

private val RING_STROKE = 2.5.dp
