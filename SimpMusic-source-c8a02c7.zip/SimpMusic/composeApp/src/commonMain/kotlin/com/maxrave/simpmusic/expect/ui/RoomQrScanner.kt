package com.maxrave.simpmusic.expect.ui

import androidx.compose.runtime.Composable

/**
 * A sheet with the camera, for joining a Listen Together room by its QR code — or, with its own
 * [title], [hint] and [rejectedHint], for reading any other SimpMusic code (a friend code).
 *
 * [onScanned] gets every code the camera reads and answers whether it was the kind wanted; the sheet
 * keeps scanning after a `false`. Android only for now — the Desktop actual just dismisses, and no
 * screen offers scanning there.
 */
@Composable
expect fun RoomQrScannerSheet(
    onScanned: (String) -> Boolean,
    onDismiss: () -> Unit,
    title: String? = null,
    hint: String? = null,
    rejectedHint: String? = null,
)
