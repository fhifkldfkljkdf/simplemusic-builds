package com.maxrave.simpmusic.ui.component

import com.maxrave.simpmusic.ui.theme.appCorner
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.maxrave.simpmusic.expect.encodeQrCode

/**
 * A QR code for [text]. Dark modules on white whatever the theme: that is the polarity scanners and
 * phone cameras expect, and an inverted code fails on many of them.
 */
@Composable
fun QrCodeImage(
    text: String,
    modifier: Modifier = Modifier,
) {
    val modules = remember(text) { encodeQrCode(text) } ?: return
    Canvas(
        modifier
            .clip(appCorner(16.dp))
            .background(Color.White)
            .padding(10.dp),
    ) {
        val cell = size.minDimension / modules.size
        modules.forEachIndexed { y, row ->
            row.forEachIndexed { x, dark ->
                // Half a pixel of overlap hides the seams between fractional-width modules.
                if (dark) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.5f, cell + 0.5f))
            }
        }
    }
}
