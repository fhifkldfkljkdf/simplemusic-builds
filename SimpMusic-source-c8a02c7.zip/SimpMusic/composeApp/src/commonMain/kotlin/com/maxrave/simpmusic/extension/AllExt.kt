package com.maxrave.simpmusic.extension

import androidx.compose.runtime.Composable
import com.maxrave.common.SponsorBlockType
import com.maxrave.domain.data.model.browse.artist.ArtistBrowse
import com.maxrave.domain.data.model.streams.TimeLine
import com.maxrave.domain.extension.now
import com.maxrave.domain.utils.FilterState
import com.maxrave.domain.utils.toTrack
import kotlin.math.roundToLong
import com.maxrave.logger.Logger
import com.maxrave.simpmusic.viewModel.ArtistScreenData
import kotlinx.datetime.LocalDate
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.Month
import kotlinx.datetime.TimeZone
import kotlinx.datetime.periodUntil
import kotlinx.datetime.toInstant
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.custom_order
import simpmusic.composeapp.generated.resources.day_s_ago
import simpmusic.composeapp.generated.resources.filler
import simpmusic.composeapp.generated.resources.hour_s_ago
import simpmusic.composeapp.generated.resources.interaction
import simpmusic.composeapp.generated.resources.intro
import simpmusic.composeapp.generated.resources.month_s_ago
import simpmusic.composeapp.generated.resources.music_off_topic
import simpmusic.composeapp.generated.resources.live_badge
import simpmusic.composeapp.generated.resources.na_na
import simpmusic.composeapp.generated.resources.newer_first
import simpmusic.composeapp.generated.resources.older_first
import simpmusic.composeapp.generated.resources.outro
import simpmusic.composeapp.generated.resources.poi_highlight
import simpmusic.composeapp.generated.resources.preview
import simpmusic.composeapp.generated.resources.recently
import simpmusic.composeapp.generated.resources.self_promotion
import simpmusic.composeapp.generated.resources.sponsor
import simpmusic.composeapp.generated.resources.title
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.time.ExperimentalTime

fun String?.removeDuplicateWords(): String {
    if (this == null) {
        return "null"
    } else {
        val regex = Regex("\\b(\\w+)\\b\\s*(?=.*\\b\\1\\b)")
        return this.replace(regex, "")
    }
}

fun <T> Iterable<T>.indexMap(): Map<T, Int> {
    val map = mutableMapOf<T, Int>()
    forEachIndexed { i, v ->
        map[v] = i
    }
    return map
}

/**
 * Whether a release from an artist's discography page is worth announcing. An unseen id is not
 * enough on its own, because YouTube re-keys old releases and pages them in and out, so only
 * releases dated this year count — plus last year's during January, so one that came out in
 * the last days of December is not lost.
 */
fun isNewRelease(
    browseId: String,
    year: String,
    known: Set<String>,
    today: LocalDate = now().date,
): Boolean {
    if (browseId in known) return false
    val released = year.toIntOrNull() ?: return false
    return released == today.year || (today.month == Month.JANUARY && released == today.year - 1)
}

@OptIn(ExperimentalTime::class)
@Composable
fun LocalDateTime.formatTimeAgo(): String {
    val now = now()
    val duration =
        this
            .toInstant(TimeZone.currentSystemDefault())
            .periodUntil(now.toInstant(TimeZone.currentSystemDefault()), TimeZone.currentSystemDefault())

    val monthsDiff = duration.months + (duration.years * 12)
    val daysDiff = duration.days

    // For hours, we need to calculate manually since Period doesn't include hours
    val thisInstant = this.toInstant(TimeZone.currentSystemDefault())
    val nowInstant = now.toInstant(TimeZone.currentSystemDefault())
    val hoursDiff = (nowInstant - thisInstant).inWholeHours

    return when {
        monthsDiff >= 1 -> stringResource(Res.string.month_s_ago, monthsDiff)
        daysDiff >= 1 -> stringResource(Res.string.day_s_ago, daysDiff)
        hoursDiff >= 2 -> stringResource(Res.string.hour_s_ago, hoursDiff)
        else -> stringResource(Res.string.recently)
    }
}

/**
 * The elapsed-time label under a seek bar sitting at [progress] (0..1) of the track. Blank for a live
 * broadcast: where playback sits in the broadcast's seek window means nothing to a listener.
 */
@Composable
fun TimeLine.elapsedLabel(progress: Float): String = if (isLive) "" else formatDuration((total * progress).roundToLong())

/** The track's length under a seek bar, or LIVE for a live broadcast, which has none. */
@Composable
fun TimeLine.lengthLabel(): String = if (isLive) stringResource(Res.string.live_badge) else formatDuration(total)

@Composable
fun formatDuration(duration: Long): String {
    if (duration < 0L) return stringResource(Res.string.na_na)
    val minutes: Long = TimeUnit.MINUTES.convert(duration, TimeUnit.MILLISECONDS)
    val seconds: Long = (
        TimeUnit.SECONDS.convert(duration, TimeUnit.MILLISECONDS) -
            minutes * TimeUnit.SECONDS.convert(1, TimeUnit.MINUTES)
    )
    return String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)
}

fun parseTimestampToMilliseconds(timestamp: String): Double {
    val parts = timestamp.split(":")
    val totalSeconds =
        when (parts.size) {
            2 -> {
                try {
                    val minutes = parts[0].toDouble()
                    val seconds = parts[1].toDouble()
                    (minutes * 60 + seconds)
                } catch (e: NumberFormatException) {
                    // Handle parsing error
                    e.printStackTrace()
                    return 0.0
                }
            }

            3 -> {
                try {
                    val hours = parts[0].toDouble()
                    val minutes = parts[1].toDouble()
                    val seconds = parts[2].toDouble()
                    (hours * 3600 + minutes * 60 + seconds)
                } catch (e: NumberFormatException) {
                    // Handle parsing error
                    e.printStackTrace()
                    return 0.0
                }
            }

            else -> {
                // Handle incorrect format
                return 0.0
            }
        }
    return totalSeconds * 1000
}

fun InputStream.zipInputStream(): ZipInputStream = ZipInputStream(this)

fun OutputStream.zipOutputStream(): ZipOutputStream = ZipOutputStream(this)

fun Long?.bytesToMB(): Long {
    val mbInBytes = 1024 * 1024
    return this?.div(mbInBytes) ?: 0L
}

/**
 * "8.4 MB" for one downloaded song, where a tenth of a megabyte is worth seeing — the cache
 * figures in Settings stay whole megabytes ([bytesToMB]).
 */
fun Long.downloadSizeText(): String =
    if (this >= 10L * 1024 * 1024) {
        "${this / (1024 * 1024)} MB"
    } else {
        "${(this * 10 / (1024 * 1024)) / 10.0f} MB"
    }

fun getSizeOfFile(dir: File): Long {
    var dirSize: Long = 0
    if (!dir.listFiles().isNullOrEmpty()) {
        for (f in dir.listFiles()!!) {
            dirSize += f.length()
            if (f.isDirectory) {
                dirSize += getSizeOfFile(f)
            }
        }
    }
    return dirSize
}

fun ArtistBrowse.toArtistScreenData(): ArtistScreenData =
    ArtistScreenData(
        title = this.name,
        imageUrl = this.thumbnails?.lastOrNull()?.url,
        subscribers = this.subscribers,
        playCount = this.views,
        isChannel = this.songs == null,
        channelId = this.channelId,
        radioParam = this.radioId,
        shuffleParam = this.shuffleId,
        description = this.description,
        listSongParam = this.songs?.browseId,
        popularSongs = this.songs?.results?.map { it.toTrack() } ?: emptyList(),
        singles = this.singles,
        albums = this.albums,
        video =
            this.video?.let { video ->
                ArtistBrowse.Videos(video.map { it.toTrack() }, this.videoList)
            },
        related = this.related,
        featuredOn = this.featuredOn ?: emptyList(),
    )

/**
 * Clamp a YouTube image URL's `w`/`h` size spec to the smaller dimension so it's square
 * (`...=w2880-h1200-...` -> `...=w1200-h1200-...`). Only the size spec after the last `=` is
 * touched. Returns the url unchanged when it has no `w`/`h` spec or is already square.
 */
fun String.toSquareThumbnailUrl(): String {
    val eq = lastIndexOf('=')
    if (eq < 0 || eq == lastIndex) return this
    val base = substring(0, eq + 1)
    val spec = substring(eq + 1)
    val width = Regex("(?:^|-)w(\\d+)").find(spec)?.groupValues?.get(1)?.toIntOrNull()
    val height = Regex("(?:^|-)h(\\d+)").find(spec)?.groupValues?.get(1)?.toIntOrNull()
    if (width == null || height == null || width == height) return this
    val min = minOf(width, height)
    return base +
        spec.replace(Regex("(^|-)([wh])\\d+")) { m -> "${m.groupValues[1]}${m.groupValues[2]}$min" }
}

fun isValidProxyHost(host: String): Boolean {
    // Regular expression to validate proxy host (without port)
    val proxyHostRegex =
        Regex(
            pattern = "^(?!-)[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(?<!-)\$",
            options = setOf(RegexOption.IGNORE_CASE),
        )

    // Return true if the host matches the regex or is an IP address
    return proxyHostRegex.matches(host) || isIPAddress(host)
}

private fun isIPAddress(host: String): Boolean {
    // Check if the host is an IPv4 address
    val ipv4Regex =
        Regex(
            pattern = "^([0-9]{1,3}\\.){3}[0-9]{1,3}\$",
        )
    if (ipv4Regex.matches(host)) {
        return host.split('.').all { it.toInt() in 0..255 }
    }

    // Check if the host is an IPv6 address
    val ipv6Regex =
        Regex(
            pattern = "^[0-9a-fA-F:]+$",
        )
    return ipv6Regex.matches(host)
}

fun String.isTwoLetterCode(): Boolean {
    val regex = "^[A-Za-z]{2}$".toRegex()
    return regex.matches(this)
}

fun FilterState.displayNameRes(): StringResource =
    when (this) {
        FilterState.NewerFirst -> Res.string.newer_first
        FilterState.OlderFirst -> Res.string.older_first
        FilterState.Title -> Res.string.title
        FilterState.CustomOrder -> Res.string.custom_order
    }

@Composable
fun String?.ifNullOrEmpty(defaultValue: @Composable () -> String): String = if (isNullOrEmpty()) defaultValue() else this

@Composable
fun SponsorBlockType.displayString(): String = stringResource(displayRes())

/** The resource behind [displayString], for callers outside composition (the skip toast). */
fun SponsorBlockType.displayRes(): StringResource =
    when (this) {
        SponsorBlockType.FILLER -> Res.string.filler
        SponsorBlockType.INTERACTION -> Res.string.interaction
        SponsorBlockType.INTRO -> Res.string.intro
        SponsorBlockType.MUSIC_OFF_TOPIC -> Res.string.music_off_topic
        SponsorBlockType.OUTRO -> Res.string.outro
        SponsorBlockType.POI_HIGHLIGHT -> Res.string.poi_highlight
        SponsorBlockType.PREVIEW -> Res.string.preview
        SponsorBlockType.SELF_PROMOTION -> Res.string.self_promotion
        SponsorBlockType.SPONSOR -> Res.string.sponsor
    }