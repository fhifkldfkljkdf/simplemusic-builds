package com.maxrave.simpmusic.ui.screen.podcast

import com.maxrave.simpmusic.ui.component.ThemedIcon
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.maxrave.domain.data.model.podcast.FeedPodcast
import com.maxrave.simpmusic.ui.icon.ArrowBackIosNew
import com.maxrave.simpmusic.ui.icon.Check
import com.maxrave.simpmusic.ui.icon.PlayArrow
import com.maxrave.simpmusic.ui.icon.Refresh
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.PodcastFeedsViewModel
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.cancel
import simpmusic.composeapp.generated.resources.podcasts_continue
import simpmusic.composeapp.generated.resources.podcasts_episodes
import simpmusic.composeapp.generated.resources.podcasts_feed_failed
import simpmusic.composeapp.generated.resources.podcasts_follow
import simpmusic.composeapp.generated.resources.podcasts_following
import simpmusic.composeapp.generated.resources.podcasts_no_episodes
import simpmusic.composeapp.generated.resources.podcasts_play_newest
import simpmusic.composeapp.generated.resources.podcasts_refresh
import simpmusic.composeapp.generated.resources.podcasts_show_less
import simpmusic.composeapp.generated.resources.podcasts_show_more
import simpmusic.composeapp.generated.resources.podcasts_unfollow
import simpmusic.composeapp.generated.resources.podcasts_unfollow_confirm
import simpmusic.composeapp.generated.resources.podcasts_youtube_note

/** Private copy: one podcast — followed, or looked at before following — and its episodes. */
@Composable
fun PodcastFeedScreen(
    podcastId: String?,
    feedUrl: String?,
    innerPadding: PaddingValues,
    navController: NavController,
    viewModel: PodcastFeedsViewModel = koinViewModel(),
) {
    LaunchedEffect(podcastId, feedUrl) { viewModel.openPage(podcastId, feedUrl) }
    val page by viewModel.page.collectAsStateWithLifecycle()
    val followedEpisodes by viewModel.episodes.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val adding by viewModel.adding.collectAsStateWithLifecycle()
    val refreshing by viewModel.refreshing.collectAsStateWithLifecycle()
    val nowPlaying by viewModel.nowPlayingVideoId.collectAsStateWithLifecycle()
    var confirmUnfollow by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when (val state = page) {
            PodcastFeedsViewModel.Page.Loading -> {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }

            is PodcastFeedsViewModel.Page.Failed -> {
                MutedText(
                    stringResource(Res.string.podcasts_feed_failed, state.message),
                    Modifier.align(Alignment.Center).padding(32.dp),
                )
            }

            is PodcastFeedsViewModel.Page.Ready -> {
                val podcast = state.podcast
                val episodes = if (state.followed) followedEpisodes else state.previewEpisodes
                // The episode left part-way, newest first: what "Continue" plays.
                val unfinished =
                    episodes.indexOfFirst { episode -> progress[episode.id]?.let { !it.finished && it.positionMs > 0 } == true }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = innerPadding.calculateBottomPadding() + 24.dp),
                ) {
                    item(key = "header") {
                        Header(
                            podcast = podcast,
                            followed = state.followed,
                            adding = adding != null,
                            refreshing = refreshing,
                            canPlay = episodes.isNotEmpty(),
                            continueLabel = unfinished >= 0,
                            onPlay = { viewModel.play(podcast, episodes, if (unfinished >= 0) unfinished else 0) },
                            onFollow = viewModel::followOpen,
                            onUnfollow = { confirmUnfollow = true },
                            onRefresh = { viewModel.refresh(podcast.id) },
                        )
                    }
                    item(key = "episodes-header") {
                        SectionHeader(stringResource(Res.string.podcasts_episodes))
                        if (podcast.isYouTube) {
                            MutedText(stringResource(Res.string.podcasts_youtube_note), Modifier.padding(horizontal = 16.dp))
                        }
                    }
                    if (episodes.isEmpty()) {
                        item(key = "no-episodes") {
                            MutedText(stringResource(Res.string.podcasts_no_episodes), Modifier.padding(16.dp))
                        }
                    }
                    itemsIndexed(episodes, key = { _, episode -> episode.id }) { index, episode ->
                        EpisodeRow(
                            episode = episode,
                            podcastTitle = null,
                            progress = progress[episode.id],
                            playing = nowPlaying == episode.id,
                        ) { viewModel.play(podcast, episodes, index) }
                    }
                }
                if (confirmUnfollow) {
                    AlertDialog(
                        onDismissRequest = { confirmUnfollow = false },
                        text = { Text(stringResource(Res.string.podcasts_unfollow_confirm, podcast.title)) },
                        confirmButton = {
                            TextButton(onClick = {
                                confirmUnfollow = false
                                viewModel.unfollowOpen()
                            }) {
                                Text(stringResource(Res.string.podcasts_unfollow), color = LocalContentColor.current)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { confirmUnfollow = false }) {
                                Text(stringResource(Res.string.cancel), color = LocalContentColor.current)
                            }
                        },
                    )
                }
            }
        }
        IconButton(
            onClick = { navController.navigateUp() },
            modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars).padding(8.dp),
        ) {
            ThemedIcon(SimpIcons.ArrowBackIosNew, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground)
        }
    }
}

@Composable
private fun Header(
    podcast: FeedPodcast,
    followed: Boolean,
    adding: Boolean,
    refreshing: Boolean,
    canPlay: Boolean,
    continueLabel: Boolean,
    onPlay: () -> Unit,
    onFollow: () -> Unit,
    onUnfollow: () -> Unit,
    onRefresh: () -> Unit,
) {
    var expanded by rememberSaveable(podcast.id) { mutableStateOf(false) }
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(start = 16.dp, end = 16.dp, top = 56.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Artwork(podcast.imageUrl, 128.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = podcast.title,
                    style = typo().titleLarge.copy(fontSize = 22.sp, lineHeight = 26.sp),
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                podcast.author?.let { MutedText(it, maxLines = 2) }
                podcast.categories.takeIf { it.isNotEmpty() }?.let { MutedText(it.takeLast(2).joinToString(" · "), maxLines = 1) }
            }
        }
        podcast.description?.let { description ->
            Column(Modifier.animateContentSize()) {
                MutedText(description, maxLines = if (expanded) Int.MAX_VALUE else 3)
                Text(
                    text = stringResource(if (expanded) Res.string.podcasts_show_less else Res.string.podcasts_show_more),
                    style = typo().labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clip(CircleShape).clickable { expanded = !expanded }.padding(vertical = 6.dp),
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (canPlay) {
                PillButton(
                    text = stringResource(if (continueLabel) Res.string.podcasts_continue else Res.string.podcasts_play_newest),
                    icon = SimpIcons.PlayArrow,
                    filled = true,
                    onClick = onPlay,
                )
            }
            if (followed) {
                PillButton(stringResource(Res.string.podcasts_following), SimpIcons.Check, filled = false, onClick = onUnfollow)
            } else {
                PillButton(stringResource(Res.string.podcasts_follow), null, filled = !canPlay, busy = adding, onClick = onFollow)
            }
            Spacer(Modifier.weight(1f))
            if (followed) {
                if (refreshing) {
                    CircularProgressIndicator(modifier = Modifier.padding(12.dp).size(22.dp), strokeWidth = 2.dp)
                } else {
                    IconButton(onClick = onRefresh) {
                        ThemedIcon(SimpIcons.Refresh, contentDescription = stringResource(Res.string.podcasts_refresh), tint = MaterialTheme.colorScheme.onBackground)
                    }
                }
            }
        }
    }
}

@Composable
private fun PillButton(
    text: String,
    icon: ImageVector?,
    filled: Boolean,
    busy: Boolean = false,
    onClick: () -> Unit,
) {
    val content = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground
    Row(
        modifier =
            Modifier
                .height(40.dp)
                .clip(CircleShape)
                .then(
                    if (filled) {
                        Modifier.background(MaterialTheme.colorScheme.primary)
                    } else {
                        Modifier.border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), CircleShape)
                    },
                ).clickable(enabled = !busy) { onClick() }
                .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (busy) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = content)
            Spacer(Modifier.width(8.dp))
        } else if (icon != null) {
            ThemedIcon(icon, contentDescription = null, tint = content, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = typo().labelLarge, color = content, maxLines = 1)
    }
}
