package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.parseThemeColorHex
import com.maxrave.simpmusic.ui.theme.typo
import org.jetbrains.compose.resources.stringResource
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.accent_color
import simpmusic.composeapp.generated.resources.accent_color_description
import simpmusic.composeapp.generated.resources.cancel
import simpmusic.composeapp.generated.resources.change
import simpmusic.composeapp.generated.resources.theme_default

/** The same ten colours the Custom color sheet offers, so the two pickers read as one family. */
private val ACCENT_PRESETS =
    listOf(
        "FF8ECAE6",
        "FF4C82EF",
        "FF9B72CF",
        "FFEF6C9B",
        "FFEF5350",
        "FFF4A340",
        "FFFFCA28",
        "FF66BB6A",
        "FF26A69A",
        "FFBDBDBD",
    )

/**
 * Private copy: picks the accent separately from the app theme. The chosen colour replaces only
 * the accent roles (primary/secondary/tertiary); the theme keeps its background and surfaces.
 * [accentHex] is empty when the theme's own accent is in use.
 */
@Composable
fun AccentColorDialog(
    accentHex: String,
    onConfirm: (String) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit,
) {
    var pendingHex by remember(accentHex) {
        mutableStateOf(
            accentHex
                .takeLast(6)
                .ifBlank { DataStoreManager.DEFAULT_THEME_COLOR_HEX.takeLast(6) },
        )
    }
    val parsed = parseThemeColorHex(pendingHex)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = stringResource(Res.string.accent_color), style = typo().titleSmall) },
        text = {
            Column {
                Text(
                    text = stringResource(Res.string.accent_color_description),
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                parsed?.let {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(LocalAppShapes.current.pill)
                                .background(it)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, LocalAppShapes.current.pill),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(text = "#${pendingHex.uppercase()}", style = typo().bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                }
                ACCENT_PRESETS.chunked(5).forEach { rowColors ->
                    Row(modifier = Modifier.padding(vertical = 2.dp)) {
                        rowColors.forEach { hex ->
                            val color = parseThemeColorHex(hex) ?: Color.Gray
                            val selected = pendingHex.equals(hex.takeLast(6), ignoreCase = true)
                            Box(
                                modifier =
                                    Modifier
                                        .padding(4.dp)
                                        .size(34.dp)
                                        .clip(LocalAppShapes.current.pill)
                                        .background(color)
                                        .border(
                                            width = if (selected) 3.dp else 0.dp,
                                            color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                            shape = LocalAppShapes.current.pill,
                                        ).clickable { pendingHex = hex.takeLast(6) },
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                TextField(
                    value = pendingHex,
                    onValueChange = { pendingHex = it.removePrefix("#").take(6).uppercase() },
                    label = { Text("HEX") },
                    prefix = { Text("#") },
                    singleLine = true,
                    isError = parsed == null,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = parsed != null,
                onClick = {
                    parsed?.let { onConfirm("FF${pendingHex.takeLast(6).uppercase()}") }
                },
            ) {
                Text(text = stringResource(Res.string.change))
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onReset) {
                    Text(text = stringResource(Res.string.theme_default))
                }
                TextButton(onClick = onDismiss) {
                    Text(text = stringResource(Res.string.cancel))
                }
            }
        },
    )
}
