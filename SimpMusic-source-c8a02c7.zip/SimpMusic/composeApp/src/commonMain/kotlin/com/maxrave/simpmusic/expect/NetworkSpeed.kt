package com.maxrave.simpmusic.expect

/** The player's estimate of the download throughput, in bits per second; 0 while it is unknown. */
expect fun networkBitrateEstimateBps(): Long

/** Private copy: recent download-speed samples (milliseconds since the first, bits per second), for the Stats graph. */
expect fun networkHistory(): List<Pair<Long, Long>>
