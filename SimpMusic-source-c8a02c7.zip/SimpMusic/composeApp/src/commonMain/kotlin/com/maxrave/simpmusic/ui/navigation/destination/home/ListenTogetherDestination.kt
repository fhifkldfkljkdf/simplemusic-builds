package com.maxrave.simpmusic.ui.navigation.destination.home

import kotlinx.serialization.Serializable

/**
 * [joinCode]: a room to join on arrival, from a `simpmusic://listen-together?code=` link.
 * [joinDirect]: the host's local addresses from the same link (`&lan=`), comma-separated.
 */
@Serializable
data class ListenTogetherDestination(
    val joinCode: String? = null,
    val joinDirect: String? = null,
)
