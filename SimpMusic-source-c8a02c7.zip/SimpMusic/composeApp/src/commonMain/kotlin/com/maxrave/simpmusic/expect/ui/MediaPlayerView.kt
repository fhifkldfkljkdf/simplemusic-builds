package com.maxrave.simpmusic.expect.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import com.maxrave.domain.data.model.metadata.Lyrics
import com.maxrave.domain.data.model.streams.TimeLine

@Composable
expect fun MediaPlayerView(
    url: String,
    modifier: Modifier,
    // When true, the video center scales-to-cover the given frame (ContentScale.Crop)
    // and clips the overflow. Default false keeps the legacy fit-height-by-screen
    // behavior used by NowPlaying / Fullscreen.
    cropToBounds: Boolean = false,
    // Called once the video has drawn its first frame. Until then the view shows a black shutter,
    // so a caller with a picture to show meanwhile keeps it on top until this fires.
    onFirstFrame: () -> Unit = {},
)

@Composable
expect fun MediaPlayerViewWithSubtitle(
    modifier: Modifier,
    playerName: String,
    shouldPip: Boolean = false,
    shouldShowSubtitle: Boolean,
    shouldScaleDownSubtitle: Boolean = false,
    isInPipMode: Boolean,
    timelineState: TimeLine,
    lyricsData: Lyrics? = null,
    translatedLyricsData: Lyrics? = null,
    mainTextStyle: TextStyle,
    translatedTextStyle: TextStyle,
)

/**
 * Aspect ratio (width / height) of the video [playerName] is showing, or null until the player
 * knows it. For laying out the frame around the video, so the frame takes the video's own shape
 * instead of assuming 16:9.
 */
@Composable
expect fun rememberVideoAspectRatio(playerName: String): Float?