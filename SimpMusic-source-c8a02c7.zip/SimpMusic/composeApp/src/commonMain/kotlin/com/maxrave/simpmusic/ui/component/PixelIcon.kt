package com.maxrave.simpmusic.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily

/**
 * Retro Pixel's icons are rasterised into this grid and then drawn with no smoothing.
 * 16×16 keeps details such as play arrows and queue lines recognisable while still reading as
 * pixel art; a coarser 12×12 grid read as too chunky. Cells are snapped to whole device pixels,
 * so the sprite never lands between two screen pixels.
 */
private const val PIXEL_GRID = 16

/** The vector is rendered this many times larger, then reduced to hard on/off pixels. */
private const val SAMPLE_SCALE = 4

/**
 * A cell becomes a solid pixel when this much of it was covered by the vector. Anything less is
 * dropped, which removes the grey anti-aliased fringe that made the old icons look blurry.
 */
private const val PIXEL_COVERAGE = 0.3f

/**
 * Private copy: every icon under the Retro Pixel theme is drawn as a coarse pixel grid instead of
 * a smooth vector, the way an 8-bit icon set would look. Other themes get the normal Material icon.
 * The pixel grid is cached per vector; tinting and scaling stay at draw time.
 */
@Composable
fun ThemedIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    if (LocalAppThemeFamily.current == AppThemeFamily.RETRO) {
        PixelIcon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    } else {
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    }
}

@Composable
private fun PixelIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier,
    tint: Color,
) {
    val painter = rememberVectorPainter(imageVector)
    val density = LocalDensity.current
    // The caller's size (Modifier.size) shows up as bounded constraints. Without one, Material's
    // Icon default of 24dp is replicated below so the sprite still has a grid to fill.
    BoxWithConstraints(modifier = modifier) {
        val bounded = constraints.hasBoundedWidth && constraints.hasBoundedHeight
        val side = if (bounded) minOf(maxWidth, maxHeight) else 24.dp
        val pixelated = remember(imageVector, painter) { pixelate(painter, PIXEL_GRID) }
        // Round down to a whole number of device pixels per cell, so every sprite pixel is the
        // same size (24dp at 2.75× is 66px: 16 cells of 4px, not 16 cells of 4.125px).
        val cellPx = (with(density) { side.toPx() } / PIXEL_GRID).toInt().coerceAtLeast(1)
        val drawnSide = with(density) { (cellPx * PIXEL_GRID).toDp() }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Image(
                bitmap = pixelated,
                contentDescription = contentDescription,
                modifier = Modifier.size(drawnSide),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(tint),
                filterQuality = FilterQuality.None,
            )
        }
    }
}

/**
 * The same hard-edged pixel mask for a painter that is drawn directly rather than through
 * [ThemedIcon] — the radio-mix slider's end icons, for example.
 */
@Composable
internal fun rememberPixelatedPainter(painter: Painter): Painter {
    val bitmap = remember(painter) { pixelate(painter, PIXEL_GRID) }
    return remember(bitmap) { BitmapPainter(bitmap, filterQuality = FilterQuality.None) }
}

/**
 * Render the vector large, measure how much of each grid cell it covers, and paint a fresh bitmap
 * with fully opaque or fully transparent pixels. The result has no soft edges for the upscaler to
 * smear, so an icon stays crisp at every size.
 */
private fun pixelate(
    painter: Painter,
    grid: Int,
): ImageBitmap {
    val sampleGrid = grid * SAMPLE_SCALE
    val sample = ImageBitmap(sampleGrid, sampleGrid)
    CanvasDrawScope().draw(
        density = Density(1f),
        layoutDirection = LayoutDirection.Ltr,
        canvas = Canvas(sample),
        size = Size(sampleGrid.toFloat(), sampleGrid.toFloat()),
    ) {
        with(painter) {
            draw(Size(sampleGrid.toFloat(), sampleGrid.toFloat()))
        }
    }
    val source = sample.toPixelMap()
    val cell = SAMPLE_SCALE
    val pixels = ImageBitmap(grid, grid)
    CanvasDrawScope().draw(
        density = Density(1f),
        layoutDirection = LayoutDirection.Ltr,
        canvas = Canvas(pixels),
        size = Size(grid.toFloat(), grid.toFloat()),
    ) {
        for (y in 0 until grid) {
            for (x in 0 until grid) {
                var alpha = 0f
                for (sampleY in 0 until cell) {
                    for (sampleX in 0 until cell) {
                        alpha += source[x * cell + sampleX, y * cell + sampleY].alpha
                    }
                }
                alpha /= (cell * cell).toFloat()
                if (alpha >= PIXEL_COVERAGE) {
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(x.toFloat(), y.toFloat()),
                        size = Size(1f, 1f),
                    )
                }
            }
        }
    }
    return pixels
}
