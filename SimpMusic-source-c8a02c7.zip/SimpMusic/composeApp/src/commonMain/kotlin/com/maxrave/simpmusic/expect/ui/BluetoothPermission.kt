@file:Suppress("ktlint:standard:filename")

package com.maxrave.simpmusic.expect.ui

import androidx.compose.runtime.Composable

/**
 * Private copy: asks for the "Nearby devices" permission (`BLUETOOTH_CONNECT`, Android 12+) that
 * headphone control needs. Calling the returned function answers [onResult] exactly once —
 * at once where nothing needs asking (older Android, Desktop), or after the system dialog.
 */
@Composable
expect fun rememberBluetoothPermission(onResult: (granted: Boolean) -> Unit): () -> Unit
