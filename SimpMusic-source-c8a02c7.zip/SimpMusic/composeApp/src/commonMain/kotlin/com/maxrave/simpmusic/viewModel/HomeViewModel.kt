package com.maxrave.simpmusic.viewModel

import androidx.lifecycle.viewModelScope
import com.maxrave.common.SELECTED_LANGUAGE
import com.maxrave.common.SUPPORTED_LANGUAGE
import com.maxrave.domain.data.entities.SongEntity
import com.maxrave.domain.data.model.home.HomeArtistRow
import com.maxrave.domain.data.model.home.HomeDataCombine
import com.maxrave.domain.data.model.home.HomeItem
import com.maxrave.domain.data.model.home.HomeShelfStyle
import com.maxrave.domain.data.model.home.chart.Chart
import com.maxrave.domain.data.model.home.distinctShelves
import com.maxrave.domain.data.model.home.isTakeItEasyShelf
import com.maxrave.domain.data.model.home.replaceTakeItEasy
import com.maxrave.domain.data.model.mood.Mood
import com.maxrave.domain.data.model.mood.MoodItem
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.manager.DataStoreManager.Values.TRUE
import com.maxrave.domain.repository.ForYouRepository
import com.maxrave.domain.repository.ForYouTitles
import com.maxrave.domain.repository.HomeArtists
import com.maxrave.domain.repository.HomeDiscoveryRepository
import com.maxrave.domain.repository.HomeRepository
import com.maxrave.domain.repository.genreItems
import com.maxrave.domain.utils.Resource
import com.maxrave.logger.Logger
import com.maxrave.simpmusic.viewModel.base.BaseViewModel
import kotlinx.coroutines.Job
import kotlin.coroutines.cancellation.CancellationException
import org.jetbrains.compose.resources.getString
import org.koin.core.component.inject
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.because_you_played
import simpmusic.composeapp.generated.resources.for_you
import simpmusic.composeapp.generated.resources.genre_for_you
import simpmusic.composeapp.generated.resources.listen_again
import simpmusic.composeapp.generated.resources.more_like_artist
import simpmusic.composeapp.generated.resources.music_video
import simpmusic.composeapp.generated.resources.new_for_you
import simpmusic.composeapp.generated.resources.new_release
import simpmusic.composeapp.generated.resources.quick_picks
import simpmusic.composeapp.generated.resources.recommended_genres
import simpmusic.composeapp.generated.resources.song
import simpmusic.composeapp.generated.resources.top_artists
import simpmusic.composeapp.generated.resources.view_count

class HomeViewModel(
    private val dataStoreManager: DataStoreManager,
    private val homeRepository: HomeRepository,
) : BaseViewModel() {
    private val _homeItemList: MutableStateFlow<List<HomeItem>> =
        MutableStateFlow(arrayListOf())
    val homeItemList: StateFlow<List<HomeItem>> = _homeItemList

    private var _homeListState = MutableStateFlow<ListState>(ListState.IDLE)
    val homeListState: StateFlow<ListState> = _homeListState

    private var _continuation = MutableStateFlow<String?>(null)
    val continuation: StateFlow<String?> = _continuation

    private val _exploreMoodItem: MutableStateFlow<Mood?> = MutableStateFlow(null)
    val exploreMoodItem: StateFlow<Mood?> = _exploreMoodItem
    private val _accountInfo: MutableStateFlow<Pair<String?, String?>?> = MutableStateFlow(null)
    val accountInfo: StateFlow<Pair<String?, String?>?> = _accountInfo

    private var homeJob: Job? = null

    val showSnackBarErrorState = MutableSharedFlow<String>()

    private val _chart: MutableStateFlow<Chart?> = MutableStateFlow(null)
    val chart: StateFlow<Chart?> = _chart
    private val _newRelease: MutableStateFlow<List<HomeItem>> = MutableStateFlow(arrayListOf())
    val newRelease: StateFlow<List<HomeItem>> = _newRelease
    var regionCodeChart: MutableStateFlow<String?> = MutableStateFlow(null)

    val loading = MutableStateFlow<Boolean>(true)
    val loadingChart = MutableStateFlow<Boolean>(true)
    private var regionCode: String = ""
    private var language: String = ""

    private val _songEntity: MutableStateFlow<SongEntity?> = MutableStateFlow(null)
    val songEntity: StateFlow<SongEntity?> = _songEntity

    private var _params: MutableStateFlow<String?> = MutableStateFlow(null)
    val params: StateFlow<String?> = _params

    /**
     * Private copy: signed out, YouTube Music's Home has no music (a podcast shelf and an artist
     * picker), so Quick picks, New for you and Listen again are built from radios of what this
     * phone plays (see [ForYouRepository]) and put first. The same radios also stand in for
     * YouTube's "Take it easy" row when the feed carries it, whatever the account state.
     */
    private val forYouRepository: ForYouRepository by inject()
    private var forYou: List<HomeItem> = emptyList()

    /** The local row that takes the place of YouTube's "Take it easy" shelf. */
    private var forYouRow: HomeItem? = null

    /** The last full home feed and its continuation pages, before local shelves are composed in. */
    private var baseHomeItems: List<HomeItem> = emptyList()
    private var extraHomeItems: List<HomeItem> = emptyList()
    private var forYouJob: Job? = null

    /**
     * Private copy: the rest of Home, built from this phone's listening — the artists for the
     * chart's "Top artists" grid, the "Recommended genres" row, and the song rows around them
     * ("Because you played …", "More like …", "… for you"). All of it is built in the background
     * (see [HomeDiscoveryRepository]); until it is ready the screen keeps YouTube's own feed, and
     * once any of it exists the feed's shelves are dropped in its favour.
     */
    private val homeDiscoveryRepository: HomeDiscoveryRepository by inject()
    private val _homeArtists = MutableStateFlow<HomeArtists?>(null)
    val homeArtists: StateFlow<HomeArtists?> = _homeArtists
    private val _recommendedGenres = MutableStateFlow<List<MoodItem>>(emptyList())
    private val _artistRows = MutableStateFlow<List<HomeItem>>(emptyList())
    private val _genreRows = MutableStateFlow<List<HomeItem>>(emptyList())
    private val recommendedGenresTitle by lazy { getString(Res.string.recommended_genres) }
    private val topArtistsTitle by lazy { getString(Res.string.top_artists) }
    private var homeArtistsJob: Job? = null
    private var localRowsJob: Job? = null
    private var genresJob: Job? = null
    private var genresParams: List<String>? = null

    /** One number per home load; the song rows are built once for it, not once per feed emission. */
    private var homeGeneration = 0
    private var localRowsGeneration = -1

    // For showing alert that should log in to YouTube
    private val _showLogInAlert: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val showLogInAlert: StateFlow<Boolean> = _showLogInAlert

    val dataSyncId =
        dataStoreManager
            .dataSyncId
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    private val _mainHomeThumbnail: MutableStateFlow<String?> = MutableStateFlow(null)
    val mainHomeThumbnail: StateFlow<String?> = _mainHomeThumbnail

    init {
        homeJob = Job()
        viewModelScope.launch {
            regionCodeChart.value = dataStoreManager.chartKey.first()
            exploreChart(regionCodeChart.value ?: "ZZ")
            language = dataStoreManager.getString(SELECTED_LANGUAGE).first()
                ?: SUPPORTED_LANGUAGE.codes.first()
            //  refresh when region change
            val job1 =
                launch {
                    dataStoreManager.location.distinctUntilChanged().collect {
                        regionCode = it
                        getHomeItemList(params.value)
                    }
                }
            //  refresh when language change
            val job2 =
                launch {
                    dataStoreManager.language.distinctUntilChanged().collect {
                        language = it
                        getHomeItemList(params.value)
                    }
                }
            val job3 =
                launch {
                    dataStoreManager.cookie.distinctUntilChanged().collect {
                        getHomeItemList(params.value)
                        _accountInfo.emit(
                            Pair(
                                dataStoreManager.getString("AccountName").first(),
                                dataStoreManager.getString("AccountThumbUrl").first(),
                            ),
                        )
                    }
                }
            val job4 =
                launch {
                    params.collectLatest {
                        getHomeItemList(it)
                    }
                }
            val job5 =
                launch {
                    dataStoreManager
                        .cookie
                        .distinctUntilChanged()
                        .collectLatest {
                            if (it.isNotEmpty()) {
                                Logger.w(tag, "Cookie changed, refreshing home")
                                loading.value = true
                                delay(1000) // To wait for the cookie to be saved properly
                                getHomeItemList(params.value)
                            }
                        }
                }
            val job6 =
                launch {
                    homeItemList.collectLatest { list ->
                        _mainHomeThumbnail.value =
                            list
                                .firstOrNull()
                                ?.contents
                                ?.firstOrNull()
                                ?.thumbnails
                                ?.lastOrNull()
                                ?.url
                    }
                }
            job1.join()
            job2.join()
            job3.join()
            job4.join()
            job5.join()
            job6.join()
        }
    }

    fun doneShowLogInAlert(neverShowAgain: Boolean = false) {
        viewModelScope.launch {
            _showLogInAlert.update { false }
            if (neverShowAgain) {
                dataStoreManager.setShouldShowLogInRequiredAlert(false)
            }
        }
    }

    fun getHomeItemList(params: String? = null) {
        loading.value = true
        _homeListState.value = ListState.LOADING
        language =
            runBlocking {
                dataStoreManager.getString(SELECTED_LANGUAGE).first()
                    ?: SUPPORTED_LANGUAGE.codes.first()
            }
        regionCode = runBlocking { dataStoreManager.location.first() }
        homeGeneration++
        val generation = homeGeneration
        homeJob?.cancel()
        homeJob =
            viewModelScope.launch {
                combine(
                    homeRepository.getHomeData(
                        params,
                        getString(Res.string.view_count),
                        getString(Res.string.song),
                    ),
                    homeRepository.getMoodAndMomentsData(),
                    homeRepository.getChartData(dataStoreManager.chartKey.first()),
                    homeRepository.getNewRelease(
                        getString(Res.string.new_release),
                        getString(Res.string.music_video),
                    ),
                ) { home, exploreMood, exploreChart, newRelease ->
                    HomeDataCombine(home, exploreMood, exploreChart, newRelease)
                }.collect { result ->
                    val home = result.home
                    Logger.d("home size", "${home.data?.second?.size}")
                    val exploreMoodItem = result.mood
                    val chart = result.chart
                    val newRelease = result.newRelease
                    when (home) {
                        is Resource.Success -> {
                            _continuation.value = home.data?.first
                            baseHomeItems = home.data?.second ?: listOf()
                            extraHomeItems = emptyList()
                        }

                        else -> {
                            _continuation.value = null
                            baseHomeItems = emptyList()
                            extraHomeItems = emptyList()
                        }
                    }
                    publishHomeItems()
                    // With local rows on screen the feed's pages are never shown, so there is
                    // nothing to paginate. A mood selection deliberately shows the YouTube feed,
                    // so its continuation still matters.
                    if (continuation.value.isNullOrEmpty() || (_params.value == null && hasLocalRows())) {
                        _homeListState.value = ListState.PAGINATION_EXHAUST
                    } else {
                        _homeListState.value = ListState.IDLE
                    }
                    when (chart) {
                        is Resource.Success -> {
                            _chart.value = chart.data
                        }

                        else -> {
                            _chart.value = null
                        }
                    }
                    refreshForYou(_chart.value, replaceTakeItEasy = baseHomeItems.any { it.isTakeItEasyShelf() })
                    loadHomeArtists()
                    loadLocalRows(generation)
                    when (newRelease) {
                        is Resource.Success -> {
                            _newRelease.value = newRelease.data ?: arrayListOf()
                        }

                        else -> {
                            _newRelease.value = arrayListOf()
                        }
                    }
                    when (exploreMoodItem) {
                        is Resource.Success -> {
                            _exploreMoodItem.value = exploreMoodItem.data
                            exploreMoodItem.data?.let { loadRecommendedGenres(it) }
                        }

                        else -> {
                            _exploreMoodItem.value = null
                        }
                    }
                    regionCodeChart.value = dataStoreManager.chartKey.first()
                    Logger.d("HomeViewModel", "getHomeItemList: $result")
                    dataStoreManager.cookie.first().let {
                        if (it != "") {
                            _accountInfo.emit(
                                Pair(
                                    dataStoreManager.getString("AccountName").first(),
                                    dataStoreManager.getString("AccountThumbUrl").first(),
                                ),
                            )
                        }
                    }
                    when {
                        home is Resource.Error -> home.message
                        exploreMoodItem is Resource.Error -> exploreMoodItem.message
                        chart is Resource.Error -> chart.message
                        else -> null
                    }?.let {
                        showSnackBarErrorState.emit(it)
                        Logger.w("Error", "getHomeItemList: ${home.message}")
                        Logger.w("Error", "getHomeItemList: ${exploreMoodItem.message}")
                        Logger.w("Error", "getHomeItemList: ${chart.message}")
                    }
                    loading.value = false
                }
            }
    }

    /**
     * Private copy: builds Quick picks, New for you and Listen again in the background, always —
     * the feed's own shelves are dropped in their favour, signed in or out. [replaceTakeItEasy]: the
     * feed carried YouTube's "Take it easy" row and no shelf was built, so one "For you" row is
     * prepared for the fallback case where the feed itself has to show. [chart]: its first playlist
     * seeds the shelves before there is any listening history.
     */
    private fun refreshForYou(
        chart: Chart?,
        replaceTakeItEasy: Boolean,
    ) {
        forYouJob?.cancel()
        forYouJob =
            viewModelScope.launch {
                val trending = chart?.listChartItem?.firstOrNull()?.playlists?.firstOrNull()?.id
                val titles =
                    ForYouTitles(
                        quickPicks = getString(Res.string.quick_picks),
                        newForYou = getString(Res.string.new_for_you),
                        listenAgain = getString(Res.string.listen_again),
                    )
                val shelves =
                    try {
                        forYouRepository.shelves(titles, trending)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Logger.w(tag, "For you shelves failed: ${e.message}")
                        forYou
                    }
                // The "For you" row only matters when the feed itself is shown: with any shelf
                // built, the feed's rows are gone and so is the "Take it easy" row it replaced.
                val row =
                    if (!replaceTakeItEasy || shelves.isNotEmpty()) {
                        null
                    } else {
                        try {
                            forYouRepository.forYou(getString(Res.string.for_you), trending)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            Logger.w(tag, "For you row failed: ${e.message}")
                            forYouRow
                        }
                    }
                forYou = shelves
                forYouRow = row
                publishHomeItems()
            }
    }

    /**
     * Private copy: the song rows around the shelves — "Because you played <song>" and one "More
     * like <artist>" per most played artist — from radios of this phone's top songs.
     */
    private fun loadLocalRows(generation: Int) {
        // The feed emits several times per load (the mood cache, then the network); the rows are
        // built once per load, not once per emission.
        if (localRowsGeneration == generation) return
        localRowsGeneration = generation
        localRowsJob?.cancel()
        localRowsJob =
            viewModelScope.launch {
                try {
                    // The two row kinds do not depend on each other, so their radios go together.
                    val (because, artists) =
                        coroutineScope {
                            val becauseRow = async { homeDiscoveryRepository.becauseYouPlayedRow(ROW_SIZE) }
                            val artistRows = async { homeDiscoveryRepository.artistRows(ARTIST_ROWS, ROW_SIZE) }
                            becauseRow.await() to artistRows.await()
                        }
                    val rows = ArrayList<HomeItem>(1 + artists.size)
                    because?.let { row ->
                        rows +=
                            HomeItem(
                                contents = row.contents,
                                title = getString(Res.string.because_you_played, row.subject),
                                itemsPerColumn = 1,
                                format = HomeShelfStyle.FEATURE,
                                feature = row.feature,
                            )
                    }
                    artists.forEach { row ->
                        rows +=
                            HomeItem(
                                contents = row.contents,
                                title = getString(Res.string.more_like_artist, row.subject),
                                itemsPerColumn = 1,
                                format = HomeShelfStyle.WIDE,
                            )
                    }
                    _artistRows.value = rows
                    publishHomeItems()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Logger.w(tag, "Home rows failed: ${e.message}")
                }
            }
    }

    /**
     * Private copy: the artists for the chart's "Top artists" grid, from this phone's listening and
     * the artists related to it. Nothing is put on screen until it is ready, so a first run without
     * a cache shows YouTube's own chart artists; a phone with no history keeps them for good.
     */
    private fun loadHomeArtists() {
        // The feed emits several times per load (the mood cache, then the network); a run already
        // under way covers all of them.
        if (homeArtistsJob?.isActive == true) return
        homeArtistsJob =
            viewModelScope.launch {
                try {
                    val artists = homeDiscoveryRepository.topArtists(TOP_ARTISTS, RELATED_ARTISTS)
                    _homeArtists.value = artists.takeIf { it.artists.isNotEmpty() }
                    publishHomeItems()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Logger.w(tag, "Top artists failed: ${e.message}")
                }
            }
    }

    /**
     * Private copy: the "Recommended genres" row, built by checking YouTube's genre pages against
     * this phone's listening, and one "… for you" row per genre from the same pages. The repository
     * caches the selection, so the second call for the same genre list is cheap.
     */
    private fun loadRecommendedGenres(mood: Mood) {
        // The mood data arrives twice (cache, then network); a run already covering the same genre
        // list is left alone, while a different one (a language change) replaces it.
        val params = mood.genreItems().map { it.params }
        if (params.isEmpty()) return
        if (genresJob?.isActive == true && params == genresParams) return
        genresParams = params
        genresJob?.cancel()
        genresJob =
            viewModelScope.launch {
                try {
                    val genres = homeDiscoveryRepository.recommendedGenres(mood, RECOMMENDED_GENRES)
                    _recommendedGenres.value = genres
                    _genreRows.value =
                        homeDiscoveryRepository.genreRows(genres, ROW_SIZE).map { row ->
                            HomeItem(
                                contents = row.contents,
                                title = getString(Res.string.genre_for_you, row.subject),
                                itemsPerColumn = 1,
                                format = HomeShelfStyle.TOP_LIST,
                            )
                        }
                    publishHomeItems()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Logger.w(tag, "Recommended genres failed: ${e.message}")
                }
            }
    }

    /**
     * Home as the screen should show it. The app's own rows come first — the shelves, the "Because
     * you played" and "More like" rows, the genre cards and the "… for you" rows — and when any of
     * them exists YouTube's feed shelves are dropped. Only with no local row at all (no history and
     * nothing to seed from) does the feed itself show, with its "Take it easy" row replaced and
     * duplicate titles dropped. Every later song row leaves out songs already shown above it.
     */
    private fun publishHomeItems() {
        // A mood chip is a YouTube feed filter. The app-built rows are generated from listening
        // history, not from the mood, so showing them under "Relax" would leave the selection with
        // no visible effect. Let the mood's own feed through instead; "All" restores the local rows.
        if (_params.value != null) {
            _homeItemList.value = (baseHomeItems + extraHomeItems).distinctShelves()
            _homeListState.value = if (continuation.value.isNullOrEmpty()) ListState.PAGINATION_EXHAUST else ListState.IDLE
            return
        }
        val used = HashSet<String>()
        forYou.forEach { shelf -> shelf.contents.forEach { content -> content?.videoId?.takeIf { it.isNotBlank() }?.let(used::add) } }
        val rows = ArrayList<HomeItem>(forYou.size + _artistRows.value.size + _genreRows.value.size + 1)
        rows += forYou
        rows += remainingRows(_artistRows.value, used)
        _recommendedGenres.value.takeIf { it.isNotEmpty() }?.let { genres ->
            rows += HomeItem(contents = emptyList(), title = recommendedGenresTitle, moodItems = genres)
        }
        rows += remainingRows(_genreRows.value, used)
        // "Top artists" sits near the top of the feed, right after the first row.
        _homeArtists.value?.let { artists ->
            val at = if (forYou.isNotEmpty()) 1.coerceAtMost(rows.size) else minOf(1, rows.size)
            rows.add(
                at,
                HomeItem(
                    contents = emptyList(),
                    title = topArtistsTitle,
                    topArtists = HomeArtistRow(artists.artists, artists.knownCount, artists.newCount),
                ),
            )
        }
        if (rows.isNotEmpty()) {
            _homeItemList.value = rows
            _homeListState.value = ListState.PAGINATION_EXHAUST
            return
        }
        _homeItemList.value = (baseHomeItems + extraHomeItems).distinctShelves().replaceTakeItEasy(forYouRow)
    }

    /** [rows] without the songs already shown above them; a row left empty is dropped. */
    private fun remainingRows(
        rows: List<HomeItem>,
        used: MutableSet<String>,
    ): List<HomeItem> =
        rows.mapNotNull { row ->
            val contents = row.contents.filter { content -> content?.videoId?.takeIf { it.isNotBlank() }?.let(used::add) ?: true }
            row.copy(contents = contents).takeIf { contents.isNotEmpty() }
        }

    /** Whether any app-built row exists; while one does, the feed's own shelves are not shown. */
    private fun hasLocalRows(): Boolean =
        forYou.isNotEmpty() ||
            _artistRows.value.isNotEmpty() ||
            _recommendedGenres.value.isNotEmpty() ||
            _genreRows.value.isNotEmpty() ||
            _homeArtists.value != null

    /** A shelf's "Play all": YouTube's own finite queue of that shelf's songs. */
    fun playAll(item: HomeItem) {
        item.playAllEndpoint?.let { playFromEndpoint(it, item.title) }
    }

    fun getContinueHomeItem(continuation: String?) {
        viewModelScope.launch {
            if (continuation.isNullOrEmpty()) {
                _homeListState.value = ListState.PAGINATION_EXHAUST
                return@launch
            } else {
                log("Get more home item with continuation: $continuation")
                _homeListState.value = ListState.PAGINATING
                homeRepository
                    .getHomeDataContinue(
                        continuation,
                        getString(Res.string.view_count),
                        getString(Res.string.song),
                    ).collect { home ->
                        when (home) {
                            is Resource.Success -> {
                                _continuation.value = home.data?.first
                                extraHomeItems = extraHomeItems + (home.data?.second ?: listOf())
                                publishHomeItems()
                                // The row can also arrive on a later page, after the first one was
                                // composed without it.
                                if (forYouRow == null && extraHomeItems.any { it.isTakeItEasyShelf() }) {
                                    refreshForYou(_chart.value, replaceTakeItEasy = true)
                                }
                                if (home.data?.first.isNullOrEmpty() || hasLocalRows()) {
                                    _homeListState.value = ListState.PAGINATION_EXHAUST
                                } else {
                                    _homeListState.value = ListState.IDLE
                                }
                            }

                            is Resource.Error -> {
                                _continuation.value = null
                                Logger.w(tag, "getContinueHomeItem: ${home.message}")
                                showSnackBarErrorState.emit(home.message ?: "Unknown error")
                                _homeListState.value = ListState.PAGINATION_EXHAUST
                            }
                        }
                    }
            }
        }
    }

    fun exploreChart(region: String) {
        viewModelScope.launch {
            loadingChart.value = true
            homeRepository
                .getChartData(
                    region,
                ).collect { values ->
                    regionCodeChart.value = region
                    dataStoreManager.setChartKey(region)
                    when (values) {
                        is Resource.Success -> {
                            _chart.value = values.data
                        }

                        else -> {
                            _chart.value = null
                        }
                    }
                    loadingChart.value = false
                }
        }
    }

    fun setParams(params: String?) {
        _params.value = params
    }

    override fun onCleared() {
        super.onCleared()
        homeJob?.cancel()
        homeArtistsJob?.cancel()
        localRowsJob?.cancel()
        genresJob?.cancel()
    }

    companion object {
        // Private copy: how many artists Home's "Top artists" grid carries, how many genres
        // "Recommended genres" may show, how many "More like" rows there can be, and how many songs
        // an app-built song row carries.
        const val TOP_ARTISTS = 10
        const val RELATED_ARTISTS = 6
        const val RECOMMENDED_GENRES = 6
        const val ARTIST_ROWS = 3
        const val ROW_SIZE = 15

        // Home params
        const val HOME_PARAMS_RELAX = "ggM8SgQIBxADSgQIBRABSgQICRABSgQIChABSgQIDRABSgQICBABSgQIBBABSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_SLEEP = "ggM8SgQIBxABSgQIBRADSgQICRABSgQIChABSgQIDRABSgQICBABSgQIBBABSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_ENERGIZE = "ggM8SgQIBxABSgQIBRABSgQICRADSgQIChABSgQIDRABSgQICBABSgQIBBABSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_SAD = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChADSgQIDRABSgQICBABSgQIBBABSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_ROMANCE = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChABSgQIDRADSgQICBABSgQIBBABSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_FEEL_GOOD = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChABSgQIDRABSgQICBADSgQIBBABSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_WORKOUT = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChABSgQIDRABSgQICBABSgQIBBADSgQIDhABSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_PARTY = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChABSgQIDRABSgQICBABSgQIBBABSgQIDhADSgQIAxABSgQIBhAB"
        const val HOME_PARAMS_COMMUTE = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChABSgQIDRABSgQICBABSgQIBBABSgQIDhABSgQIAxADSgQIBhAB"
        const val HOME_PARAMS_FOCUS = "ggM8SgQIBxABSgQIBRABSgQICRABSgQIChABSgQIDRABSgQICBABSgQIBBABSgQIDhABSgQIAxABSgQIBhAD"
    }
}