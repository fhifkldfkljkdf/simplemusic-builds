package com.maxrave.simpmusic.ui.navigation.destination.home

import kotlinx.serialization.Serializable

/** Private copy: the Statistics screen (headphones battery and network graphs). */
@Serializable
data object StatsDestination
