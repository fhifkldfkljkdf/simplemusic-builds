package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.maxrave.domain.data.model.home.HomeItem
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.ui.HorizontalScrollBar
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.component.HomeSectionHeader
import com.maxrave.simpmusic.ui.component.MoodMomentAndGenreHomeItem
import com.maxrave.simpmusic.ui.navigation.destination.home.MoodDestination

/**
 * Private copy: Home's own "Recommended genres" row. The cards are the same stripe cards the
 * Moods & Genres grid uses, each opening its category page, so a genre behaves the same wherever
 * it is met. The row carries its own [HomeItem], whose `moodItems` hold the cards; nothing here
 * touches YouTube's feed.
 */
@Composable
fun RecommendedGenresRow(
    data: HomeItem,
    navController: NavController,
) {
    val listState = rememberLazyListState()
    val flingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyListState = listState))
    Column {
        HomeSectionHeader(data = data, navController = navController, onPlayAll = {})
        LazyRow(
            state = listState,
            flingBehavior = flingBehavior,
        ) {
            items(data.moodItems, key = { it.params }) { genre ->
                MoodMomentAndGenreHomeItem(
                    title = genre.title,
                    stripeColor = genre.stripeColor,
                ) {
                    navController.navigate(MoodDestination(genre.params))
                }
            }
        }
        if (getPlatform() == Platform.Desktop) {
            HorizontalScrollBar(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                scrollState = listState,
                flingBehavior = flingBehavior,
            )
        }
    }
}
