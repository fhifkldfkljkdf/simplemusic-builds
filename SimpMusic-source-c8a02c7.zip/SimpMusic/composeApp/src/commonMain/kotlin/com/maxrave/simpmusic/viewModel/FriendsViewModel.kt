package com.maxrave.simpmusic.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxrave.domain.data.model.friends.AddFriendResult
import com.maxrave.domain.data.model.friends.FriendsState
import com.maxrave.domain.repository.FriendsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * The Friends page, and the app-wide prompts for incoming invites and requests. Everything that
 * lasts lives in [FriendsRepository]; this holds only what one page is doing right now.
 */
class FriendsViewModel(
    private val repository: FriendsRepository,
) : ViewModel() {
    init {
        repository.start()
    }

    val state: StateFlow<FriendsState> = repository.state

    sealed interface Notice {
        data class Added(
            val name: String,
            val delivered: Boolean,
        ) : Notice

        data class AlreadyFriends(
            val name: String,
        ) : Notice

        data object NotAFriendCode : Notice

        data object ThatIsYou : Notice

        data class InviteFailed(
            val name: String,
        ) : Notice
    }

    private val _notice = MutableStateFlow<Notice?>(null)
    val notice: StateFlow<Notice?> = _notice.asStateFlow()

    /** Friends invited to the room during this visit, and those whose invite is still on its way. */
    private val _invited = MutableStateFlow<Set<String>>(emptySet())
    val invited: StateFlow<Set<String>> = _invited.asStateFlow()
    private val _sending = MutableStateFlow<Set<String>>(emptySet())
    val sending: StateFlow<Set<String>> = _sending.asStateFlow()

    private val _adding = MutableStateFlow(false)
    val adding: StateFlow<Boolean> = _adding.asStateFlow()

    /** Gives this device its key, so it has a friend code to show. */
    fun open() {
        viewModelScope.launch { repository.ensureIdentity() }
    }

    fun setMyName(name: String) {
        viewModelScope.launch { repository.setMyName(name) }
    }

    fun isFriendCode(text: String): Boolean = repository.isFriendCode(text)

    fun addFriend(code: String) {
        if (_adding.value) return
        _adding.value = true
        viewModelScope.launch {
            try {
                _notice.value =
                    when (val result = repository.addFriend(code)) {
                        is AddFriendResult.Added -> Notice.Added(result.friend.name, result.delivered)
                        is AddFriendResult.AlreadyFriends -> Notice.AlreadyFriends(result.friend.name)
                        AddFriendResult.NotAFriendCode -> Notice.NotAFriendCode
                        AddFriendResult.ThatIsYou -> Notice.ThatIsYou
                    }
            } finally {
                _adding.value = false
            }
        }
    }

    /** For the camera: answers whether [text] was a friend code, and adds its owner if so. */
    fun onScanned(text: String): Boolean {
        if (!repository.isFriendCode(text)) return false
        addFriend(text)
        return true
    }

    fun accept(publicKey: String) {
        viewModelScope.launch { repository.acceptRequest(publicKey) }
    }

    fun decline(publicKey: String) {
        viewModelScope.launch { repository.declineRequest(publicKey) }
    }

    fun remove(publicKey: String) {
        viewModelScope.launch { repository.removeFriend(publicKey) }
    }

    fun invite(
        publicKey: String,
        roomCode: String,
    ) {
        if (publicKey in _sending.value) return
        _sending.update { it + publicKey }
        viewModelScope.launch {
            try {
                if (publicKey in repository.inviteToRoom(listOf(publicKey), roomCode)) {
                    _invited.update { it + publicKey }
                } else {
                    val name = state.value.friends.firstOrNull { it.publicKey == publicKey }?.name.orEmpty()
                    _notice.value = Notice.InviteFailed(name)
                }
            } finally {
                _sending.update { it - publicKey }
            }
        }
    }

    fun dismissInvite(inviteId: String) {
        viewModelScope.launch { repository.dismissInvite(inviteId) }
    }

    fun clearNotice() {
        _notice.value = null
    }
}
