package com.maxrave.simpmusic.ui.navigation.destination.home

import kotlinx.serialization.Serializable

/**
 * [roomCode]: the Listen Together room we are in, so friends can be invited into it.
 * [addCode]: a friend code to offer on arrival, from a `simpmusic://friend?npub=` link.
 */
@Serializable
data class FriendsDestination(
    val roomCode: String? = null,
    val addCode: String? = null,
)
