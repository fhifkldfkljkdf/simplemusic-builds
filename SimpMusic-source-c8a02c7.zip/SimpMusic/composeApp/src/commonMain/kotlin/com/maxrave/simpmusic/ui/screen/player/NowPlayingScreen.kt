@file:OptIn(ExperimentalMaterial3Api::class)

package com.maxrave.simpmusic.ui.screen.player

import com.maxrave.simpmusic.ui.theme.appCorner
import androidx.compose.animation.Animatable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetValue
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.kmpalette.rememberPaletteState
import com.maxrave.common.Config.MAIN_PLAYER
import com.maxrave.domain.data.entities.DownloadState
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.mediaservice.handler.MediaPlayerHandler
import com.maxrave.logger.Logger
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.networkBitrateEstimateBps
import com.maxrave.simpmusic.expect.ui.rememberVideoAspectRatio
import com.maxrave.simpmusic.extension.GradientAngle
import com.maxrave.simpmusic.extension.GradientOffset
import com.maxrave.simpmusic.extension.KeepScreenOn
import com.maxrave.simpmusic.extension.getColorFromPalette
import com.maxrave.simpmusic.extension.getScreenSizeInfo
import com.maxrave.simpmusic.extension.hsvToColor
import com.maxrave.simpmusic.extension.rememberIsInPipMode
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.component.AddToPlaylistModalBottomSheet
import com.maxrave.simpmusic.ui.component.FullscreenLyricsContent
import com.maxrave.simpmusic.ui.component.FullscreenLyricsSheet
import com.maxrave.simpmusic.ui.component.InfoPlayerBottomSheet
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.utils.toSongEntity
import com.maxrave.simpmusic.ui.component.NowPlayingBottomSheet
import com.maxrave.simpmusic.ui.component.QueueBottomSheet
import com.maxrave.simpmusic.ui.component.QueuePosition
import com.maxrave.simpmusic.ui.component.VoteLyricsDialog
import com.maxrave.simpmusic.ui.icon.KeyboardArrowDown
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.navigation.destination.home.ListenTogetherDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.ArtistDestination
import com.maxrave.simpmusic.ui.navigation.destination.player.FullscreenDestination
import com.maxrave.simpmusic.ui.screen.player.content.NowPlayingContentActions
import com.maxrave.simpmusic.ui.screen.player.content.downloadSpeedLabel
import com.maxrave.simpmusic.ui.screen.player.content.NowPlayingContentAppleMusic
import com.maxrave.simpmusic.ui.screen.player.content.NowPlayingContentM3Expressive
import com.maxrave.simpmusic.ui.screen.player.content.NowPlayingContentSpotify
import com.maxrave.simpmusic.ui.screen.player.content.NowPlayingContentState
import com.maxrave.simpmusic.ui.screen.player.content.PlayerBackdropColor
import com.maxrave.simpmusic.ui.screen.player.content.playbackSourceLabel
import com.maxrave.simpmusic.ui.screen.player.content.fullscreenCanvas
import com.maxrave.simpmusic.ui.screen.player.content.toAudioQualityLabel
import com.maxrave.simpmusic.viewModel.LyricsProvider
import com.maxrave.simpmusic.viewModel.NowPlayingBottomSheetUIEvent
import com.maxrave.simpmusic.viewModel.NowPlayingBottomSheetViewModel
import com.maxrave.simpmusic.viewModel.SharedViewModel
import com.maxrave.simpmusic.viewModel.UIEvent
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import kotlinx.coroutines.flow.flowOf
import com.maxrave.domain.repository.HeadsetRepository
import com.maxrave.domain.repository.StreamRepository
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.downloaded

private const val TAG = "NowPlayingScreen"

// Desktop's fullscreen lyrics page: in a little slower than out, so opening reads as arriving and
// closing gets out of the way.
private const val FULLSCREEN_LYRICS_ENTER_MS = 300
private const val FULLSCREEN_LYRICS_EXIT_MS = 220

@OptIn(ExperimentalFoundationApi::class)
@ExperimentalMaterial3Api
@Composable
fun NowPlayingScreen(
    sharedViewModel: SharedViewModel = koinInject(),
    navController: NavController,
    onDismiss: () -> Unit = {},
) {
    val coroutineScope = rememberCoroutineScope()
    val sheetState =
        rememberModalBottomSheetState(
            skipPartiallyExpanded = true,
        )

    val hideSheet: () -> Unit = {
        coroutineScope.launch {
            sheetState.hide()
            onDismiss()
        }
    }

    ModalBottomSheet(
        modifier =
            Modifier
                .fillMaxHeight(),
        onDismissRequest = {
            onDismiss()
        },
        containerColor = Color.Black,
        dragHandle = {},
        scrimColor = Color.Black.copy(alpha = .5f),
        sheetState = sheetState,
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) },
        shape = RectangleShape,
    ) {
        NowPlayingScreenContent(
            sharedViewModel = sharedViewModel,
            navController = navController,
            isExpanded = sheetState.currentValue == SheetValue.Expanded,
            dismissIcon = SimpIcons.KeyboardArrowDown,
            onDismiss = {
                hideSheet()
            },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NowPlayingScreenContent(
    sharedViewModel: SharedViewModel = koinInject(),
    mediaPlayerHandler: MediaPlayerHandler = koinInject(),
    navController: NavController,
    isExpanded: Boolean,
    dismissIcon: ImageVector,
    onDismiss: () -> Unit = {},
) {
    val coroutineScope = rememberCoroutineScope()

    // ViewModel State
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val screenDataState by sharedViewModel.nowPlayingScreenData.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    // Audio-delay correction, read here and applied ONLY to the lyric line below. The seek bar and
    // the elapsed-time readout keep the raw position: they report where the player is, while a
    // lyric reports what the ear is hearing, and those two are what the offset separates.
    val lyricsOffsetMs by sharedViewModel.getLyricsOffsetMs().collectAsStateWithLifecycle(0)
    val likeStatus by sharedViewModel.likeStatus.collectAsStateWithLifecycle()
    val castState by sharedViewModel.castState.collectAsStateWithLifecycle()
    // Apple Music style's quality line under the progress bar — see NowPlayingContentState.toAudioQualityLabel.
    val formatState by sharedViewModel.format.collectAsStateWithLifecycle(initialValue = null)

    val shouldShowVideo by sharedViewModel.getVideo.collectAsStateWithLifecycle()
    val translatedVoteState by sharedViewModel.translatedVoteState.collectAsStateWithLifecycle()
    val lyricsVoteState by sharedViewModel.lyricsVoteState.collectAsStateWithLifecycle()
    val isUserLoggedIn by sharedViewModel
        .isUserLoggedInFlow()
        .collectAsStateWithLifecycle(initialValue = false)

    // Which Now Playing style renders the content layer (Settings → Now Playing style).
    val nowPlayingStyle by sharedViewModel
        .getNowPlayingStyle()
        .collectAsStateWithLifecycle(initialValue = DataStoreManager.NOW_PLAYING_STYLE_SPOTIFY)

    // Artwork Pager state — Spotify-style horizontal swipe between queue tracks.
    // The pager wraps the Canvas + Thumbnail layers. Controller layout below stays fixed.
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val queueDataState by sharedViewModel.getQueueDataState().collectAsStateWithLifecycle()
    val artworkQueue by remember {
        derivedStateOf { queueDataState?.data?.listTracks ?: emptyList() }
    }
    // ⚠️ Use track.videoId (already prefix-stripped at MediaServiceHandlerImpl.kt:386).
    // Do NOT use mediaItem.mediaId — it carries the "Video" prefix for video items.
    val nowPlayingVideoId: String? = nowPlayingState?.track?.videoId
    val streamRepository: StreamRepository = koinInject()
    val playingSource by remember(nowPlayingVideoId) {
        nowPlayingVideoId?.let { streamRepository.playingSource(it) } ?: flowOf(null)
    }.collectAsStateWithLifecycle(initialValue = null)
    // Private copy: the player's download-throughput estimate, refreshed while the player is up, for
    // the stats beside the source pill. It is 0 while nothing has been measured, so the label hides.
    var downloadSpeedBps by remember { mutableStateOf(0L) }
    LaunchedEffect(nowPlayingVideoId) {
        while (true) {
            downloadSpeedBps = networkBitrateEstimateBps()
            delay(2_000)
        }
    }
    // Private copy: noise control of the connected headphones. Collecting it is what keeps the
    // headset's control channel open (HeadsetRepository), so it is collected here, with the player.
    val headsetRepository: HeadsetRepository = koinInject()
    val headsetState by headsetRepository.state.collectAsStateWithLifecycle()
    val headsetBadge = rememberHeadsetBadge(headsetState)
    // currentOrderIndex() is a plain getter over the player, NOT Compose state, so it is read
    // inside this remember block — whose keys (the queue, and the track now playing) are exactly
    // the two things that can move the player's position. nowPlayingState is published FROM the
    // player's own transition callback, so by the time nowPlayingVideoId changes here the player
    // index has already moved; reading it any earlier would sample the outgoing track.
    val currentOrderIndex by remember(artworkQueue, nowPlayingVideoId) {
        derivedStateOf {
            deriveOrderIndex(
                queue = artworkQueue,
                nowPlayingVideoId = nowPlayingVideoId,
                playerOrderIndex = mediaPlayerHandler.currentOrderIndex(),
            )
        }
    }
    // Single PagerState — the unified ArtworkPager renders BOTH the fullscreen canvas
    // background and the centered square thumbnail in each page, so we don't need two
    // pagers + state mirroring.
    val artworkPagerState =
        rememberPagerState(
            initialPage = currentOrderIndex.coerceAtLeast(0),
            pageCount = { artworkQueue.size.coerceAtLeast(1) },
        )
    var isAnimatingFromPlayer by remember { mutableStateOf(false) }
    var isUserDraggingActive by remember { mutableStateOf(false) }
    // Whether a real finger-drag is waiting to be turned into a seek. See the latch below.
    var pendingUserSwipe by remember { mutableStateOf(false) }

    // Drag detection — `isScrollInProgress` is `true` for both user drags (forwarded
    // by the outer Modifier.scrollable on the Column) and programmatic
    // `animateScrollToPage`. We disambiguate via `isAnimatingFromPlayer`, which we
    // set explicitly around the player → pager animation (try/finally).
    LaunchedEffect(artworkPagerState) {
        snapshotFlow {
            artworkPagerState.isScrollInProgress to isAnimatingFromPlayer
        }.collect { (scrolling, animating) ->
            isUserDraggingActive = scrolling && !animating
            // Latched, and cleared only once a seek has been dispatched for it. settledPage can
            // move for reasons that are NOT a swipe — the pager being composed for the first time,
            // or re-composed after the Apple Music style spent a while on its Queue/Lyrics tab,
            // where the pager does not exist at all and its settledPage stays frozen on the track
            // that was playing when the user left MAIN. Without this latch, coming back from that
            // tab replays a stale page as though it had just been swiped to.
            if (isUserDraggingActive) pendingUserSwipe = true
        }
    }

    // ① Player → Pager: animate to new track when player advances.
    //
    // Keyed on the track ALONE. It used to be keyed on the queue SIZE as well, and a changing key
    // cancels the running effect — including the animateScrollToPage in flight. A cancelled scroll
    // simply stops where it is; nothing snaps it to a page afterwards, because snapping belongs to
    // the gesture path, not to a programmatic scroll. Turning on the radio appends to the queue
    // repeatedly, so the size changed again and again and cut the animation short each time,
    // leaving the pager parked between two pages. The size is still read below — just as a value,
    // not as a trigger; ③ handles the case where the queue shrinks under the current page.
    LaunchedEffect(currentOrderIndex) {
        val target = currentOrderIndex
        if (!isUserDraggingActive &&
            artworkQueue.isNotEmpty() &&
            target in 0 until artworkQueue.size &&
            target != artworkPagerState.currentPage
        ) {
            isAnimatingFromPlayer = true
            try {
                // Animate only a neighbouring page — that is a track change, and the slide IS the
                // feedback. A jump of many pages is not: trimming a radio queue's history drops the
                // current track's index by dozens without changing the track, and animating that
                // flings the pager through dozens of covers to land on the same song.
                if (abs(target - artworkPagerState.currentPage) <= 1) {
                    artworkPagerState.animateScrollToPage(target)
                } else {
                    artworkPagerState.scrollToPage(target)
                }
            } finally {
                isAnimatingFromPlayer = false
            }
        }
    }

    // ② Pager → Player: seek when user settles on a different page.
    // Adjacent (±1) → Next/Previous (preserves crossfade flow on Android).
    // Far skip → playMediaItemInMediaSource (handles unshuffling internally).
    //
    // Keyed on artworkPagerState ALONE — deliberately NOT on currentOrderIndex/queue size, which
    // are read through rememberUpdatedState instead. This effect exists to catch a user SWIPE, and
    // the only thing that moves settledPage is the pager. Re-keying it on the track built a NEW
    // snapshotFlow on every track change, and a new flow's FIRST emission is whatever settledPage
    // happens to hold — distinctUntilChanged has no previous value to suppress it against — so a
    // STALE page was dispatched as though the user had just swiped to it.
    //
    // That is what broke the Apple Music queue: its pager lives inside MAIN, so while QUEUE is on
    // screen the pager is not composed at all and settledPage still points at the previous track.
    // Tapping a row seeked correctly, the track changed, this effect was rebuilt, and it
    // immediately read the stale page — computeSeekAction(previous, current) == Previous — which
    // sent the player straight back to the song that had just been playing.
    // AppleMusicQueueView already uses rememberUpdatedState for exactly this hazard (its offset).
    val latestOrderIndex by rememberUpdatedState(currentOrderIndex)
    val latestQueueSize by rememberUpdatedState(artworkQueue.size)
    LaunchedEffect(artworkPagerState) {
        snapshotFlow { artworkPagerState.settledPage }
            .distinctUntilChanged()
            .collect { settled ->
                if (isAnimatingFromPlayer) return@collect
                // The seek is a response to a SWIPE, so there must have been one. This is what
                // stops the Apple Music queue from being overruled: tapping a row seeks correctly,
                // the track changes, and then this effect would otherwise notice the pager sitting
                // on the old page and "correct" it right back.
                if (!pendingUserSwipe) return@collect
                pendingUserSwipe = false
                val queueSize = latestQueueSize
                val orderIndex = latestOrderIndex
                if (queueSize == 0) return@collect
                if (settled !in 0 until queueSize) return@collect
                if (settled == orderIndex) return@collect

                runCatching {
                    when (val action = computeSeekAction(settled, orderIndex)) {
                        ArtworkSeekAction.Next -> {
                            sharedViewModel.onUIEvent(UIEvent.Next)
                        }
                        // Use SkipToPrevious so a swipe always goes to the previous track —
                        // UIEvent.Previous would seek to 0 of the current track once the
                        // playhead has passed the 3-second mark.
                        ArtworkSeekAction.Previous -> {
                            sharedViewModel.onUIEvent(UIEvent.SkipToPrevious)
                        }
                        is ArtworkSeekAction.Skip -> {
                            mediaPlayerHandler.playMediaItemInMediaSource(action.index)
                        }
                        ArtworkSeekAction.NoOp -> {
                            Unit
                        }
                    }
                }.onFailure { error ->
                    Logger.w(TAG, "ArtworkPager seek failed: ${error.message}")
                }
            }
    }

    // ③ Queue mutation guard — when queue shrinks below currentPage, scroll to last index
    // to avoid IndexOutOfBoundsException during recomposition.
    LaunchedEffect(artworkQueue.size) {
        if (artworkQueue.isNotEmpty() && artworkPagerState.currentPage >= artworkQueue.size) {
            runCatching { artworkPagerState.scrollToPage(artworkQueue.lastIndex) }
        }
    }

    // State
    val isInPipMode = rememberIsInPipMode()

    val mainScrollState = rememberScrollState()

    var showHideMiddleLayout by rememberSaveable {
        mutableStateOf(true)
    }

    var showSheet by rememberSaveable {
        mutableStateOf(false)
    }

    var showFullscreenLyrics by rememberSaveable {
        mutableStateOf(false)
    }
    val fullscreenLyricsRequested by sharedViewModel.fullscreenLyricsRequest.collectAsStateWithLifecycle()
    LaunchedEffect(fullscreenLyricsRequested) {
        if (fullscreenLyricsRequested) {
            showFullscreenLyrics = true
            sharedViewModel.consumeFullscreenLyricsRequest()
        }
    }

    var showQueueBottomSheet by rememberSaveable {
        mutableStateOf(false)
    }
    // A queue row's ⋯ in the Apple Music style, whose queue is a tab of this screen rather than a
    // sheet: its position and the track that was there. The other styles' queue sheet hosts its own.
    var queueMoreFor by remember { mutableStateOf<Pair<Int, Track>?>(null) }

    // Private copy: the sources sheet, and what the player says it reads from.
    var showSourcesSheet by rememberSaveable {
        mutableStateOf(false)
    }
    var showHeadsetSheet by rememberSaveable {
        mutableStateOf(false)
    }

    var showInfoBottomSheet by rememberSaveable {
        mutableStateOf(false)
    }

    var showVoteDialog by rememberSaveable {
        mutableStateOf(false)
    }

    // NEW: Add to Playlist state
    var showAddToPlaylistDirectly by rememberSaveable {
        mutableStateOf(false)
    }

    var shouldShowToolbar by remember {
        mutableStateOf(false)
    }

    // Palette state
    val paletteState = rememberPaletteState()

    val startColor =
        remember {
            Animatable(Color.Black)
        }
    val endColor =
        remember {
            Animatable(Color.Black)
        }
    val gradientOffset by remember {
        mutableStateOf(GradientOffset(GradientAngle.CW135))
    }

    var spotShadowColor by remember {
        mutableStateOf(Color.White)
    }

    LaunchedEffect(screenDataState) {
        Logger.d(TAG, "ScreenDataState: $screenDataState")
        // Only a canvas that fills the page replaces it; animated artwork sits at its top.
        showHideMiddleLayout = screenDataState.fullscreenCanvas() == null
    }

    // Palette generation lives in its own NEVER-restarting effect. Keyed on screenDataState it
    // was cancelled mid-generate every time ANOTHER field of the data class arrived (canvasData,
    // lyrics, songInfo), and kmpalette parks on Loading when generate() is cancelled — palette
    // stays null, startColor stays black, and the M3E style falls back to the app seed (the
    // "canvas songs are always cyan" bug). Canvas songs hit this deterministically because the
    // canvas fetch always lands after the artwork bitmap.
    LaunchedEffect(Unit) {
        snapshotFlow { screenDataState.bitmap }
            .filterNotNull()
            .distinctUntilChanged()
            .collectLatest {
                paletteState.generate(it)
            }
    }

    LaunchedEffect(Unit) {
        snapshotFlow { paletteState.palette }
            .distinctUntilChanged()
            .collectLatest {
                spotShadowColor = it.getColorFromPalette()
                startColor.animateTo(it.getColorFromPalette())
                // Lands on the same backdrop colour the fade and the area below the gradient
                // use, so the palette ramp resolves into the surface instead of a black patch.
                endColor.animateTo(PlayerBackdropColor)
            }
    }

    LaunchedEffect(spotShadowColor) {
        Logger.d(TAG, "spotShadowColor: $spotShadowColor")
    }

    var isSliding by rememberSaveable {
        mutableStateOf(false)
    }
    var sliderValue by rememberSaveable {
        mutableFloatStateOf(0f)
    }
    LaunchedEffect(key1 = timelineState, key2 = isSliding) {
        if (!isSliding) {
            sliderValue =
                if (timelineState.total > 0L) {
                    timelineState.current.toFloat() * 100 / timelineState.total.toFloat()
                } else {
                    0f
                }
        }
    }

    // Crossfade: RGB rainbow color cycling when transitioning between tracks
    val infiniteTransition = rememberInfiniteTransition(label = "crossfadeRainbow")
    val rainbowHue by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(1000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart,
            ),
        label = "rainbowHue",
    )
    val rainbowColor = hsvToColor(rainbowHue, 1f, 1f)
    val sliderTrackColor by animateColorAsState(
        targetValue = if (timelineState.isCrossfading) rainbowColor else Color.White,
        animationSpec = tween(300),
        label = "sliderCrossfadeColor",
    )

    // Show ControlLayout Or Show Artist Badge
    var showHideControlLayout by rememberSaveable {
        mutableStateOf(true)
    }
    val controlLayoutAlpha: Float by animateFloatAsState(
        targetValue = if (showHideControlLayout) 1f else 0f,
        animationSpec =
            tween(
                durationMillis = 500,
                easing = LinearEasing,
            ),
        label = "ControlLayoutAlpha",
    )

    var showHideJob by remember {
        mutableStateOf(true)
    }

    LaunchedEffect(key1 = showHideJob) {
        if (!showHideJob) {
            delay(5000)
            if (mainScrollState.value == 0) showHideControlLayout = false
            showHideJob = true
        }
    }

    LaunchedEffect(Unit) {
        snapshotFlow {
            screenDataState
        }.distinctUntilChangedBy {
            it.canvasData?.url
        }.collectLatest {
            if (it.fullscreenCanvas() != null && mainScrollState.value == 0) {
                showHideJob = false
            } else {
                showHideJob = true
                showHideControlLayout = true
            }
        }
    }

    LaunchedEffect(key1 = showHideControlLayout) {
        if (showHideControlLayout && screenDataState.fullscreenCanvas() != null && mainScrollState.value == 0) {
            showHideJob = false
        }
    }

    LaunchedEffect(Unit) {
        snapshotFlow { mainScrollState.value }
            .distinctUntilChanged()
            .collect {
                if (it > 0 && !showHideControlLayout && screenDataState.fullscreenCanvas() != null) {
                    showHideJob = true
                    showHideControlLayout = true
                } else if (showHideControlLayout && it == 0 && screenDataState.fullscreenCanvas() != null) {
                    showHideJob = false
                }
            }
    }

    var currentLyricLineIndex by rememberSaveable {
        mutableIntStateOf(-1)
    }

    // Canvas subtitle sync
    LaunchedEffect(timelineState, screenDataState.lyricsData?.lyrics, lyricsOffsetMs) {
        val lyrics = screenDataState.lyricsData?.lyrics
        if (lyrics == null || lyrics.syncType == "UNSYNCED" || lyrics.syncType == null) {
            currentLyricLineIndex = -1
            return@LaunchedEffect
        }
        val lines = lyrics.lines ?: return@LaunchedEffect
        val translatedLines =
            screenDataState.lyricsData
                ?.translatedLyrics
                ?.first
                ?.lines
        // What the ear is hearing right now, which is what a lyric answers to. Keyed on the offset
        // as well so dragging the setting while paused still moves the line.
        val nowMs = timelineState.current - lyricsOffsetMs
        if (nowMs > 0L) {
            lines.indices.forEach { i ->
                val startTimeMs = lines[i].startTimeMs.toLongOrNull() ?: 0L
                val endTimeMs =
                    if (i < lines.size - 1) {
                        lines[i + 1].startTimeMs.toLongOrNull() ?: 0L
                    } else {
                        startTimeMs + 60000
                    }
                if (nowMs in startTimeMs..endTimeMs) {
                    currentLyricLineIndex = i
                }
            }
            if (lines.isNotEmpty() &&
                nowMs in 0..(lines.getOrNull(0)?.startTimeMs?.toLongOrNull() ?: 0L)
            ) {
                currentLyricLineIndex = -1
            }
        } else {
            currentLyricLineIndex = -1
        }
    }

    if (screenDataState.lyricsData != null && controllerState.isPlaying) {
        KeepScreenOn()
    }
    val state =
        NowPlayingContentState(
            screenData = screenDataState,
            controllerState = controllerState,
            timelineState = timelineState,
            timelineFlow = sharedViewModel.timeline,
            likeStatus = likeStatus,
            castState = castState,
            shouldShowVideo = shouldShowVideo,
            isUserLoggedIn = isUserLoggedIn,
            artworkQueue = artworkQueue,
            currentOrderIndex = currentOrderIndex,
            artworkPagerState = artworkPagerState,
            startColor = startColor,
            endColor = endColor,
            spotShadowColor = spotShadowColor,
            gradientOffset = gradientOffset,
            sliderTrackColor = sliderTrackColor,
            sliderValue = sliderValue,
            currentLyricLineIndex = currentLyricLineIndex,
            showControlLayout = showHideControlLayout,
            controlLayoutAlpha = controlLayoutAlpha,
            showHideMiddleLayout = showHideMiddleLayout,
            shouldShowToolbar = shouldShowToolbar,
            isInPipMode = isInPipMode,
            mainScrollState = mainScrollState,
            isExpanded = isExpanded,
            dismissIcon = dismissIcon,
            playbackSourceLabel =
                playbackSourceLabel(
                    source = playingSource,
                    format = formatState,
                    downloadedLabel =
                        stringResource(Res.string.downloaded).takeIf {
                            nowPlayingState?.songEntity?.downloadState == DownloadState.STATE_DOWNLOADED
                        },
                    speedLabel = downloadSpeedLabel(downloadSpeedBps),
                ),
            audioQualityLabel = formatState.toAudioQualityLabel(),
            lyricsOffsetMs = lyricsOffsetMs.toLong(),
            videoAspectRatio = rememberVideoAspectRatio(MAIN_PLAYER) ?: 16f / 9,
            headsetBadge = headsetBadge,
        )
    val actions =
        NowPlayingContentActions(
            onUIEvent = { sharedViewModel.onUIEvent(it) },
            onSeekToQueueIndex = { index ->
                mediaPlayerHandler.playMediaItemInMediaSource(index)
            },
            onArtworkBitmap = { sharedViewModel.setBitmap(it) },
            onSliderChange = { newValue ->
                isSliding = true
                sliderValue = newValue
            },
            onSliderChangeFinished = {
                isSliding = false
                sharedViewModel.onUIEvent(
                    UIEvent.UpdateProgress(sliderValue),
                )
            },
            onToggleControls = {
                showHideJob = true
                showHideControlLayout = !showHideControlLayout
            },
            onNavigateToArtist = {
                val song = sharedViewModel.nowPlayingState.value?.songEntity
                (
                    song?.artistId?.firstOrNull()?.takeIf { it.isNotEmpty() }
                        ?: screenDataState.songInfoData?.authorId
                )?.let { channelId ->
                    onDismiss()
                    navController.navigate(
                        ArtistDestination(
                            channelId = channelId,
                        ),
                    )
                }
            },
            onOpenListenTogether = {
                onDismiss()
                navController.navigate(ListenTogetherDestination)
            },
            onAddToYouTubeLiked = { sharedViewModel.addToYouTubeLiked() },
            onShowMoreSheet = { showSheet = true },
            onShowQueue = { showQueueBottomSheet = true },
            onShowInfo = { showInfoBottomSheet = true },
            onShowAddToPlaylist = { showAddToPlaylistDirectly = true },
            onShowFullscreenLyrics = { showFullscreenLyrics = true },
            onShowVoteDialog = { showVoteDialog = true },
            onLyricsOffsetChange = { sharedViewModel.setLyricsOffsetMs(it) },
            onEnterFullscreenVideo = {
                onDismiss()
                navController.navigate(FullscreenDestination)
            },
            onDismiss = onDismiss,
            onToolbarVisibilityChange = { shouldShowToolbar = it },
            onMoveQueueItem = { from, to ->
                coroutineScope.launch {
                    mediaPlayerHandler.swap(from, to)
                }
            },
            onRemoveQueueItem = { index ->
                mediaPlayerHandler.removeMediaItem(index)
            },
            onShowSources = { showSourcesSheet = true },
            onShowHeadset = { showHeadsetSheet = true },
            onQueueItemMore = { index, track -> queueMoreFor = index to track },
        )

    // Below `state`/`actions`: the landscape lyrics layout renders the current style's own track row
    // and playback controls, so it takes the same contract the style content does.
    if (showFullscreenLyrics) {
        if (getPlatform() == Platform.Desktop) {
            // Desktop's Now Playing is a side panel, not a sheet, so the page opens as a Popup over
            // the whole window — the custom title bar included. A Popup that stops below the bar
            // leaves the bar outside it, and a focusable Popup dismisses on any press outside
            // itself, so a click on the bar used to close the page.
            val windowSize = LocalWindowInfo.current.containerSize
            val density = LocalDensity.current
            // DesktopApp makes the window transparent and clips its content to 12dp corners exactly
            // when it draws the custom title bar (both macOS-only). A Popup is a layer of its own
            // that clip never reaches, so the page rounds itself. getScreenSizeInfo() subtracts that
            // same bar, which makes the height difference the one signal commonMain can read.
            val windowIsRounded = windowSize.height > getScreenSizeInfo().hPX
            val popupPositionProvider =
                remember {
                    object : PopupPositionProvider {
                        override fun calculatePosition(
                            anchorBounds: IntRect,
                            windowSize: IntSize,
                            layoutDirection: LayoutDirection,
                            popupContentSize: IntSize,
                        ): IntOffset = IntOffset.Zero
                    }
                }
            // A Popup appears in a single frame, which reads as a flash over the whole window. The
            // page fades and scales in instead, and a close plays the reverse first: the flag only
            // drops once the exit has finished, or the Popup would leave mid-animation.
            val pageVisibility = remember { MutableTransitionState(false).apply { targetState = true } }
            val closePage = { pageVisibility.targetState = false }
            LaunchedEffect(pageVisibility.currentState, pageVisibility.isIdle) {
                if (pageVisibility.isIdle && !pageVisibility.currentState) {
                    showFullscreenLyrics = false
                }
            }
            Popup(
                popupPositionProvider = popupPositionProvider,
                onDismissRequest = closePage,
                properties = PopupProperties(focusable = true),
            ) {
                AnimatedVisibility(
                    visibleState = pageVisibility,
                    enter =
                        fadeIn(tween(FULLSCREEN_LYRICS_ENTER_MS)) +
                            scaleIn(tween(FULLSCREEN_LYRICS_ENTER_MS, easing = FastOutSlowInEasing), initialScale = 0.96f),
                    exit =
                        fadeOut(tween(FULLSCREEN_LYRICS_EXIT_MS)) +
                            scaleOut(tween(FULLSCREEN_LYRICS_EXIT_MS, easing = FastOutSlowInEasing), targetScale = 0.96f),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .size(
                                    with(density) { windowSize.width.toDp() },
                                    with(density) { windowSize.height.toDp() },
                                ).then(
                                    if (windowIsRounded) Modifier.clip(appCorner(12.dp)) else Modifier,
                                ),
                    ) {
                        FullscreenLyricsContent(
                            sharedViewModel = sharedViewModel,
                            navController = navController,
                            color = startColor.value,
                            state = state,
                            actions = actions,
                            nowPlayingStyle = nowPlayingStyle,
                            onDismiss = closePage,
                        )
                    }
                }
            }
        } else {
            FullscreenLyricsSheet(
                sharedViewModel = sharedViewModel,
                navController = navController,
                color = startColor.value,
                state = state,
                actions = actions,
                nowPlayingStyle = nowPlayingStyle,
            ) {
                showFullscreenLyrics = false
            }
        }
    }

    // Declared AFTER the lyrics host on purpose. A rotation recreates the activity, so every open
    // sheet re-enters composition in one pass and attaches in declaration order: the landscape
    // lyrics page opens these same sheets (more, queue, add to playlist) on top of itself, and
    // declaring them first would bury them under the page after the device is turned.
    if (showSheet) {
        NowPlayingBottomSheet(
            onDismiss = {
                showSheet = false
            },
            navController = navController,
            onNavigateToOtherScreen = {
                onDismiss()
            },
            song = null, // Auto set now playing
            setSleepTimerEnable = true,
            changeMainLyricsProviderEnable = true,
        )
    }

    if (showSourcesSheet) {
        // Private copy: the sheet's song id, with a fallback. nowPlayingVideoId is the queue
        // track's, and that is null until the player's media item has been matched back to a queue
        // row — opening the sheet right after a song starts (a downloaded song especially, whose
        // row the player may not have matched yet) then showed nothing at all until the next
        // track. The song row's own id is there as soon as the state is, and is the same id.
        val sourcesVideoId = nowPlayingVideoId ?: nowPlayingState?.songEntity?.videoId
        if (sourcesVideoId != null) {
            val song = nowPlayingState?.songEntity
            PlaybackSourcesSheet(
                videoId = sourcesVideoId,
                title = song?.title ?: nowPlayingState?.track?.title.orEmpty(),
                thumbnail = song?.thumbnails ?: nowPlayingState?.track?.thumbnails?.lastOrNull()?.url.orEmpty(),
                onDismiss = { showSourcesSheet = false },
            )
        }
    }

    if (showHeadsetSheet) {
        HeadsetSheet(onDismiss = { showHeadsetSheet = false })
    }

    if (showQueueBottomSheet) {
        QueueBottomSheet(
            onDismiss = {
                showQueueBottomSheet = false
            },
            navController = navController,
            onNavigateToOtherScreen = {
                showQueueBottomSheet = false
                onDismiss()
            },
        )
    }

    queueMoreFor?.let { (index, track) ->
        NowPlayingBottomSheet(
            onDismiss = { queueMoreFor = null },
            navController = navController,
            song = track.toSongEntity(),
            queuePosition = QueuePosition(index, track.videoId),
            onNavigateToOtherScreen = { onDismiss() },
        )
    }

    if (showInfoBottomSheet) {
        InfoPlayerBottomSheet(
            onDismiss = {
                showInfoBottomSheet = false
            },
        )
    }

    // NEW: Add to Playlist Bottom Sheet
    if (showAddToPlaylistDirectly) {
        val viewModel: NowPlayingBottomSheetViewModel = koinViewModel()
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()

        LaunchedEffect(Unit) {
            viewModel.resetPlaylists()
            viewModel.setSongEntity(null) // Uses current playing song
        }

        AddToPlaylistModalBottomSheet(
            isBottomSheetVisible = true,
            listLocalPlaylist = uiState.listLocalPlaylist,
            listYouTubePlaylist = uiState.listYouTubePlaylist,
            onDismiss = { showAddToPlaylistDirectly = false },
            onClick = { playlist ->
                viewModel.onUIEvent(NowPlayingBottomSheetUIEvent.AddToPlaylist(playlist.id))
                showAddToPlaylistDirectly = false
            },
            onYTPlaylistClick = { playlist ->
                viewModel.onUIEvent(NowPlayingBottomSheetUIEvent.AddToYouTubePlaylist(playlist.browseId))
                showAddToPlaylistDirectly = false
            },
            videoId = uiState.songUIState.videoId,
        )
    }

    // Vote Dialog
    if (showVoteDialog) {
        val canVoteLyrics =
            screenDataState.lyricsData?.lyricsProvider == LyricsProvider.SIMPMUSIC &&
                screenDataState.lyricsData
                    ?.lyrics
                    ?.simpMusicLyrics != null
        val canVoteTranslatedLyrics =
            screenDataState.lyricsData?.translatedLyrics?.second == LyricsProvider.SIMPMUSIC &&
                screenDataState.lyricsData
                    ?.translatedLyrics
                    ?.first
                    ?.simpMusicLyrics != null

        VoteLyricsDialog(
            canVoteLyrics = canVoteLyrics,
            canVoteTranslatedLyrics = canVoteTranslatedLyrics,
            lyricsVoteState = lyricsVoteState,
            translatedLyricsVoteState = translatedVoteState,
            onVoteLyrics = { upvote ->
                sharedViewModel.voteLyrics(upvote)
            },
            onVoteTranslatedLyrics = { upvote ->
                sharedViewModel.voteTranslatedLyrics(upvote)
            },
            onDismiss = {
                showVoteDialog = false
            },
        )
    }

    when (nowPlayingStyle) {
        DataStoreManager.NOW_PLAYING_STYLE_M3_EXPRESSIVE ->
            NowPlayingContentM3Expressive(
                state = state,
                actions = actions,
            )

        DataStoreManager.NOW_PLAYING_STYLE_APPLE_MUSIC ->
            NowPlayingContentAppleMusic(
                state = state,
                actions = actions,
            )

        else ->
            NowPlayingContentSpotify(
                state = state,
                actions = actions,
            )
    }
}
