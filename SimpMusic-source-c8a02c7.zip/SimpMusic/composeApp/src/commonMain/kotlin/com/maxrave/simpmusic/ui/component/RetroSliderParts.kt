package com.maxrave.simpmusic.ui.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.maxrave.simpmusic.ui.theme.pixelFrame
import kotlin.math.roundToInt

/**
 * Retro Pixel's slider parts: a track cut into hard blocks and a square, framed thumb. The radio
 * mix's ten-block track is the reference; these are the same shapes for the seek/volume/strength
 * sliders, which otherwise inherit Material's smooth pill track and round thumb.
 *
 * Both helpers are only called from Retro branches, so other themes keep their own drawing.
 */

/**
 * A blocky progress track: [segments] rectangles separated by a [gap], filled up to [fraction].
 * Coordinates are snapped to whole device pixels, and when [blockBorder] is set each block gets a
 * one-unit outline, the same 1dp edge the radio mix uses.
 */
@Composable
fun RetroSegmentedTrack(
    fraction: Float,
    activeColor: Color,
    inactiveColor: Color,
    modifier: Modifier = Modifier,
    height: Dp = 5.dp,
    segments: Int = 20,
    gap: Dp = 2.dp,
    blockBorder: Color? = null,
    // Optional per-block colour (index / count), for tracks that are a ramp rather than a fill.
    colorForBlock: ((Float) -> Color)? = null,
) {
    Canvas(modifier.height(height)) {
        val count = segments.coerceAtLeast(1)
        val gapPx = gap.toPx().roundToInt().coerceAtLeast(1).toFloat()
        val total = size.width - gapPx * (count - 1)
        if (total <= 0f) return@Canvas
        val blockWidth = total / count
        val cutoff = fraction.coerceIn(0f, 1f)
        val border = blockBorder
        for (i in 0 until count) {
            val left = (i * (blockWidth + gapPx)).roundToInt().toFloat()
            val right = (left + blockWidth).roundToInt().toFloat()
            if (right <= left) continue
            val filled = (left + (right - left) / 2f) / size.width <= cutoff
            drawRect(
                color = colorForBlock?.invoke((i + 0.5f) / count) ?: if (filled) activeColor else inactiveColor,
                topLeft = Offset(left, 0f),
                size = Size(right - left, size.height),
            )
            if (border != null) {
                drawRect(
                    color = border,
                    topLeft = Offset(left, 0f),
                    size = Size(right - left, size.height),
                    style = Stroke(width = 1.dp.toPx().roundToInt().coerceAtLeast(1).toFloat()),
                )
            }
        }
    }
}

/**
 * A square pixel thumb: a hard-edged rectangle with the theme's notched pixel frame and its hard
 * drop shadow. No round corners, no swell animation.
 */
@Composable
fun RetroSliderThumb(
    color: Color,
    modifier: Modifier = Modifier,
    width: Dp = 12.dp,
    height: Dp = 18.dp,
    frameColor: Color = MaterialTheme.colorScheme.primary,
) {
    Box(modifier.size(width, height)) {
        Box(
            Modifier
                .matchParentSize()
                .background(color, RectangleShape)
                .pixelFrame(selected = true, color = frameColor),
        )
    }
}
