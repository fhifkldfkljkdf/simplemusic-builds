package com.maxrave.simpmusic.expect

/**
 * The modules of a QR code for [text], row by row; `true` is a dark module. Null if it cannot be
 * encoded.
 *
 * An expect/actual rather than a commonMain call because ZXing is a plain Java library declared only
 * in androidMain and jvmMain — both actuals are the same few lines.
 */
expect fun encodeQrCode(text: String): Array<BooleanArray>?
