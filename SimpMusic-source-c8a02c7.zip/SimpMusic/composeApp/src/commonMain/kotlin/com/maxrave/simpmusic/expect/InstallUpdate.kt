package com.maxrave.simpmusic.expect

/**
 * Downloads the update APK at [url] and starts the system installer. The user still confirms the
 * install — Android always asks — but nothing opens a browser.
 *
 * [onProgress] is called with 0f..1f as the file arrives, or null while its size is not known. On a
 * platform with nothing to install (the desktop), the file is opened instead.
 */
expect suspend fun downloadAndInstallUpdate(
    url: String,
    onProgress: (Float?) -> Unit,
): Result<Unit>

/** Whether an update APK was already downloaded and is still there to install. */
expect fun downloadedUpdateReady(): Boolean

/** Starts the installer for the update APK downloaded earlier, without downloading it again. */
expect fun installDownloadedUpdate(): Result<Unit>

/**
 * Whether the update may be fetched without asking first: only over a connection the user is not
 * paying by the byte for. The desktop always says yes; Android asks its connectivity manager.
 */
expect fun updateDownloadAllowed(): Boolean
