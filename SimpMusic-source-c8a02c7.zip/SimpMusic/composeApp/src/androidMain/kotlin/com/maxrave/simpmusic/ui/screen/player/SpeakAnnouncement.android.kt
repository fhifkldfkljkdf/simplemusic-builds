package com.maxrave.simpmusic.ui.screen.player

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import com.maxrave.logger.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.koin.mp.KoinPlatform.getKoin
import java.util.Locale

private const val TAG = "SpeakAnnouncement"
private const val UTTERANCE_ID = "simpmusic-announcement"

// Calm delivery: a little slower and a touch lower than the engine default.
private const val SPEECH_RATE = 0.9f
private const val SPEECH_PITCH = 0.97f

// Android exposes no voice gender. Google's voice ids encode it in a short code, so these are the
// soft female-sounding ones, best first, as observed for the two English locales that matter here.
private val EN_US_FEMALE_CODES = listOf("tpf", "sfg", "iob", "tpc", "iog", "iol")
private val EN_GB_FEMALE_CODES = listOf("gba")

/**
 * One TextToSpeech engine for the whole process: creating one is slow, and a value spoken seconds
 * after the slider was released is worse than one not spoken at all.
 */
private object Speaker {
    private val lock = Any()
    private var engine: TextToSpeech? = null
    private var starting = false
    private var ready = false

    // The value to say once init finishes; the newest one wins, since only the last matters.
    private var pending: String? = null

    // null until something is known: the package probe or an init result sets it.
    private val availability = MutableStateFlow<Boolean?>(null)
    private var probed = false

    /** Whether an announcement can be heard; the first call looks for an engine, cheaply. */
    fun state(): StateFlow<Boolean?> {
        synchronized(lock) {
            if (!probed) {
                probed = true
                probe()
            }
        }
        return availability
    }

    /**
     * Asks the package manager whether any text-to-speech service is installed, without creating an
     * engine: enough to tell a phone with none from one that will speak. A later init refines it.
     */
    @Suppress("DEPRECATION")
    private fun probe() {
        try {
            val context = getKoin().get<Context>()
            // An app targeting API 30+ only sees other apps' services its manifest asks for: the
            // TTS_SERVICE intent in <queries>. Without it this list is empty even when one exists.
            val services =
                context.packageManager.queryIntentServices(
                    Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE),
                    0,
                )
            val anyInstalled = services?.isNotEmpty() == true
            availability.value = anyInstalled
            if (!anyInstalled) Logger.w(TAG, "No text to speech engine is installed")
        } catch (t: Throwable) {
            availability.value = false
            Logger.e(TAG, "Could not look for a text to speech engine: ${t.message}", t)
        }
    }

    fun speak(text: String) {
        try {
            synchronized(lock) {
                pending = text
                if (!ready) {
                    start()
                    return
                }
                speakPending()
            }
        } catch (t: Throwable) {
            availability.value = false
            Logger.e(TAG, "Could not speak announcement: ${t.message}", t)
        }
    }

    private fun start() {
        if (starting) return
        starting = true
        try {
            val context = getKoin().get<Context>()
            val created = TextToSpeech(context.applicationContext, ::onInit)
            engine = created
        } catch (t: Throwable) {
            starting = false
            pending = null
            availability.value = false
            Logger.e(TAG, "Could not create the text to speech engine: ${t.message}", t)
        }
    }

    @Suppress("DEPRECATION")
    private fun onInit(status: Int) {
        synchronized(lock) {
            starting = false
            val tts = engine
            if (status != TextToSpeech.SUCCESS || tts == null) {
                pending = null
                availability.value = false
                Logger.w(TAG, "Text to speech is unavailable (status $status)")
                // Release the dead engine, so a later call can try a fresh one.
                runCatching { tts?.shutdown() }
                engine = null
                return
            }
            try {
                val requested = Locale.getDefault()
                val language = tts.setLanguage(requested)
                val defaultUsable =
                    language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED
                val locale =
                    if (defaultUsable) {
                        requested
                    } else {
                        // No voice data for the phone's language: English is the fallback the
                        // announcement is written in, and without that there is nothing to hear.
                        val fallback = tts.setLanguage(Locale.US)
                        if (fallback == TextToSpeech.LANG_MISSING_DATA || fallback == TextToSpeech.LANG_NOT_SUPPORTED) {
                            pending = null
                            ready = false
                            availability.value = false
                            Logger.w(TAG, "Text to speech has no voice data for this language")
                            runCatching { tts.shutdown() }
                            engine = null
                            return
                        }
                        Locale.US
                    }
                applyVoice(tts, locale)
                // A slightly slower, slightly lower read: unhurried and warm rather than clipped.
                runCatching { tts.setSpeechRate(SPEECH_RATE) }
                runCatching { tts.setPitch(SPEECH_PITCH) }
                // Accessibility speech: the engine takes transient audio focus that may duck, so
                // the music dips under the announcement instead of stopping.
                tts.setAudioAttributes(
                    AudioAttributes
                        .Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                ready = true
                availability.value = true
                speakPending()
            } catch (t: Throwable) {
                availability.value = false
                Logger.e(TAG, "Could not set up text to speech: ${t.message}", t)
            }
        }
    }

    /**
     * Picks the warmest, most natural installed voice for [locale] and asks the engine to use it.
     * Never throws: on any trouble the engine keeps its own default voice.
     */
    private fun applyVoice(
        tts: TextToSpeech,
        locale: Locale,
    ) {
        val voice = selectVoice(tts, locale) ?: return
        try {
            val result = tts.setVoice(voice)
            if (result == TextToSpeech.SUCCESS) {
                Logger.i(TAG, "Speaking with voice ${voice.name} (${voice.locale.toLanguageTag()})")
            } else {
                Logger.w(TAG, "Could not use voice ${voice.name} (result $result); keeping the default")
            }
        } catch (t: Throwable) {
            Logger.w(TAG, "Could not use voice ${voice.name}: ${t.message}")
        }
    }

    /** Highest-scoring installed voice in the right language, or null when none matches. */
    private fun selectVoice(
        tts: TextToSpeech,
        locale: Locale,
    ): Voice? {
        val voices =
            try {
                tts.voices
            } catch (t: Throwable) {
                Logger.w(TAG, "Could not list text to speech voices: ${t.message}")
                null
            } ?: return null
        var best: Voice? = null
        var bestScore = Int.MIN_VALUE
        for (voice in voices) {
            try {
                val voiceLocale = voice.locale ?: continue
                if (!voiceLocale.language.equals(locale.language, ignoreCase = true)) continue
                val features = voice.features ?: emptySet<String>()
                // Voices the package manager knows of but whose data is not downloaded cannot speak.
                if (features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue
                val score = voiceScore(voice, voiceLocale, locale, features)
                if (score > bestScore) {
                    bestScore = score
                    best = voice
                }
            } catch (t: Throwable) {
                // One malformed voice must not lose the others.
            }
        }
        return best
    }

    private fun voiceScore(
        voice: Voice,
        voiceLocale: Locale,
        locale: Locale,
        features: Set<String>,
    ): Int {
        // Quality dominates: bonuses below only separate voices of the same tier.
        var score =
            when (voice.quality) {
                Voice.QUALITY_VERY_HIGH -> 300
                Voice.QUALITY_HIGH -> 200
                Voice.QUALITY_NORMAL -> 100
                else -> 50
            }
        if (voiceLocale.country.equals(locale.country, ignoreCase = true)) score += 20
        val name = voice.name?.lowercase(Locale.US).orEmpty()
        val natural =
            name.contains("neural") ||
                name.contains("natural") ||
                features.any { it.contains("neural", ignoreCase = true) || it.contains("natural", ignoreCase = true) }
        if (natural) score += 10
        // Network voices are often the most natural, so they are allowed; only a local voice of
        // equal quality is ranked first, and the engine falls back if a network one fails.
        if (!voice.isNetworkConnectionRequired) score += 1
        if (name.contains("female")) {
            score += 30
        } else if (name.contains("male")) {
            score -= 30
        }
        val preferred =
            when {
                locale.language.equals("en", ignoreCase = true) && voiceLocale.country.equals("GB", ignoreCase = true) ->
                    EN_GB_FEMALE_CODES
                locale.language.equals("en", ignoreCase = true) -> EN_US_FEMALE_CODES
                else -> emptyList()
            }
        val rank = preferred.indexOfFirst { name.contains(it) }
        if (rank >= 0) score += 30 - rank * 4
        // "rjs" is a male en-GB voice whose id carries no gender hint.
        if (voiceLocale.country.equals("GB", ignoreCase = true) && name.contains("rjs")) score -= 30
        return score
    }

    private fun speakPending() {
        val tts = engine ?: return
        val text = pending ?: return
        pending = null
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }
}

actual fun speakAnnouncement(text: String) {
    Speaker.speak(text)
}

actual fun speechAvailability(): StateFlow<Boolean?> = Speaker.state()
