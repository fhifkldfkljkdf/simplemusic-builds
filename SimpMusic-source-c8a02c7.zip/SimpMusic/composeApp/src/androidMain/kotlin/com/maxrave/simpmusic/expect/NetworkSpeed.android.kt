package com.maxrave.simpmusic.expect

import com.maxrave.media3.service.NetworkStats

actual fun networkBitrateEstimateBps(): Long = NetworkStats.currentBitsPerSecond()

actual fun networkHistory(): List<Pair<Long, Long>> = NetworkStats.history()
