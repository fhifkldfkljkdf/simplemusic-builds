package com.maxrave.simpmusic.expect

import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.WriterException
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

actual fun encodeQrCode(text: String): Array<BooleanArray>? =
    try {
        val matrix =
            QRCodeWriter().encode(
                text,
                BarcodeFormat.QR_CODE,
                0,
                0,
                mapOf(EncodeHintType.MARGIN to 2, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M),
            )
        Array(matrix.height) { y -> BooleanArray(matrix.width) { x -> matrix[x, y] } }
    } catch (e: WriterException) {
        null
    }
