package com.maxrave.simpmusic.expect

import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.koin.mp.KoinPlatform.getKoin
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * The update APK is downloaded into the cache, then handed to Android's package installer through
 * the app's FileProvider. Android still shows its own "Install?" prompt — an app cannot install
 * silently — but nothing leaves the app for a browser. The file is kept after a download, so an
 * install can be finished later ([installDownloadedUpdate]).
 *
 * A download goes to a `.part` file that is only renamed into place once it is complete and
 * [installBlocker] accepts it, so a truncated or unusable file is never offered as a ready update.
 */
actual suspend fun downloadAndInstallUpdate(
    url: String,
    onProgress: (Float?) -> Unit,
): Result<Unit> =
    withContext(Dispatchers.IO) {
        runCatching {
            val context = appContext()
            val apk = updateFile(context)
            val part = File(apk.parentFile, "${apk.name}.part")
            part.delete()
            try {
                download(url, part, onProgress)
                installBlocker(context, part)?.let { error(it) }
                apk.delete()
                check(part.renameTo(apk)) { "Could not save the update" }
            } catch (e: Throwable) {
                part.delete()
                throw e
            }
            installApk(context, apk)
        }
    }

/**
 * Whether a downloaded update APK is there *and* would install over this app. A file that would
 * only produce the installer's "App not installed" is dropped instead, so the next download gets a
 * fresh one rather than repeating the same refusal.
 */
actual fun downloadedUpdateReady(): Boolean {
    val context = appContext()
    val apk = updateFile(context)
    if (!apk.exists()) return false
    val blocker = installBlocker(context, apk)
    if (blocker != null) {
        apk.delete()
        return false
    }
    return true
}

actual fun installDownloadedUpdate(): Result<Unit> =
    runCatching {
        val context = appContext()
        val apk = updateFile(context)
        check(apk.exists()) { "No downloaded update" }
        installBlocker(context, apk)?.let { error(it) }
        installApk(context, apk)
    }

/**
 * The update is downloaded by itself, so it must not eat a metered plan: Wi-Fi or Ethernet only. An
 * unknown answer says yes — a phone that cannot tell is no reason to stop offering the download.
 */
actual fun updateDownloadAllowed(): Boolean {
    val manager = appContext().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    return manager?.isActiveNetworkMetered != true
}

/**
 * Why Android would refuse [apk], or null when it should install. The installer only says "App not
 * installed", which names no cause, so the causes it would reject the file for are checked here
 * instead and the reason is shown in the dialog.
 */
private fun installBlocker(
    context: Context,
    apk: File,
): String? {
    val manager = context.packageManager
    // Also the check that the file is a whole APK: a truncated one, or a web page saved as
    // "something.apk", has no readable manifest.
    val archive =
        manager.getPackageArchiveInfo(apk.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES)
            ?: return "The downloaded update is not a readable app file — it may have downloaded only partly. Try again"
    if (archive.packageName != context.packageName) {
        return "The downloaded update is for ${archive.packageName}, not for this app (${context.packageName})"
    }
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    val installed = manager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
    val installedSigner = installed.signingInfo?.apkContentsSigners?.firstOrNull()
    val updateSigner = archive.signingInfo?.apkContentsSigners?.firstOrNull()
    // Android refuses an update whose signing key differs from the installed app's, and this is the
    // one failure the app cannot work around. Only a known, different pair counts — a file whose
    // signer cannot be read is left to the installer rather than refused here.
    if (installedSigner != null && updateSigner != null && installedSigner != updateSigner) {
        return "Android will not install this update: it is signed with a different key than the installed app. " +
            "The only way is to uninstall SimpMusic (which erases its data) and install the APK from the repository by hand"
    }
    if (archive.longVersionCode <= installed.longVersionCode) {
        return "The downloaded update (${archive.versionName}) is not newer than the installed app " +
            "(${installed.versionName}), which Android refuses. Downloading it again"
    }
    return null
}

private fun appContext(): AppCompatActivity = getKoin().get()

/** The same name every time: an old download is replaced rather than piling up. */
private fun updateFile(context: Context): File =
    File(File(context.cacheDir, "updates").apply { mkdirs() }, "SimpMusic-update.apk")

private fun installApk(
    context: Context,
    apk: File,
) {
    // Android only lets an app install a package if the user has allowed it; without this the
    // installer prompt never appears. Send them to that setting; tapping Install again continues.
    if (!context.packageManager.canRequestPackageInstalls()) {
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(FLAG_ACTIVITY_NEW_TASK),
        )
        error("Allow this app to install updates, then tap Install again")
    }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.FileProvider", apk)
    val installer =
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or FLAG_ACTIVITY_NEW_TASK)
        }
    context.startActivity(installer)
}

private fun download(
    url: String,
    target: File,
    onProgress: (Float?) -> Unit,
) {
    val connection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "SimpMusic (private build)")
            connect()
        }
    try {
        val code = connection.responseCode
        check(code in 200..299) { "The update download failed (HTTP $code)" }
        val total = connection.contentLengthLong
        connection.inputStream.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var read = 0L
                var nextReport = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    read += count
                    if (total > 0 && read >= nextReport) {
                        onProgress((read.toDouble() / total).toFloat().coerceIn(0f, 1f))
                        nextReport = read + total / 50
                    }
                }
            }
        }
        onProgress(1f)
    } finally {
        connection.disconnect()
    }
}
