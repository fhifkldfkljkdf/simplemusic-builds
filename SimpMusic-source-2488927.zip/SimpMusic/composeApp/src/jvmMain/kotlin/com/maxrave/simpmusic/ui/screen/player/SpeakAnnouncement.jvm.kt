package com.maxrave.simpmusic.ui.screen.player

/** Desktop has no voice to speak with: the toast is the whole announcement here. */
actual fun speakAnnouncement(text: String) = Unit
