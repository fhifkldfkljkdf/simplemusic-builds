package com.maxrave.simpmusic.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.RippleConfiguration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import com.materialkolor.PaletteStyle
import com.materialkolor.rememberDynamicColorScheme
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.simpmusic.expect.ui.SystemBarAppearanceEffect
import com.maxrave.simpmusic.expect.ui.platformDynamicColorScheme

/**
 * Semantic colors that sit outside the Material 3 ColorScheme.
 * Read them via [LocalAppColors] inside composables.
 */
@Immutable
data class AppColors(
    val favorite: Color,
    val lyricActive: Color,
    val shimmerBackground: Color,
    val shimmerLine: Color,
    val overlay: Color,
    val overlayHeavy: Color,
)

private val DarkAppColors =
    AppColors(
        favorite = favoriteColor,
        lyricActive = lyricActiveColor,
        shimmerBackground = shimmerBackground,
        shimmerLine = shimmerLine,
        overlay = overlay,
        overlayHeavy = blackMoreOverlay,
    )

// Overlays stay dark in both themes: they cover artwork, where content is always light.
private val LightAppColors =
    DarkAppColors.copy(
        shimmerBackground = shimmerBackgroundLight,
        shimmerLine = shimmerLineLight,
    )

val LocalAppColors = staticCompositionLocalOf { DarkAppColors }

/** True in dark theme. Provided by [AppTheme] so platform glass (blur/tint) can adapt reliably. */
val LocalIsDarkTheme = staticCompositionLocalOf { true }

/**
 * Whether liquid-glass surfaces may actually draw glass.
 *
 * Provided by [AppTheme] from the user's setting; the default is true so previews and anything
 * composed outside [AppTheme] keep today's look. The setting row is Android-only, so Desktop always
 * provides true — its capsule player and detail-screen buttons are glass by design, with no switch.
 */
val LocalLiquidGlassEnabled = staticCompositionLocalOf { true }

/**
 * The dark scheme to use for immersive screens while the app itself is on the light theme.
 * Provided by [AppTheme], consumed by [ForceDarkContent]; null only outside of [AppTheme].
 */
val LocalForcedDarkColorScheme = staticCompositionLocalOf<ColorScheme?> { null }

/** Parses "RRGGBB" or "AARRGGBB" (optionally "#"-prefixed) into a [Color]; null if malformed. */
fun parseThemeColorHex(hex: String): Color? {
    val clean = hex.trim().removePrefix("#")
    val argb =
        when (clean.length) {
            6 -> "FF$clean"
            8 -> clean
            else -> return null
        }
    return argb.toLongOrNull(16)?.let { Color(it) }
}

/**
 * Neutral surfaces for the light theme, on a pure neutral-grey ramp (R=G=B, no seed tint);
 * primary/secondary/tertiary stay seed-derived. The page background is #FAFAFA (neutral tone 98,
 * the Material 3 stance) rather than pure white: a full-bleed #FFFFFF expanse glares on a large
 * desktop window, and even Apple — who pins systemBackground to white — puts #F2F2F7 behind
 * list pages. Pure white is kept for surfaceBright/surfaceContainerLowest so cards and sheets
 * still have a brighter-than-page tier to lift onto. Dark stays pure-black AMOLED: black does
 * not glare and saves OLED.
 */
private fun ColorScheme.withNeutralLightSurfaces(): ColorScheme =
    copy(
        background = Color(0xFFFAFAFA),
        onBackground = Color(0xFF1B1B1B),
        surface = Color(0xFFFAFAFA),
        onSurface = Color(0xFF1B1B1B),
        surfaceVariant = Color(0xFFE2E2E2),
        onSurfaceVariant = Color(0xFF474747),
        surfaceTint = primary,
        surfaceBright = Color(0xFFFFFFFF),
        surfaceDim = Color(0xFFDADADA),
        surfaceContainerLowest = Color(0xFFFFFFFF),
        surfaceContainerLow = Color(0xFFF7F7F7),
        surfaceContainer = Color(0xFFF1F1F1),
        surfaceContainerHigh = Color(0xFFECECEC),
        surfaceContainerHighest = Color(0xFFE6E6E6),
        outline = Color(0xFF777777),
        outlineVariant = Color(0xFFC7C7C7),
        inverseSurface = Color(0xFF303030),
        inverseOnSurface = Color(0xFFF1F1F1),
    )

@OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppTheme(
    themeMode: String = DataStoreManager.THEME_MODE_DARK,
    themeColorSource: String = DataStoreManager.THEME_COLOR_DEFAULT,
    customThemeColor: Color? = null,
    liquidGlassEnabled: Boolean = true,
    content:
        @Composable()
        () -> Unit,
) {
    // Private copy: the named app themes (Spotify, Apple Music, Ocean, AMOLED Black, Retro Pixel)
    // replace the seeded palette and the wallpaper/custom seeds with their own, in both modes.
    val family = themeFamily(themeColorSource)
    val spotifyTheme = family == AppThemeFamily.SPOTIFY
    val isDark = isDarkTheme(themeMode)
    val wallpaperScheme =
        if (themeColorSource == DataStoreManager.THEME_COLOR_WALLPAPER) {
            platformDynamicColorScheme(isDark)
        } else {
            null
        }
    val seedColor =
        if (themeColorSource == DataStoreManager.THEME_COLOR_CUSTOM) {
            customThemeColor ?: seed
        } else {
            seed
        }
    // Symmetric base: dark pins background/surface to pure black via isAmoled; light pins them to
    // pure white with a neutral-grey ramp (the seed otherwise tints the light neutrals warm/cream).
    val colorScheme =
        when (family) {
            AppThemeFamily.SPOTIFY ->
                spotifyColorScheme(isDark)
            AppThemeFamily.APPLE_MUSIC ->
                appleMusicColorScheme(isDark)
            AppThemeFamily.OCEAN ->
                oceanColorScheme(isDark)
            AppThemeFamily.AMOLED ->
                amoledColorScheme(isDark)
            AppThemeFamily.RETRO ->
                retroColorScheme(isDark)
            else ->
                wallpaperScheme
                    ?: rememberDynamicColorScheme(
                        seedColor = seedColor,
                        isDark = isDark,
                        isAmoled = isDark,
                        style = PaletteStyle.TonalSpot,
                        modifyColorScheme = { cs -> if (isDark) cs else cs.withNeutralLightSurfaces() },
                    )
        }
    // Immersive screens stay dark even at light theme (see [ForceDarkContent]). Resolve their scheme
    // once here instead of letting every such subtree build a palette of its own.
    val forcedDarkScheme =
        when (family) {
            AppThemeFamily.SPOTIFY ->
                spotifyColorScheme(true)
            AppThemeFamily.APPLE_MUSIC ->
                appleMusicColorScheme(true)
            AppThemeFamily.OCEAN ->
                oceanColorScheme(true)
            AppThemeFamily.AMOLED ->
                amoledColorScheme(true)
            AppThemeFamily.RETRO ->
                retroColorScheme(true)
            else ->
                if (isDark) {
                    colorScheme
                } else {
                    rememberDynamicColorScheme(
                        seedColor = seedColor,
                        isDark = true,
                        isAmoled = true,
                        style = PaletteStyle.TonalSpot,
                    )
                }
        }
    // Spotify's heart is green and its active lyric line is the reading colour, not yellow.
    val appColors =
        when {
            spotifyTheme ->
                (if (isDark) DarkAppColors else LightAppColors).copy(
                    favorite = SpotifyGreen,
                    lyricActive = if (isDark) Color.White else Color(0xFF121212),
                )
            isDark ->
                DarkAppColors
            else ->
                LightAppColors
        }
    val shapes =
        when (family) {
            AppThemeFamily.SPOTIFY -> SpotifyShapes
            AppThemeFamily.APPLE_MUSIC -> AppleShapes
            AppThemeFamily.OCEAN -> OceanShapes
            AppThemeFamily.AMOLED -> AmoledShapes
            AppThemeFamily.RETRO -> RetroShapes
            else -> MaterialTheme.shapes
        }
    val typographyFamily =
        when (family) {
            AppThemeFamily.APPLE_MUSIC, AppThemeFamily.OCEAN, AppThemeFamily.AMOLED -> FontFamily.SansSerif
            AppThemeFamily.RETRO -> vt323Family()
            else -> null
        }
    val baseTypography = typo(colorScheme)
    val appTypography =
        if (typographyFamily != null) {
            typographyWithFamily(baseTypography, typographyFamily, if (family == AppThemeFamily.RETRO) 1.1f else 1f)
        } else {
            baseTypography
        }
    SystemBarAppearanceEffect(isDark)
    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        shapes = shapes,
        content = {
            CompositionLocalProvider(
                LocalRippleConfiguration provides SoftRippleConfiguration,
                LocalContentColor provides colorScheme.onSurfaceVariant,
                LocalAppColors provides appColors,
                LocalSpotifyTheme provides spotifyTheme,
                LocalAppThemeFamily provides family,
                LocalAppShapes provides appShapesFor(family),
                LocalAppChipStyle provides chipStyleFor(family),
                LocalIsDarkTheme provides isDark,
                LocalForcedDarkColorScheme provides forcedDarkScheme,
                LocalLiquidGlassEnabled provides liquidGlassEnabled,
            ) {
                // Private copy: Retro Pixel lays a faint CRT scanline grid over the whole app,
                // under the typography and pixel icons rather than instead of them.
                if (family == AppThemeFamily.RETRO) {
                    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                        content()
                        RetroScanlines(Modifier.fillMaxSize())
                    }
                } else {
                    content()
                }
            }
        },
        typography = appTypography,
    )
}

/** The Retro Pixel theme's faint horizontal CRT lines, drawn over the app content. */
@Composable
private fun RetroScanlines(modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.045f)
    androidx.compose.foundation.Canvas(modifier) {
        val step = 3.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = color,
                start = androidx.compose.ui.geometry.Offset(0f, y),
                end = androidx.compose.ui.geometry.Offset(size.width, y),
                strokeWidth = 1f,
            )
            y += step
        }
    }
}

/**
 * A quieter ripple than the Material default, applied app-wide.
 *
 * Material 3's own alphas are tuned for light surfaces; on the near-black background this app
 * uses they read as a grey flash rather than a touch response. Each value is roughly 40% of
 * the default — enough to register the touch, not enough to wash the surface.
 *
 * The colour is left unspecified on purpose, so the ripple keeps deriving from LocalContentColor
 * and stays correct inside [ForceDarkContent] subtrees, which run a different scheme.
 *
 * This reaches bare `Modifier.clickable` too, not just Material components: MaterialTheme
 * already provides `material3.ripple()` as LocalIndication, and that is the one indication that
 * reads this configuration. Nothing extra has to be provided for it.
 *
 * The (color, rippleAlpha) constructor is deprecated in favour of one that also takes a `focus`,
 * but that three-argument version is internal to material3, and the two public replacements —
 * (color) and (focus, color) — drop rippleAlpha entirely. Adjusting ripple alpha therefore has
 * no non-deprecated path in this version, so the warning is suppressed rather than designed
 * around. Revisit once material3 opens up the full constructor.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Suppress("DEPRECATION")
private val SoftRippleConfiguration =
    RippleConfiguration(
        // Colour is deliberately left alone. Ripple derives it from LocalContentColor, which is
        // light on the dark theme and dark on the light one — always contrasting with what it
        // covers. Pinning a dark grey here instead made the ripple paint *darker* than the black
        // surface underneath, so a tap read as a sooty smudge rather than a highlight.
        // Alpha is the only lever that softens without changing which way the contrast runs.
        rippleAlpha =
            RippleAlpha(
                draggedAlpha = 0.06f,
                focusedAlpha = 0.04f,
                hoveredAlpha = 0.03f,
                pressedAlpha = 0.04f,
            ),
    )

/**
 * Wraps immersive screens — artist, album, playlist, local playlist, podcast and the players — which
 * always draw over dark artwork and must therefore render dark even on the light theme.
 *
 * [LocalForceDarkText] alone is not enough: it only recolors text through [typo]. Icons, buttons and
 * every other Material default read [LocalContentColor] and [MaterialTheme.colorScheme], which at
 * light theme resolve to dark-on-light and turn grey and unreadable over the artwork. Providing the
 * dark scheme here fixes the whole subtree in one place.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun ForceDarkContent(content: @Composable () -> Unit) {
    val darkScheme = LocalForcedDarkColorScheme.current ?: MaterialTheme.colorScheme
    val darkTypography = typo(darkScheme, forceDark = true)
    val typographyFamily =
        when (LocalAppThemeFamily.current) {
            AppThemeFamily.APPLE_MUSIC, AppThemeFamily.OCEAN, AppThemeFamily.AMOLED -> FontFamily.SansSerif
            AppThemeFamily.RETRO -> vt323Family()
            else -> null
        }
    MaterialExpressiveTheme(
        colorScheme = darkScheme,
        // Carry the active shapes and face through, so a theme's corners and type survive on the
        // immersive screens too.
        shapes = MaterialTheme.shapes,
        content = {
            CompositionLocalProvider(
                LocalForceDarkText provides true,
                LocalIsDarkTheme provides true,
                LocalContentColor provides darkScheme.onSurfaceVariant,
                LocalAppColors provides DarkAppColors,
                content = content,
            )
        },
        typography =
            if (typographyFamily != null) {
                typographyWithFamily(
                    darkTypography,
                    typographyFamily,
                    if (LocalAppThemeFamily.current == AppThemeFamily.RETRO) 1.1f else 1f,
                )
            } else {
                darkTypography
            },
    )
}

/**
 * Resolves the stored theme mode to a plain boolean.
 *
 * Pulled out of [AppTheme] so chrome living *outside* it can ask the same question — the desktop
 * title bar is drawn before AppTheme is entered, so it has no MaterialTheme to read and would
 * otherwise need its own copy of this `when`.
 */
@Composable
fun isDarkTheme(themeMode: String): Boolean =
    when (themeMode) {
        DataStoreManager.THEME_MODE_LIGHT -> false
        DataStoreManager.THEME_MODE_SYSTEM -> isSystemInDarkTheme()
        else -> true
    }
