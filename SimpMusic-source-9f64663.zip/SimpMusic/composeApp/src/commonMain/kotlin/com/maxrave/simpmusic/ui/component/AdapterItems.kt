package com.maxrave.simpmusic.ui.component

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.common.Config
import com.maxrave.domain.data.entities.AlbumEntity
import com.maxrave.domain.data.entities.LocalPlaylistEntity
import com.maxrave.domain.data.entities.PlaylistEntity
import com.maxrave.domain.data.entities.PodcastsEntity
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.data.model.browse.artist.ResultAlbum
import com.maxrave.domain.data.model.browse.artist.ResultPlaylist
import com.maxrave.domain.data.model.browse.artist.ResultSingle
import com.maxrave.domain.data.model.home.Content
import com.maxrave.domain.data.model.home.HomeItem
import com.maxrave.domain.data.model.home.HomeItem.MoreEndpoint
import com.maxrave.domain.data.model.home.chart.ItemArtist
import com.maxrave.domain.data.model.home.chart.ItemVideo
import com.maxrave.domain.data.model.mood.genre.ItemsPlaylist
import com.maxrave.domain.data.model.mood.moodmoments.Item
import com.maxrave.domain.data.model.searchResult.albums.AlbumsResult
import com.maxrave.domain.data.model.searchResult.playlists.PlaylistsResult
import com.maxrave.domain.data.model.searchResult.songs.Artist
import com.maxrave.domain.data.model.streams.YouTubeWatchEndpoint
import com.maxrave.domain.data.type.ChartItem
import com.maxrave.domain.data.type.HomeContentType
import com.maxrave.domain.data.type.MonthlyRecapItem
import com.maxrave.domain.mediaservice.handler.PlaylistType
import com.maxrave.domain.mediaservice.handler.QueueData
import com.maxrave.domain.utils.connectArtists
import com.maxrave.domain.utils.toListName
import com.maxrave.domain.utils.toSongEntity
import com.maxrave.domain.utils.toTrack
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.expect.ui.HorizontalScrollBar
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.ui.navigation.destination.list.AlbumDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.ArtistDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.BrowseDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.PlaylistDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.PodcastDestination
import com.maxrave.simpmusic.ui.icon.PlayArrow
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.LocalForceDarkText
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.HomeViewModel
import com.maxrave.simpmusic.viewModel.base.BaseViewModel
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.album
import simpmusic.composeapp.generated.resources.app_name
import simpmusic.composeapp.generated.resources.live_badge
import simpmusic.composeapp.generated.resources.description
import simpmusic.composeapp.generated.resources.more
import simpmusic.composeapp.generated.resources.play_all
import simpmusic.composeapp.generated.resources.playlist
import simpmusic.composeapp.generated.resources.subscribers
import simpmusic.composeapp.generated.resources.wrapped_recap_subtitle
import simpmusic.composeapp.generated.resources.you

@Composable
fun HomeItem(
    homeViewModel: HomeViewModel = koinViewModel(),
    navController: NavController,
    data: HomeItem,
) {
    var bottomSheetShow by remember { mutableStateOf(false) }

    val lazyListState = rememberLazyListState()
    val snapperFlingBehavior = rememberSnapFlingBehavior(SnapLayoutInfoProvider(lazyListState = lazyListState))

    var track by remember { mutableStateOf<Track?>(null) }

    if (bottomSheetShow) {
        NowPlayingBottomSheet(
            onDismiss = { bottomSheetShow = false },
            song = track?.toSongEntity(),
            navController = navController,
        )
    }

    Column {
        HomeSectionHeader(data = data, navController = navController, onPlayAll = { homeViewModel.playAll(data) })
        LazyRow(
            state = lazyListState,
            flingBehavior = snapperFlingBehavior,
        ) {
            items(data.contents) { temp ->
                if (temp != null) {
                    HomeContentCard(
                        temp = temp,
                        navController = navController,
                        viewModel = homeViewModel,
                        onLongClick = {
                            track = it.toTrack()
                            bottomSheetShow = true
                        },
                    )
                }
            }
        }
        if (getPlatform() == Platform.Desktop) {
            HorizontalScrollBar(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                scrollState = lazyListState,
                flingBehavior = snapperFlingBehavior,
            )
        }
    }
}

/**
 * A Home shelf's header: the optional avatar, strapline and title, plus the one button YouTube
 * sends with the shelf — "More" (a browse page) or "Play all" (a watch endpoint). Every shelf
 * style uses it, so the two buttons look and behave the same everywhere.
 */
@Composable
fun HomeSectionHeader(
    data: HomeItem,
    navController: NavController,
    onPlayAll: () -> Unit,
) {
    val channelId = data.channelId
    val moreEndpoint = data.moreEndpoint
    Row(
        modifier =
            if (channelId != null) {
                Modifier
                    .focusable(true)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        navController.navigate(
                            ArtistDestination(
                                channelId = channelId,
                            ),
                        )
                    }
            } else if (moreEndpoint != null) {
                // The section title carries the same endpoint as its "More" button, as on the web.
                Modifier
                    .focusable(true)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { navController.navigateToMoreEndpoint(moreEndpoint, data.title) }
            } else {
                Modifier
            },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AnimatedVisibility(
            visible = (data.thumbnail?.lastOrNull() != null),
            modifier = Modifier.align(Alignment.CenterVertically),
        ) {
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalPlatformContext.current)
                        .data(data.thumbnail?.lastOrNull()?.url)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .diskCacheKey(data.thumbnail?.lastOrNull()?.url)
                        .crossfade(550)
                        .build(),
                contentDescription = "",
                placeholder = rememberHolderPainter(),
                error = rememberHolderPainter(),
                modifier =
                    Modifier
                        .size(36.dp)
                        .clip(
                            CircleShape,
                        ),
            )
        }
        Column(
            Modifier
                .weight(1f)
                .padding(start = 10.dp),
        ) {
            AnimatedVisibility(visible = (data.subtitle != null && data.subtitle != "")) {
                Text(
                    text = data.subtitle ?: "",
                    style = typo().bodySmall,
                )
            }
            Text(
                text = data.title,
                style = typo().headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (moreEndpoint != null) {
            TextButton(
                onClick = { navController.navigateToMoreEndpoint(moreEndpoint, data.title) },
                colors =
                    ButtonDefaults
                        .textButtonColors()
                        .copy(contentColor = MaterialTheme.colorScheme.onSurface),
            ) {
                Text(stringResource(Res.string.more), style = typo().bodySmall)
            }
        } else if (data.playAllEndpoint != null) {
            TextButton(
                onClick = onPlayAll,
                colors =
                    ButtonDefaults
                        .textButtonColors()
                        .copy(contentColor = MaterialTheme.colorScheme.onSurface),
            ) {
                Text(stringResource(Res.string.play_all), style = typo().bodySmall)
            }
        }
    }
}

/**
 * One shelf item, drawn as the card its ids call for, with Home's click handling: a song or video
 * starts its radio, anything else opens its page. Shared by Home's rows and the "More" page, so an
 * item behaves the same in both.
 */
@Composable
fun HomeContentCard(
    temp: Content,
    navController: NavController,
    viewModel: BaseViewModel,
    onLongClick: (Content) -> Unit,
    // Every card fills its grid cell, as on the "More" page; Home's rows keep the fixed sizes.
    fillMaxWidth: Boolean = false,
) {
    val browseId = temp.browseId
    val playlistId = temp.playlistId
    if ((playlistId != null && temp.videoId == null) || (playlistId != null && temp.videoId == "")) {
        if (playlistId.startsWith("UC")) {
            HomeItemArtist(onClick = {
                navController.navigate(
                    ArtistDestination(
                        channelId = playlistId,
                    ),
                )
            }, data = temp, fillMaxWidth = fillMaxWidth)
        } else {
            HomeItemContentPlaylist(onClick = {
                navController.navigate(
                    PlaylistDestination(
                        playlistId = playlistId,
                    ),
                )
            }, data = temp, fillMaxWidth = fillMaxWidth, onPlay = temp.hoverPlay(viewModel))
        }
    } else if ((browseId != null && temp.videoId == null) || (browseId != null && temp.videoId == "")) {
        if (browseId.startsWith("UC")) {
            HomeItemArtist(onClick = {
                navController.navigate(
                    ArtistDestination(
                        channelId = browseId,
                    ),
                )
            }, data = temp, fillMaxWidth = fillMaxWidth)
        } else if (browseId.startsWith("MPSP")) {
            HomeItemContentPlaylist(onClick = {
                navController.navigate(
                    PodcastDestination(
                        podcastId = browseId,
                    ),
                )
            }, data = temp, fillMaxWidth = fillMaxWidth, onPlay = temp.hoverPlay(viewModel))
        } else {
            HomeItemContentPlaylist(onClick = {
                navController.navigate(
                    AlbumDestination(
                        browseId = browseId,
                    ),
                )
            }, data = temp, fillMaxWidth = fillMaxWidth, onPlay = temp.hoverPlay(viewModel))
        }
    } else if (temp.thumbnails.firstOrNull()?.width != temp.thumbnails.firstOrNull()?.height) {
        HomeItemVideo(
            onClick = { temp.playRadio(viewModel) },
            onLongClick = { onLongClick(temp) },
            data = temp,
            fillMaxWidth = fillMaxWidth,
            onPlay = temp.hoverPlay(viewModel),
        )
    } else {
        HomeItemSong(
            onClick = { temp.playRadio(viewModel) },
            onLongClick = { onLongClick(temp) },
            data = temp,
            fillMaxWidth = fillMaxWidth,
            onPlay = temp.hoverPlay(viewModel),
        )
    }
}

/**
 * The card's hover play button. A song or video plays exactly as a tap on the card does, so every
 * one of them gets it. A playlist or album plays what YouTube's own play button points at, straight
 * from Home; a playlist card that came without one still plays by its id. Artists and podcasts,
 * which have nothing to play, get no button.
 */
private fun Content.hoverPlay(viewModel: BaseViewModel): (() -> Unit)? {
    if (!videoId.isNullOrEmpty()) return { playRadio(viewModel) }
    val endpoint =
        playEndpoint
            ?: playlistId?.takeUnless { it.startsWith("UC") }?.let { YouTubeWatchEndpoint(playlistId = it.removePrefix("VL")) }
            ?: return null
    return { viewModel.playFromEndpoint(endpoint, title) }
}

/**
 * Spotify-style hover for a Home card: while the pointer is over it, or keyboard focus is on it,
 * the card sits on a faint onSurface tint and [HoverPlayButton] rises onto the artwork. Touch
 * screens never hover, so phones keep the plain card. Returns the card's modifier (it has to come
 * before the card's own focusable to see its focus) and whether the card is active.
 */
@Composable
internal fun rememberCardHover(enabled: Boolean): Pair<Modifier, Boolean> {
    val source = remember { MutableInteractionSource() }
    val hovered by source.collectIsHoveredAsState()
    var focused by remember { mutableStateOf(false) }
    val active = enabled && (hovered || focused)
    val tint by animateColorAsState(
        targetValue = if (active) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f) else Color.Transparent,
        label = "cardHoverTint",
    )
    val modifier =
        Modifier
            .onFocusChanged { focused = it.isFocused }
            .hoverable(source)
            .drawBehind { drawRoundRect(color = tint, cornerRadius = CornerRadius(8.dp.toPx())) }
    return modifier to active
}

/** The theme-coloured play button of a hovered Home card, rising onto the artwork's corner. */
@Composable
internal fun BoxScope.HoverPlayButton(
    visible: Boolean,
    onClick: () -> Unit,
) {
    val progress by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(200),
        label = "hoverPlay",
    )
    Box(
        Modifier
            .align(Alignment.BottomEnd)
            .padding(8.dp)
            .graphicsLayer {
                alpha = progress
                translationY = (1f - progress) * 8.dp.toPx()
            }.size(44.dp)
            .shadow(6.dp, CircleShape)
            .background(MaterialTheme.colorScheme.primary, CircleShape)
            .clickable(enabled = visible, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = SimpIcons.PlayArrow,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(24.dp),
        )
    }
}

/**
 * The thumbnail shape [HomeContentCard] draws for [this]: 16:9 for the video card, square for every
 * other card. It mirrors the card's dispatch, so a layout can size a row before drawing it.
 */
fun Content.homeCardAspectRatio(): Float {
    val opensPage = (playlistId != null || browseId != null) && videoId.isNullOrEmpty()
    val wide = thumbnails.firstOrNull()?.width != thumbnails.firstOrNull()?.height
    return if (!opensPage && wide) 16f / 9f else 1f
}

internal fun Content.playRadio(viewModel: BaseViewModel) {
    val firstQueue: Track = toTrack()
    viewModel.setQueueData(
        QueueData.Data(
            listTracks = arrayListOf(firstQueue),
            firstPlayedTrack = firstQueue,
            playlistId = "RDAMVM$videoId",
            playlistName = title,
            playlistType = PlaylistType.RADIO,
            continuation = null,
        ),
    )
    viewModel.loadMediaItem(
        firstQueue,
        Config.SONG_CLICK,
    )
}

/**
 * Opens what a section's "More" endpoint points to. YouTube names the page type on the endpoint, so
 * an album, playlist, artist or podcast opens its own screen; an unnamed one (`FEmusic_*`) is a
 * generic shelf page.
 */
fun NavController.navigateToMoreEndpoint(
    endpoint: MoreEndpoint,
    title: String?,
) {
    when (endpoint.pageType) {
        MoreEndpoint.PAGE_TYPE_ALBUM, MoreEndpoint.PAGE_TYPE_AUDIOBOOK -> {
            navigate(AlbumDestination(browseId = endpoint.browseId))
        }

        MoreEndpoint.PAGE_TYPE_PLAYLIST -> {
            navigate(PlaylistDestination(playlistId = endpoint.browseId))
        }

        MoreEndpoint.PAGE_TYPE_ARTIST, MoreEndpoint.PAGE_TYPE_USER_CHANNEL -> {
            navigate(ArtistDestination(channelId = endpoint.browseId))
        }

        MoreEndpoint.PAGE_TYPE_PODCAST -> {
            navigate(PodcastDestination(podcastId = endpoint.browseId))
        }

        else -> {
            navigate(BrowseDestination(browseId = endpoint.browseId, params = endpoint.params, title = title))
        }
    }
}

@Composable
fun HomeItemContentPlaylist(
    onClick: () -> Unit,
    data: HomeContentType,
    thumbSize: Dp = 160.dp,
    forceDark: Boolean = LocalForceDarkText.current,
    // Fill a grid cell instead of the fixed thumbSize, as Metrolist's browse grid does.
    fillMaxWidth: Boolean = false,
    // Home's hover play button; null leaves the card exactly as it was.
    onPlay: (() -> Unit)? = null,
) {
    val appShapes = LocalAppShapes.current
    val titleColor = if (forceDark) Color.White else MaterialTheme.colorScheme.onSurface
    val textWidth = if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.width(thumbSize)
    val (hoverModifier, hovered) = rememberCardHover(enabled = onPlay != null)
    Box(
        Modifier
            .then(hoverModifier)
            .wrapContentSize()
            .focusable(true)
            .clip(appShapes.card)
            .clickable {
                onClick()
            },
    ) {
        Column(
            modifier =
                Modifier
                    .padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 6.dp)
                    // One floor for every home card, so a row mixing them stays one height. 70
                    // covers the tallest text block among them, HomeItemSong's: 69.5dp when the
                    // text engine counts Poppins' line gap (Skia on Desktop does), 65.8dp when not.
                    // A cell-filling card has no such row to match and its artwork is narrower than
                    // thumbSize, so the floor would only add empty space under every tile.
                    .then(if (fillMaxWidth) Modifier else Modifier.heightIn(min = thumbSize + 70.dp)),
        ) {
            val thumb =
                when (data) {
                    is Content -> data.thumbnails.lastOrNull()?.url
                    is com.maxrave.domain.data.model.mood.genre.Content -> data.thumbnail?.lastOrNull()?.url
                    is com.maxrave.domain.data.model.mood.moodmoments.Content -> data.thumbnails?.lastOrNull()?.url
                    is LocalPlaylistEntity -> data.thumbnail
                    is ChartItem -> null
                    is PlaylistsResult -> data.thumbnails.lastOrNull()?.url
                    is AlbumEntity -> data.thumbnails
                    is PlaylistEntity -> data.thumbnails
                    is ResultSingle -> data.thumbnails.lastOrNull()?.url
                    is ResultAlbum -> data.thumbnails.lastOrNull()?.url
                    is ResultPlaylist -> data.thumbnails.lastOrNull()?.url
                    is PodcastsEntity -> data.thumbnail
                    is AlbumsResult -> data.thumbnails.lastOrNull()?.url
                    // A recap owns no artwork; it borrows the month's own top song's, resolved
                    // where the recap itself is (LibraryViewModel.getMonthlyRecaps).
                    // Deliberately null: a recap has no artwork of its own, so it falls to
                    // the title placeholder below — the same tile a local playlist without
                    // a thumbnail gets. Same reason ChartItem above is null.
                    is MonthlyRecapItem -> null
                    else -> null
                }
            Box {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(thumb)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .diskCacheKey(thumb)
                            .crossfade(550)
                            .build(),
                    placeholder =
                        when (data) {
                            is LocalPlaylistEntity -> {
                                painterPlaylistThumbnail(
                                    data.title,
                                    style = typo().bodySmall,
                                    thumbSize * 0.9f to thumbSize * 0.9f,
                                )
                            }

                            is ChartItem -> {
                                painterPlaylistThumbnail(
                                    data.name,
                                    style = typo().bodySmall,
                                    thumbSize * 0.9f to thumbSize * 0.9f,
                                )
                            }

                            // A month whose top song has no artwork still has a name, and the
                            // deterministic title tile reads as a playlist where the grey holder
                            // reads as a failed load.
                            is MonthlyRecapItem -> {
                                painterPlaylistThumbnail(
                                    data.title,
                                    style = typo().bodySmall,
                                    thumbSize * 0.9f to thumbSize * 0.9f,
                                )
                            }

                            else -> {
                                rememberHolderPainter()
                            }
                        },
                    error =
                        when (data) {
                            is LocalPlaylistEntity -> {
                                painterPlaylistThumbnail(
                                    data.title,
                                    style = typo().bodySmall,
                                    thumbSize * 0.9f to thumbSize * 0.9f,
                                )
                            }

                            is ChartItem -> {
                                painterPlaylistThumbnail(
                                    data.name,
                                    style = typo().bodySmall,
                                    thumbSize * 0.9f to thumbSize * 0.9f,
                                )
                            }

                            // A month whose top song has no artwork still has a name, and the
                            // deterministic title tile reads as a playlist where the grey holder
                            // reads as a failed load.
                            is MonthlyRecapItem -> {
                                painterPlaylistThumbnail(
                                    data.title,
                                    style = typo().bodySmall,
                                    thumbSize * 0.9f to thumbSize * 0.9f,
                                )
                            }

                            else -> {
                                rememberHolderPainter()
                            }
                        },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        (if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.size(thumbSize))
                            .aspectRatio(1f)
                            .clip(
                                appShapes.artwork,
                            ),
                )
                if (onPlay != null) HoverPlayButton(visible = hovered, onClick = onPlay)
            }
            Text(
                text =
                    when (data) {
                        is Content -> data.title
                        is com.maxrave.domain.data.model.mood.genre.Content -> data.title.title
                        is com.maxrave.domain.data.model.mood.moodmoments.Content -> data.title
                        is LocalPlaylistEntity -> data.title
                        is ChartItem -> data.name
                        is PlaylistsResult -> data.title
                        is AlbumEntity -> data.title
                        is PlaylistEntity -> data.title
                        is ResultSingle -> data.title
                        is ResultAlbum -> data.title
                        is ResultPlaylist -> data.title
                        is PodcastsEntity -> data.title
                        is AlbumsResult -> data.title
                        is MonthlyRecapItem -> data.title
                        else -> ""
                    },
                style = typo().titleSmall,
                color = titleColor,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier =
                    textWidth
                        .wrapContentHeight(align = Alignment.CenterVertically)
                        .padding(top = 8.dp),
            )
            Text(
                text =
                    when (data) {
                        is Content -> {
                            data.description
                                ?: if (data.playlistId == null) {
                                    (
                                        if (!data.artists.isNullOrEmpty()) {
                                            data.artists
                                                .toListName()
                                                .connectArtists()
                                        } else {
                                            stringResource(Res.string.album)
                                        }
                                    )
                                } else {
                                    stringResource(Res.string.playlist)
                                }
                        }

                        is com.maxrave.domain.data.model.mood.genre.Content -> {
                            data.title.subtitle
                        }

                        is com.maxrave.domain.data.model.mood.moodmoments.Content -> {
                            data.subtitle
                        }

                        is LocalPlaylistEntity -> {
                            stringResource(Res.string.you)
                        }

                        is ChartItem -> {
                            stringResource(Res.string.app_name)
                        }

                        is PlaylistsResult -> {
                            data.author
                        }

                        is AlbumEntity -> {
                            data.artistName?.connectArtists() ?: stringResource(Res.string.album)
                        }

                        is PlaylistEntity -> {
                            data.author ?: stringResource(Res.string.playlist)
                        }

                        is ResultSingle -> {
                            data.year
                        }

                        is ResultAlbum -> {
                            data.year
                        }

                        is ResultPlaylist -> {
                            data.author
                        }

                        is PodcastsEntity -> {
                            data.authorName
                        }

                        is MonthlyRecapItem -> {
                            stringResource(Res.string.wrapped_recap_subtitle)
                        }

                        is AlbumsResult -> {
                            data.year
                        }

                        else -> {
                            ""
                        }
                    },
                style = typo().bodySmall,
                minLines = 1,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier =
                    textWidth
                        .wrapContentHeight(align = Alignment.CenterVertically)
                        .basicMarquee(
                            initialDelayMillis = 2000,
                            repeatDelayMillis = 2000,
                            velocity = 25.dp,
                        ),
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun QuickPicksItem(
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    widthDp: Dp,
    data: Content,
) {
    val appShapes = LocalAppShapes.current
    val tag = "QuickPicksItem"
    Box(
        modifier =
            Modifier
                .wrapContentHeight()
                .width(widthDp - 30.dp)
                .focusable(true)
                .clip(appShapes.card)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick,
                ),
    ) {
        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
        ) {
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalPlatformContext.current)
                        .data(data.thumbnails.lastOrNull()?.url)
                        .crossfade(550)
                        .diskCacheKey(data.thumbnails.lastOrNull()?.url)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .build(),
                placeholder = rememberHolderPainter(),
                contentDescription = stringResource(Res.string.description),
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .align(Alignment.CenterVertically)
                        .size(44.dp)
                        .clip(
                            appShapes.artworkSmall,
                        ),
            )
            Column(
                Modifier
                    .padding(
                        start = 16.dp,
                    ).align(Alignment.CenterVertically),
                verticalArrangement = Arrangement.SpaceEvenly,
            ) {
                // One line + marquee, NOT maxLines = 2: the parent LazyHorizontalGrid uses
                // GridCells.Fixed(4) over a fixed 256.dp, so every cell is exactly 64.dp and a
                // second title line pushes the artist row out of the cell, where the grid clips it.
                Text(
                    text = data.title,
                    style = typo().titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .padding(
                                bottom = 3.dp,
                            ).basicMarquee(
                                iterations = Int.MAX_VALUE,
                                initialDelayMillis = 2000,
                                repeatDelayMillis = 2000,
                                velocity = 25.dp,
                            ),
                )
                LazyRow(verticalAlignment = Alignment.CenterVertically) {
                    item {
                        androidx.compose.animation.AnimatedVisibility(visible = data.isExplicit == true) {
                            ExplicitBadge(
                                modifier =
                                    Modifier
                                        .size(20.dp)
                                        .padding(end = 4.dp)
                                        .weight(1f),
                            )
                        }
                    }
                    item {
                        Text(
                            text = data.artists.toListName().connectArtists(),
                            style = typo().bodySmall,
                            minLines = 1,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .wrapContentHeight(align = Alignment.CenterVertically)
                                    .basicMarquee(
                                        initialDelayMillis = 2000,
                                        repeatDelayMillis = 2000,
                                        velocity = 25.dp,
                                    ),
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeItemSong(
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    data: Content,
    // Fill a grid cell instead of the fixed 160dp, as Metrolist's browse grid does.
    fillMaxWidth: Boolean = false,
    // Home's hover play button; null leaves the card exactly as it was.
    onPlay: (() -> Unit)? = null,
) {
    val appShapes = LocalAppShapes.current
    val textWidth = if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.width(160.dp)
    val (hoverModifier, hovered) = rememberCardHover(enabled = onPlay != null)
    Box(
        modifier =
            Modifier
                .then(hoverModifier)
                .fillMaxSize()
                .focusable(true)
                .clip(appShapes.card)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick,
                ),
    ) {
        Column(
            modifier =
                Modifier
                    .padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 6.dp)
                    .heightIn(min = 230.dp),
        ) {
            val thumb =
                data.thumbnails.lastOrNull()?.url?.let {
                    if (it.contains("w120")) {
                        Regex("([wh])120").replace(it, "$1544")
                    } else {
                        it
                    }
                }
            Box(Modifier.align(Alignment.CenterHorizontally)) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(thumb)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .diskCacheKey(thumb)
                            .crossfade(550)
                            .build(),
                    placeholder = rememberHolderPainter(),
                    error = rememberHolderPainter(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .then(if (fillMaxWidth) Modifier.fillMaxWidth().aspectRatio(1f) else Modifier.size(160.dp))
                            .clip(
                                appShapes.artwork,
                            ),
                )
                if (onPlay != null) HoverPlayButton(visible = hovered, onClick = onPlay)
            }
            Text(
                text = data.title,
                style = typo().titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier =
                    textWidth
                        .wrapContentHeight(align = Alignment.CenterVertically)
                        .padding(top = 8.dp),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedVisibility(visible = data.isExplicit == true) {
                    ExplicitBadge(
                        modifier =
                            Modifier
                                .size(20.dp)
                                .padding(end = 4.dp)
                                .weight(1f),
                    )
                }
                Text(
                    text =
                        listOfNotNull(
                            data.artists
                                .toListName()
                                .connectArtists()
                                .takeIf { it.isNotBlank() },
                            data.album?.name?.takeIf { it.isNotBlank() },
                        ).joinToString(" • "),
                    style = typo().bodySmall,
                    minLines = 1,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        textWidth
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .basicMarquee(
                                initialDelayMillis = 2000,
                                repeatDelayMillis = 2000,
                                velocity = 25.dp,
                            ).padding(vertical = 3.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeItemVideo(
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    data: Content,
    forceDark: Boolean = LocalForceDarkText.current,
    // Fill a grid cell instead of the fixed 284.5dp, as Metrolist's browse grid does.
    fillMaxWidth: Boolean = false,
    // Home's hover play button; null leaves the card exactly as it was.
    onPlay: (() -> Unit)? = null,
) {
    val appShapes = LocalAppShapes.current
    val titleColor = if (forceDark) Color.White else MaterialTheme.colorScheme.onSurface
    val textWidth = if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.width(284.5.dp)
    val (hoverModifier, hovered) = rememberCardHover(enabled = onPlay != null)
    Box(
        Modifier
            .then(hoverModifier)
            .fillMaxSize()
            .focusable(true)
            .clip(appShapes.card)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick,
            ),
    ) {
        Column(
            modifier =
                Modifier
                    .padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 6.dp)
                    .heightIn(min = 230.dp),
        ) {
            val thumb = data.thumbnails.lastOrNull()?.url
            Box(Modifier.align(Alignment.CenterHorizontally)) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(thumb)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .diskCacheKey(thumb)
                            .crossfade(550)
                            .build(),
                    placeholder = rememberHolderPainter(isVideo = true),
                    error = rememberHolderPainter(isVideo = true),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .then(if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.height(160.dp))
                            .aspectRatio(16f / 9f)
                            .clip(
                                appShapes.artwork,
                            ),
                )
                if (onPlay != null) HoverPlayButton(visible = hovered, onClick = onPlay)
            }
            Text(
                text = data.title,
                style = typo().titleSmall,
                color = titleColor,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier =
                    textWidth
                        .wrapContentHeight(align = Alignment.CenterVertically)
                        .padding(top = 8.dp),
            )
            Row(
                modifier = textWidth.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Ahead of the channel name, where YouTube Music puts it.
                if (data.isLive) LiveBadge(modifier = Modifier.padding(end = 6.dp))
                Text(
                    text =
                        listOfNotNull(
                            data.artists
                                .toListName()
                                .connectArtists()
                                .takeIf { it.isNotBlank() },
                            data.views?.takeIf { it.isNotBlank() },
                        ).joinToString(" • "),
                    style = typo().bodySmall,
                    minLines = 1,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        Modifier
                            .weight(1f)
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .basicMarquee(
                                initialDelayMillis = 2000,
                                repeatDelayMillis = 2000,
                                velocity = 25.dp,
                            ),
                )
            }
        }
    }
}

/**
 * The red LIVE chip on a broadcast that is on air right now. Sized off the subtitle beside it
 * (bodySmall, 11sp) and kept a step smaller, as on the web — this app's labelSmall is 14sp
 * SemiBold, which made the chip taller than the line it sits on.
 */
@Composable
private fun LiveBadge(modifier: Modifier = Modifier) {
    Text(
        text = stringResource(Res.string.live_badge),
        style = typo().bodySmall.copy(fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold),
        color = Color.White,
        maxLines = 1,
        modifier =
            modifier
                // YouTube's own live red, so the chip reads the same as on the web.
                .background(LiveBadgeRed, RoundedCornerShape(2.dp))
                .padding(horizontal = 3.dp),
    )
}

private val LiveBadgeRed = Color(0xFFCC0000)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeItemArtist(
    onClick: () -> Unit,
    data: Content,
    forceDark: Boolean = LocalForceDarkText.current,
    // Fill a grid cell instead of the fixed 160dp, as Metrolist's browse grid does.
    fillMaxWidth: Boolean = false,
) {
    val appShapes = LocalAppShapes.current
    val titleColor = if (forceDark) Color.White else MaterialTheme.colorScheme.onSurface
    val textWidth = if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.width(160.dp)
    Box(
        Modifier
            .fillMaxSize()
            .focusable(true)
            .clip(appShapes.card)
            .clickable {
                onClick()
            },
    ) {
        Column(
            modifier =
                Modifier
                    .padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 6.dp)
                    .heightIn(min = 230.dp),
        ) {
            val thumb = data.thumbnails.lastOrNull()?.url
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalPlatformContext.current)
                        .data(thumb)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .diskCacheKey(thumb)
                        .crossfade(550)
                        .build(),
                placeholder = rememberHolderPainter(),
                error = rememberHolderPainter(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .then(if (fillMaxWidth) Modifier.fillMaxWidth().aspectRatio(1f) else Modifier.size(160.dp))
                        .clip(
                            CircleShape,
                        ),
            )
            Text(
                text = data.title,
                style = typo().titleSmall,
                color = titleColor,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier =
                    textWidth
                        .wrapContentHeight(align = Alignment.CenterVertically)
                        .padding(top = 8.dp),
            )
            Text(
                text = data.description?.takeIf { it.isNotBlank() }.orEmpty(),
                style = typo().bodySmall,
                minLines = 1,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier =
                    textWidth
                        .wrapContentHeight(align = Alignment.CenterVertically)
                        .basicMarquee(
                            initialDelayMillis = 2000,
                            repeatDelayMillis = 2000,
                            velocity = 25.dp,
                        ),
            )
        }
    }
}

@Composable
fun MoodMomentAndGenreHomeItem(
    title: String,
    stripeColor: Long,
    // Fill a grid cell instead of the fixed 160dp.
    fillMaxWidth: Boolean = false,
    onClick: () -> Unit,
) {
    val appShapes = LocalAppShapes.current
    ElevatedCard(
        elevation =
            CardDefaults.cardElevation(
                defaultElevation = 6.dp,
            ),
        onClick = onClick,
        shape = appShapes.cardSmall,
        modifier =
            (if (fillMaxWidth) Modifier.fillMaxWidth() else Modifier.width(160.dp))
                .height(50.dp)
                .padding(8.dp),
    ) {
        Row {
            Box(
                // `solid.leftStripeColor` straight from the API (full ARGB). This used to be
                // generateRandomColor(), which — being outside remember — rolled a new colour on
                // every recomposition, so the stripes flickered while scrolling.
                Modifier
                    .width(10.dp)
                    .height(64.dp)
                    .background(Color(stripeColor)),
            )
            Text(
                text = title,
                style = typo().titleSmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .align(Alignment.CenterVertically),
            )
        }
    }
}

@Composable
fun ItemVideoChart(
    onClick: () -> Unit,
    data: ItemVideo,
    position: Int,
) {
    Box(
        Modifier
            .wrapContentSize()
            .focusable(true)
            .clip(RoundedCornerShape(8.dp))
            .clickable {
                onClick()
            },
    ) {
        Column(
            modifier =
                Modifier
                    .padding(10.dp),
        ) {
            val thumb = data.thumbnails.lastOrNull()?.url
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalPlatformContext.current)
                        .data(thumb)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .diskCacheKey(thumb)
                        .crossfade(550)
                        .build(),
                placeholder = rememberHolderPainter(isVideo = true),
                error = rememberHolderPainter(isVideo = true),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .width(280.dp)
                        .height(160.dp)
                        .clip(
                            RoundedCornerShape(10),
                        ),
            )
            Row {
                Text(
                    text = position.toString(),
                    style = typo().titleLarge,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier =
                        Modifier
                            .width(40.dp)
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .align(Alignment.CenterVertically),
                )
                Column(Modifier.padding(start = 10.dp)) {
                    Text(
                        text = data.title,
                        style = typo().titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier =
                            Modifier
                                .width(210.dp)
                                .wrapContentHeight(align = Alignment.CenterVertically)
                                .padding(top = 10.dp),
                    )
                    Text(
                        text =
                            listOfNotNull(
                                data.artists
                                    .toListName()
                                    .connectArtists()
                                    .takeIf { it.isNotBlank() },
                                data.views.takeIf { it.isNotBlank() },
                            ).joinToString(" • "),
                        style = typo().bodyMedium,
                        minLines = 1,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier =
                            Modifier
                                .width(210.dp)
                                .wrapContentHeight(align = Alignment.CenterVertically)
                                .basicMarquee(
                                    initialDelayMillis = 2000,
                                    repeatDelayMillis = 2000,
                                    velocity = 25.dp,
                                ).padding(vertical = 3.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun ItemArtistChart(
    onClick: () -> Unit,
    data: ItemArtist,
    widthDp: Dp,
    // The chart's podcast rows reuse this row: a square cover, and the author shown as-is.
    thumbnailShape: Shape = CircleShape,
    subtitle: String? = null,
) {
    val appShapes = LocalAppShapes.current
    Box(
        Modifier
            .wrapContentSize()
            .focusable(true)
            .clip(appShapes.card)
            .clickable {
                onClick()
            },
    ) {
        Row(
            modifier =
                Modifier
                    .padding(10.dp)
                    .width(widthDp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = data.rank,
                style = typo().titleLarge,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier =
                    Modifier
                        .wrapContentSize(Alignment.Center)
                        .align(Alignment.CenterVertically)
                        .padding(end = 20.dp),
            )
            val thumb = data.thumbnails.lastOrNull()?.url
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalPlatformContext.current)
                        .data(thumb)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .diskCacheKey(thumb)
                        .crossfade(550)
                        .build(),
                placeholder = rememberHolderPainter(),
                error = rememberHolderPainter(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .align(Alignment.CenterVertically)
                        .size(60.dp)
                        .clip(thumbnailShape),
            )
            Column(
                Modifier
                    .padding(start = 15.dp)
                    .width(160.dp)
                    .align(Alignment.CenterVertically),
            ) {
                Text(
                    text = data.title,
                    style = typo().titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        Modifier
                            .wrapContentHeight(align = Alignment.CenterVertically),
                )
                Text(
                    text =
                        subtitle ?: if (data.subscribers.contains(
                                stringResource(Res.string.subscribers).replace("%1\$s ", ""),
                            )
                        ) {
                            data.subscribers
                        } else {
                            stringResource(
                                Res.string.subscribers,
                                data.subscribers,
                            )
                        },
                    style = typo().bodySmall,
                    minLines = 1,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        Modifier
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .basicMarquee(
                                initialDelayMillis = 2000,
                                repeatDelayMillis = 2000,
                                velocity = 25.dp,
                            ),
                )
            }
        }
    }
}

@Composable
fun ItemTrackChart(
    onClick: () -> Unit,
    data: Track,
    position: Int?,
    widthDp: Dp,
) {
    val appShapes = LocalAppShapes.current
    Box(
        modifier =
            Modifier
                .wrapContentSize()
                .focusable(true)
                .clip(appShapes.card)
                .clickable {
                    onClick()
                },
    ) {
        Row(
            modifier =
                Modifier
                    .width(widthDp)
                    .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Crossfade(targetState = position != null, label = "Chart Track Position") {
                if (it) {
                    Row {
                        Text(
                            text = position.toString(),
                            style = typo().titleLarge,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier =
                                Modifier
                                    .width(40.dp)
                                    .wrapContentHeight(align = Alignment.CenterVertically)
                                    .align(Alignment.CenterVertically),
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                    }
                }
            }
            val thumb = data.thumbnails?.lastOrNull()?.url
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalPlatformContext.current)
                        .data(thumb)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .diskCacheKey(thumb)
                        .crossfade(550)
                        .build(),
                placeholder = rememberHolderPainter(),
                error = rememberHolderPainter(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .align(Alignment.CenterVertically)
                        .size(50.dp)
                        .clip(
                            appShapes.artwork,
                        ),
            )
            Column(
                Modifier
                    .padding(
                        start = 20.dp,
                    ).align(Alignment.CenterVertically),
                verticalArrangement = Arrangement.SpaceEvenly,
            ) {
                Text(
                    text = data.title,
                    style = typo().titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .padding(
                                bottom = 3.dp,
                            ),
                )

                Text(
                    text = data.artists.toListName().connectArtists(),
                    style = typo().bodySmall,
                    minLines = 1,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(align = Alignment.CenterVertically)
                            .basicMarquee(
                                initialDelayMillis = 2000,
                                repeatDelayMillis = 2000,
                                velocity = 25.dp,
                            ),
                )
            }
        }
    }
}

@Composable
fun MoodAndGenresContentItem(
    data: Any?,
    navController: NavController,
    homeViewModel: HomeViewModel = koinViewModel(),
) {
    Column(
        modifier = Modifier.wrapContentHeight(align = Alignment.CenterVertically, unbounded = true),
    ) {
        Text(
            text =
                when (data) {
                    is ItemsPlaylist -> (data).header
                    is Item -> (data).header
                    else -> ""
                },
            style = typo().titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier =
                Modifier
                    .padding(top = 8.dp)
                    .padding(
                        horizontal = 15.dp,
                    ).fillMaxWidth(),
        )
        LazyRow(
            modifier =
                Modifier.padding(
                    10.dp,
                ),
        ) {
            val itemList =
                when (data) {
                    is ItemsPlaylist -> (data).contents
                    is Item -> (data).contents
                    else -> listOf()
                }
            items(itemList) { item ->
                HomeItemContentPlaylist(onClick = {
                    // The "Songs" shelf mixes tracks into a list that is otherwise all playlists,
                    // so route by videoId: a track starts its radio, everything else opens a page.
                    val moodSong = item as? com.maxrave.domain.data.model.mood.moodmoments.Content
                    val songVideoId = moodSong?.videoId
                    if (moodSong != null && songVideoId != null) {
                        val track =
                            Track(
                                album = null,
                                artists = listOf(Artist(id = null, name = moodSong.subtitle)),
                                duration = null,
                                durationSeconds = null,
                                isAvailable = true,
                                isExplicit = false,
                                likeStatus = null,
                                thumbnails = moodSong.thumbnails,
                                title = moodSong.title,
                                videoId = songVideoId,
                                videoType = null,
                                category = null,
                                feedbackTokens = null,
                                resultType = null,
                            )
                        homeViewModel.setQueueData(
                            QueueData.Data(
                                listTracks = arrayListOf(track),
                                firstPlayedTrack = track,
                                playlistId = "RDAMVM$songVideoId",
                                playlistName = "\"${moodSong.title}\" Radio",
                                playlistType = PlaylistType.RADIO,
                                continuation = null,
                            ),
                        )
                        homeViewModel.loadMediaItem(track, type = Config.SONG_CLICK)
                    } else {
                        navController.navigate(
                            PlaylistDestination(
                                playlistId =
                                    if (item is com.maxrave.domain.data.model.mood.genre.Content) {
                                        item.playlistBrowseId
                                    } else {
                                        (item as com.maxrave.domain.data.model.mood.moodmoments.Content).playlistBrowseId
                                    },
                            ),
                        )
                    }
                }, data = item)
            }
        }
    }
}