package com.maxrave.simpmusic.ui.screen.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.maxrave.domain.data.player.SourceAvailability
import com.maxrave.domain.data.player.SourceKind
import com.maxrave.domain.data.player.isHighQuality
import com.maxrave.domain.data.player.SourceOption
import com.maxrave.domain.mediaservice.handler.MediaPlayerHandler
import com.maxrave.domain.repository.StreamRepository
import com.maxrave.simpmusic.ui.component.rememberSurfaceDarkColors
import com.maxrave.simpmusic.ui.icon.CheckCircle
import com.maxrave.simpmusic.ui.icon.CloudOff
import com.maxrave.simpmusic.ui.icon.GraphicEq
import com.maxrave.simpmusic.ui.icon.Settings
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.screen.player.content.sourceQuality
import com.maxrave.simpmusic.ui.theme.typo
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.source_audius
import simpmusic.composeapp.generated.resources.source_available
import simpmusic.composeapp.generated.resources.source_downloaded
import simpmusic.composeapp.generated.resources.source_podcast
import simpmusic.composeapp.generated.resources.source_internet_archive
import simpmusic.composeapp.generated.resources.source_monochrome
import simpmusic.composeapp.generated.resources.source_lossless
import simpmusic.composeapp.generated.resources.source_needs_backup
import simpmusic.composeapp.generated.resources.source_needs_hifi
import simpmusic.composeapp.generated.resources.source_not_found
import simpmusic.composeapp.generated.resources.source_playing
import simpmusic.composeapp.generated.resources.source_searching
import simpmusic.composeapp.generated.resources.source_soundcloud
import simpmusic.composeapp.generated.resources.source_switch_failed
import simpmusic.composeapp.generated.resources.source_switching
import simpmusic.composeapp.generated.resources.source_youtube
import simpmusic.composeapp.generated.resources.sources_description
import simpmusic.composeapp.generated.resources.sources_title

/**
 * Every place the song now playing can come from, best first, and which one it is playing from.
 * Tapping another plays the song from it, carrying on from the same moment. Private copy.
 *
 * Opening the sheet starts the searches the settings allow (the Internet Archive with Hi-Fi sound
 * on, SoundCloud with its backup switch on), so a row can go from "Searching…" to available while
 * it is open.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaybackSourcesSheet(
    videoId: String,
    onDismiss: () -> Unit,
    streamRepository: StreamRepository = koinInject(),
    mediaPlayerHandler: MediaPlayerHandler = koinInject(),
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()
    val options by remember(videoId) { streamRepository.sourceOptions(videoId) }.collectAsState(emptyList())
    var switching by remember { mutableStateOf<SourceKind?>(null) }
    var failed by remember { mutableStateOf<SourceKind?>(null) }
    val colors = rememberSurfaceDarkColors()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.Transparent,
        contentColor = Color.Transparent,
        dragHandle = {},
        scrimColor = Color.Black.copy(alpha = .5f),
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) },
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors().copy(containerColor = colors.container),
        ) {
            Column(
                modifier =
                    Modifier
                        .navigationBarsPadding()
                        .padding(top = 20.dp, bottom = 12.dp),
            ) {
                Text(
                    text = stringResource(Res.string.sources_title),
                    style = typo().titleMedium,
                    color = colors.content,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(Res.string.sources_description),
                    style = typo().bodySmall,
                    color = colors.subtitle,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
                Spacer(Modifier.height(12.dp))
                if (options.isEmpty()) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    }
                }
                for (option in options) {
                    SourceRow(
                        option = option,
                        switching = switching == option.kind,
                        failed = failed == option.kind,
                        onClick = {
                            if (switching != null) return@SourceRow
                            switching = option.kind
                            failed = null
                            mediaPlayerHandler.player.switchSource(option.kind) { done ->
                                coroutineScope.launch {
                                    switching = null
                                    if (done) {
                                        sheetState.hide()
                                        onDismiss()
                                    } else {
                                        failed = option.kind
                                    }
                                }
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun SourceRow(
    option: SourceOption,
    switching: Boolean,
    failed: Boolean,
    onClick: () -> Unit,
) {
    val colors = rememberSurfaceDarkColors()
    val playing = option.availability == SourceAvailability.PLAYING
    val selectable = option.availability == SourceAvailability.AVAILABLE
    val name =
        when (option.kind) {
            SourceKind.YOUTUBE -> stringResource(Res.string.source_youtube)
            SourceKind.INTERNET_ARCHIVE -> stringResource(Res.string.source_internet_archive)
            SourceKind.MONOCHROME -> stringResource(Res.string.source_monochrome)
            SourceKind.AUDIUS -> stringResource(Res.string.source_audius)
            SourceKind.SOUNDCLOUD -> stringResource(Res.string.source_soundcloud)
            SourceKind.DOWNLOADED -> stringResource(Res.string.source_downloaded)
            SourceKind.PODCAST -> stringResource(Res.string.source_podcast)
        }
    val quality = option.source?.let(::sourceQuality).orEmpty()
    val status =
        when {
            switching -> stringResource(Res.string.source_switching)
            failed -> stringResource(Res.string.source_switch_failed)
            else ->
                when (option.availability) {
                    SourceAvailability.PLAYING -> stringResource(Res.string.source_playing)
                    SourceAvailability.AVAILABLE -> stringResource(Res.string.source_available)
                    SourceAvailability.SEARCHING -> stringResource(Res.string.source_searching)
                    SourceAvailability.NOT_FOUND -> stringResource(Res.string.source_not_found)
                    SourceAvailability.TURNED_OFF ->
                        if (option.kind.isHighQuality) {
                            stringResource(Res.string.source_needs_hifi)
                        } else {
                            stringResource(Res.string.source_needs_backup)
                        }
                }
        }
    val dim = !playing && !selectable
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            Modifier
                .fillMaxWidth()
                .then(if (selectable) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            when {
                switching || option.availability == SourceAvailability.SEARCHING ->
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = colors.content)

                else ->
                    Icon(
                        imageVector =
                            when (option.availability) {
                                SourceAvailability.PLAYING -> SimpIcons.CheckCircle
                                SourceAvailability.NOT_FOUND -> SimpIcons.CloudOff
                                SourceAvailability.TURNED_OFF -> SimpIcons.Settings
                                else -> SimpIcons.GraphicEq
                            },
                        contentDescription = null,
                        tint = if (dim) colors.disabled else colors.content,
                        modifier = Modifier.size(22.dp),
                    )
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = name,
                    style = typo().labelMedium,
                    color = if (dim) colors.disabled else colors.content,
                )
                if (option.source?.isLossless == true) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(Res.string.source_lossless),
                        style = typo().bodySmall,
                        color = if (dim) colors.disabled else colors.content.copy(alpha = 0.8f),
                    )
                }
            }
            Text(
                text = listOf(quality, status).filter { it.isNotEmpty() }.joinToString(" · "),
                style = typo().bodySmall,
                color = colors.subtitle,
            )
        }
    }
}
