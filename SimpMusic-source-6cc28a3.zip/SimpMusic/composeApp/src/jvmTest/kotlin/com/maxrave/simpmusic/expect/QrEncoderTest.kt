package com.maxrave.simpmusic.expect

import com.google.zxing.BinaryBitmap
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import com.maxrave.simpmusic.viewModel.ListenTogetherViewModel
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class QrEncoderTest {
    /** Draws the modules as pixels the way a camera would see them, then reads them back. */
    @Test
    fun theRoomQrCodeScansBackToTheInviteLink() {
        val link = ListenTogetherViewModel.inviteLink("AB12CD34")
        val modules = assertNotNull(encodeQrCode(link))
        val scale = 6
        val size = modules.size * scale
        val pixels =
            IntArray(size * size) { i ->
                val x = (i % size) / scale
                val y = (i / size) / scale
                if (modules[y][x]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            }
        val decoded = QRCodeReader().decode(BinaryBitmap(HybridBinarizer(RGBLuminanceSource(size, size, pixels)))).text
        assertEquals(link, decoded)
        assertEquals("AB12CD34", ListenTogetherViewModel.parseRoomCode(decoded))
    }
}
