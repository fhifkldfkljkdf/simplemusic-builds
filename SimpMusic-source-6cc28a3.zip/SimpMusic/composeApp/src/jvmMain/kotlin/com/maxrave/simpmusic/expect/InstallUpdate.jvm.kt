package com.maxrave.simpmusic.expect

/**
 * The desktop has nothing to install itself into: the download page is opened in the browser, as
 * before. [onProgress] is not used, and there is no downloaded update to install later.
 */
actual suspend fun downloadAndInstallUpdate(
    url: String,
    onProgress: (Float?) -> Unit,
): Result<Unit> =
    runCatching {
        openUrl(url)
    }

actual fun downloadedUpdateReady(): Boolean = false

actual fun installDownloadedUpdate(): Result<Unit> = Result.failure(UnsupportedOperationException("Nothing to install on the desktop"))

/** The desktop downloads whatever it likes; there is no metered plan to respect. */
actual fun updateDownloadAllowed(): Boolean = true
