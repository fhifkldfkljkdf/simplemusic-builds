package com.maxrave.simpmusic.expect.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect

/** Desktop has no scanner: the Listen Together screen never offers it there. */
@Composable
actual fun RoomQrScannerSheet(
    onScanned: (String) -> Boolean,
    onDismiss: () -> Unit,
    title: String?,
    hint: String?,
    rejectedHint: String?,
) {
    LaunchedEffect(Unit) { onDismiss() }
}
