package com.maxrave.simpmusic.expect

/** The desktop player does not measure a download throughput. */
actual fun networkBitrateEstimateBps(): Long = 0

actual fun networkHistory(): List<Pair<Long, Long>> = emptyList()
