# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

The root `CLAUDE.md` is upstream's project guide: architecture, module roles, and a long changelog of traps
already hit. It loads alongside this file. This file adds what the root guide leaves out (commands, the Gradle
module map, places where the root guide is out of date) and the rules for this private copy.

## Private copy rules

This repository is a private copy of maxrave-dev/SimpMusic. See `.private-fork/README.md`.

- Never open pull requests, issues, or comments on maxrave-dev/SimpMusic or maxrave-dev/core, and never push there.
- Pull in upstream changes with `.private-fork/sync-upstream.sh`, which merges them into `main` of this repository.
- Do not commit to `upstream-main` by hand; it is a filtered mirror that only the sync script updates.
- **Do not edit the root `CLAUDE.md`.** Upstream changes it almost daily, so a local edit turns every sync into a
  merge conflict. Its "CLAUDE.md Auto-Update Rule" applies to this file instead: record changes made in this copy here.
- The root guide's "Pull Request Guidelines" and `CONTRIBUTING.md` (fork, branch from `dev`) describe upstream.
  Here, work lands on `main` of fhifkldfkljkdf/simplemusic.
- **Every change ends published.** Push `main` here, then publish to the builds repo
  `fhifkldfkljkdf/simplemusic-builds`: the version bumped by one in `gradle/libs.versions.toml`, the
  arm64 optimized APK as `SimpMusic-dev-listen-together-arm64.apk`, the source zip
  `SimpMusic-source-<short sha>.zip` (app commit + core commit, tracked files only), `icon.png` when
  the icon changed, the README's "New in this update" entry, and **a GitHub release `v<version>` with
  the APK as its only asset** — the app's update check reads `releases/latest` of that repo (see
  Commands), so publishing the file without the release leaves every installed build on the old one.
  A release's tag is what the update dialog offers, so the bump and the tag must agree. **Without asking**: this
  is a standing instruction from the user (2026-10-16) — the routine publish is not a decision to confirm, and a
  change is not finished until it is on both repositories with its release cut. Questions are for what to *build*
  (a design fork, a destructive step, a platform limit like the notification visualiser), never for whether to
  ship what was asked for.
- `.claude/skills/simpmusic-release-changelog` Step 1 comments on, edits and closes issues in maxrave-dev/SimpMusic
  and its Project #2 (`gh … --repo maxrave-dev/SimpMusic`). Never run those commands from this copy.
- `core/` is a git submodule cloned from the `core-main` branch of THIS repository (`.gitmodules` uses the
  relative URL `../simplemusic.git`); `core-upstream` mirrors maxrave-dev/core. Most modules live there, so run
  `git submodule update --init core` after cloning (shallow, per `.gitmodules`) and `git submodule update core` after each
  sync. To change core: commit inside `core/` on `core-main`, `git -C core push origin HEAD:core-main`, then
  commit the new `core` pointer here. Never push `core/` anywhere else.

## Commands

Full vs FOSS is **not** an Android product flavor. It is the Gradle property `isFullBuild`. It swaps
`crashlytics`/`cast`/`lastfm` for their `*-empty` stubs in `androidApp`, `composeApp`, `core/data` and
`core/media/media3`. Upstream sets it `true`; **this copy sets it `false` in `gradle.properties`** (see "No tracking"
below), so every build here is the tracking-free one. `-PisFullBuild=true` brings Sentry, Cast and Last.fm back.

Secrets come from an optional root `local.properties` (`SENTRY_DSN`, `SENTRY_AUTH_TOKEN`, `LASTFM_API_KEY`,
`LASTFM_SECRET`). If the file is missing the build still works: the values are empty and Sentry and Last.fm do nothing.

```sh
# Android
./gradlew :androidApp:assembleDebug            # applicationId com.maxrave.simpmusic.dev
./gradlew :androidApp:assembleRelease          # R8 + per-ABI splits + universal APK, unsigned
./gradlew :androidApp:assembleOptimized        # this copy: release build (R8, no debug code) as com.maxrave.simpmusic.dev,
                                               # signed with .private-fork/test-signing.keystore; what the builds repo ships
./build_and_sign_apk.sh --release              # assembles, zipaligns and signs with ./simpmusic.jks;
                                               # needs KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD, ANDROID_HOME.
                                               # --full/--foss only rename the output; set isFullBuild yourself.
./gradlew exportLibraryDefinitions             # aboutLibraries.json; upstream CI runs it before release builds

# Publishing a test build (fhifkldfkljkdf/simplemusic-builds) is two halves, and the updater only
# reads one of them: it asks releases/latest of that repo (Ytmusic.checkForGithubReleaseUpdate, core),
# offers the tag when VersionManager.isBehind(tag), and downloads the release's first .apk asset.
# So the APK file, source zip, icon.png and README on main are NOT enough - a GitHub release with the
# same version must exist too, or every installed build keeps seeing the previous tag:
#   gh release create v2.4.25 SimpMusic-dev-listen-together-arm64.apk -R fhifkldfkljkdf/simplemusic-builds \
#     --title v2.4.25 --notes "<short notes; the app shows this body>"
# One .apk asset only (the code takes the first), the arm64 optimized APK (installs over the previous
# build, same test key), tag = the app's own version with a leading "v".

# In the OpenCode container: run the build detached, or the daemon dies within seconds of starting
# (Gradle reports "daemon disappeared" with no error of its own; nothing in the daemon log either).
# setsid + stdin from /dev/null survives, and `--foreground`/`--no-daemon` do not help.
#   export JAVA_HOME=$HOME/tools/jdk ANDROID_HOME=$HOME/tools/android-sdk
#   # $HOME/tools: Temurin 21; android-sdk with platforms/android-37.0, build-tools 37.0.0 and 36.0.0
#   setsid nohup ./gradlew :androidApp:assembleOptimized --console=plain > /tmp/build.log 2>&1 < /dev/null &
# assembleDebug was 7 min, assembleOptimized 5 min after it, on the container's caches.

# Desktop
./gradlew :composeApp:mpvSetupAll --no-configuration-cache   # fetch + checksum libmpv natives into mpv-natives/
                                               # (without them the app falls back to a system libmpv)
./gradlew :desktopApp:run
./gradlew :desktopApp:hotRunJvm --auto         # Compose Hot Reload
# Packaging (upstream CI order): :desktopApp:writeConveyorConfig, then the external `conveyor` CLI,
# then :desktopApp:packageConveyorAppImage. Add --no-configuration-cache to these tasks.

# Tests. KMP modules run commonTest + jvmTest under the jvm target.
./gradlew :domain:jvmTest :kotlinYtmusicScraper:jvmTest :listenTogether:jvmTest :loginSync:jvmTest :nostr:jvmTest :headsetControl:jvmTest
./gradlew :domain:jvmTest --tests 'com.maxrave.domain.mediaservice.handler.RadioQueueTrimTest'
./gradlew :media3:testDebugUnitTest --tests 'com.maxrave.media3.audio.EchoAudioProcessorTest'
```

- The `:media3` audio tests compare against ffmpeg-generated reference vectors in
  `core/media/media3/src/test/resources/audio/`.
- `listenTogether`'s `Live*Test` classes talk to a real server, so they are `@Ignore`d on purpose.
- There is no ktlint/detekt/spotless task. `.editorconfig` holds the ktlint settings: 150-character lines,
  wildcard imports allowed, `@Composable` functions exempt from function naming.
- Cloud sessions: the default container has JDK 21 but no Android SDK, and Maven Central answers HTTP 429 to its
  shared egress. This recipe made every command above work (2026-09-28): unzip `cmdline-tools` from dl.google.com
  into `/root/android-sdk/cmdline-tools/latest`, accept licences, `sdkmanager "platforms;android-37.0"
  "build-tools;37.0.0" "platform-tools"`, write `sdk.dir=/root/android-sdk` to `local.properties` (gitignored), and
  add a Gradle init script in `~/.gradle/init.d/` that rewrites `https://repo.maven.apache.org/maven2` to
  `https://maven-central.storage-download.googleapis.com/maven2/` in the plugin and dependency repositories.
  A cold compile of the JVM targets then takes about 6 minutes. The root guide's verification route (JetBrains MCP)
  and research route (Context7 MCP) are not available there. Say what was not verified instead of claiming it was.

## Module map

Gradle paths do not follow directories. `settings.gradle.kts` includes the submodule's projects under short names:

| Gradle path | Directory |
|---|---|
| `:common`, `:data`, `:domain` | `core/<name>` |
| `:kotlinYtmusicScraper`, `:lyricsService`, `:spotify`, `:aiService`, `:autoEqService`, `:kizzy`, `:ktorExt`, `:listenTogether`, `:loginSync`, `:nostr` and `:headsetControl` (this copy only) | `core/service/<name>` |
| `:media3`, `:media3-ui`, `:media-jvm`, `:media-jvm-ui` | `core/media/<name>` |

Type-safe accessors are on (`projects.data`, `projects.crashlyticsEmpty`). Entry points:

- Android: `androidApp` (`SimpMusicApplication`, `MainActivity`). It only hosts `composeApp`.
- Desktop: `desktopApp/.../Main.kt` calls `runDesktopApp()` in `composeApp/src/jvmMain/.../DesktopApp.kt`, which
  starts Koin.
- All shared UI and ViewModels are in `composeApp/src/commonMain`.

## Where the root guide is out of date

- **DI is Koin only; there is no Hilt.** Modules: `core/data/.../di/` (`DatabaseModule`, `RepositoryModule`,
  `MediaHandlerModule`, `ListenTogetherModule`, plus a per-platform `loader/`),
  `composeApp/.../di/ViewModelModule.kt`, `media3/.../di/Media3ServiceModule.kt` and
  `media-jvm/.../di/DesktopPlayerModule.kt`.
- **There are no use-case classes.** `core/domain` holds models, repository interfaces and the media-service handler
  contracts. ViewModels take repositories directly (for example `AlbumViewModel(songRepository, albumRepository, …)`).
- **Room is KMP.** The database is `core/data/src/commonMain/kotlin/com/maxrave/data/db/MusicDatabase.kt`, not
  `src/main/java`. It is currently version 27 (upstream's, merged 2026-10-04), schema changes go through `AutoMigration`s, and exported schemas are in
  `core/data/schemas`. A schema change is a `core/` change (see the submodule rule above).

## Changes in this copy

Upstream does not have these; keep them working across syncs.

- **Listen Together keeps your room seat and lets you listen on your own (2026-09-28).** Written against metroserver,
  before rooms went peer to peer (next entry); the seat, solo and sharing behaviour carry over. Protocol facts, read from
  MetrolistGroup/metroserver: the server keeps a disconnected member's seat for 15 minutes (`ReconnectGracePeriod`)
  and the same session token keeps working; it has **no chat or presence** — the only message a guest can send that
  reaches anyone else is `suggest_track`, and it reaches the host alone.
  - `ReconnectPolicy` (listenTogether): while holding a seat, retry every ≤10 s for 15 minutes instead of giving up
    after 5 attempts (~31 s). Without a seat the old 5-attempt budget stays. Unit-tested in `ReconnectPolicyTest`.
  - `ListenTogetherClient`: a silence watchdog (no frame for 45 s ⇒ the socket is dead; the server pongs every
    ping) so a vanished network is noticed instead of looking connected for minutes; `reconnect` refusals
    (`session_expired`, `session_not_found`, `room_not_found` while a reconnect is outstanding) emit `SeatLost`;
    `forgetSession()` on leaving so a stale token is never replayed.
  - `ListenTogetherSession`: handles `reconnected` (it was ignored) and `SeatLost`; `sync_state` now sets
    `lastActionServerTime = lastUpdate`, because its position is already live there — the old code added the gap
    since the last command a second time.
  - Listening on your own is app state (`ListenTogetherRoom.listeningSolo`, held in `ListenTogetherRepositoryImpl`),
    not protocol state. While set, the bridge neither follows nor publishes, and still answers the buffer barrier at
    once so it never holds the room up. A host going solo first hands host to the first other connected member.
    A guest who plays a song that is not the room's (not current, not queued) for 5 s goes solo automatically; the
    wait exists because endless queue can move a guest to its own radio track a moment before the host's
    change_track at the end of a song. Room play/pause/seek is not applied while the player is on a different track.
  - "Share what I play" (`lt_share_now_playing` in DataStore, read by the bridge directly): a solo guest's song is
    sent to the host as a suggestion after 8 s on it. Hosts see it with the other suggestions; other guests cannot.
  - `LocalServerResumeTest` drives real sessions through a restart, a restart that lost its state, and a SIGSTOP
    of a metroserver running locally, never the public one. Build it from MetrolistGroup/metroserver (with its
    `metroproto` submodule): `protoc` from `pip install grpcio-tools` (`python -m grpc_tools.protoc`),
    `go install google.golang.org/protobuf/cmd/protoc-gen-go@v1.36.11`, generate into `proto/` as
    `scripts/generate_proto.sh` does, `GOTOOLCHAIN=auto go build ./cmd/metroserver`, then run the test with
    `LT_SERVER_BINARY=<binary>`. The playback bridge (following, going solo, sharing) has no automated test: it
    needs a real player handler.
- **Listen Together room QR codes (2026-09-28).** The QR holds `simpmusic://listen-together?code=<ROOM>`
  (`ListenTogetherViewModel.inviteLink`), not the bare code, so a phone's own camera app opens SimpMusic on it too;
  App.kt routes that host (and Desktop's rewritten `https://simpmusic.org/app/listen-together?code=`) to
  `ListenTogetherDestination(joinCode)`, which is now a data class. Every member can show the QR (`RoomQrDialog`);
  scanning is Android only (`RoomQrScannerSheet`, reusing login sync's `QrScanner` and camera-permission flow).
  `joinByInvite` connects if needed and joins under the remembered name (`lt_display_name`); without a name it
  stops at a filled form, and inside another room it asks the user to leave first. Encoding is an expect/actual
  (`encodeQrCode`) because ZXing is declared only in androidMain and jvmMain. Tests:
  `composeApp` commonTest `ListenTogetherInviteTest` and jvmTest `QrEncoderTest` (encode, then decode with ZXing).

- **Radio pages ranked by this device's listening history (2026-09-28).** `RadioPersonalizer` (domain,
  `mediaservice/handler/`) re-orders what a radio plays next. It is applied in `SongRepositoryImpl` to the same three
  radio sources that the audio-only filter covers: `getRadioFromEndpoint` keeps its seed first, while
  `getRelatedData` and `getContinueTrack`'s radio branch do not. A playlist, an album or Shuffle is never touched.
  - YouTube's order stays the backbone. The score is `-position` plus bounded weights, all in queue places:
    - +3·ln(1+plays) for the most-played credited artist over 90 days (≈7 places at 10 plays, ≈14 at 100)
    - −8 for each time the song was cut short, counted at most 3 times
    - +5 if the song is liked
  - A spacing pass then avoids the same artist twice in a row, looking up to 4 places ahead.
  - Songs heard in the last 3 hours are dropped while at least 10 fresh ones remain; otherwise they go to the end.
  - "Cut short" has two sources:
    - `playback_event` rows under half their length (that table only records plays of 20% or more);
    - `SkipLog`: leaving a song after ≥1 s but before 20%, recorded by both handlers in
      `mayBeTrackingListeningLocal` and therefore only while local tracking is on.
  - `SkipLog` is a DataStore string (`radio_skip_log`, `videoId:count:epochDay;…`, 500 entries, 90 days), **not a
    Room table**: a schema version of this copy's own would collide with upstream's next version bump.
    Clear-history wipes it.
  - Setting: `personalize_radio`, on by default, in Settings next to the audio-only radio row. The three DAO
    queries are read-only (`getVideoIdsPlayedSince`, `getCutShortCountsSince`, `getLikedVideoIds`).
  - Tests: domain commonTest `RadioPersonalizerTest` and `SkipLogTest`.
  - Discovery slider (`radio_discovery`, 0 familiar … 1 new; 0.5 = the ranking above unchanged; default 1.0 since
    2026-09-29, see the radio mix entry), under the switch in Settings. `lean = (d − 0.5)·2`:
    - artist term `3·(1 − 2·lean)·ln(1+plays)`;
    - song term `−6·lean·ln(1+songPlays)`, from `getVideoPlayCountsSince`;
    - liked `5·(1 − lean)`;
    - from 0.8, known songs are held back like recently heard ones.
    It can only reorder and hold back what YouTube's radio returns; it never adds songs.

- **Friends and room invites over Nostr (2026-09-28).** Peer to peer, with no SimpMusic server or account. Each
  device holds a secp256k1 key, and a friend is someone whose key was added by QR code or link
  (`simpmusic://friend?npub=…&name=…`, which Desktop receives as `https://simpmusic.org/app/friend?…`). Messages go
  through three public relays (`relay.damus.io`, `nos.lol`, `relay.primal.net`), end-to-end encrypted. Rooms stay on
  the Listen Together server; only the invitation travels this way.
  - New module `:nostr` (`core/service/nostr`). It is registered in a separate block at the bottom of
    `settings.gradle.kts` so upstream's module lists never conflict. It targets android, jvm and an iOS stub.
    - The curve is BouncyCastle's lightweight API (`bcprov-jdk18on`, already shipped by PipePipeExtractor, so no
      size cost). It lives in a custom `jvmShared` hierarchy group shared by Android and Desktop. It is not
      secp256k1-kmp, whose JNI library extracts itself to a temp dir at runtime, which hardened-runtime macOS
      builds can refuse.
    - NIP-44's ChaCha20 is plain Kotlin; SHA-256/HMAC come from okio.
    - Tests (`:nostr:jvmTest`, 25):
      - every official BIP-340 and NIP-44 vector (the NIP-44 file's sha256 is asserted);
      - two real events signed by go-nostr;
      - `TestRelay`, a local NIP-01 relay that checks ids and signatures like public relays do;
      - two or three `FriendsSession`s talking through it.
    - The public relays are not reachable from cloud sessions (the egress proxy answers 503 to a WebSocket
      upgrade), so there is no live test.
  - Protocol (`FriendsSession`): kind 30078 addressable events, `d = simpmusic:<type>:<recipient>`, a `p` tag and
    a NIP-40 `expiration`, with NIP-44 content `{"v":1,"t":type,"name":…}`.
    - `friend` (7 days) means "you are on my list". From a stranger it is a request; from a friend it confirms
      them. Adding and accepting both send one, so one scan is enough.
    - `invite` (30 min, `room` = Listen Together code) is only shown from someone on our list.
    - Handled messages are remembered per type and sender, so a dismissed invite or declined request does not
      come back after a restart.
  - Storage is DataStore (`friends_identity`, `friends_list`, `friends_handled`), never Room, for the same
    schema-version reason as `SkipLog`. The display name is Listen Together's `lt_display_name`.
  - UI:
    - `FriendsScreen` (`FriendsDestination(roomCode, addCode)`), opened from a row on the Listen Together page.
      That row reads "Invite friends" inside a room, and each friend then gets an Invite pill.
    - `FriendsInbox` in App.kt shows invites (Join → `ListenTogetherDestination(joinCode)`) and requests over any
      screen. It uses the repository, not a ViewModel, because it sits above navigation.
    - `RoomQrScannerSheet` gained optional title and hint strings so it can read friend codes.
  - Not done: Android notifications for invites while the app is closed (the socket lives only as long as the
    process), and iOS.

- **Android: songs stuck at the end (2026-09-28).** Three causes, all in `CrossfadeExoPlayerAdapter` unless noted.
  - A failed preload was handed over. `triggerPrecachingInternal` now attaches a failure listener that evicts the
    entry, and `takePrecachedPlayer()` (used by `loadAndPlayTrackInternal` and `triggerCrossfadeTransition`) drops
    any player in STATE_IDLE or with a `playerError`. `play()` on such a player does nothing, and its error fired
    before the active listener existed, so the next song sat silent at 0:00.
  - A stream that never reports STATE_ENDED. `checkForStall()` runs in the position loop:
    - a position frozen within `END_STALL_WINDOW_MS` (3 s) of the end for `END_STALL_TIMEOUT_MS` (5 s) calls
      `onCurrentTrackEnded()`, the extracted STATE_ENDED body;
    - STATE_IDLE while PLAYING for 4 s reloads the track at its position, once per track.
    - Ordinary mid-song buffering is left alone.
  - A radio page that arrives after the queue ended. `addMediaItem` (append) continues into it within 10 minutes
    of the end, and `MediaServiceHandlerImpl` calls `loadMore()` on STATE_ENDED when the queue can still grow.
  - Not on a device; Desktop (`MpvPlayerAdapter`) unchanged.

- **Listen Together is peer to peer (2026-09-28).** There is no room server any more: the device that creates a
  room runs it, and everyone reaches it through the same public Nostr relays the friends feature uses. Rooms are no
  longer compatible with Metrolist clients. The session, bridge and UI above did not change: they talk to the new
  `RoomTransport` interface, which both `ListenTogetherClient` (metroserver, kept but unbound) and
  `peer/PeerRoomTransport` implement, and `ListenTogetherModule` binds the peer one.
  - `peer/RoomHub` is metroserver's room rules ported message for message (join/approve, playback with in-flight
    compensation, queue, suggestions, buffer barrier, kick/transfer, presence from pings, 15-minute seats). Pure
    and clock-injected; `RoomHubTest` drives it.
  - Wire: kind 21078 ephemeral events tagged `h` = a hash of the room code, NIP-44 encrypted with a key derived
    from the code (`SharedCodeSecret`). Each device has a fresh key per process, which is its user id. Frames are
    `{"v":1,"n":seq,"d":"u"|"d","to":[ids],"e":<MessageCodec envelope>}`: `u` goes to the hub (`to` = its id, empty
    for a join), `d` comes from it. `SequenceGate` restores each sender's order, waiting 400 ms on a gap.
  - The hub moves with the host role (`hub_moved` carries a gzipped `HubSnapshot`). The old hub decides the
    hand-over and numbers every frame before it first suspends, or a concurrent step overtakes it. The new host's
    own `host_changed` is held back until `hub_moved` has made it the hub; otherwise its session sends its first
    command to the old device, which drops it.
  - **Failover.** The hub sends a `state` beacon (gzipped snapshot) to members when the room changes, and at least
    every 60 s. If the hub is silent for 30 s, the first connected member in the snapshot's order takes over
    (`RoomHub.claim`, advancing the position by the silence); each next one waits 15 s more. Every take-over or
    hand-over raises `HubSnapshot.epoch`, and a claim wins by higher epoch, then smaller key, and only from a member.
    A host that comes back hears the new hub's beacon, steps down and asks for sync. Tests use short `Timing`.
  - `ListenTogetherSession` now sends through one ordered queue (`inOrder`). Each send used to be its own
    coroutine, so a track change and the play after it could arrive swapped; `capturedAtServerTime` is read when
    the command is issued, not when it goes out.
  - Tests: `peer/RoomHubTest` (10) and `peer/PeerRoomTest` (7, devices meeting through `LocalRelay` on localhost:
    join, follow, transfer, host leaves, suggestions, unknown code, host vanishes, host returns).
  - Settings: the server picker is replaced by a note on how rooms connect; the `lt_server_url` value is unread.
  - Not verified: public relays from a real device, rate limits on busy rooms, iOS.

- **Start radio keeps the song playing (2026-09-28).** `MediaPlayerHandler.startRadio()` (domain,
  `handler/StartRadio.kt`), used by the Now Playing sheet and both handlers' `toggleRadio`: when the seed is the song
  already playing, `MediaPlayerInterface.clearMediaItemsExceptCurrent()` drops every other queue item and the radio is
  loaded around it, instead of reloading the song from 0:00. Implemented in `CrossfadeExoPlayerAdapter` (refuses while
  crossfading or casting) and `MpvPlayerAdapter` (refuses while crossfading); a refusal falls back to the old reload.

- **Optimized build (2026-09-28).** `androidApp` has an `optimized` build type: `initWith(release)` (R8, shrinking),
  `applicationIdSuffix ".dev"` so it installs over the debug builds shipped before, signed with
  `.private-fork/test-signing.keystore` (the same key those debug builds used, so it updates in place). Sentry skips
  it. `SharedViewModel.checkOfficialBuild` accepts that key's certificate, or the anti-clone screen would block it.

- **Radio curation and "new songs" Start radio (2026-09-29).** `RadioCurator` (domain, `handler/RadioCurator.kt`,
  pure, `RadioCuratorTest`) sits between YouTube's radio pages and the queue, in `SongRepositoryImpl.curateRadio`,
  for all three radio sources. Measured anonymously on YouTube Music: a radio's continuation pages repeat most of what
  came before (49 rows each, of which 10, 11, then 4 were new), and one song arrives as several uploads with
  different videoIds.
  - `songKey()` = normalised title + first artist: strips bracketed upload words ("Official Video", "4K Remaster",
    "Live", "feat."…), a leading "Artist - " when it names the artist, and channel suffixes (VEVO, Official, Topic).
    Letters of any script are kept. Remixes and covers stay distinct.
  - `dropRepeats` removes what the queue holds (the handlers now pass `queued = listTracks` to `getContinueTrack` and
    `getRelatedData`) and repeats within a page; `capArtists` allows 2 per artist in any 8 places (moved down, not
    dropped); a page left with fewer than 15 useful songs is topped up from the radios of up to 2 new songs on it
    (`driftSeeds`, one request each, in parallel).
  - Start radio (`getRadioFromEndpoint(startRadio = true)` while the radio mix is New: the Now Playing sheet, the
    handlers' `toggleRadio`, and the playlist and artist Radio buttons) keeps only songs never started or liked (`DatabaseDao.getHeardSongs`: song rows
    with `totalPlayTime > 0 OR liked = 1`, which exists with local tracking off too), matched by id and by song key. It
    leans to new artists (`discovery ≥ 0.9`), wants 20 on the first page, and falls back to the least played known
    songs only when fewer than 10 new ones exist. The mode is carried in the queue's continuation string
    (`RadioContinuation`, `SMNEW:` prefix), so every later page is new songs too and the radio goes on from seeded
    radios when YouTube's chain ends. All of it reads history only while "Learn from my listening" is on.
- **Temporary request log (2026-10-16).** The Stats screen shows the app's last 200 HTTP requests — method,
  host/path, status, duration, and the failure when there was one — so what the app is asking, and where, can be
  read off the phone. It is **meant to be removed**, and it is four pieces: `RequestLog`/`LoggedRequest`
  (`core/common`), `RequestLogPlugin` + `logRequests()` (`ktorExt`), the `logRequests()` line inside the clients
  that report (Ytmusic, Monochrome, InternetArchive, Audius, SoundCloud, PodcastFeeds, RestrictedHttpFetch,
  SimpMusicLyrics) and the `RequestLogSection` in `StatsScreen`. Deleting those four leaves nothing behind. In
  memory only, bounded, nothing on disk and nothing sent anywhere; a request that never answers is listed with
  its error instead of a status. Not reported: Ytmusic's download client (its own comment says logging there
  costs performance, and those are stream fetches, not API calls), the platform cipher fetches (FaradayJsDecoder)
  and the services outside the music path (Nostr, Discord RPC, Spotify import, login sync, AutoEQ).
- **A download from another source is off, and what turning it back on needs (2026-10-16).** The first attempt
  let a download come from Monochrome/the archive/Audius (`downloadTrack(..., kind)`), and that is what a user hit
  next: "most of them have sound only at the start of a song". Those files are not YouTube's progressive stream —
  a streamer can answer with *less* than the file (Media3 treats EOF as a finished download, so a short copy
  *replaced* a good one, which is the real bug), and a FLAC's audio can begin after a large metadata block
  (`PlaybackStream.audioOffset`; irrelevant for a downloaded *file*, which is read from byte 0 and parsed, but it is
  why the clip and the copy must not be confused). So `supportsSourceDownloads` is false, the resolver's source
  branch is gone, the sources sheet shows only YouTube's download action and the Settings upgrade row is hidden
  behind that flag (2.4.31, code 101; the row and the actions come back with the flag). Turning it back on needs,
  in this order: (1) resolve the source's final URL and **require a known length** (a ranged request; skip the
  source when it will not say) and pin the download to it, so a short answer *fails* instead of completing;
  (2) keep the existing copy until the new one is complete and its byte count verified — never remove first;
  (3) only then re-enable, one song at a time and in bulk. The plan, so the next session does not have to
  rediscover it.
- **"Download songs you like" asks for the missing ones (2026-10-16).** The switch already sweeps on being turned
  on — `SettingsViewModel.getAutoDownloadLikedSongs`'s setter calls `songRepository.downloadAllLikedSongs()`, which
  queues every liked song whose `downloadState != STATE_DOWNLOADED` and returns the count for the toast — so what
  the user asked for is one stale flag away from working. The flag is the weak part: it lives in the song's row, and
  a copy that was removed or never finished (the short source downloads especially) can still read DOWNLOADED, and
  then the sweep skips it. The next change: decide "not downloaded" from the **device** rather than the row —
  `DownloadHandler.downloadedBytes(videoId) == null` (already used for the sizes) — for each liked song, and queue
  what is missing. Also worth doing while in there: run the sweep on every *check* of the switch, not only on the
  off→on transition, so toggling it on again is a catch-up, not a no-op.
- **An upgrade really downloads, and a plain download is quality-first (2026-10-17).** The plan above was not
  actually done: step (2) was read as "do not remove the old copy", and that hid the real behaviour — a download
  re-added for a song already on the device is served **entirely from the cache**. Media3's `CacheWriter` asks the
  cache key how long the resource is and skips every cached span, so with the old copy under the bare video id the
  source URL was never contacted, the copy stayed as it was, the record's URI said "from Monochrome" anyway, and the
  next start's repair measured the old bytes against the source's length, deleted the copy and fetched YouTube again.
  Monochrome was never the problem: `HEAD https://tracks.monochrome.st/track/<id>` answers `content-length:
  40647395` and `accept-ranges: bytes` (checked 2026-10-17), so the length rule accepts it.
  - A source copy is now fetched under the **staging key** `<videoId>#incoming` (`DOWNLOAD_STAGING_SUFFIX`), so the
    bare id — what playback, the size readouts and the record use — is untouched while it runs. `downloadTrack` puts
    the declared length on the request URI (`length=`), and `settleStagedDownload` measures the fetched bytes against
    it (≥98%, `WHOLE_COPY_PERCENT`) when the download finishes:
    - whole → `promoteStagedDownload`: remove the old spans, set the key's content length to the new total **before**
      committing (SimpleCache's `commitFile` refuses a span past the recorded length), copy each staged span over
      the bare id through `startReadWrite`/`startFile`/`commitFile`, clear the redirected URI, write the canonical
      record into `DefaultDownloadIndex`, drop the staging key. The completion notice goes out here.
    - short → the old copy stays and its record comes back (`replacedRecords`), or, with nothing on the device,
      `retakeFromYouTube` takes YouTube's whole stream. A failed staged download settles the same way, and
      `recoverStagedDownloads` retries whatever a kill left behind at startup; one still downloading is resumed by
      the manager.
  - `repairShortDownloads` now reads the **download index** instead of `DownloadManager.currentDownloads` — that list
    holds only active downloads, so the old pass skipped every finished copy and had never repaired anything (and an
    in-flight source download it *could* see was taken for short). It also clears a short copy with `removeResource`
    rather than `removeDownload` + add: a download merged into a removing one is restarted, and a restart keeps the
    old file. A promoted copy's record carries the size it was verified against (`length=` on the canonical
    request), so the pass trusts it and only asks the source about copies from earlier builds — otherwise every
    source copy would be re-probed on every launch.
  - **Quality-first default:** `downloadTrack(..., qualityFirst = true)` — every plain Download (song sheet, album,
    playlist, liked-songs sweep) asks the sources first (`awaitLossless`, 6 s; the search carries on afterwards, so a
    later download or play finds it, then the SoundCloud backup) and takes YouTube's stream when nothing better
    answers. Unmetered only: on a metered connection a plain download takes YouTube as before, since the mobile-data
    decision belongs to the Settings upgrade dialog. The sources sheet passes `qualityFirst = false` so a row the
    listener picked is honoured, and so does the repair. The switches (Hi-Fi, each source, the backup) still gate it.
  - **The completion notice says what arrived:** "Song · 24.6 MB · from Monochrome". The nested
    `TerminalStateNotificationHelper` gets the `Context` and file-level helpers (`downloadSourceLabel`,
    `downloadBytesText`) instead of reaching for the service as a receiver — the earlier attempt failed on exactly
    that. A staged download's own completed/failed events post nothing; the notice is posted from the settle, so it
    never announces a copy that then fails its check, and a retaken YouTube copy announces itself. The notice has
    its own channel (`MusicDownloadService.COMPLETE_CHANNEL_ID`, "Download complete") and that is its **only**
    switch: Android's app notification settings list it, and the app deliberately has no row for it — the user asked
    for the setting to live only there, so 2.4.41 removed the Settings switch and the DataStore key 2.4.40 had.
    A failed download's notice stays on the main "Download" channel.
  - **A copy must open like audio before it can be the song's:** `looksLikeAudio` reads the first 16 bytes of the
    staged file — `fLaC`, `OggS`, `ID3`, an MP3/ADTS frame, `ftyp` at 4, EBML — and a copy that does not is treated
    like a short one (old copy kept, or YouTube taken). The startup repair checks the same opening bytes of a settled
    copy (locally, no request) before it checks its size, so the "downloaded songs with no audio" of the first
    source-download attempt are all caught, whether they are short or are not audio at all.
  - Not verified on a device (no emulator here): the swap rests on media3 1.11.1's own guarantees, read from source
    (`CacheWriter` skipping cached spans, `mergeRequest` taking the new request's custom cache key, `SimpleCache`
    startFile/commitFile). Worth watching on the phone: a promote holds both copies for a moment (enough free space
    for two), the upgrade changes the Downloads list size only when it completes, and the completion notice should
    name a source only when that source's copy really is the one on the device.
- **Downloads: the notification says more, and Settings can upgrade them all (2026-10-16).** The download
  notification's line is now "Song · 45% · 12.4 MB · 1.2 MB/s · from Monochrome" — the percentage and the bytes
  come from the `Download` itself, the speed from the change since the last notification (smoothed, reset when
  the song changes; `bytesText` formats them, since media3 1.11 has no `Util.getStringForBytes`), and the source
  from the `?source=` parameter the request carries — so an upgrade is visible while it runs. The notification is
  still media3's `buildProgressNotification`, so a queue keeps its per-song lines. In Settings → storage, beside
  the downloaded cache, **Upgrade downloads** does for the whole library what the sources sheet does for one song:
  each downloaded song's sources are searched, the best `AVAILABLE` one that is not YouTube is taken, and
  `downloadTrack` refetches and replaces the copy; nothing is touched when no better source answered, and a
  metered connection gets a toast rather than the transfer. Progress is a `StateFlow<Pair<Int, Int>>` the row
  shows as "Upgrading 3 of 12…". (`SettingsViewModel` gained a `StreamRepository` constructor parameter and the
  Koin definition a matching `get()`.)
- **The notification's icon says whether the music is running (2026-10-16).** The media notification's small
  icon is the pixel wave while it plays and *the same wave at a third of its amplitude* while it is paused
  (`mono_paused.xml`: every column of the playing wave, tallest peak two cells instead of seven, on the same
  108 grid and ×0.303 transform). The first attempt flattened it to a line, which the user sent back — "show
  another wave not just a line": a line reads as no music, a quiet wave as paused. `SpeedMediaNotificationProvider.getMediaButtons`
  picks it — that runs inside the final `createNotification`, so the icon is never a state behind, and nothing
  re-posts in a loop. Carried into the App icon section's list below: a change to the mark has to update
  `mono_paused` too. Worth knowing for the next request of this kind: a notification icon cannot animate — Android
  draws it statically, and a live visualiser there would mean re-posting the whole notification every second,
  which flashes the shade, is throttled by the OS and costs battery. State is the honest signal; the app's own UI
  is where a sound-reactive visualiser belongs.
- **Downloads can be taken from a better source, and upgraded (2026-10-16).** The sources sheet's rows
  (Monochrome, Internet Archive, Audius, SoundCloud, YouTube) now carry a download action: the copy is
  fetched from *that* source, and a copy already on the device is removed first — so a downloaded song
  can be upgraded to Monochrome's FLAC, or to a 320 kbps Audius upload, without losing its place in the
  library. `DownloadHandler.downloadTrack(..., kind)` is the whole contract. The Android implementation
  rides the source on the request *URI* (`?source=KIND`) because the resolver is handed a DataSpec, not
  the DownloadRequest, and keeps the custom cache key the bare video id (playback looks the copy up by
  it, and `isFullyCached` answers on it), then resolves through `StreamRepository.streamFrom`, falling
  back to YouTube's stream when that source has nothing — an upgrade that cannot happen is a download at
  the usual quality, never an error. The switches that gate a source for playback gate this too (Hi-Fi
  sound and each source's own switch, so a row shows "needs Hi-Fi sound" rather than failing), and the
  transfer replaces the button in the row while it runs. The Desktop takes the parameter and downloads
  YouTube's file (`supportsSourceDownloads = false`), and the sheet hides the actions it cannot honour.
  What a copy takes up sits beside the downloaded badge in every track row — and as "Downloaded · 8.4 MB"
  in the song sheet — from `DownloadHandler.downloadedBytes`: the download cache's own spans on Android,
  the download folder's files on Desktop, so one still arriving reports what has really arrived.
  Not done: a bulk "upgrade all downloads", showing what quality a copy already is, and Desktop support.
- **App icon (2026-10-15).** A pixel sound wave, at the user's request ("a nice sound wave made of pixel … pixel art,
  modern and clean", then "more of a wave instead of an eye" — the first, mirror-symmetric profile read as a lens with
  a pupil, so the mirror is gone): twenty-two columns of 3 units, each column `(2m+1)` cells tall about the axis, in
  the profile `0,1,2,6,4,1,0,2,7,5,1,0,3,6,4,1,2,5,3,1,0,1` (m = 0..7) — a one-cell line the whole way with four
  bursts whose shoulders step in twos, the tallest just left of centre. A cell is 3 units, so the mark is 66 units
  wide (exactly the adaptive icon's safe zone's own width, centred at 21..87) and 45 tall (units 31.5..76.5), every
  column inside a circular mask. One flat colour behind (`#000000`), one flat colour for the mark (`#FFFFFF`). It is
  written as one `<path>` holding one rectangle per run of equal columns (adjacent cells share an edge, so there are
  no seams). The PNG, ICO and ICNS copies are the same geometry rasterised — a cell is 12 pixels at the 432-pixel
  renders, which is what makes the steps crisp. Where it is used, and at which size (a `<group>` transform on the
  same 108-grid paths, so there is one copy of the geometry — the 24 dp files have a 24-unit viewport, so their
  transform maps the mark's centre (54,54) to (12,12)):
  - launcher: `drawable/ic_launcher_together_{background,foreground,monochrome}.xml` (both `mipmap-anydpi-v26`
    files), mark at 1.0 — the foreground and the monochrome layer are the same shapes and colour;
  - notification small icon (status bar, media controls, downloads) and Android Auto's attribution icon:
    `androidApp/res/drawable/mono.xml` and `monochrome.xml`, 24 dp white, mark ×0.303, and
    `media3/res/drawable/mono_paused.xml` — the same mark quiet (every column at a third of its amplitude, its
    tallest peak two cells) shown in the media notification while playback is paused. The app's `mono.xml`
    overrides core media3's drawable of the same name at resource merge, so `SimpleMediaService` and
    `MusicDownloadService` pick it up with no core change;
  - Compose resources: `mono.xml` (the in-app logo, `#5B8CFF`, mark at 1.0), `monochrome.xml` (the badge on
    generated playlist and mood artwork, mark ×0.64), `app_icon.png` (Credits) and `circle_app_icon.png` (Desktop
    window, tray, mini player), both at the launcher's own 1.0;
  - Desktop packaging: `composeApp/icon/circle_app_icon.{png,ico,icns}`, the .ico and .icns holding PNG entries.
  (Before: the same grid with a mirror-symmetric peak-at-the-centre profile, which read as an eye, 2026-10-15;
  a pixel-art S on a 16 x 16 grid, which also read as a sound wave, published for one build, 2026-10-14;
  Monochrome's own 3 x 3 diagonal mark, white on black, cells of 22 units, 2026-10-14; a play triangle on a
  3 x 3 grid of our own, 2026-10-20; a 9 x 10 pixel play on a 16 x 16 grid, black and white, 2026-10-20; the same
  grid with a play-and-wave glyph on blue, 2026-10-20; a smooth play-and-wave glyph,
  flat, 2026-10-14; the same with a gradient, a glow and two soft shadows, 2026-10-14; a thinner, tighter wave on a
  darker violet, 2026-10-11; a play button sending out two sound waves, 2026-10-04; a seven-bar sound wave,
  2026-09-29; upstream's note.)
- **Listen Together repairs lost messages (2026-09-29).** Nothing is re-sent; a guest notices what it missed:
  - every hub frame carries `"r"` = the room's revision; a guest whose session is behind for 1.5 s, whose
    `SequenceGate` gave up on a hole in the hub's frames, or whose connection just came back sends `request_sync`
    (at most one per 2 s);
  - on the hub's state beacon a guest compares the member list and host with what its session was told, and
    delivers the missing `user_joined` / `user_left` / `user_(dis|re)connected` / `host_changed` itself;
  - the room's own `RelayPool` gives up on a silent socket after 35 s (keepalive at 15 s) instead of 100 s.
  - `LocalRelay.drop` loses chosen events; `PeerRoomTest` loses every playback frame and a `user_joined` and checks
    the room still converges.
- **Playback recovers instead of stopping (2026-09-29).** Every player error used to end in a toast and a pause, and
  `play()` in the ERROR state did nothing, so the music stayed stopped until another song was picked.
  - Android (`CrossfadeExoPlayerAdapter` + `PlaybackRecovery`): a connection error (2001, 2002, 1003), or any error
    while offline, shows buffering and waits for the network (2, 4, 8, 16 s, then every 30 s, fresh URL from the 3rd
    try), then resumes the same song at the same position; up to 10 minutes, or until the user pauses or picks
    something else. Online and still failing after 5 attempts counts as the song's problem.
  - A song that fails with a fresh URL twice is skipped, not paused on (`PlayerConstants.ERROR_CODE_SKIPPED_UNPLAYABLE`
    → `ToastType.SkippedUnplayable`), at most 3 in a row. `play()` on a failed player reloads the song where it stopped.
  - Desktop (`MpvPlayerAdapter`): the same play-after-error and skipping, and its retry now resumes at the position
    instead of 0:00. It has no wait-for-network.
  - Not on a device. `isOnline()` uses plain null checks: release lint crashes on `?: return` locals in that file.
- **Radio mix: Familiar · Mix · New (2026-09-29).** `RadioMix` (domain, `handler/RadioMix.kt`, `RadioMixTest`) names
  three stops of the discovery slider (0, 0.5, 1), and `RadioMix.of` reads any slider value back as the nearest one
  (≥ 0.8 New, ≤ 0.2 Familiar). `RadioMixBar` (composeApp `ui/component/RadioMixBar.kt`) writes the same
  `radio_discovery` value, so every place it appears and Settings always agree:
  - last in the song ⋯ sheet, under Share;
  - at the bottom of both queues, pinned under the list (the Classic/M3E sheet: the list takes `weight(1f)`; the
    Apple Music queue: above its bottom controls, in its artwork colours), with `whilePlaying = true`: shown only while
    `RadioQueueTrim.appliesTo` says the queue is a real YouTube radio, and letting go of the slider calls
    `toggleRadio()`, which rebuilds the radio around the playing song without restarting it.
  - It is a slider (`RadioMixSlider`, also used by Settings' `DiscoverySlider`): Material's `Slider` with custom
    `track`/`thumb` slots, so drag, tap, keys and accessibility come from Material. A 36 dp rounded track filled with a
    tertiary→primary gradient up to a 4×48 dp handle with a 5 dp gap each side, History and AutoAwesome icons at the
    ends, a midpoint dot, and a `SegmentFrequentTick` haptic per step. 10 steps; commits are snapped to tenths
    (`snapRadioMix`), so 0.8 is the same float `RadioMix.startsWithNewOnly` compares against. `RadioMixHeader` names
    the position (`radioMixLabel`: Familiar ≤0.2, Mostly familiar 0.3, Mix 0.4–0.6, Mostly new 0.7, New ≥0.8).
  - Uses the value-based `Slider(thumb, track)` overload, the one Now Playing already depends on — see the
    `material3-expressive` pin note in `libs.versions.toml` before bumping Material 3.
  - The default is New (`RadioMix.DEFAULT_DISCOVERY = 1f`), so an untouched install still gets new songs from Start
    radio. `getRadioFromEndpoint(startRadio = true)` uses new-songs mode only while the mix is New; on Mix or
    Familiar, Start radio is an ordinary personalised radio.
- **Listen Together: direct links on the same network (2026-09-29).** A room no longer needs a relay when its
  devices share a network. `peer/DirectLinks` (commonMain interface; `SocketDirectLinks` in a `jvmShared` source set
  shared by Android and Desktop, declared with `applyDefaultHierarchyTemplate` in `listenTogether/build.gradle.kts`;
  iOS gets `NoDirectLinks`) carries the same signed, encrypted Nostr events as the relays, over plain TCP: `SMLT/1\n`
  greeting, then frames of a 4-byte length plus the event JSON, an empty frame as a heartbeat every 4 s, and a link
  silent for 12 s is dead.
  - The hub listens on a random port while it is the hub (`serve()`), and its addresses (`lanAddresses()`: up,
    non-loopback, non-link-local IPv4, container bridges and mobile-data interfaces left out, Wi-Fi/Ethernet first) ride
    on its `state` beacon and on the join acknowledgement it sends a joiner (`"l"`). Guests dial them and redial with
    1/2/4/8 s back-off; a hand-over or failover moves the listener to the new hub and re-points every guest.
  - `PeerRoomTransport.publish` sends each event both ways; the receiver drops the copy it already saw (last 4000
    event ids). Either path alone keeps the room going, so a relay outage on a shared Wi-Fi is not noticed at all.
    The room reports itself connected when a relay OR a direct link is up.
  - The room QR carries the host's addresses: `simpmusic://listen-together?code=X&lan=ip:port,ip:port`
    (`ListenTogetherViewModel.inviteLink`/`parseDirectHints`, at most 8, strict `a.b.c.d:port`). A guest that scans it
    dials before joining (`RoomTransport.hintDirect`) and waits up to 2 s for the link, so a room with no reachable
    relay can still be joined by scanning. A typed code has no hints and learns the addresses from the first frame.
  - `joinRoom` now always returns true: the answer (joined or "no such room") comes back as an event, and returning
    false when no relay was up turned a direct-only join into "Not connected".
  - `ListenTogetherSession` collects transport events with `CoroutineStart.UNDISPATCHED`: a transport that connects
    instantly (a direct link, or a local relay in tests) emitted `Connected` before the session was listening.
  - The room screen's connection line now says how it is reached (`routeText`: "Connected directly to the host", "N
    phones connected directly", "Relays 2 of 3", or no relay but direct still possible), replacing a placeholder.
  - Tests: `PeerRoomTest` (12: the 9 relay-only ones plus a room with no relay at all, a room that loses its relays
    mid-song, and duplicate delivery). Not verified on devices: Android's LAN behaviour, networks with client isolation
    (guest Wi-Fi), iOS.
- **Listen Together finds peers on the same network by itself (2026-09-29).** No QR code or relay needed on one Wi-Fi.
  `peer/LanDiscovery` (commonMain interface + `LanBeacon` wire format; `SocketLanDiscovery` in `jvmSharedMain`; iOS
  `NoLanDiscovery`) sends a UDP broadcast every 2 s to port 45797, to each interface's broadcast address and
  255.255.255.255: `{"m":"SMLT-D/1","t":<room tag>,"l":[hub endpoints],"h":host,"c":code?,"n":listeners}`. A room
  unheard for 7 s is forgotten.
  - The hub announces while it runs a room and serves direct links (`PeerRoomTransport.announceRoom`, on every tick
    and on any change). The tag is `SharedCodeSecret.tag`, so a guest who typed the code recognises its room without
    the code being broadcast. The code rides along only while the host allows "Show my rooms on this Wi-Fi"
    (`lt_visible_nearby`, on by default, in Listen Together settings; `RoomTransport.setVisibleNearby`).
  - A guest dials the hub as soon as it is heard (`onNearby`), also before joining, so a typed code joins with no relay.
    The hub's address lists from its frames (`frameEndpoints`) and from the network (`lanEndpoints`, which adds the
    address the beacon came from) are merged, and `SocketDirectLinks.dial` keeps an up link whose endpoint is still in
    the new list, so the two sources cannot make it hang up and redial.
  - After the host's phone vanishes, the member who takes over starts announcing and the others dial it, so a room
    with no relay survives failover on one Wi-Fi.
  - "Nearby on this Wi-Fi" on the Listen Together lobby lists rooms that carry a code; Join calls `joinByInvite`, and
    the host still approves. `RoomTransport.nearby` → `ListenTogetherRepository.nearbyRooms` (`NearbyListenRoom`).
  - Android: the Wi-Fi driver drops broadcasts without a `WifiManager.MulticastLock`, held only while listening or
    announcing, via `LanDiscoveryPlatform.holdBroadcastReceive`, set by `loadListenTogetherPlatform()` in core's
    `Loader.android.kt`; `CHANGE_WIFI_MULTICAST_STATE` is in the manifest (normal permission).
  - Trap: inside `DatagramSocket(null).apply { … }`, a bare `port` is the socket's own port (-1), not the class
    property. The first version bound nothing, and the loopback test is what caught it.
  - Tests: `LanDiscoveryTest` (beacon encoding, and one real UDP round trip on loopback) and three `PeerRoomTest`s on
    an in-memory `LocalLan`: typed code joins with no relay, nearby list and hiding it, and failover with no relay.
    Not verified on real phones or networks that block broadcast; iOS has none.
- **Radios lift the best songs (2026-09-29).** `RadioQuality` (domain, `handler/RadioQuality.kt`, `RadioQualityTest`
  on a real Queen radio page) ranks by what YouTube says about each song. A video row's byline reads
  "artist • 536M views • 3M likes" (a song row's reads "artist • album • year"), so `NextPage.fromPlaylistPanelVideoRenderer`
  now parses those into `SongItem.viewCount`/`likeCount` (`NextPage.parseCount`, English plus common localised
  suffixes; a bare number is a year and is ignored; `CountParseTest`). `Track.viewCount`/`likeCount` carry them,
  falling back to the music video's counts for a song (`counterpart`, logged-in only), and the audio-only swap keeps
  them.
  - `boosts()`: percentile of log views ±18 places, likes-per-view ±4, rows under 100K views another 10 back, and +5
    per other seeded radio that picked the song (at most 2; `curateRadio` counts `appearances` by `songKey`, without
    each seed radio's own first row). Added to `RadioPersonalizer.rank` as `boost`, so it also works with history off.
  - `hits()` = the most played quarter of the page (≥1M views); `weave()` pulls the next hit forward after
    `HIT_EVERY` = 4 songs without one. It runs last and keeps the artist cap at every place (`RadioCurator.fitsArtistCap`):
    run before the cap, an artist with many hits undid it. With new songs only, a known hit is never pulled forward.
  - `capArtists` now places each song at the first spot where its artist fits, in ranked order. It used to defer
    every extra song of a crowded artist to the end of the page, so Queen's biggest hits landed last on a Queen radio.
  - Rows with no numbers stay neutral, so an audio-only page with no music videos keeps YouTube's order.
- **Upcoming songs are looked up ahead of time (2026-09-29).** Both players already keep the next
  `StreamWarmer.PRELOADED` songs fully loaded (2, now 3 — see the caching entry below) (standby ExoPlayers on Android, paused mpv handles on Desktop). After
  those, `StreamWarmer` (domain) looks up the stream addresses of the next `AHEAD` songs (5, now 10), from `warmStreamsAhead()`
  at the end of each precache job in `CrossfadeExoPlayerAdapter` and `MpvPlayerAdapter`. It calls
  `StreamRepository.getStream`, which saves a `NewFormatEntity`; both players check that first, so a skip past the
  preloaded songs or a tap further down the queue skips the address lookup and signature solving. Songs whose saved
  address is good for 30 more minutes are left alone. Videos (watch-video on) get their video stream too.
  - Android: a preload that fails is retried after 5 s, up to 3 failures per song (`precacheFailures`), instead of
    waiting for the next track change.
  - Not verified on a device: how much faster skipping feels depends on the network and on YouTube's response times.
- **Moving a song in a shuffled queue moves only that song (2026-10-03, replaced by upstream 2026-10-04).** Fixed here
  first with a play-order branch inside `moveMediaItem`; upstream then shipped the same fix as
  `MediaPlayerInterface.moveShuffledItem` (both handlers' `swap`/`moveQueueItem` call it while shuffle is on). The
  merge took upstream's version on both players and dropped this copy's `QueueMoves`, so `moveMediaItem` is
  upstream's again (playlist positions, shuffle rebuilt).
- **No tracking (2026-10-03).** `isFullBuild=false` in `gradle.properties`: no Sentry (Android `crashlytics-empty`),
  no Google Play Services Cast SDK (`cast-empty`) and no Last.fm. Desktop's Sentry was not behind that flag, so it was
  removed by hand: the `Sentry.init` block, `machineId()`, the crash dialog's capture and `pushPlayerError`'s report
  in `DesktopApp.kt`/`CrashDialog.kt`, and `sentry-jvm` from `composeApp` and `desktopApp`. The BuildKonfig
  `sentryDsn` field is still generated but read by nothing. Left as they were because they are opt-in and off by
  default: "Send back listening data to Google" (`sendBackToGoogle`) and "Help build the lyrics database"
  (`helpBuildLyricsDatabase`). `SharedViewModel.checkOfficialBuild` makes no network call for this copy's key.
- **SoundCloud backup source (2026-10-03).** When YouTube gives no playable audio for a song (every extraction tier
  failed, or no audio format), the same recording plays from SoundCloud. Setting `soundcloud_backup`, on by default,
  under Content next to the quality rows.
  - `kotlinYtmusicScraper/.../soundcloud/`: `SoundCloud` (client, `YouTube.soundCloud`, shares the proxy) uses
    SoundCloud's public web API — `client_id` scraped from the `a-v2.sndcdn.com/assets/*.js` scripts soundcloud.com
    links (cached 6 h, refetched once on 401/403), `api-v2.soundcloud.com/search/tracks`, then the progressive
    transcoding's url `?track_authorization=` → a signed `cf-media.sndcdn.com/….128.mp3` (CloudFront, range requests
    work, extra query parameters are tolerated). Its life is read from the `Policy` parameter (base64 JSON with
    CloudFront's `-_~` substitutions); it was about 8 minutes when measured.
  - `SoundCloudMatcher` (pure, `SoundCloudMatcherTest`; `SoundCloudLiveTest` runs only with `SOUNDCLOUD_LIVE=1`)
    takes a candidate only when it streams in full (`policy != SNIP`, a non-snipped progressive `audio/mpeg`), is
    within 5 s of the song's length, carries no other-version word ("remix", "live", "sped"…) the song's title lacks,
    has the song's title once upload decorations and an "Artist - " side are removed, and names the artist in
    `publisher_metadata.artist`, the uploader or the title — as the whole name or its start, never merely
    contained: the first live run matched Queen to "Killer Queen Band Page", a tribute band, at the right length. Label releases on SoundCloud are mostly 30-second
    `SNIP` previews, so those songs simply have no backup; full-length matches are user re-uploads.
  - `StreamRepositoryImpl.getStream` is now a wrapper: upstream's body is `youTubeStream` unchanged (one
    `bestAudio` fallback added), and the backup runs only for playback (`!isDownloading && !isVideo && !muxed`). The
    title, artists and length come from the song's `SongEntity` (waited for up to 2 s, since the handlers save a song
    as it starts). The row is a normal `NewFormatEntity` with `itag = SOUNDCLOUD_BACKUP_ITAG` (0) and an expiry 30 s
    before the url's; within 15 minutes of YouTube's failure an expired backup is renewed straight from SoundCloud
    instead of asking YouTube again. `ExtractSource` shows "SoundCloud · backup (<uploader>)" in the info sheet.
  - Android: `Mp3Extractor` added (last) to the extractor list, which had no MP3 extractor at all; backup audio is
    cached under `soundcloud:<videoId>` (`DataSpec.keyedForSource`) so MP3 bytes never share a cache entry with
    YouTube's WebM/MP4 for the same song; `DownloadUtils` ignores a cached backup row. Desktop: mpv plays the url as is.
  - Not used, on purpose: Monochrome and Octave (lossless) stream TIDAL/Qobuz through shared paid accounts; ArtistGrid
    and unmusic host leaked unreleased songs; public Piped instances were all failing (`SignInConfirmNotBot`) and the
    one Invidious instance with its API on hides audio behind a bot challenge; soundcloak's docs ask not to be scraped.
  - Not verified on a device. The live test (search, match, resolve, a 206 range read, renew) passed from a cloud
    container on 2026-10-03, matching "Queen - Bohemian Rhapsody" (352 s, a re-upload) with a url valid for 473 s.
- **Hi-Fi sound (2026-10-03).** Setting `hifi_sound`, off by default, first row under Playback. While on:
  `StreamRepositoryImpl.bestAudio` takes the highest-bitrate audio YouTube returned (Opus over AAC at equal rate:
  774/141 at 256 kbps with Premium, 251 at about 160 kbps without), for playback and downloads, whatever the quality
  settings say; both handlers send a flat equalizer and `AudioEffects.NONE`, and Android's `mayBeNormalizeVolume`
  treats normalisation as off. The EQ, delay, reverb and normalise rows grey out with "Bypassed while Hi-Fi sound is
  on"; their stored values are kept. Nothing lossless exists on YouTube or SoundCloud. Separately, the ordinary
  quality path now falls back to `bestAudio` when neither the chosen itag nor its twin is there (a non-Premium
  account on "High"), instead of taking the last format with a url, which could be a video stream with no sound.
- **YouTube rate limits switch to the backup without a pause (2026-10-04).** `YouTubeHealth` (domain,
  `handler/YouTubeHealth.kt`, pure, clock-injected, `YouTubeHealthTest`) is a breaker held by `StreamRepositoryImpl`.
  - Opens at once on a rate limit: HTTP 429/403 from the player request (ktor `ResponseException`), or a playability
    reason with "not a bot" / "unusual traffic" / "too many requests". `YouTube.player` now throws
    `YouTubePlayabilityException(status, reason)` for a non-OK playability status instead of letting `newPipePlayer`
    return null into "No URL found"; `youTubeFailureOf()` (scraper, `extractor/YouTubeFailure.kt`) classifies.
    Cool-down 5 min, doubling per trip without a success in between, capped at 60 min; signals during one outage
    do not stack. "Sign in to confirm your age" is a song problem, not a rate limit — the first draft matched
    "confirm you" and would have read it as one.
  - Also opens when 3 different songs fail to extract inside 3 minutes; an unavailable/private song never counts.
  - While open, `getStream` goes to the SoundCloud backup first and only asks YouTube when the backup has no match;
    any YouTube success closes it.
  - `StreamRepository.reportStreamRejected(videoId)` (default no-op): both adapters call it on their source-error
    retry, right before `invalidateFormat`. If the refused stream was an unexpired YouTube one, that song prefers the
    backup for 10 minutes and it counts as a strike — asking YouTube again usually hands out another URL that the
    CDN refuses the same way. The retry already reloads at the saved position, so the song carries on from the
    backup where it stopped, with no toast. Not wired to the network-recovery path: an outage is not YouTube's fault.
  - Not done, on purpose: Monochrome-style "HiFi API" instances for lossless. They stream TIDAL/Qobuz through shared
    paid accounts. Lossless would need the user's own TIDAL or Qobuz subscription.
  - Not verified against a real rate limit or on a device.
- **The player shows which source is playing (2026-10-04).** A pill in the time row under the seek bar: "YouTube ·
  OPUS 160 kbps", "SoundCloud · MP3 128 kbps" or "Downloaded · OPUS" (`playbackSourceLabel` +
  `PlaybackSourcePill`, `ui/screen/player/content/PlaybackSourcePill.kt`; `NowPlayingContentState.playbackSourceLabel`).
  Classic and M3 Expressive show it where "Crossfading" appears, and hide it while crossfading; the Apple Music
  style's existing codec badge now carries the label. It is read off the song's format row, which the stream lookup
  rewrites when the source changes, so it follows a mid-song switch to the backup. "Downloaded" comes from
  `songEntity.downloadState`. The kbps is YouTube's nominal `bitrate`, not a measurement.
- **More songs cached ahead (2026-10-04).** `StreamWarmer.PRELOADED` 2 → 3 (fully prepared players on Android, paused
  mpv handles on Desktop) and `AHEAD` 5 → 10 (stream lookups). Android also caches the opening `UpcomingPrefetch.BYTES`
  (1.5 MiB, about 75 s at 160 kbps) of the `SONGS` = 5 songs after the preloaded ones (`media3/exoplayer/
  UpcomingPrefetch.kt`, from `prefetchAhead()` at the end of the precache job, so a queue change cancels it). It reads
  through its own copy of the player's resolving data source (a Koin single built with the same caches, proxy and
  resolver), so the URL, the SoundCloud backup and the cache key are the ones playback uses — reading is what fills
  `playerCache`. Songs already holding that many cached bytes and songs that will play as video are skipped. Data
  cost: up to ~7.5 MiB ahead of the preloaded songs, on any network.
- **Remaining tracking removed (2026-10-04).** On top of "No tracking":
  - "Send back listening data to Google" (`sendBackToGoogle`: `initPlayback`/`updateWatchTime` to YouTube's
    playback-tracking URLs) and "Help build the lyrics database" (uploads lyrics tagged with the song, plus contributor
    name/email) are gone from Settings, and `DataStoreManagerImpl` reports both as `FALSE` whatever an older install
    stored, so the existing gates in the handlers and `SharedViewModel` never open.
  - `YouTube.getSongInfo` no longer calls Return YouTube Dislike: it ran on every song change and sent each video id to
    returnyoutubedislikeapi.com. `viewCount`/`like`/`dislike` are now null.
  - SponsorBlock (off by default) uses the hash-prefix API: `/api/skipSegments/<first 4 hex of SHA-256(videoId)>`
    (okio) answers every video under that prefix, `HashedSkipSegments` picks ours. Checked live: a list of
    `{videoID, segments}`.
  - The per-song TIDAL metadata search (title + artist → BPM/key for AutoMix) runs only while crossfade and DJ mode
    are both on.
  - Still contacted, because they are the features themselves: the selected lyrics provider (SimpMusic lyrics by video
    id, LRCLIB/BetterLyrics by title), YouTube, SoundCloud when it backs a song up, GitHub/F-Droid for the update
    check, chart.simpmusic.org for charts, and Discord/Spotify/AI services only after the user signs in or adds a key.
- **Upstream merge (2026-10-04).** maxrave-dev/core gained 6 commits (live broadcasts over HLS with
  `LiveStreamRegistry`, per-app audio output selection, an AI "taste reading" from local history, Apple Music animated
  artist artwork, `moveShuffledItem`); upstream SimpMusic had none, so those features are in core but have no app UI
  until upstream adds it. Conflicts resolved: the handlers' `swap` and `moveMediaItem` are upstream's;
  `loadAndPlayTrackInternal` keeps this copy's `takePrecachedPlayer()` (it drops errored AND idle precaches, a
  superset of upstream's new error check); the precache loop takes both this copy's failure limit and upstream's
  "never precache a live broadcast"; `YouTube.player` runs upstream's live check before this copy's
  `YouTubePlayabilityException` (a live response is answered before anything needs an OK status);
  `UpcomingPrefetch` skips live broadcasts too.
- **Lossless from the Internet Archive (2026-10-04).** While Hi-Fi sound is on, `StreamRepositoryImpl.getStream`
  first asks archive.org for a FLAC file of the same recording (`archiveLossless`, playback only, before the YouTube
  and SoundCloud paths); no account or key. The user has a TIDAL subscription, but signing in needs TIDAL's app client
  credentials, and the session's auto-mode classifier refused decoding them from python-tidal twice ("Third-Party
  Attack", "Credential Exploration"); Monochrome-style public "HiFi API" instances (shared paid accounts) and torrents
  were declined.
  - `kotlinYtmusicScraper/.../archive/`: `InternetArchive` (`YouTube.internetArchive`, shares the proxy) runs
    `advancedsearch.php` twice — `title:("T") AND creator:("A") AND format:(Flac)`, then `creator:("A") AND
    format:(Flac) AND ("T")` for albums naming the song — reads up to 6 items' `/metadata/<id>` in parallel, and hands
    every FLAC file to the matcher. `ArchiveCandidates` (pure) reads archive.org's loose JSON: `creator`/`collection`
    are a string or a list, `length` is seconds or a clock, most files have no title of their own (a single-file item
    takes the item's title, otherwise the file name minus its track number), items in the `stems` collection are
    skipped, and the item title rides along as `context` so a clean file title inside "Live at Wembley" or "Boombox
    Demo" is still refused.
  - Matching moved to `matching/RecordingMatcher.kt` (`RecordingCandidate`), shared with `SoundCloudMatcher`, which
    now only adds SoundCloud's full-stream gate. Version words gained multitrack(s), stem(s), acapella, isolated,
    recreation, boombox.
  - The stream is `https://archive.org/download/<id>/<path>` (percent-encoded per segment; 302 to a data node, which
    answers range requests with `audio/flac`). The row is `itag = ARCHIVE_LOSSLESS_ITAG` (1), trusted for 6 h (the
    address itself does not expire). A miss, or a file the player refuses (`reportStreamRejected`), is not searched
    again for 6 h; the whole lookup gives up after 6 s so a slow archive.org cannot hold a song's start. Android caches it under
    `archive:<videoId>` (`otherSourceCacheKey`), downloads ignore it, and the source pill reads "Internet Archive ·
    FLAC <kbps>".
  - Coverage measured on ten well-known songs: items for Queen, the Beatles, Michael Jackson and Nirvana; none for
    Taylor Swift, Pink Floyd, Eagles or Miles Davis. Uploads are mostly users', some 24-bit/176.4 kHz (220 MB a song).
  - Tests: `ArchiveCandidatesTest` (real answer shapes); `InternetArchiveLiveTest` runs only with `ARCHIVE_LIVE=1`.
    Not verified on a device.
- **Streams keep their source; songs start at once; seamless upgrade to lossless (2026-10-10).** Three fixes to the
  Internet Archive feature above, plus a sources sheet.
  - **The "no sound" bug.** The player reads a song in 5 MiB chunks, and every chunk ran the resolver again, which
    read the song's single format row. When that row changed under a playing song, the next chunk came from another
    file. The 6 s archive timeout, a failed HEAD check or a lookup for the same song could each swap the row, so
    YouTube's WebM bytes landed in the middle of a FLAC stream, which the extractor cannot decode.
    - `PinnedResolvingDataSource` (media3, one per media period) remembers what its stream was resolved to
      (`StreamPin.Local`/`Remote(PlaybackStream)`), and later chunks only renew that same file.
    - `StreamResolver` holds the old resolver body. Past the first chunk a googlevideo `range=` parameter is
      dropped, because upstream never sent it there.
    - Cache keys now name the file: `archive:<id>:<fnv64(fileKey)>` and `soundcloud:<id>:…`
      (`otherSourceCacheKey(stream, mediaId)`).
  - **Archive matches no longer share the song's row.** They live in their own `NewFormatEntity` keyed
    `archive:<videoId>` (hit trusted 30 days, miss 6 h); `cpn` holds bits;channels;item. A legacy main-key archive row
    from the last build is ignored. `InternetArchive.findLossless` checks before accepting:
    - it reads the first 64 KiB of each candidate (`FlacHeader`: STREAMINFO after an optional ID3 tag);
    - it refuses non-FLAC, more than 2 channels, rates above 96 kHz (Android plays 16-bit/48 kHz anyway; 176.4 kHz
      streams at ~4.6 Mbps) and a real length more than 5 s off;
    - it skips `is_dark` / `access-restricted-item` items, `private` files and `.ffp` fingerprints;
    - it prefers CD quality over 24-bit/high-rate (`isHighResolution`), and works through `RecordingMatcher.ranked`.
  - **Instant start.** `getStream` never waits for archive.org any more.
    - A lossless file already found (`knownLossless`) starts at once; otherwise the search runs in the background
      (`searchLossless`, two at a time, 25 s budget).
    - `StreamWarmer` and the precache start searches for queued songs. Each precache waits up to 12 s for its song's
      search, so queued songs start on FLAC.
    - Handlers push queued tracks as `SongRef`s (`rememberSongs`), because the library only holds a song once it
      has started.
  - **What is playing.** The resolver publishes each new stream's `PlaybackSource` (`publishPlayingSource`), unless
    the media item URI marks it `sm_trial`/`sm_prefetch` (`StreamRequest`; `sm_source=<KIND>` asks for one source).
    The badge reads it, falling back to the format row. A music video's audio half always asks for YouTube.
  - **Seamless upgrade (Android, Hi-Fi on).** Once a song's lossless file is found mid-song, `scheduleUpgrade` →
    `SeamlessSourceSwitch` does the switch:
    - a second, muted player opens the FLAC 2 s behind;
    - both sinks are tapped (`TappingAudioSink` → `AnalysisTap`: mono, Blackman-sinc low-pass, about 8 kHz, every
      sample stamped in sink presentation time, plus the sink's own position readings);
    - `StreamAligner` (GCC-PHAT-0.8, 150–3500 Hz, three 3 s windows) must find one offset: strength ≥ 25,
      distinctness ≥ 2.5, spread ≤ 1 ms;
    - the muted player is seeked and nudged with Sonic speed (±5%) until both sinks are within 1.5 ms;
    - levels are matched (the quieter copy decides; ramps over seconds);
    - an 80 ms linear crossfade hands over.
    Anything else gives up and the song stays as it was; the next play starts on FLAC.
    - Measured on real audio: one master as FLAC and as its MP3 derivative lines up within 1 µs, strength 67–127.
      Two CD transfers of a 1975 recording drift 5.8 ms/s (0.58% speed) and are refused. So classic recordings often
      upgrade only on their next play.
    - After a switch the adapter reports positions on the song's original timeline (`currentTimelineOffsetMs`,
      `DelegatingForwardingPlayer.timelineOffsetMs`), so the seek bar, the session and synced lyrics do not jump.
      Reloads of the same song (`SongReload.SAME_SOURCE`: network recovery, stall, play-after-error) keep source and
      offset; a refused stream (`AFTER_REFUSAL`) reloads afresh.
    - Not with Hi-Fi off: volume normalisation lives on the old player's audio session.
  - **Sources sheet.** Tapping the source badge opens `PlaybackSourcesSheet`. It lists Internet Archive / YouTube /
    SoundCloud (and Downloaded) with quality and state from `StreamRepository.sourceOptions`, which starts the
    allowed searches. Tapping a row calls `MediaPlayerInterface.switchSource(kind)`:
    - Android tries the seamless switch, and reloads at the position when that is not possible;
    - Desktop always reloads at the position (mpv gives no PCM to align).
  - Tests: `StreamAlignerTest` (synthetic, and real recordings with `ALIGN_AUDIO_DIR` of raw mono f32 44.1 kHz files),
    `StreamRequestTest`, `FlacHeaderTest`, `OtherSourceCacheKeyTest`, new `ArchiveCandidatesTest` cases;
    `InternetArchiveLiveTest` (`ARCHIVE_LIVE=1`) now asserts the header was read.
  - Not verified on a device: the seamless switch itself (dual ExoPlayers, sink position accuracy, the 80 ms fade)
    has only been reasoned about and unit-tested in its parts.
- **Headphone noise control: Sennheiser MOMENTUM 4 (2026-10-10, Android).** (Huawei earbuds were added the same
  day; see the next entry for what changed in the shared model.) The player shows the connected
  MOMENTUM 4's noise control as a pill beside the source pill (Classic and M3E: in the time row, the source pill
  capped at 130 dp then; Apple Music: beside its codec badge): "ANC 80%", "Adaptive ANC", "Transparency" or
  "ANC off". Tapping it opens `HeadsetSheet` (composeApp `ui/screen/player/HeadsetControls.kt`): the four modes,
  the cancelling strength (ANC only), wind noise reduction (Off / Maximum / Automatic, hidden when off) and the
  battery.
  - Protocol, from two MIT projects verified on the headset (firmware 3.37.3 / 3.38.3):
    Tumult1337/momentum4-control and Zhengyang-Liu/m4-companion. Their captured bytes are the test vectors.
    - GAIA v3 frames over Bluetooth Classic RFCOMM, SDP service UUID `a2129ff3-081b-4c45-8afe-469d9c4842ec`:
      `FF 03 00 len vendor(2) command(2) payload`, Sennheiser vendor `0x0495`. The answer is command + `0x0100`,
      an error + `0x0180` (first byte the reason), a change notification + `0x0080`.
    - ANC on/off `0x1A04`/`0x1A05`; mode table `0x1A00`/`0x1A01` as (id, value) pairs: 1 anti-wind
      (0 off, 1 max, 2 auto), 2 comfort, 3 adaptive; level `0x1A02`/`0x1A03`, 0…100 with **0 the strongest**
      (the UI shows strength = 100 − level); Transparent Hearing `0x1804`/`0x1805`. Notifications are registered
      per feature with `0x0007` (13 ANC, 12 Transparent Hearing, 3 battery); without feature 12 the headset's own
      touch gesture is not reported.
    - Firmware side effects the plans respect: any `0x1A00` write (even unchanged) ends Transparent Hearing and
      sets the level to 0; Transparent Hearing on saves the level and sets 100, off restores it; ANC on ends
      Transparent Hearing at level 0. So anti-wind in ANC mode writes the level back afterwards, and in
      transparency turns Transparent Hearing back on.
  - New module `:headsetControl` (`core/service/headsetControl`, android + jvm for tests, registered in the
    private block of `settings.gradle.kts`): `gaia/Gaia.kt` (codec, reassembling reader), `momentum/NoiseControl.kt`
    (state, mode table, `NoiseControlPlan`: the writes from one state to another, pure), `momentum/Momentum4Session.kt`
    (one command in flight, answers matched by command, notifications folded into `status`, each change read
    before, written and read back; three unanswered commands close the channel), androidMain
    `RfcommHeadsetLink`. Tests: `GaiaCodecTest`, `Momentum4SessionTest` against `FakeMomentum4`, which
    reproduces the side effects above.
  - Domain: `HeadsetRepository` + `NoHeadsetRepository` (Desktop and iOS) and `data/model/headset/HeadsetState`.
    Data androidMain: `HeadsetRepositoryImpl`, bound by the new `loadHeadsetModule()` loader actual.
    - The headset is found through `AudioManager` outputs (A2DP, SCO, LE Audio), which need no permission: an
      output named "MOMENTUM 4" makes the pill offer "Allow" (`NEEDS_PERMISSION`). With `BLUETOOTH_CONNECT`
      (Android 12+; `BLUETOOTH` with maxSdk 30 below) the bonded device is matched by the output's address, or by
      name, or by advertising the service UUID (a renamed headset); a device matched only by the UUID that does
      not answer like a MOMENTUM 4 is left alone for the rest of the process.
    - The channel is open while `state` is collected (the player collects it with the lifecycle) and 2 minutes
      after; reconnects after 5, 15, 30, 60 s, or at once on an audio-output change or `retry()`. Slider moves
      are debounced 250 ms.
  - Not verified on a device: no MOMENTUM 4 here. The protocol layer is tested against captured bytes and a
    simulated headset; the Bluetooth discovery and connection on Android are untested. Other Sennheiser models
    are not supported. Sennheiser Smart Control holding the channel at the same time is untested; the failure
    text suggests closing it.
- **Huawei / Honor earbuds join the noise control (2026-10-10, Android).** FreeBuds, FreeClip, FreeLace and Honor
  Earbuds now use the same pill and sheet as the MOMENTUM 4. Exact model names come from OpenFreebuds'
  `DEVICE_TO_DRIVER_MAP` (melianmiko/OpenFreebuds, GPL-3.0 like this app), including FreeBuds Pro 4 and 6i:
  `huawei/HuaweiModels.kt` gives each its channel, whether it has ANC, its cancelling levels (Comfort / Normal /
  Ultra, plus Dynamic on newer ones), voice boost, per-bud battery, and FreeLace Pro's 2 s connect delay.
  - Unlisted names that still name a family (`freebuds|freeclip|freelace|freearc|honor earbuds|honor choice`) are
    guessed: a later "FreeBuds Pro" as the Pro 3, anything else as ANC on/off without levels. A guess whose ANC
    read gets no answer falls back to battery only. A listed name followed by more of a model name ("FreeBuds Pro 6")
    is not that model; one followed by a tag ("FreeBuds 5i (A1B2)") is.
  - Protocol (`huawei/HuaweiPacket.kt`, `huawei/HuaweiHeadset.kt`): `5A len(2) 00 command(2)` + TLV parameters +
    CRC-16/XMODEM; a packet is `len + 5` bytes. OpenFreebuds' own reader reads one byte short, so some of its
    captured answers miss the last CRC byte; this reader takes a packet with a wrong CRC when its parameters fill it
    exactly. Noise read `2B 2A` → parameter 1 `[level, mode]` (0 off, 1 ANC, 2 awareness), also sent unasked;
    older models send only `2B 03` and are re-read. Mode write `2B 04` parameter 1 `[mode, FF]`, `[00, 00]` for off
    (FreeBuddy and Gadgetbridge; OpenFreebuds always sends FF). A level write is `[mode, level]` in parameter 1
    (OpenFreebuds) or 2 (Gadgetbridge): parameter 1 goes first, parameter 2 when reading back shows no change, and
    the one that worked is kept. Battery `01 08` / unasked `01 27`: 1 = overall, 2 = left/right/case (0 = unknown),
    3 = a charging flag per part. A write answer may carry `7F` = result code, 100000 = done.
  - Connection: the standard Serial Port service UUID `00001101-…`, as FreeBuddy and Gadgetbridge open it on
    Android; if that fails, OpenFreebuds' fixed channel for the model through the hidden `createRfcommSocket(int)`
    (reflection; may be refused). After a failed session the other way goes first.
  - Shared model: `HeadsetSession` / `HeadsetReport` in `:headsetControl` (which now depends on `:domain`);
    `Momentum4Headset` adapts `Momentum4Session`, `HeadsetModels.recognise(name)` picks the kind. Domain
    `NoiseControl` gained `modes`, `level`/`levels` (`NoiseLevel`), and `strength`/`antiWind` became nullable;
    `HeadsetState.battery` (`HeadsetBattery`: overall, left, right, case, charging) replaced `batteryPercent`/`charging`;
    `HeadsetRepository.setLevel`. The sheet shows only the controls a model has; the pill shows "ANC Dynamic",
    "Voice boost", or the battery for earbuds without noise control.
  - Tests: `HuaweiPacketTest` (OpenFreebuds' captured packets, CRCs included), `HuaweiHeadsetTest` against
    `FakeHuaweiBuds` (modes, levels in either parameter, the earbuds' own button, battery, no-ANC and guessed
    models, a silent channel), and `Momentum4SessionTest.theAdapterSpeaksTheSharedModel`.
  - Not verified on a device: no Huawei earbuds here.
- **The developer's pop-ups, blog and start-up update prompt removed (2026-10-11).** Upstream counts app opens and
  shows, on Home: a "give a star / review" dialog (opens 10–50), a request to share saved lyrics (1, 15, 30…; it
  could never be satisfied here, since this copy reports `helpBuildLyricsDatabase` as off), a promo for the
  developer's blog (5) and a "kotlin-footguns" star request with a complaint about lost nights (6, 16…46). All four
  dialogs are deleted (`ReviewDialog`, `ShareSavedLyricsDialog`, `BlogPromoDialog`, `FootgunsStarDialog`) with their
  triggers in `HomeScreen` and hooks in `SharedViewModel`. Also gone:
  - the "log in to YouTube" warning on Home (it mentioned Piped, which nothing here uses), with the two `runBlocking`
    DataStore reads in `HomeViewModel.init` that fed it;
  - the developer-blog news: `RssFeedNotifyWork` (a daily job polling maxrave.dev's RSS and posting notifications),
    the Settings rows "Developer blog" and "Blog post notifications", and the credits page's blog button. Installed
    copies still had the job and its "Blog updates" channel, so `MainActivity` cancels the job and deletes the
    channel on every start; blog entries already saved are filtered out of the notification list;
  - the automatic update check on start (`SharedViewModel.shouldCheckForUpdate()` returns false; the Settings switch
    is gone). It reads the official SimpMusic releases, a different app from this build, and popped their release
    notes up. "Check for update" in Settings still works on demand.
  Kept on purpose: the author credit, the third-party licences, and the passive donation and "follow me" rows.
  Strings stay in `strings.xml` (and its Crowdin translations) so upstream syncs do not conflict.
- **Crash guards and a lost upgrade (2026-10-11).** The background scopes this copy added had no exception handler,
  so one failure would end the app: `StreamRepositoryImpl.scope` now logs failures, and a lossless search that
  throws counts as a miss instead of making `awaitLossless` throw. The Android adapter's `scheduleUpgrade` and
  `switchSource` bodies (`upgradeWhenFound`, `switchSourceNow`) and Desktop's `switchSource` catch and log; the
  headset watcher restarts after a failure, and `findTarget` treats a revoked Bluetooth permission as no headset.
  A seek used to cancel the pending lossless upgrade for the rest of the song; it now waits again from the new
  position.
- **Upstream 2.3.0 merged (2026-10-11).** 31 app and 12 core commits (queue order kept on append, synced playlist
  edits past the first page, Japanese romanization after a reinstall, seek bars while paused, the Apple Music player
  rework, Settings in grouped cards, Home's daily discover carousel, the App log screen, and more). Kept out, as before:
  the review, blog, footguns and share-lyrics dialogs, the log-in warning, the developer-blog rows and job, Desktop's
  Sentry (upstream added OS details and a machine id to it). New and left out: Home's launch banners. Their `promos`
  block still arrives with the remote config upstream already fetched for TIDAL, and `SharedViewModel` still caches it,
  but nothing draws a banner. Upstream replaced the Apple Music codec badge with a "kbps · kHz" line read from YouTube's
  format row; this copy keeps its source pill there instead, since that row says nothing while a lossless or SoundCloud
  copy plays. `toAudioCodecLabel` now lives in `PlaybackSourcePill.kt`, and the pill's text uses the `footer` style
  (upstream dropped `badge`). Merging into the work branch needed the merge commit's own resolutions (`git checkout
  <merge> -- <file>`): the work branch carries this copy's commits as different ids, so git re-raises every conflict.
- **Skipping ahead with Hi-Fi sound on (2026-10-11).** The Android preload waits up to 12 s per song for the lossless
  search, one song after another, and only then looked up the addresses of the songs after it. A skip made during
  those waits found neither a loaded player nor a looked-up address. Now the preload starts the searches side by side,
  and looks up the addresses of the preloaded songs and the next ten in a child job while it waits. With Hi-Fi off
  nothing waits, so the preloaded songs are not looked up twice.
- **Headset channel hardening (2026-10-11).** MOMENTUM 4: a battery read with no answer in time, or a
  notification registration the firmware refuses or ignores, ended the session, so every retry failed the same
  way and noise control never showed; both are logged and skipped now (tests in `Momentum4SessionTest`; the fake
  headset gained `unanswered` and `refusedFeatures`). The repository's activity flow gets `distinctUntilChanged`
  after its debounce as well: the player closed and reopened within the two-minute grace sent a second "active",
  which restarted the watcher and reopened a channel that was still open. `HeadsetRepositoryImpl.serve` subscribes its change collectors
  (`CoroutineStart.UNDISPATCHED`) before marking the channel connected, because the change flows replay nothing and a
  tap in that gap was dropped while the pill showed the change as pending. A session whose `run()` returns, which the
  interface says it never does, now counts as a closed channel instead of leaving the pill connected to nothing.
- **Tap to sound, then an upgrade that is not heard (2026-10-11).** For a song that has to be looked up:
  - `YouTube.player` used to send its WEB_REMIX player request and only then run the stream extraction, though
    neither needs the other. The extraction now starts first, in `extractionScope` (not a child: the extractor
    blocks and cannot be interrupted, so a child would make a refused or live video wait for it), and
    `newPipePlayer` awaits it.
  - PipePipe's tiers HEAD-check the URLs they return (`headCheckRandomStream`), so `newPipePlayer`'s own
    `is403Url` runs only for BravePipe's answer (`ExtractSource.of(id)` names the tier).
  - The cipher solver (YouTube's 1–2 MB player script, downloaded and compiled in QuickJS) is built 1.5 s after
    `YouTube` is created (`FaradayCipherEngine.prewarm`, `Extractor.prewarm`); it shares the decode lock, so a
    song arriving meanwhile waits for that build instead of starting a second one.
  - `StreamResolver.quickStart(videoId, waitedFor)`: when the lossless file is known but its opening is not
    cached, a song someone is waiting for (`StreamRequest.waitedFor`: no `sm_trial`, `sm_prefetch` or the new
    `sm_preload`) starts on a still-fresh YouTube address. Measured from a container: archive.org's first byte
    arrives 1.0–1.6 s after the request (TLS, a redirect to a storage node, TLS again). The seamless upgrade
    then moves the song onto the file. Preloads (`sm_preload`, set by the precache) and songs whose seamless
    move was refused (`UpgradeRefusals`, process memory) take the lossless file directly.
  - The upgrade is also scheduled after a crossfade cut short (`commitIncomingAsCurrentInternal`); a finished
    crossfade already did.
  - Loudness: a louder copy keeps the level the song was heard at until the song ends (`matchedLevel`, applied
    wherever the playing volume is set: the volume setter, focus gain and duck, a crossfade out, a same-source
    reload) instead of being raised over 10 s, and the old copy is lowered to a quieter one at no more than
    0.25 dB/s (4–24 s). `MIN_REMAINING_FOR_UPGRADE_MS` went from 60 to 90 s to leave room for that ramp.
  - Not measured on a phone: how much each of these saves depends on the network.
- **High-bitrate sources: whole songs, real releases, real sound (2026-10-11).**
  - **The "no sound / stops" bug.** `StreamResolver.open` capped every read at `CHUNK_LENGTH` (5 MiB).
    - YouTube's containers (WebM, MP4) know their own size, so a chunk's end throws EOF and the loader opens the
      next chunk.
    - `FlacExtractor` and `Mp3Extractor` take END_OF_INPUT as the song's end, and size their seek maps by the
      input length.
    - So an archive.org FLAC stopped after 5 MiB (about 46 s; 13 s behind a 3.5 MB embedded cover), an Audius
      song after about two minutes, and seeking past the first chunk was impossible.
    - Only YouTube is chunked now; other sources open one range from the requested position. A read that asked
      for less than a chunk (the prefetch) gets no more.
  - **Covers.** `FlacHeader.walk` follows the metadata blocks to the first audio frame, stepping over blocks
    longer than the 64 KiB probe with small range reads (`InternetArchive.audioStart`, at most 6 reads,
    16 MiB of metadata).
    - The offset rides on `ArchiveFile.audioOffset` / `PlaybackStream.audioOffset`, persisted in the archive
      row as `v2;bits;channels;audioOffset;origin`. Rows without `v2` are searched again.
    - `StreamResolver.openingCached` counts from it, and a prefetch of such a file asks for the cover plus its
      bytes (`UpcomingPrefetch` reads to the end of what was opened, at most 8 MiB).
    - Measured: Queen's archive file starts its audio at byte 3,502,611, and the live test checks for a FLAC
      frame sync there.
  - **Sound.** A file averaging under 100 kbps of audio per channel (measured past the cover) is refused as
    silence.
  - **Releases, not concerts.**
    - The searches add `mediatype:(audio)`, which drops the Live Music Archive's `etree` items.
    - `ArchiveCandidates` refuses:
      - items in the `etree`, `GratefulDead`, `78rpm`, `georgeblood`, `taperssection` and `roiocollection`
        collections (and a few radio/audiobook ones);
      - items with taper fields (`venue`, `taper`, `transferer`, `lineage`);
      - items with a show date (`yyyy-mm-dd`) in their identifier or title.
    - Item `subject` tags and the `source` note now count as context. `RecordingMatcher` gained concert words
      (concert, tour, festival, gig, soundboard, sbd, unplugged, rehearsal, session(s), outtake(s), alternate)
      and transfer words (vinyl, needledrop, shellac, cassette, 78rpm, acetate). These apply to SoundCloud and
      Audius too.
    - Live run on 2026-10-11: Queen still matches. Beatles and Nirvana no longer do; their only archive.org
      FLACs were a video upload (`mediatype:movies`), a tribute-band tape and live bootlegs. Grateful Dead and
      Phish (concert tapes only) match nothing.
- **Starting a tapped song sooner (2026-10-11).**
  - `StreamResolver.freshYouTube` HEAD-checked every saved address before opening it: a TLS handshake plus a
    round trip, about 0.2–0.5 s.
    - `StreamRepository.isRecentlyVerified/markVerified/forgetVerified` now trust an address found playable in
      the last 10 minutes on the same network. It is marked by `getStream`'s extraction, whose tiers HEAD-check,
      and by the resolver's own check.
    - Google's stream addresses are bound to the asking IP, so `media3/service/NetworkChangeWatcher` (a default
      network callback, created at Koin start) clears the memory when the network changes.
    - A stale one still fails into the normal error retry.
  - `SharedViewModel.loadMediaItemFromTrack` hands the song to the player right after inserting its row. The
    like-status read and the duration update come after.
- **Battery (2026-10-11).**
  - **Position tick.** `MediaServiceHandlerImpl.startProgressUpdate` published the position every 50 ms,
    screen off included. It now ticks every 50 ms while the screen is on, 250 ms off-screen with SponsorBlock
    on, and 1 s otherwise. A `SCREEN_ON/OFF` receiver, registered for the life of the process, keeps
    `screenOn` (do not unregister it in `release()`: the handler can be reused). The notification, lock screen
    and Android Auto read the session's own clock.
  - **Preload buffers.** `exoplayer/PausedBufferCap` wraps each player's `DefaultLoadControl`. It stops loading
    at 30 s while `playWhenReady` is false: preloaded players, and a paused song. Each preload used to fill the
    full 200 s, three songs per track change (about 25 MB each for lossless).
    - Every `DefaultLoadControl` method is forwarded by name, not through `by` delegation alone, so the
      per-player bookkeeping is never skipped.
  - **Battery Saver** (`PowerManager.isPowerSaveMode`, read at each use): one preloaded song instead of three,
    3 addresses looked up ahead instead of 10, no opening prefetch.
  - **Lyrics and canvas wait while no screen shows** (`SharedViewModel.setAppVisible`, set by a
    `LifecycleStartEffect` in `App`). They are fetched when the app comes back, through the existing
    null checks. This is a privacy gain too: a song played with the screen off is not sent to a lyrics or
    canvas provider unless the listener looks.
  - **Friends relays.** `FriendsSession` connects only while someone is on the list, or after the Friends page
    asks for the identity. `setForeground(false)` (from `FriendsInbox`'s `LifecycleStartEffect`) closes the
    sockets in the background. Messages are stored on the relays, so the next connect (`since` =
    `FRIEND_TTL` ago) delivers what was sent meanwhile. Tests: `theRelaysAreLeftAloneInTheBackground`, and
    `strangersCanAskButNotInvite` now calls `ensureIdentity()` after the restart.
- **Privacy: the upstream remote config is fetched only for AutoMix (2026-10-11).**
  `CommonRepositoryImpl` waited for nothing and fetched `remote-config.json` from the upstream developer's
  GitHub on every launch. Its only use here is TIDAL access for AutoMix; its promo block is never drawn. It is
  now fetched once crossfade and DJ mode are both on, and saved credentials keep working meanwhile.
- **Player cache keeps storage free (2026-10-11).** Settings → Storage → "Keep free storage": Off, 10, 15, 20
  (default), 25 or 30%. DataStore key `player_cache_keep_free_percent`.
  - `media3/cache/StorageAwareCacheEvictor` replaces `LeastRecentlyUsedCacheEvictor` for the player cache. It
    removes the least recently played audio when the cache is over "Limit player cache", or when free space
    (`StatFs` on the cache directory) is below the share.
  - `CacheTrim.bytesToFree` is pure and tested in `CacheTrimTest`. It never trims the free-space rule below
    `FLOOR_BYTES` (64 MiB), so the playing song and the next openings stay.
  - Both settings now apply without a restart. The size limit used to need one.
  - `followCacheLimits` in `Media3ServiceModule` re-checks every 15 minutes, for space other apps took. The
    download cache is not touched.
- **AI without a key (2026-10-11).**
  - **Taste card.** With no AI key, the "Your music taste" card is written on the phone by
    `domain/.../taste/OnDeviceTasteWriter`. It uses the same `TasteInput` an AI gets, picks from phrasings
    (a random variant per Regenerate), uses no figures and invents no genres. `OnDeviceTasteWriterTest`.
    `TasteProfile.onDevice` makes the card add "written on this phone".
  - **Playlist suggestions.** The ✨ panel worked only for playlists synced to a YouTube account (YouTube's
    own suggestions). Any other playlist with songs now gets on-device ones:
    - `LocalPlaylistRepositoryImpl.onDeviceSuggestions` takes 4 seeds spread over the playlist, a different
      slice per reload (`PlaylistSuggestions.seeds`);
    - it fetches their anonymous `RDAMVM` radios, the same request as starting a radio;
    - `PlaylistSuggestions.pick` leaves out the playlist's songs by id and `songKey`, takes the radios in
      turn, and allows at most 2 songs per artist. `PlaylistSuggestionsTest`.
    - Reload params `ondevice:<id>:<batch>`. Suggestions load when the panel opens, no longer on every visit.
  - Lyrics translation still needs a key: no on-device model is bundled.
- **Analytics' back arrow only where there is somewhere to go back to (2026-10-11).** Analytics became a tab
  (2026-08-16), but kept the back arrow from its days as a page under Library: from the tab bar it only jumped to
  Home. `AnalyticsScreen` now draws it only when the screen below is not the graph's start destination (Home):
  every tab is opened with `popUpTo(start)`, so a tab always sits right on Home, while a link opened from another
  screen keeps its arrow. System back is unchanged.
- **Auto backup on Android 8 and 9 (2026-10-11).** `MediaStore.Downloads` exists from Android 10; touching it
  below that throws `NoClassDefFoundError`, an Error `AutoBackupWorker`'s `catch (e: Exception)` does not see, so
  auto backup never ran there. Those versions write `Downloads/SimpMusic` through the File API (the app holds
  `WRITE_EXTERNAL_STORAGE` up to SDK 28). Found by `:androidApp:lintOptimized`, whose other three errors
  (`UseAppTint` in `widget_preview_playlists.xml`) are wrong for a widget layout, which cannot use AppCompat.
- **Listen Together: connects by itself, guests can control playback (2026-10-11).**
  - Opening the screen connects (`ListenTogetherViewModel.ensureConnected`). Create and Join no longer wait for
    "Connected"; they connect too. Leaving the screen with no room and no pending join disconnects again, but
    only if this screen opened the connection (`connectedHere`). `ListenTogetherSession.connect()` now does
    nothing while connected or connecting: a second call used to set Connecting over a live peer transport,
    which then reported nothing new, so the screen stayed on "Connecting" with Create and Join disabled.
  - **Shared control.** Four message types exist in peer rooms only (`Protocol.kt`):
    - `control`: guest → room, a `PlaybackActionPayload`;
    - `control_request`: room → host, `ControlRequestPayload`;
    - `set_room_settings`: host → room, `RoomSettingsPayload`;
    - `room_settings`: room → everyone, `RoomSettingsPayload`.
    `RoomState`/`SyncStatePayload` carry `guestControl` at field 101, outside metroproto's numbering.
  - **`RoomHub.control` never edits the room.** It checks membership, the room's `guestControl` flag and the action
    (play, pause, seek, skip, or change track with a track), then forwards the request to the host. The host's
    bridge (`carryOutGuestControl`) runs it on the host's own player, and the host's usual publishers send the
    result. One device keeps deciding what plays next, so its queue, radio and endless queue keep working.
  - The setting lives in `HubSnapshot.guestControl`, so it survives a host transfer. A new room takes it from
    `lt_guest_control` (on unless `FALSE`), sent right after `room_created`. The host flips it from a switch on
    the room screen, which also stores it. Settings → Listen Together has the same toggle for new rooms. The
    transport's beacon check (`reconcileMembers`) re-delivers a lost `room_settings`.
  - Guest side (`ListenTogetherPlaybackBridge`). A guest's action is sent only when it disagrees with the room,
    which is what keeps the guest's own applied commands from echoing back:
    - play/pause: when the intent differs from `room.isPlaying`;
    - seek: when the guest is more than 2 s from the room's live position, checked 400 ms after the jump;
    - a song picked anywhere: sent as `change_track`.
    While a request is pending (4 s; 8 s for a song pick), the room's older state is not applied over it. A pick
    the room has not taken after 8 s switches the guest to listening on their own. A song the player moved to by
    itself (last seen within 3 s of its end, `lastSeen`) is not a pick. A pause from a call or another app taking
    the audio is not sent either: `MediaPlayerInterface.pausedBySystem`, set by the Android adapter's focus
    listener.
  - Bugs fixed on the way:
    - **Queue changes moved guests' playheads.** A `sync_queue` or `queue_add` overwrote the session's
      `lastActionServerTime` (and `queue_add` its position, set to 0). Every queue change from the host (endless
      queue appending, a trim, an approved suggestion) made guests seek back to the last play command, or to
      0:00. Only play, pause, seek and change_track move the playhead now (`PLAYHEAD_ACTIONS`). A play's or a
      seek's time base is the room's `serverTime`, at which the hub already compensated the position.
    - **Approving a suggestion played it at once on every guest**: `queue_add`'s `trackInfo` became
      `currentTrack`.
    - **Joins, leaves and host transfers made guests jump to 0:00 and back**: `publishSnapshot` re-sent
      `change_track` for the song already playing. It now sends play/pause (and the queue) when the room is on
      that song.
    - **Guests restarted every next song a second in.** Their player reached it first, and the host's
      `change_track` then rebuilt the queue and reloaded it. `playTrack` now keeps the playing item
      (`clearMediaItemsExceptCurrent`) when it is the room's song, and also when only the queue changed.
    - **The room queue held the songs already played.** The host published its whole queue, so a guest's player
      lined those up after the current song. Only songs after the current one go out now (`upcoming()`, at most
      100).
    - **A song change could go out as a seek of the old song to 0:00.** Seeks are now confirmed 400 ms later,
      on the same song.
  - Tests: `RoomHubTest` (control refused, allowed, forwarded, kept across a transfer) and `PeerRoomTest`
    (control through the host; a queue change and a suggestion leave guests' playheads alone). The bridge has
    no automated test (it needs a player handler). Not tried on devices.
- **Audius as a second high-bitrate source; YouTube rips refused as lossless (2026-10-11).**
  - With Hi-Fi sound on, the background search (`StreamRepositoryImpl.searchArchive`) tries Audius after an
    archive.org miss: `kotlinYtmusicScraper/.../audius/` (`Audius`, `AudiusCandidates`, `Mp3Header`),
    `YouTube.audius`.
  - It uses Audius's public API (`api.audius.co/v1/tracks/search`, `/v1/tracks/{id}/stream`, `app_name=SimpMusic`,
    no key). Every request needs a User-Agent; Cloudflare answers 403 to Python's default one.
  - Only tracks the artist uploaded themselves count: the account's name or handle is the artist. They must be
    streamable and not gated, deleted or unlisted, with no `remix_of` tracks and no `cover_original_song_title`.
    `RecordingMatcher` then applies its usual checks, and the stream's first MP3 frame must read ≥ 256 kbps stereo.
  - Audius re-signs the stream on every request: 302 to a content node, 307 to signed storage, 206 with ranges.
    The stored URL is the API one and never expires.
  - The hit is a `SourceKind.AUDIUS` stream, persisted in the song's `archive:` row with `itag = AUDIUS_ITAG`
    (2); `cpn` holds `trackId|uploader`. Its cache key is `audius:<id>:<hash>`.
  - `SourceKind.isHighQuality` (archive or Audius) now stands in for "is the archive" wherever the upgrade path
    asked: the seek re-schedule, the refusal list, and `reportStreamRejected`.
  - The seamless upgrade takes the found copy's own kind, and skips a copy that ranks below what plays.
    `PlaybackSource.rank` puts Audius MP3 at 208, between YouTube's Opus 160 (160) and Premium's 256.
  - The sources sheet shows an Audius row only when there is a match.
  - Measured 2026-10-11: ODESZA "Say My Name" matched at 320 kbps / 48 kHz in 2.9 s. A rough check found 2 of
    14 well-known songs (ODESZA, Marshmello); Queen and Taylor Swift have nothing there. First byte takes 0.8
    to 2 s, so instant start relies on the opening cache as with archive.org.
  - **archive.org's original MP3s were left out on purpose.** The ones checked were mostly YouTube rips
    re-encoded at 250–330 kbps ("Eagles - Hotel California (Official Audio).mp3", a Bad Bunny file inside an
    Eagles item): a higher number, but worse than YouTube's own stream.
  - The same reasoning now applies to FLAC: `ArchiveCandidates.looksLikeRip` drops items and files named after
    a downloader or a YouTube upload ("y2mate", "Official Audio", "Lyric Video"…).
  - Tests: `AudiusCandidatesTest` and `Mp3HeaderTest` (real search rows); `AudiusLiveTest` with `AUDIUS_LIVE=1`;
    `ArchiveCandidatesTest.youTubeRipsAreNotLossless`.
- **Starting on the lossless file needs 1 MiB cached (2026-10-11).** `StreamResolver.OPENING_BYTES` went from
  256 KiB (about 2 s of CD FLAC) to 1 MiB (about 9 s). With archive.org's 1.0–1.6 s first byte, the old bar could
  run out right after the start, which is a stall. With less cached, a song someone is waiting for starts on
  YouTube and the seamless upgrade moves it. Preloaded songs and the 1.5 MiB upcoming prefetch still clear the
  bar and start on the file.
- **Player notification: Like first, then noise control or Shuffle (2026-10-11).**
  - The system's media controls (notification, lock screen, quick settings) show only the first two custom
    buttons beside previous / play / next, and some phones only one. So the order is the priority.
  - `SimpleMediaService.publishButtons` orders them:
    1. Like (the heart);
    2. the noise-control button (`service/HeadsetNotification.kt`), while headphones with noise control are
       connected;
    3. Shuffle;
    4. Repeat and Radio.
    Shuffle is therefore visible only without such headphones. Everything after the second shows where a host
    has more room (Android Auto, watches).
  - `MediaServiceHandlerImpl.toggleLike` now updates `controlState.isLiked` itself. Before, the heart refreshed
    only when the app's screen reported the change, so a tap in the notification with the app closed looked
    ignored.
  - The noise button's icon is the mode (`ic_noise_control_on` / `ic_noise_aware` / `ic_noise_control_off`,
    converted from the app's SimpIcons to vector XML). Its name uses the in-app pill's words: "ANC · 80%",
    "ANC · Comfort", "Adaptive ANC", "Transparency", "Voice boost", "ANC off".
  - Its session command (`noise_control`) is granted in `SimpleMediaSessionCallback.onConnect`, since Media3
    leaves a button off the notification unless its command is granted. It reaches the service through the
    callback's `onNoiseControl`, the same pattern as `toggleLike`. The constant lives in the media3 module, not
    in upstream's `MEDIA_CUSTOM_COMMAND`, so no upstream `when` grows a case.
  - **Switching from the notification.**
    - A tap moves to the next mode at once on screen (`pendingMode`). The headphones get it only after
      `HeadsetNotification.SETTLE_MS` (700 ms) without another tap (`HeadsetRepository.setMode(mode, settleMs)`).
      Mode requests are a conflated channel, so tapping from ANC to Off writes Off alone, never the modes in
      between.
    - The next mode is computed from the repository's own state, not the service's copy, which can lag a tap
      behind.
    - The notification is re-posted only when the button's icon or name changes. One switch reports several
      intermediate states, and Android drops a burst of notification updates, possibly including the last one.
    - While paused, the button stays live for its 60 s: it used to freeze as soon as playback stopped.
  - **No song pauses on a switch.**
    - The MOMENTUM 4 has its own "pause music in Transparent Hearing" setting (`0x1800`/`0x1801`, Smart
      Control's "automatic pause", read from Tumult1337/momentum4-control). With it on, the headset sends AVRCP
      pause when Transparent Hearing turns on, and play when it turns off.
    - `HeadsetRepository.isChangingNoiseControl()` is true while the app applies a change and for 3 s after
      (`MEDIA_KEYS_AFTER_CHANGE_MS`). Meanwhile `SimpleMediaSessionCallback.onMediaButtonEvent` consumes play,
      pause, play/pause, stop and headset-hook keys. `onPlayerCommandRequest` refuses `COMMAND_PLAY_PAUSE` from
      the Bluetooth stack's packages, for stacks that send a transport command instead of a key.
    - The headset's own setting is not changed, so its touch gesture still pauses as the listener set it.
  - **Fewer round trips.** Once both ANC and Transparent Hearing notifications are registered,
    `Momentum4Session.act` plans from the state those keep current, so a switch costs its writes and one read
    back instead of a read, writes and a read back. If the read back shows a stale start, it plans once more
    from what was read.
  - The service collects `HeadsetRepository.state` only while music plays, and until 60 s after it stops.
    Collecting is what keeps the headphones' control channel open, and the headphones' own app needs that
    channel back.
  - The in-app pill and the notification leave the strength out while a switch is under way, since it is still
    the old mode's (it read "ANC 0%" on the way out of Transparency).
  - Tests: `Momentum4SessionTest` (`aSwitchSendsItsWritesAndOneReadBack`,
    `aStaleStartIsPlannedAgainFromWhatWasRead`, `withoutNotificationsTheStateIsReadFirst`). Not tried on a
    device, including whether the headset's pause arrives as a key.
- **Home recommendations when signed out (2026-10-11).**
  - Signed out, YouTube Music's own Home is "Podcasts to get you started" and an artist picker
    (`musicTastebuilderShelfRenderer`), with no music: measured anonymously on 2026-10-11.
  - `ForYouRepository` (domain; `data/foryou/ForYouRepositoryImpl`, `forYouModule`) builds Quick picks, New for
    you and Listen again, and `HomeViewModel.refreshForYou` puts them first. Signed in, they are removed again.
  - The shelves come from radios (`next` on `RDAMVM<id>`, no account) of the songs played most in the last 30
    days, then of all time (up to 4 seeds). With no history at all, the first chart playlist seeds them
    instead: for the global chart, "Daily Top Music Videos". Its queue becomes Quick picks.
  - `ForYouShelves` (domain, pure, `ForYouShelvesTest`) decides what goes where:
    - the radios take turns;
    - seeds and songs heard in the last 3 h are left out;
    - "New for you" holds only songs never started or liked, matched by id and by `songKey`;
    - at most 2 songs per artist in a shelf.
  - Quick picks must carry the app's own `quick_picks` string: Home draws that shelf by its title.
  - Listen again gets `itemsPerColumn = 1` only so it stays a row of cards. A card shelf of songs only with no
    More page is otherwise drawn as the large hero carousel (`isSongCardShelf`), which New for you does use.
  - The repository is injected in `HomeViewModel` with `by inject()`, so upstream's `ViewModelModule` is
    untouched.
- **Podcasts tab: RSS feeds and YouTube channels (2026-10-12).** A nav tab (`BottomNavScreen.Podcasts`, ordinal 5,
  before Library in all three bars: `AppBottomNavigationBar`, `AppNavigationRail` in the same file, and both lists
  of the Android liquid-glass bar) opens `PodcastsScreen` (`PodcastsDestination`); a podcast opens
  `PodcastFeedScreen` (`PodcastFeedDestination(podcastId | feedUrl)`). One `PodcastFeedsViewModel` serves both.
  - **Adding.** One field takes an RSS feed, a podcast's web page (its `<link rel="alternate">` feed is followed),
    a YouTube channel (`/channel/UC…`, `@handle`, `/c/`, `/user/`: the id is read from the page's `externalId`)
    or a YouTube playlist (`list=`). `kotlinYtmusicScraper/.../podcast/`: `PodcastFeeds` (client,
    `YouTube.podcastFeeds`, shares the proxy), `FeedXml` (a forgiving hand-written XML reader: entities outside
    CDATA, unclosed `<br>`, DOCTYPEs; no new dependency), `FeedParser` (RSS 2.0 with iTunes tags, RSS 1.0,
    Atom; RFC 822 and ISO dates without a library), `YouTubeChannelPage`.
  - **YouTube channels are read through InnerTube, not their RSS feed.** `feeds/videos.xml` answered 404 for every
    channel on 2026-10-12 (Invidious #6074 reports the same) and never gives lengths. A WEB `browse` of the
    channel with `params=EgZ2aWRlb3PyBgQKAjoA` (Videos tab, no Shorts) or of `VL<playlist>` returns
    `lockupViewModel`s: `contentId`, title, `["989K views","3 weeks ago"]`, a length badge. Dates are therefore
    approximate (now − age); a refresh keeps the date first worked out. The RSS feed stays as the fallback, with
    Shorts dropped. Only the newest page (30 videos) is read; what was seen before stays.
  - **Storage** is JSON files under `fileDir()/podcasts/` (`feeds.json`, `episodes/<id>.json`, `progress.json`),
    written temp-file + atomic move: not Room (no schema version of this copy's own), not DataStore (back catalogues
    would be rewritten with every settings change). `PodcastFeedRepositoryImpl` (`data/podcast/`,
    `podcastFeedModule`) keeps at most 500 episodes a podcast, refreshes feeds older than an hour when the tab
    opens (4 at a time), and writes positions at most every 5 s.
  - **Playback.** A YouTube episode is its video id and plays like any video. An RSS episode is `pod_<hash>`
    (`FeedIds`): `StreamRepository.feedEpisodeStream` gives the enclosure as a `SourceKind.PODCAST` stream, which
    `StreamResolver` (Android, unchunked, cache key `podcast:<id>:<hash>`) and `MpvPlayerAdapter` (Desktop) check
    first, and `getStream` returns for downloads. `GenericMediaItem.isVideo()` / `MediaItem.isVideo()` are false for
    `pod_` ids, since `SongEntity.toTrack()` turns any non-544 artwork into a "video". No lossless search, lyrics
    provider, canvas or song-info lookup is ever asked about a followed podcast's episode (`isPodcastEpisode`
    in `StreamRepositoryImpl` and `SharedViewModel`), and `getRelatedData` refuses `pod_` ids.
  - **Resume.** `PodcastPlaybackTracker` (data, started from `App`) saves a followed episode's position every 5 s on
    the main thread, and on its next start seeks there once the length is known, unless it was left within 30 s of
    the end or 95% through (`EpisodeProgress.finished`), or the player already moved past 3 s.
  - **Recommendations** come from Apple's public directory (`itunes.apple.com/search?media=podcast`), which returns
    RSS feed addresses, so a suggestion can be followed in one tap or opened first (`preview`, kept in memory,
    playable). Search words come only from the followed feeds (`PodcastSuggestionPicker`: keywords, then the most
    specific categories, then the shows' names; shared words first), never from listening history; with nothing
    followed, six broad subjects. Two searches at a time, one retry after a 403/429 (Apple allows about 20 a
    minute), results cached 6 h.
  - Tests: `FeedParserTest`, `YouTubeChannelPageTest`, `PodcastSuggestionPickerTest`; `PodcastFeedsLiveTest`
    (`PODCAST_LIVE=1`: Darknet Diaries' feed, Lex Fridman's channel by handle, the directory) passed on 2026-10-12.
    Not tried on a device.
- **Hi-Fi sources can be turned off one by one (2026-10-12).** Under Hi-Fi sound in Settings → Playback: "Internet
  Archive" (`source_internet_archive`) and "Audius" (`source_audius`), both on by default. `StreamRepositoryImpl`
  skips a turned-off source in the background search, ignores a match already found from it (`knownLossless`), and
  remembers a miss (6 h) only when every source was asked, so turning one back on searches again. The sources sheet
  lists a turned-off source as off. YouTube is always on; the SoundCloud backup keeps its own switch.
- **The noise button keeps its slot in the media controls (2026-10-17).** It used to appear only once the
  headphones' channel was open (`CONNECTED` with noise control), so while the Bluetooth permission was missing, a
  channel was being opened or one had failed, Shuffle took the second slot. The user saw Shuffle where they wanted
  noise control. `HeadsetNotification.button` now shows it for every state but `NONE`: "Allow ANC control"
  (`NEEDS_PERMISSION`), "ANC · connecting", "ANC · tap to retry" (`FAILED`). A tap on those retries, or, for the
  permission, posts a notification (`headset_control` channel, high importance, silent) whose tap opens
  `simpmusic://headset`: a media-controls button cannot open an activity itself (background activity starts are
  blocked). `App.kt` routes that link to `rememberBluetoothPermission` and `HeadsetRepository.retry()`; the
  notification is cancelled once the state leaves `NEEDS_PERMISSION`. Shuffle now shows only with no supported
  headphones connected, or with earbuds that have no noise control. Not tried on a device.
- **Downloads from other sources play to the end; download progress rings (2026-10-17).** A song downloaded from
  Monochrome, the Internet Archive, Audius or SoundCloud played its opening and then stopped. The file was whole: a
  Monochrome FLAC measured 2026-10-17 is a proper 24-bit/44.1 kHz FLAC (51 MB) whose byte ranges match a full read.
  Playback cut it short. `StreamResolver.local()` read every copy on the device in 5 MiB chunks. That is upstream's
  rule for YouTube's WebM/MP4, whose containers know their own size, so the loader reopens past a chunk's end. Media3's
  `FlacExtractor` and `Mp3Extractor` instead take a read's end as the song's end, and size their seeking by it, so a
  downloaded FLAC played its first 5 MiB (about 25 s at 24 bits). The earlier repair pass, which re-downloaded such
  copies from YouTube as "short", was chasing this.
  - `LocalCopyFormat.isYouTubeContainer` reads a copy's first 8 bytes (EBML, or `ftyp` at byte 4). Only those copies
    are chunked; the others are read in one go. `StreamPin.Local` became `Local(youTubeBytes)`. When a non-YouTube
    copy goes away mid-song, the resolver throws instead of continuing it from YouTube's stream at the same byte
    offset, and the player's error path reloads the song from its position.
  - Downloads themselves (`DownloadUtils`):
    - The source stream is pinned per song (`pinnedStreams`, and `file=<otherSourceCacheKey>` on the request URI
      for after a restart). A resumed download reads the same file, renewed when its address runs out.
    - A staged copy never falls back to YouTube's bytes: the download fails instead, and the old copy stays.
    - The inner player-cache layer is keyed by the file's own key, so nothing is left under `#incoming`.
    - A finished copy must equal the declared size exactly (the repair pass keeps its 98%).
    - A second request for a song whose source copy is under way is ignored, since Media3 would merge it into
      the first.
  - Progress: `DownloadHandler.transfers` (`Transfer(fraction, source)`, empty by default, so Desktop shows a
    spinning ring). Android reads `downloadManager.currentDownloads` on the main thread every 500 ms, woken by a
    conflated channel the download listener nudges, and only while something is under way. The song sheet's
    Download row (`ActionButton(leading = …)`) and the sources sheet's row for the source really being fetched draw
    `DownloadProgressRing` (ring plus percentage; spins while the size is unknown). The other source rows hide their
    download button meanwhile.
  - Tests: `LocalCopyFormatTest` covers real container openings, and builds a verbatim FLAC in memory (about 7 MiB)
    that Media3's `FlacExtractor` reads whole, but only up to the 5 MiB cap when capped. Not verified on a device.
- **A source's file must be the song; downloaded songs say what they are (2026-10-17).**
  - **Monochrome served another recording under a track's id.** `tracks.monochrome.st/track/155102257094856704`
    is listed as Pixies' "Where Is My Mind? - 2007 Remaster" (234.97 s, ISRC GBAFL0700145), but the FLAC it serves
    is tagged Nathan Lambertson's "Where Is My Mind (Pixies)" from *Dames* (191.77 s, ISRC QZTB42251473).
    Measured 2026-10-17 by decoding both that file and archive.org's copy of the song: they do not correlate
    anywhere. The listing passed every match rule, and `Monochrome.check` only looked for `fLaC`, so the cover was
    streamed and downloaded as the song.
    - `FlacIdentity` (domain, `data/player/`, `FlacIdentityTest`) reads a FLAC's STREAMINFO and VORBIS_COMMENT from
      its first 16 KiB (`PROBE_BYTES`; Monochrome files carry the comment block at byte 42).
    - `mismatch(title, artists, durationSeconds, isrc)` refuses a file that disagrees on any of these:
      - its ISRC;
      - its real length (±5 s);
      - its artist (leading "The" and accents set aside);
      - its title.
      A shared ISRC accepts the file, whatever the tags spell.
    - Applied in four places:
      - `Monochrome.check`, which compares against the listing's ISRC;
      - `InternetArchive.check`;
      - `DownloadUtils.settleStagedDownload`, so a wrong copy never replaces anything;
      - the startup repair, which re-downloads a wrong copy from YouTube. The repair passes
        `tagsMustAgree = false`, because it deletes: the tags only count there when the title and the artist both
        disagree, and the length and ISRC count as usual.
    - Monochrome rows saved before the check carry no `checked` mark (`MONOCHROME_FILE_CHECKED`, the third part of
      the row's origin), so they are searched again.
  - **The label read YouTube's format row for every download.** A Monochrome FLAC therefore showed "OPUS", and the
    speed beside it was the disk read rate, because `CountingBandwidthMeter` counted every transfer.
    - `StreamResolver.publishLocal` now describes the copy from its own bytes (`LocalCopyFormat.describe`: codec
      from the opening; bits and rate from STREAMINFO; average bitrate from its size).
    - The meter counts `isNetwork` bytes only.
    - The pill shows no speed for a downloaded copy.
    - `PlaybackSource.isLossless` also covers a FLAC codec, so a downloaded FLAC reads "Downloaded · FLAC 24/44.1".
  - **Picking a source for a downloaded song did nothing.**
    - Asking for YouTube was answered with the copy on the device, whatever it was. Now a copy that is not
      YouTube's file (`isYouTubeContainer` false) is passed over, and YouTube's stream opens under its own cache key
      (`youtube:<id>`, `youTubeKeyBesideDownload`). The player's outer cache layer is the download cache, keyed by
      the song's id, so the bare key would have played the FLAC again.
    - `SourceKind.DOWNLOADED` can be picked: the adapter no longer refuses it, `sm_source=DOWNLOADED` reads the
      device copy, and the sheet lists the download as available while another source plays.
  - A plain download no longer falls back to the SoundCloud backup (`DownloadUtils.bestSource`). Its listeners'
    128 kbps MP3 re-uploads sound worse than YouTube's own stream and are the likeliest to be another recording.
    It can still be picked by hand in the sources sheet.
  - Not verified on a device.
- **Upstream core sync is pending (2026-10-17).** The mirror `core-upstream` was advanced to
  maxrave-dev/core@9c3d8f97a, but merging it into `core-main` conflicts in five files — this copy's download work
  against upstream's: `data/.../repository/SongRepositoryImpl.kt`, `media/media3/.../download/DownloadUtils.kt`,
  `media/media3/.../download/MusicDownloadService.kt`, `kotlinYtmusicScraper/.../models/YTItem.kt` and
  `kotlinYtmusicScraper/.../pages/NextPage.kt`. The sync script aborted and left the mirror pushed; upstream's app
  `main` is already fully merged (it has not moved since 2026-10-10), so only the core merge is outstanding — do it
  by hand (`git -C core merge origin/core-upstream`) when upstream's core is wanted, then re-run the sync script.
- **The sync script can use a git-filter-repo already on the machine (2026-10-17).** This container's python3 has
  no `ensurepip`, so the script's venv could not be built; it now prefers `git-filter-repo` from `PATH` or
  `~/.local/bin` (the v2.47.0 tag's single script) and only falls back to the venv. The mirror's fast-forward
  guard still catches a wrong version.
- **The liked-songs catch-up says how far it has got, and the sources sheet opens for a downloaded song (2026-10-17).**
  Two reports from the phone, one build:
  - Switching "Download songs you like" on queues the missing favourites (toast "Downloading 12 liked songs"); the
    switch's row now also says "Downloading 4 of 12 liked songs…" until the last one lands. `downloadAllLikedSongs`
    returns the **ids** it queued (was a count), and `SettingsViewModel.watchLikedDownloads` watches
    `DownloadHandler.downloadTask` until each is downloaded or failed — a generation counter keeps a replaced sweep
    from clearing the new one's line, and an hour's cap keeps a stuck download from leaving it there. The status
    lives in the ViewModel, so leaving Settings and coming back shows nothing (the downloads themselves carry on).
  - The sources sheet was gated on `nowPlayingState.track?.videoId`, which is null until the player has matched its
    media item back to a queue row — opening it right after a downloaded song started showed nothing (no menu at
    all) until the next track. The gate now falls back to `nowPlayingState.songEntity.videoId` (the same id, there
    as soon as the state is), and the sheet asks `sourceOptions` again (up to five times, every 4 s) if its first
    list never arrives instead of spinning for the whole song.
  - Not verified on a device; the sheet's empty-for-a-while symptom is fixed at the gate, and the retry covers a
    flow that never answers.
- **The liked-songs catch-up finishes even when Settings is left, and skips nothing (2026-10-17).** "It downloads
  some songs but not all" had three causes:
  - The sweep ran in the caller's scope — the Settings screen's view model — which is cancelled when the listener
    leaves the screen, so the loop stopped half-way: some favourites queued, the rest never. `SongRepositoryImpl`
    now queues on its own application-lifetime scope (`likedDownloadScope`) and three songs at a time, because each
    `downloadTrack` asks the better sources first (up to 6 s) and one after another a large library took minutes
    just to queue.
  - The filter was `downloadedBytes(videoId) == null`, so the partial bytes of a download that failed or is still
    going made the sweep skip a favourite that is not really on the phone. It now asks the new
    `DownloadHandler.isDownloaded(videoId)` — Android: `downloadCache.isFullyCached(videoId, 0)`, the cache's own
    whole-copy rule (recorded length and every byte of it cached); other platforms default to
    `downloadedBytes != null`.
  - Failures were silent — the progress line just stopped counting. When the watch ends with songs still
    NOT_DOWNLOADED, a toast says how many could not be downloaded and that toggling the switch again retries them
    (a failed download is not a whole copy, so the sweep sees it as missing).
  - Not verified on a device. If songs are still missing after this, check whether they are liked **locally**: the
    sweep reads the app's own library (`getLikedSongs`), so a song liked only on YouTube and never synced is not
    in it.
- **The headphone's name scrolls in the noise-control sheet (2026-10-17).** A name too long for the sheet's header
  row was cut with an ellipsis; it now marquees (the `basicMarquee` the rest of the app uses, starting at once,
  repeating) so the whole name can be read. The battery keeps its room beside it.
- **The headphone's name reads cleanly, and scrolls calmly (2026-10-17).** Two follow-ups to the marquee above.
  - `HeadsetRepositoryImpl.displayName` drops the maker's prefix from a Bluetooth name — "HUAWEI FreeBuds 6i" reads
    as "FreeBuds 6i" — and, for a recognised Huawei model, shows the model's own name, so a device alias or a tag
    the phone appended ("… (ABCD)") never reaches the sheet, the pill or the permission notice. Private copy.
  - The sheet's marquee slows to 20 dp/s with a 2 s pause before each pass, so the name can be read rather than
    raced.
  - Not verified on a device.
- **Home's "Take it easy" row is replaced by local "For you" recommendations (2026-10-18).** The owner's Home feed
  carries YouTube's own "Take it easy" mood row; it is removed and a row built from this phone's listening stands in
  its place, signed in or out.
  - `HomeItem.isTakeItEasyShelf()` (domain) matches the row by its words alone — case, spacing, punctuation and any
    emoji ignored, and a longer title that merely starts with them is another row. `List<HomeItem>.replaceTakeItEasy()`
    drops every such row and puts the local one where the first stood, so the section's old place is kept, not the top
    or the bottom (`TakeItEasyShelfTest`, 6 tests).
  - `ForYouRepository.forYou` builds that one row from the same radios as the signed-out shelves: never-heard songs
    first, then songs worth hearing again, at most 20, `itemsPerColumn = 1` so it stays an ordinary row of cards,
    titled with the app's new `for_you` string. The seed/radio/pick work moved into one `recommendation()` shared by
    both methods.
  - `HomeViewModel` keeps the feed and its continuation pages (`baseHomeItems` + `extraHomeItems`) and composes
    `forYou + …replaceTakeItEasy(forYouRow)` in `publishHomeItems()`, so the late-arriving local row and later pages
    both compose from the truth instead of mutating the visible list. The row is also built when only a continuation
    page carries the section.
  - The row appears only when the feed carried the section. Matched on the English title, as the owner's feed is
    English; a localized title would need its own words.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Home's "Top artists" and "Recommended genres" come from the phone (2026-10-18).** The chart's "Top artists"
  grid and a new "Recommended genres" feed row are built from this phone's listening; YouTube's global chart
  artists stay only as the fallback.
  - `HomeDiscoveryRepository` (domain) and `HomeDiscoveryRepositoryImpl` (`data/foryou/`, registered in
    `forYouModule`) do the work. Top artists: the library's own play counter (`getMostPlayedSongs`, works with
    local tracking off) gives the top 10, then each artist's page (`youTube.artist`) gives the picture and its
    related-artist carousel — up to 6 related artists nobody has heard yet. Genres: each of YouTube's genre pages
    (`FEmusic_moods_and_genres_category`, the Moods & Genres params) is scored against the heard artists and most
    played songs, best 6 win.
  - `HomeArtistPicker` (domain, pure, `HomeArtistPickerTest`) ranks related artists by how many played artists
    point at them; `GenreMatcher` (domain, pure, `GenreMatcherTest`) scores a genre page's Songs shelf — one
    matched artist is 1, one matched song is 2. `Mood.genreItems()` (`MoodGenresTest`) picks the Genres section by
    its title, falling back to the last section (a signed-in account only pushes "For you" in front).
  - Caches live in DataStore under this copy's own keys through the generic `putString`/`getString`
    (`home_discovery_artists`, 7 days; `home_discovery_genres`, 24 h), so no shared interface changed. The genre
    cache stores the selection, not its wording, so a language change re-labels the row without re-fetching.
    Artist pages are fetched at most 10 s, genre pages 12 s, 6 at a time.
  - UI: the genre row is a `HomeItem` carrying `moodItems` (a new field on the domain model) drawn by
    `RecommendedGenresRow` (`ui/screen/home/HomeRecommendations.kt`), placed after the local shelves (or after the
    first row when there are none). The artist grid swaps in `HomeArtists` (`ChartData` takes it), the listener's
    own first and related artists labelled "New to you" (new `new_to_you` string; `recommended_genres` names the
    row).
  - Works signed in and out; with no listening history the chart's own artists stay and no genre row appears.
  - **Upstream files touched, for the next sync**: `core/domain/.../data/model/home/HomeItem.kt` (the `moodItems`
    field), `composeApp/.../viewModel/HomeViewModel.kt`, `composeApp/.../ui/screen/home/HomeScreen.kt`, and
    `composeApp/.../composeResources/values/strings.xml` (two strings). Everything else is in private files.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Home is composed from the phone's listening; YouTube's feed rows are the fallback (2026-10-19).** The
  duplicate "Quick picks" (the app's own shelf at the top, YouTube's same-looking row below it) is gone with the
  same change: as soon as any app-built row exists, the feed's shelves are dropped.
  - `HomeViewModel` now builds, signed in and out: Quick picks / New for you / Listen again (`ForYouRepository`,
    no longer signed-out only), "Because you played <song>" and up to three "More like <artist>" rows (radios of
    the top song and of each top artist's next most played song), the "Recommended genres" cards and one
    "<Genre> for you" row per genre (`HomeDiscoveryRepository`). Every later row leaves out songs already shown
    above it (`remainingRows`), so the same radio does not fill two rows.
  - YouTube's feed shows only when no app-built row exists at all (no history and nothing to seed from); then it
    is deduplicated by title (`distinctShelves`, `HomeShelvesTest`) and its "Take it easy" row is still replaced.
    With local rows the feed is never paginated (`hasLocalRows` forces `PAGINATION_EXHAUST`).
  - `HomeDiscoveryRepository` gained `becauseYouPlayedRow`, `artistRows` and `genreRows` (`HomeSongRow`); a genre
    page's Songs shelf is parsed privately with its thumbnails (the shared parser drops them) and kept in memory
    per session, so the genre rows reuse the pages the scoring pass already fetched.
  - `ForYouContent.kt` (private) now holds the one `Track`/`SongEntity` → `Content` mapping and the one radio
    fetch that `ForYouRepositoryImpl` and `HomeDiscoveryRepositoryImpl` share.
  - **Upstream files touched, for the next sync**: `core/domain/.../HomeItem.kt` (`distinctShelves` added),
    `core/domain/.../repository/ForYouRepository.kt` (KDoc only), `HomeViewModel.kt`, and `strings.xml` (three
    strings: `because_you_played`, `more_like_artist`, `genre_for_you`). `ForYouRepositoryImpl`, `ForYouModule`,
    `HomeDiscoveryRepositoryImpl`, `ForYouContent.kt` and the tests are this copy's files.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Home's app-built song rows now have three layouts (2026-10-20).** Only the new rows vary; Quick picks, New for
  you, Listen again, the genre cards and Top artists keep their existing looks.
  - `HomeShelfStyle` (domain) marks the layout on `HomeItem` (`format`), and `HomeItem.feature` carries the song a
    `FEATURE` row shows above its contents (`HomeSongRow.feature` supplies it for "Because you played").
  - "Because you played <song>" is `FEATURE`: one full-width 16:9 card of the seed song — title and artists over the
    art, a play circle — and then the radio's songs in the ordinary card row (`FeatureSongRow`).
  - "More like <artist>" is `WIDE`: one row of wide 16:9 cards (`WideSongRow`), distinct from the square covers.
  - "<Genre> for you" is `TOP_LIST`: a compact numbered Top 5 list (`TopSongsListRow`), the one vertical layout.
  - The three live in `ui/screen/home/HomeSongRowStyles.kt` (private); `HomeScreen` adds one branch that reads
    `format`. Each row type keeps its layout from visit to visit.
  - **Upstream files touched, for the next sync**: `core/domain/.../HomeItem.kt` (two fields and the enum),
    `core/domain/.../repository/HomeDiscoveryRepository.kt` (`HomeSongRow.feature`), `HomeViewModel.kt`,
    `HomeScreen.kt`. No shared interface changed.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **The video chart row is hidden, and Top artists is a shelf of big cards (2026-10-20).**
  - `ChartItemPlaylist.isVideoChart()` (domain, new `ChartShelves.kt`, `ChartShelvesTest`) drops YouTube's
    "Video charts" row — the first carousel in the Charts block — while every other chart row stays. Matched by
    its words, as that title comes in English on this feed.
  - The "Top artists" grid is now one horizontal row of big circular cards (`HomeArtistCard`,
    `ui/screen/home/HomeArtistCards.kt`): photo, name and subtitle underneath, no rank numbers. Known artists
    show their subscriber line, the new ones "New to you", the rest "You might like".
  - Top artists are drawn more reliably, so the row no longer comes out short: `playedArtists` takes the
    analytics' top artists first (every play in 180 days, not just the fifty songs the library keeps) and fills
    from the library's play counter, which is all there is with local tracking off. An artist known only from
    analytics takes their name from the artist page (fetched for the picture anyway).
  - Discovery is ranked against the played artists only, so heard-but-related artists can fill the six slots
    instead of being dropped wholesale; unheard ones keep "New to you" (marked by `HomeArtists.newCount`), the
    heard ones say "You might like" (new string `you_might_like`).
  - **Upstream files touched, for the next sync**: `core/domain/.../chart/ChartShelves.kt` (new),
    `core/domain/.../repository/HomeDiscoveryRepository.kt` (`HomeArtists.newCount`), `HomeScreen.kt`,
    `strings.xml`. Private: `HomeDiscoveryRepositoryImpl` (analytics dependency), `ForYouModule`, `HomeArtistCards.kt`.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Top artists moves into the feed; alternate versions are filtered; genre rows seed from the listener
  (2026-10-20).**
  - "Top artists" is now a feed row near the top (right after the first shelf), through `HomeItem.topArtists`
    (`HomeArtistRow`); the Charts block no longer draws it. `HomeViewModel.publishHomeItems` inserts the row when
    the artists are ready.
  - The Charts block also hides YouTube's country selector. Its remaining playlist rows (video charts already
    hidden) and podcasts are all it may show; with none left, the whole block disappears, selector included.
  - `SongQuality` (domain, pure, `SongQualityTest`) drops alternate uploads — covers, karaoke, instrumentals,
    remixes, live takes, sped-up/slowed/nightcore/8D, acoustic/piano/orchestral versions, AI covers — from Quick
    picks, New for you, "Because you played", "More like" and both genre-row paths. Markers must be whole words in
    brackets/after a dash, or strong words anywhere, so "Live Forever" and "Discovery" survive. Listen again keeps
    the listener's own songs whatever version they chose.
  - `<Genre> for you` rows are no longer the genre page's random top songs: each row is now a radio from a seed
    song by one of the listener's own artists found on that genre page (original version only). The seed is cached
    with the genre selection (`GenreCache.version` 2; older caches recompute), and the genre page's songs are only
    the fallback when the radio cannot be fetched.
  - **Upstream files touched, for the next sync**: `core/domain/.../HomeItem.kt` (`HomeArtistRow` and the
    `topArtists` field), `HomeScreen.kt`, `HomeViewModel.kt`. `ForYouShelves.kt`, `SongQuality.kt` and
    `HomeDiscoveryRepositoryImpl` are this copy's files.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Genre rows follow artists the listener actually plays; playback speed reaches 3× (2026-10-20).**
  - Genre matching no longer uses `getHeardSongs` (every artist ever heard): `recommendedGenres` builds
    `artistPlays` from the library's most played songs (the play counter, up to 50 songs), so one random play can
    no longer pull R&B or dance in. Only those artists count towards the score.
  - The row's seed is now the song by the **most played** matched artist (`GenreMatcher.seedVideoId`, pure,
    `GenreMatcherTest`), not the first match on the page; only an original studio recording can seed. The genre
    cache version is 3, so an existing selection recomputes.
  - Playback speed now goes to 3× — the song and podcast controls in the speed sheet used `coerceIn(0.2f, 2f)`,
    now `3f`; nothing else clamped it.
  - **Upstream files touched, for the next sync**: `composeApp/.../ui/component/ModalBottomSheet.kt`,
    `core/domain/.../recommendation/GenreMatcher.kt`; `HomeDiscoveryRepositoryImpl` is this copy's.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **A Spotify theme, with a Spotify-shaped Home (2026-10-23).**
  - `THEME_COLOR_SPOTIFY` is a third Theme color choice beside Default / Wallpaper / Custom (Settings →
    Theme color → Spotify). It follows the app's light/dark/system mode: `spotifyColorScheme` provides both a
    dark (#121212 page, #181818 cards, #1DB954 green) and a light (white page, same green) palette. Green buttons
    take black labels, as Spotify's do.
  - `LocalSpotifyTheme` is provided by `AppTheme`; `SpotifyShapes` rounds Material components a step further (and
    `ForceDarkContent` now carries the active shapes through). The app's semantic `AppColors` switch the heart to
    green and the active lyric to white (dark) / black (light).
  - Home under the theme: the greeting alone in the top bar (no app-name line), no account row, no artwork
    gradient (flat #121212), and the filter chips become filled pills — #282828 with white text off, green with
    black text on — instead of the transparent/outline chips (`ChipGroup`). A two-column quick-access grid of up
    to six most-played songs (the Listen again shelf, else the first shelf with songs) opens Home
    (`SpotifyHome.kt`); the currently playing tile turns green.
  - The player is already the Spotify layout by default (`NOW_PLAYING_STYLE_SPOTIFY`); the theme now colours it,
    and immersive screens use the Spotify dark scheme.
  - **Upstream files touched, for the next sync**: `core/domain/.../DataStoreManager.kt` (the constant),
    `composeApp/.../ui/theme/Theme.kt` (branch, provider, shapes), `ui/component/ChipGroup.kt`,
    `ui/screen/home/HomeScreen.kt`, `ui/screen/home/SettingScreen.kt`, `values/strings.xml`
    (`theme_color_spotify`). Private: `ui/theme/SpotifyTheme.kt`, `ui/screen/home/SpotifyHome.kt`.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **An app-theme picker with five named themes, including Retro Pixel (2026-10-23).**
  - Settings → **App theme** (the old Theme color row) now opens a visual swatch grid instead of a text list:
    Default, Material You (Android only), Spotify, Apple Music, Ocean, AMOLED Black, Retro Pixel and Custom.
    Each card previews its background and two accents, with a tick on the current theme; Custom still opens the
    colour picker (and the separate Custom color row stays when Custom is active).
  - Every named theme follows the app's light/dark/system mode. Palettes live in `AppThemes.kt`
    (`appleMusicColorScheme`, `oceanColorScheme`, `amoledColorScheme`, `retroColorScheme`) beside
    `SpotifyTheme.kt`. Themes are palettes + accents only; Spotify alone keeps its Home layout (quick-access
    grid, filled pills, greeting header).
  - Retro Pixel: an 8-bit palette (neon green/magenta/cyan on near-black, or a paper light variant), blocky
    Material shapes (`RetroShapes`) and the monospace face (`retroTypography`) everywhere, immersive screens
    included. `LocalRetroTheme` is provided by `AppTheme` like `LocalSpotifyTheme`.
  - `DataStoreManager` gained `THEME_COLOR_APPLE_MUSIC`, `THEME_COLOR_OCEAN`, `THEME_COLOR_AMOLED` and
    `THEME_COLOR_RETRO` beside `THEME_COLOR_SPOTIFY`. Material You keeps the wallpaper dynamic scheme and is
    hidden where the platform cannot provide one.
  - **Upstream files touched, for the next sync**: `core/domain/.../DataStoreManager.kt` (four constants),
    `ui/theme/Theme.kt`, `ui/screen/home/SettingScreen.kt`, `values/strings.xml`. Private:
    `ui/theme/AppThemes.kt`, `ui/screen/home/ThemePicker.kt`.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Themes change shapes, type, Home and the player, not only colours (2026-10-23).**
  - `ThemeDesign.kt` adds `AppThemeFamily` (from the theme id), `AppShapes` (card, artwork, hero, chip, nav
    capsule/indicator, search) and `AppChipStyle`, provided as composition locals by `AppTheme`. Material `Shapes`
    are per theme too (`AppleShapes`, `OceanShapes`, `AmoledShapes`, `RetroShapes`, `SpotifyShapes`). Apple, Ocean
    and AMOLED use the system sans face; Retro is monospace; Spotify/Default/Custom keep Poppins.
  - Home's cards, artwork and hero use `LocalAppShapes` (`AdapterItems`, `HomeSectionStyles`, `HomeArtistCards`,
    `SpotifyHome`, `HomeSongRowStyles`); filter chips fill for Spotify/Apple/Ocean and square off for AMOLED/Retro,
    staying outlined elsewhere; the flat nav bar's capsule/indicator/search follow the same shapes.
  - Signature Home touches: Spotify's grid/pills/greeting (as before), Apple Music's **Top Picks** feature row,
    Ocean's tinted header, and flat headers for AMOLED/Retro. Named themes also paint the Desktop shell with their
    own surfaces instead of #121212.
  - Choosing Spotify or Apple Music in App theme also switches the player layout to Spotify/Apple; the other
    themes leave the listener's player choice alone.
  - **Upstream files touched, for the next sync**: `ui/theme/Theme.kt`, `ui/component/ChipGroup.kt`,
    `ui/component/AdapterItems.kt`, `ui/component/HomeSectionStyles.kt`, `ui/component/AppBottomNavigationBar.kt`,
    `ui/screen/home/HomeScreen.kt`, `viewModel/SharedViewModel.kt`, `App.kt`, `MixForYouScreen.kt`,
    `BrowseScreen.kt`, `AmbientThemeGlow.kt`, `values/strings.xml` (`top_picks`). Private: `ui/theme/ThemeDesign.kt`,
    `ui/theme/AppThemes.kt`, `ui/theme/SpotifyTheme.kt`, `ui/screen/home/ThemePicker.kt`, `HomeArtistCards.kt`,
    `SpotifyHome.kt`, `HomeSongRowStyles.kt`.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Retro Pixel now runs the whole app through a pixel/ASCII filter (2026-10-23).**
  - The face is **VT323** (bundled, SIL OFL — `font/vt323_regular.ttf`, licence in
    `composeResources/files/licenses/VT323-OFL.txt`), used for every text style with a 1.1 size lift because
    its x-height is small. Other themes keep Poppins/system sans.
  - `ThemedIcon` (`ui/component/PixelIcon.kt`, private) samples any icon into a 12×12 bitmap and scales it
    up with `FilterQuality.None` under Retro, so the nav, top bar, player controls, mini player, Home card
    buttons and Settings lose their smooth Material icons; other themes get the normal icon. It is used in
    `BottomNavScreen`, `RippleIconButton`, the three player layouts, `PlayerControlLayout`, `MiniPlayer`,
    `AdapterItems` and `SettingScreen`.
  - A faint CRT scanline layer (`RetroScanlines`) is drawn over the whole app under Retro (1 px lines every
    3 dp, 4.5% onBackground), on top of the square shapes and 8-bit palette.
  - **Upstream files touched, for the next sync**: `ui/theme/Typo.kt`, `Theme.kt`,
    `ui/component/LiquidGlassAppBottomNavigationBar.kt`, `RippleIconButton.kt`, `PlayerControlLayout.kt`,
    `AdapterItems.kt`, `MiniPlayer.kt`, `SettingScreen.kt`, the three
    `ui/screen/player/content/NowPlayingContent*.kt` files. Private: `ui/component/PixelIcon.kt`; new font and
    licence under `composeResources/`.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Theme fonts now reach every screen, and Retro pixelates every vector icon (2026-10-23).**
  - `typo()` was still hard-wired to Poppins: `MaterialTheme.typography` carried the theme face, but screens
    build their styles with `typo()`, so the theme font almost never reached the text. It now reads
    `LocalAppFontFamily` / `LocalAppFontScale`, provided by `AppTheme`, and `AppTheme` passes the resolved face
    explicitly when building the Material typography. Apple/Ocean/AMOLED now really use system sans, Retro VT323
    (1.1× sizes), Spotify/Default/Custom Poppins; `ForceDarkContent` inherits the same locals.
  - Every vector `Icon(` in `composeApp/src` is now `ThemedIcon` — 241 call sites — so Retro Pixel samples every
    one of them. The eight painter-based icons (wrapped-share cards, `share_lyrics` artwork) stay normal vectors,
    as does `PixelIcon`'s own non-Retro path; `Space Mono` stays only in the listening receipt and the app-log
    screen, where the mono face is the design.
  - **Upstream files touched, for the next sync**: `ui/theme/Typo.kt`, `Theme.kt`, and the whole UI set the icon
    replacement touched (see `git show --stat` for this commit). Private: `ui/component/PixelIcon.kt`,
    `ui/theme/ThemeDesign.kt`, the VT323 font and licence.
  - Not verified on a device. Domain tests, data and composeApp JVM compilation pass.
- **Retro Pixel's corners are stair-stepped across the whole app (2026-10-23).**
  - Retro's cards were square and its Material shapes nearly square, but every hard-coded
    `RoundedCornerShape` stayed smooth. `ThemeDesign.kt` now has `PixelCornerShape`, a `CornerBasedShape`
    that draws each corner as a staircase (1–12 steps, sized from the corner), used by `RetroShapes` and
    Retro's `AppShapes` (cards, artwork, hero, chips, nav capsule/indicator, search, pill, avatar).
  - `appCorner(radius)` returns a stepped shape under Retro and the original arc elsewhere; every simple
    `RoundedCornerShape(N.dp)` in `composeApp/src/commonMain` (181 call sites), every top-only sheet/card
    corner, and the `RoundedCornerShape(percent = 50)` pills now go through it. The five top-level shape
    vals in Settings, Library, Podcast, Friends and Listen Together became `@Composable` getters. The mini
    player capsule, its round controls and artwork, Home's artist avatars and the account avatar use the
    new Retro `pill`/`avatar` shapes too. Non-Retro themes keep their exact previous radii.
  - **Upstream files touched, for the next sync**: the whole UI set above (`git show --stat` for this
    commit), notably `ThemeDesign.kt`, `AppThemes.kt`, `MiniPlayer.kt`, `HomeArtistCards.kt`,
    `HomeScreen.kt`, `SettingItem.kt`, `LibraryTilingBox.kt`, `PodcastUi.kt`, `FriendsScreen.kt`,
    `ListenTogetherScreen.kt` and the three `NowPlayingContent*.kt` files.
  - Not verified on a device. ComposeApp JVM compilation passes.
- **Round pixel corners, crisper Retro icons and a separate accent color (2026-10-23).**
  - `PixelCornerShape` now follows a quarter-circle arc in equal-height rows, taking each step's
    coordinate from the middle of its row. The first pass moved diagonally in 45° steps, which read as
    a chamfer; the outline is now symmetric and visibly round while staying stair-stepped. It remains
    the shape behind `RetroShapes` and Retro's `AppShapes`/`appCorner` call sites.
  - `PixelIcon` renders a vector at 4× into a sample bitmap, measures each cell's coverage and paints a
    fresh 16×16 bitmap with fully opaque or fully transparent pixels (threshold 0.3). The old 12×12
    bitmap kept anti-aliased grey edge pixels, which the upscaler made look soft; the new mask has no
    soft edges, and 16×16 keeps more of each glyph's shape. Tinting and `FilterQuality.None` remain at
    draw time.
  - **Accent color is now independent of the theme.** Settings → App theme is followed by an Accent
    color row (Theme default, ten presets, or any 6-digit hex). The stored value is an optional ARGB
    string (`accentThemeColor`); `AppTheme` builds an accent scheme with MaterialKolor and replaces only
    primary/secondary/tertiary roles, so the selected theme still owns its background, surfaces, shapes,
    typeface and special colours (Spotify's heart, for example). The theme cards preview the override.
  - **Core commit**: `08acc80` (DataStoreManager domain + data). **Upstream files touched, for the next
    sync**: `core/domain/.../DataStoreManager.kt`, `core/data/.../DataStoreManagerImpl.kt`,
    `viewModel/SharedViewModel.kt`, `App.kt`, `ui/theme/Theme.kt`, `ui/theme/ThemeDesign.kt`,
    `ui/component/PixelIcon.kt`, `ui/screen/home/SettingScreen.kt`, `ui/screen/home/ThemePicker.kt`,
    `values/strings.xml`. Private: `ui/screen/home/AccentColorDialog.kt`.
  - Not verified on a device. ComposeApp JVM compilation passes.
- **Mood chips work, podcast speed is separate and real, and the radio mix follows the theme (2026-10-23).**
  - Home's mood chips (Relax, Sleep, Energize …) used to change only the hidden YouTube feed: `publishHomeItems`
    always preferred the app-built rows. With a mood selected it now shows `(baseHomeItems + extraHomeItems)`
    from the mood's feed and lets the feed paginate; **All** restores the personalised rows. The local rows
    are listening-derived and deliberately not filtered by a mood.
  - Podcast speed is now a real, separate control. `SongEntity.isPodcast()` recognises RSS episodes (`pod_`
    ids) and YouTube podcast episodes (`videoType` containing PODCAST); `NowPlayingTrackState.isPodcast()`
    adds the queue track's type. Both the Android and Desktop playback-speed collectors pick
    `podcastPlaybackSpeed` for those and song speed otherwise, and Discord RPC reports the matching speed.
    The bottom sheet shows only the podcast row for a podcast and only song speed + pitch for a song; the
    three-dots action is labelled **Podcast speed** for podcasts and stays enabled even with crossfade.
  - The three-dots sheet was bypassing the pixel filter: `ActionButton` and `HeartCheckBox` used
    `Image(imageVector=…)` directly. Both now use `ThemedIcon`; the sheet's speed/pitch/sleep, add-to-playlist,
    done and artist rows were converted too, so Retro samples every one of them.
  - `RadioMixBar` is theme-shaped: Retro draws ten hard blocks with a square, pixel-stepped thumb and
    pixelated end icons; AMOLED is square and solid; Spotify is a solid pill with a wider thumb; Apple/Ocean
    keep rounded tracks with a wider thumb; default/Material keep the original gradient. `PixelIcon.kt`
    exposes `rememberPixelatedPainter` for painters drawn directly in a Canvas.
  - **Media notification**: left with Media3's `DefaultMediaNotificationProvider`. Media3 draws its
    notification and controls itself and exposes no colour hook; replacing the provider risks the media
    controls. Its small icon is already the pixel sound wave.
  - **Core commit**: `5b24214`. **Upstream files touched, for the next sync**:
    `core/domain/.../data/entities/SongEntity.kt`, `core/domain/.../mediaservice/handler/MediaPlayerHandler.kt`,
    `core/data/.../androidMain/.../MediaServiceHandlerImpl.kt`, `core/data/.../jvmMain/.../JvmMediaPlayerHandlerImpl.kt`,
    `viewModel/HomeViewModel.kt`, `viewModel/NowPlayingBottomSheetViewModel.kt`,
    `ui/component/ModalBottomSheet.kt`, `ui/component/RadioMixBar.kt`, `ui/component/PixelIcon.kt`.
  - Not verified on a device. ComposeApp JVM compilation passes.
- **Three-dots menu icons keep their old size (2026-10-24).**
  - `ActionButton` went from `Image(imageVector=…)` (24dp intrinsic) to `ThemedIcon`, but its modifier was
    only `wrapContentSize().padding(12.dp)`, so `ThemedIcon` did not add its 24dp fallback and the pixel
    bitmap rendered at its 16px intrinsic size. The modifier now ends in `.size(24.dp)`, restoring the
    24dp icon inside the 12dp padding and the 48dp menu row while keeping the hard pixel grid.
  - Not verified on a device. ComposeApp JVM compilation passes.
- **The ANC strength slider says its percentage when let go (2026-10-26).** Releasing the MOMENTUM 4's strength slider shows a short toast such as "ANC 80%" (`onValueChangeFinished`, cmptoast's `showToast`, the same as `BaseViewModel.makeToast`). A bubble that followed the thumb while dragging (2.4.64) was removed at the user's request. The readout beside "Strength" is larger and brighter, and the slider reports the percentage to screen readers (`stateDescription`). `HeadsetControls.kt` only. That toast was later removed in 2.4.69: the slider is voice only now (below). Not verified on a device.
- **Retro Pixel reworked with the ui-ux-pro-max skill (2026-10-26).**
  - **The skill**: installed at `~/.claude/skills/ui-ux-pro-max` from
    `nextlevelbuilder/ui-ux-pro-max-skill` @ `1f88579` (skill folder `.claude/skills/ui-ux-pro-max`,
    `data/` + `scripts/` beside `SKILL.md`). Its Python is standard-library only (no network calls, no
    package installs; the only writer is `--persist`, which was not used). Queried for the `pixel-art`
    style, Arcade & Retro palette, the Press Start 2P/VT323 pairing and the UX contrast/touch rules; the
    repo itself is not vendored into the app.
  - **Palette** (`ui/theme/AppThemes.kt`, `retroColorScheme`): dark primary `#39FF14` → `#22C55E`
    (`onPrimary #06140A`), secondary `#FF2E88` → `#FF5C7A`, `surfaceTint` `#39FF14` → the surface
    `#12121C` (elevated cards were being washed green), `outline` `#5D5D78` → `#7A7A96` (4.5:1 on
    surface) and `outlineVariant` `#2A2A3D` → `#5E5E78`. Light `outline` `#7A7A6A` → `#6B6B58` (4.8:1
    on cream), `outlineVariant` → `#B8AE90`, `surfaceTint` → `#FFF8E7`.
  - **Scanlines** (`ui/theme/Theme.kt`, `RetroScanlines`): one 1dp line every 2dp (was 1px every 3dp),
    alpha 0.10 dark / 0.06 light (was 0.045 and effectively 1.08:1), with the line offsets precomputed
    in `Modifier.drawWithCache` instead of a per-frame Canvas loop.
  - **Typography** (`ui/theme/Typo.kt`, new `retroTypography` in `ThemeDesign.kt`): the blanket ×1.1
    became explicit even sizes — body 14/16/20, titles 14/18/24, labels 14/16/18, headline 20/22/26,
    display 22/24/24 — every style `FontWeight.Normal` (VT323 has one weight; synthetic bold smeared
    it) and `lineHeight = 1.15 × size`.
  - **Shapes** (`ui/theme/ThemeDesign.kt`): `PixelCornerShape.copy()` used to return `this`, so every
    adapted corner was ignored; it now builds a real copy carrying all four `CornerSize`s. Step counts
    come from the shape's own corner/step pair (not a nominal radius), coordinates snap to whole
    pixels, and `appCorner` no longer multiplies the radius by 1.4. Radii are step-aligned: `Shapes`
    8/2, 12/2, 16/4, 20/4, 24/4 and `AppShapes` card 8/2, cardSmall 4/2, artwork 8/2, artworkSmall
    4/2, hero 16/4, chip 4/2, navBar 12/4, navIndicator 8/4, searchButton 8/4, pill/avatar 8/4.
  - **Hard pixel frames** (`ThemeDesign.kt`, new `Modifier.pixelShadow`): 2dp `outline` border plus a
    3dp offset rectangle in `#07070D`, no blur. Applied to Retro chips (`ui/component/ChipGroup.kt`,
    which also drops the grey/white sweep-gradient border and uses a 1dp primary/outline edge), Retro
    home mood cards (`ui/component/AdapterItems.kt`, 6dp elevation → 0), Wrapped entry cards
    (`ui/component/WrappedEntryCard.kt`, 1dp → 0) and the hover play button (square `pill`, no blur
    shadow).
  - **Radio mix** (`ui/component/RadioMixBar.kt`): Retro’s ten blocks are flat `primary` (filled) or
    `outlineVariant` (empty) with a 1dp `outline` edge, instead of the cyan→green `lerp`; the 10%/55%
    alpha track became solid roles; the thumb no longer swells 1.12× on touch.
  - **Motion** (`ui/component/AppBottomNavigationBar.kt`, `ui/screen/home/HomeScreen.kt`): Retro uses
    `snap()` for the nav indicator, the header colour and the top-bar fade. Its ripple is now visibly
    stronger (`pressed 0.16 / focused 0.22 / dragged 0.18 / hovered 0.12`, `Theme.kt`) instead of the
    app-wide 0.04.
  - **Pixel icons** (`ui/component/PixelIcon.kt`): the default 24dp sprite rounds down to a whole
    number of device pixels per cell, so a 16-cell icon no longer draws 4.125px cells. Callers that
    size the icon themselves are untouched, and the 0.3 coverage threshold is unchanged.
  - **Shimmer** (`ui/theme/Theme.kt`): Retro's skeleton uses `#3322C55E`/`#2E5B2E` (light
    `#E5D9B8`/`#C8F0C0`) instead of the neutral greys.
  - **Upstream files touched, for the next sync**: `ui/theme/AppThemes.kt`, `ui/theme/Theme.kt`,
    `ui/theme/ThemeDesign.kt`, `ui/theme/Typo.kt`, `ui/component/ChipGroup.kt`,
    `ui/component/RadioMixBar.kt`, `ui/component/PixelIcon.kt`, `ui/component/AppBottomNavigationBar.kt`,
    `ui/component/AdapterItems.kt`, `ui/component/WrappedEntryCard.kt`, `ui/screen/home/HomeScreen.kt`
    and `gradle/libs.versions.toml` (2.4.66 / 136). No `core/` changes; core stays at `5b24214`.
  - Not verified on a device. ComposeApp JVM compilation passes.
- **The ANC strength is spoken when the slider is let go (2026-10-26).**
  - `HeadsetControls.kt` calls `speakAnnouncement(text)` when the MOMENTUM 4's strength slider is
    released, with the spoken form built from `headset_percent_spoken` ("Noise cancelling at 80
    percent") via `rememberUpdatedState` so the non-composable slider callback sees the current
    value. The toast that said "ANC 80%" beside it is gone (2.4.69, at the user's request): voice
    only, plus the "NN%" readout beside "Strength".
  - **Voice choice** (`Speaker.selectVoice`/`voiceScore`, 2.4.70): the user asked for a voice like
    the one in the film *Her* — warm, close and unhurried. Nothing is cloned or imitated: the app
    scores the voices the phone already has and picks the warmest-sounding one, then keeps the
    engine default if that fails. Quality dominates the score (very high 300, high 200, normal 100),
    then +20 for the same country as the requested locale and +10 for a `neural`/`natural` name or
    feature; a downloaded (non-`isNetworkConnectionRequired`) voice gets +1 so only a local voice of
    equal quality wins. Android exposes no gender, so female-presenting name heuristics add 30
    (`female` +30, `male` −30) and Google's voice ids rank +30 down to −2: en-US `tpf`, `sfg`,
    `iob`, `tpc`, `iog`, `iol`; en-GB `gba`. The male en-GB `rjs`, whose id carries no gender
    hint, gets −30. Speech rate is 0.9 and pitch 0.97 — slower and a touch lower than the engine
    default — so the phrase ("Noise cancelling at N percent") reads calmly rather than clipped.
  - `speakAnnouncement` is an `expect` in `ui/screen/player/SpeakAnnouncement.kt`: the androidMain
    actual keeps one process-wide `TextToSpeech` engine in a `Speaker` object (creating it is slow),
    speaks with `QUEUE_FLUSH` and a fixed utterance id, and falls back from `Locale.getDefault()` to
    `Locale.US` when the default has no data. Audio attributes are
    `USAGE_ASSISTANCE_ACCESSIBILITY` + `CONTENT_TYPE_SPEECH`, so the music ducks under the
    announcement instead of stopping. A failed init drops the engine and can be retried; nothing
    throws. The jvmMain actual is a no-op.
  - **Package visibility** (`androidApp/src/main/AndroidManifest.xml`, which `vivoAndroidApp` also
    uses): an app targeting API 30+ only sees other apps' services that its manifest asks for, so
    the existing audio-effect `<queries>` gained
    `<intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>`. Without it no
    engine binds and the engine list comes back empty even on phones that have one.
  - **`speechAvailability(): StateFlow<Boolean?>`** (expect beside `speakAnnouncement`; `null` =
    not known yet) says whether a voice exists. The first call in the androidMain `Speaker` runs a
    cheap `PackageManager.queryIntentServices(Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE))`
    probe, so no engine is created just to draw the sheet; init refines the answer, and a
    non-SUCCESS status, a throw, or no voice data for both the default locale and `Locale.US` set it
    to `false`. jvmMain returns a constant `MutableStateFlow(false)`.
  - When that flow is `false` on Android, `HeadsetControls.kt` shows one muted `typo().bodySmall`
    line under the slider: `headset_speech_unavailable` ("Install a text-to-speech app to hear the
    strength"). Retro and the other themes alike; it is gated on `getPlatform() == Platform.Android`
    because Desktop always reports `false` and has no voice to miss.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **Retro Pixel: modern and retro at once (2026-10-26).**
  - **Direction** (chosen from the ui-ux-pro-max skill output for the Pixel Art style, the Arcade &
    Retro palette, retro-futurism and a Terminal monospace body): "neo-retro terminal-modern" —
    pixel display type over readable terminal body copy, a deep blue-black ink ground with one neon
    green, and CRT texture only where it frames content instead of filtering it.
  - **Two faces** (`ui/theme/Typo.kt`, `ui/theme/ThemeDesign.kt`): VT323 now only carries display,
    headline, title and label styles; body copy uses the already-bundled **Space Mono**
    (`space_mono_regular`, OFL, Vietnamese coverage) at 16/14/12sp with `lineHeight = 1.45 × size`.
    A new `LocalAppBodyFontFamily` (provided by `AppTheme`, `ui/theme/Theme.kt`) lets a theme pair
    two faces; `retroTypography` takes `displayFamily` + `bodyFamily`.
  - **Palette** (`ui/theme/AppThemes.kt`, `retroColorScheme`): dark bg `#0B0E16`, surface `#10141E`,
    the surface ramp `#161B27` / `#1D2331` / `#252C3D`, text `#E9EBF2`, secondary text `#9AA5B8`,
    outline `#7C8599`, primary `#22C55E`, secondary `#FF5C8A`, tertiary `#22D3EE`; light cream
    `#F6F1E4` / `#FFFCF4`, green `#1B6B36`, outline `#656D79`.
  - **Shapes** (`ui/theme/AppThemes.kt`, `ui/theme/ThemeDesign.kt`): `RetroShapes` 6/2, 10/2, 12/3,
    16/3, 20/4 and the Retro `AppShapes` follow the same smaller corners (cards/artwork 6/2, hero
    12/3, navBar 10/2, navIndicator/searchButton/pill/avatar 6).
  - **Scanlines** (`ui/theme/Theme.kt`, `ui/screen/home/HomeScreen.kt`): the full-screen CRT layer
    is gone. `RetroScanlines` became the public `Modifier.retroScanlines(spacing = 3.dp, alpha ?=
    4.5% dark / 3% light)`, applied only to the Home header surface, behind its labels and chips, so
    artwork and body copy below stay clean.
  - **Pixel shadow with glow** (`ui/theme/ThemeDesign.kt`, `Modifier.pixelShadow`): the default hard
    frame is now a 1.5dp border plus a 2dp offset in `#05070C` (no blur), with an optional
    `glowColor` drawn as two hard strokes (22% at +3dp, 10% at +7dp) rather than a blur. The glow
    marks selected Retro chips (`ui/component/ChipGroup.kt`, which also turns the selected border
    to `primary`), the nav indicator and the selected Search FAB
    (`ui/component/AppBottomNavigationBar.kt`) and the radio-mix thumb
    (`ui/component/RadioMixBar.kt`).
  - **Home details** (`ui/component/AdapterItems.kt`, `ui/screen/home/HomeScreen.kt`): the mood-card
    stripe went 10dp → 6dp (and the padding now sits inside the pixel frame), and the Retro chip
    row uses 6dp gaps and 10dp vertical padding (still 4dp/8dp elsewhere).
  - **Upstream files touched, for the next sync**: `ui/theme/AppThemes.kt`, `ui/theme/Theme.kt`,
    `ui/theme/ThemeDesign.kt`, `ui/theme/Typo.kt`, `ui/component/ChipGroup.kt`,
    `ui/component/AppBottomNavigationBar.kt`, `ui/component/RadioMixBar.kt`,
    `ui/component/AdapterItems.kt`, `ui/screen/home/HomeScreen.kt`, plus the ANC pair
    (`ui/screen/player/HeadsetControls.kt`, `ui/screen/player/SpeakAnnouncement*.kt`) and
    `composeResources/values/strings.xml`. No `core/` changes.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **Retro Pixel borders become pixel-grid frames (2026-10-26).**
  - **`Modifier.pixelFrame(selected, color, bracketColor)`** (`ui/theme/ThemeDesign.kt`) replaces
    `Modifier.pixelShadow`. It draws with `drawWithContent` and filled `drawRect`s only: one unit
    thick on all four sides, where the unit is `round(1.5dp)` floored to whole device pixels
    (minimum 2px, so 2px at 1x and 4px at 2.75x). Each side's corner unit is left empty, so the
    corners are stepped 8-bit notches rather than joints; bounds are snapped to whole pixels.
    A hard drop shadow of the same notched outline is drawn first, one unit right and down, in
    `#05070C` on the dark theme and a darker cream (`#D3C9B2`) light. `selected` draws the frame
    in `primary` (normal is `outline`) one unit in and adds four 3-unit L-shaped terminal corner
    ticks in the band outside it; the old two-stroke glow is gone. Non-Retro themes return the
    modifier untouched.
  - **Call sites**: Retro chips (`ui/component/ChipGroup.kt`, selected ticks in `onPrimary` so they
    read on the filled chip), the nav indicator and Search FAB (`ui/component/AppBottomNavigationBar.kt`),
    the radio-mix thumb (`ui/component/RadioMixBar.kt`), mood cards and the Wrapped entry card
    (`ui/component/AdapterItems.kt`, `ui/component/WrappedEntryCard.kt`; the mood card's 8dp padding
    now sits outside the frame so it hugs the card). The room-code caret in
    `ui/screen/home/ListenTogetherScreen.kt` uses the same frame as a terminal cursor under Retro.
    Pill-shaped `PixelCornerShape` borders (`appCorner(999.dp)`, accent swatches) were checked and
    left as stepped strokes: a square pixel frame around a capsule would break its silhouette.
  - Upstream files touched, for the next sync: `ui/theme/ThemeDesign.kt`,
    `ui/component/ChipGroup.kt`, `ui/component/AppBottomNavigationBar.kt`,
    `ui/component/RadioMixBar.kt`, `ui/component/AdapterItems.kt`,
    `ui/component/WrappedEntryCard.kt`, `ui/screen/home/ListenTogetherScreen.kt`, plus
    `gradle/libs.versions.toml` (2.4.68 / 138). No `core/` changes.
  - Not verified on a device. ComposeApp JVM compilation passes.
- **Retro Pixel goes more pixelated (2026-10-26).**
  - **`ArtworkImage`** (new, `ui/component/ArtworkImage.kt`) is a drop-in `AsyncImage` replacement
    for artwork: same parameters, same defaults. Under Retro it asks Coil to decode a tiny bitmap
    — `pixelLongSide` 48dp for list rows and 96dp for Now Playing, canvas and backdrop — and draws
    it with `FilterQuality.None`, so covers and backdrops are chunky hard pixels upscaled from a
    thumbnail-sized source. Strings become an `ImageRequest` at that size and an existing
    `ImageRequest` is rebuilt; the URL and disk-cache key stay untouched, and the decode size is
    part of Coil's memory-cache key, so full-size and pixelated versions never collide. Every other
    theme gets the exact call it had before: `AsyncImage` with `FilterQuality.Low`. Wired at 60
    artwork call sites in 26 files (`AdapterItems`, the Now Playing variants, `FullscreenLyrics`
    extras, album/artist/playlist/search/library plants, home rows, MiniPlayer, mood cards,
    `CollapsingToolbar`, `FiveImagesComponent`, episode/taste cards and the rest). **Removed on
    2026-10-26:** pixelated artwork was dropped — Retro now keeps cover photos sharp like every
    other theme (see “Retro Pixel: photos stay sharp, nav icons at full size” below);
    `pixelLongSide` is still accepted but ignored, so call sites did not change.
  - **`Modifier.retroDither`** (`ui/theme/Theme.kt`): a 2×2 ordered-dither checker behind the
    content, one dot per whole device pixel (about 2dp), tiled through an `ImageShader` so a full
    screen is one GPU shader rather than thousands of `drawRect`s. Faint by design — 6% of
    `onBackground` on the dark palette, 5% on the cream one — so it reads as texture and leaves
    text contrast alone. `App.kt` paints it on the app ground and makes Scaffold's `containerColor`
    `Color.Transparent` only under Retro (a flat `Color` cannot carry the checker); the mood cards
    in `ui/component/AdapterItems.kt` use it at 5% inside their frame.
  - **`RetroSliderParts.kt`** (new): `RetroSegmentedTrack` (progress cut into hard, pixel-snapped
    blocks with optional 1-unit borders and an optional per-block ramp colour) and
    `RetroSliderThumb` (square, hard-edged, `pixelFrame(selected = true)` plus its hard shadow, no
    round corners or swell). Wired in Retro-only branches of `FullscreenPlayer`, the Spotify and
    Apple Music Now Playing sliders (the Apple Music thin bar uses 24 segments), `FullscreenLyrics`
    (the lyrics seek and volume bars), `WavySeekBar` and the ANC strength slider in
    `HeadsetControls.kt`, so the Material pill track and round thumb do not survive the theme.
  - **`PixelIcon`** (`ui/component/PixelIcon.kt`): every Retro icon draws on a 16×16 sprite grid
    again. The size-dependent 12×12 grid shipped in 2.4.70 read as too chunky and was reverted in
    2.4.71 at the user's request, so 24dp icons and the 18dp track icons via
    `rememberPixelatedPainter` are back to 16×16, where play arrows and queue lines stay
    recognisable. The improvement is kept: the drawn side is rounded down to a whole number of
    device pixels per cell, so every cell is the same size and no sprite pixel lands between two
    screen pixels. **Superseded on 2026-10-26 by “Retro Pixel becomes a modern pixel theme” below**,
    which moves standard icons to a finer 24×24 grid and a higher coverage threshold.
  - **Upstream files touched, for the next sync**: `App.kt`, `ui/theme/Theme.kt`,
    `ui/component/PixelIcon.kt`, `ui/component/AdapterItems.kt`, `ui/component/CollapsingToolbar.kt`,
    `ui/component/FiveImagesComponent.kt`, `ui/component/FullWidthItems.kt`,
    `ui/component/FullscreenLyricsContent.kt`, `ui/component/HomeSectionStyles.kt`,
    `ui/component/LibraryItem.kt`, `ui/component/LibraryTilingBox.kt`,
    `ui/component/MoodCategoryCard.kt`, `ui/component/PodcastEpisodeItem.kt`,
    `ui/component/taste/TasteCard.kt`, `ui/screen/MiniPlayer.kt`,
    `ui/screen/home/HomeArtistCards.kt`, `ui/screen/home/HomeSongRowStyles.kt`,
    `ui/screen/home/SpotifyHome.kt`, `ui/screen/library/LibraryScreen.kt`,
    `ui/screen/library/LocalPlaylistScreen.kt`, `ui/screen/other/AlbumScreen.kt`,
    `ui/screen/other/ArtistScreen.kt`, `ui/screen/other/PlaylistScreen.kt`,
    `ui/screen/other/SearchScreen.kt`, `ui/screen/player/FullscreenPlayer.kt`,
    `ui/screen/player/HeadsetControls.kt`,
    `ui/screen/player/content/NowPlayingContentAppleMusic.kt`,
    `ui/screen/player/content/NowPlayingContentM3Expressive.kt`,
    `ui/screen/player/content/NowPlayingContentSpotify.kt`,
    `ui/screen/player/content/NowPlayingExpressiveCards.kt`,
    `ui/screen/player/content/applemusic/AppleMusicShared.kt`,
    `ui/screen/player/content/expressive/WavySeekBar.kt`,
    `ui/screen/player/SpeakAnnouncement.android.kt` and
    `composeResources/values/strings.xml`, plus the two new local files
    `ui/component/ArtworkImage.kt` and `ui/component/RetroSliderParts.kt`. No `core/` changes.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **The ANC strength is read by a bundled neural voice (2026-10-26).** The user asked for the calm, warm *Her*-like
  assistant voice, not a phone's system text-to-speech. Nothing was cloned or imitated from a real person: the voice
  is **Kokoro-82M v0.19** (hexgrad, Apache-2.0) voice **af_heart** (speaker id 0), a synthetic model voice. Its model
  card attributes the training data Koniwa (CC BY 3.0) and SIWIS (CC BY 4.0); both are credited in
  `androidApp/src/main/assets/voice/LICENSE.txt` (which also carries the Apache-2.0 text) and mirrored as
  `composeApp/src/commonMain/composeResources/files/licenses/Kokoro-82M-Apache-2.0.txt`, the same way
  `VT323-OFL.txt` credits the Retro font (those files are bundled, not listed in `aboutlibraries.json`, which is
  generated from Gradle dependencies).
  - **Pre-rendered, not on-device.** Running Kokoro on the phone would mean a 100+ MB model (134 MB int8 here) and
    RTF ~0.6–3.5 — several seconds of CPU for a two-second line — and the sherpa-onnx AAR adds ~12 MB to every ABI.
    So the 101 sentences "Noise cancelling at N percent." (N = 0..100) are rendered once on a Linux x86_64 container
    and shipped as `assets/voice/anc_000.ogg .. anc_100.ogg`. sherpa-onnx **1.13.8** is pinned because Kokoro v1.0+
    needs its own lexicon and **v2.0.0 dropped espeak-ng**, which `kokoro-en-v0_19` still uses.
  - **How they were rendered** (`$HOME/work/tts`, not committed): sherpa-onnx v1.13.8 prebuilt linux-x64-shared
    (`sherpa-onnx-v1.13.8-linux-x64-shared.tar.bz2`), model package `kokoro-int8-en-v0_19.tar.bz2`
    (103,248,205 bytes, sha256 `c9f0dd393615805b0bab050c340834d5e684e732aec91c0e860cd30e982c08bd`, verified), command
    `sherpa-onnx-offline-tts --kokoro-model=.../model.int8.onnx --kokoro-voices=.../voices.bin
    --kokoro-tokens=.../tokens.txt --kokoro-data-dir=.../espeak-ng-data --sid=0 --speed=0.95 --num-threads=2
    --output-filename=... "Noise cancelling at N percent"` (24 kHz mono). The int8 build was checked for the known
    ARM glitch and is clean here. Then each WAV is trimmed of leading/trailing silence to a 30 ms pad, peak-normalised
    to -1 dBFS, given 10 ms fades, and encoded with static ffmpeg 7.0.2: `-c:a libopus -b:a 24k -ar 48000 -ac 1
    -application voip -af volume=-1.5dB` (the 1.5 dB pulls the codec's overshoot back under full scale). Result:
    101 files, 722,915 bytes (0.69 MB), 1.75–2.42 s each, decoded peak -2.5..-1.1 dBFS, no clipping.
  - **Playback.** `announceAncStrength(percent, fallbackText)` is the new common `expect` (no-op on JVM).
    androidMain's `AncVoice` plays `voice/anc_%03d.ogg` with `MediaPlayer` (data source from `AssetManager.openFd`,
    so the build keeps `noCompress += "ogg"` in both `androidApp` and `vivoAndroidApp`), `USAGE_ASSISTANCE_ACCESSIBILITY`
    + `CONTENT_TYPE_SPEECH`, transient-may-duck `AudioFocusRequest` (legacy call below API 26) abandoned on
    completion/error, and a new release stops the old clip. Every failure falls back to the system-TTS
    `speakAnnouncement(fallbackText)`, and nothing throws. `vivoAndroidApp` also needed
    `assets.srcDirs(File(androidAppDir, "src/main/assets"))`.
  - **The hint is gone for good.** `speechAvailability()` now reports `true` as soon as the clip asset is found
    (cached), so `headset_speech_unavailable` only appears on a build with no clips *and* no TTS engine.
  - `HeadsetControls.kt` calls `announceAncStrength(value.roundToInt(), spoken)` from `onValueChangeFinished`;
    `headset_percent_spoken` stays as the fallback text. Files touched: `ui/screen/player/SpeakAnnouncement.kt`,
    `SpeakAnnouncement.android.kt`, `SpeakAnnouncement.jvm.kt`, `HeadsetControls.kt`, `androidApp/build.gradle.kts`,
    `vivoAndroidApp/build.gradle.kts`, the `voice/` assets, the licences file and `gradle/libs.versions.toml`.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **Swiss and Neo-Brutalism themes (2026-10-26).** Two new entries in Settings → App theme, on top of the five
  named themes. The ui-ux-pro-max skill drove both: `--domain style "minimalism swiss style"` returned
  **Minimalism & Swiss Style** (monochrome black/white, grid, no shadows/gradients, 0 radius, one accent, 4.5:1
  text, visible focus); `--domain style "neubrutalism neo brutalism"` returned **Brutalism** (pure saturated
  primaries, 2–4px visible borders, 0 radius, weight 700+, instant transitions); `--domain typography "music app
  bold geometric sans"` suggested Kinetic Brutalism (Space Grotesk 700–900) / Bauhaus Geometric (Outfit 900), and
  `--domain color "music player app minimal high contrast"` + `--design-system "music streaming player mobile app
  minimal"` returned the usual dark-audio palette (#1E1B4B/#4338CA/#22C55E) and Righteous/Poppins pairing. The
  fonts were **not** adopted: the brief asks for the system sans, so both themes use `FontFamily.SansSerif`, with
  weight/tracking in `typo()` (no new bundled font or licence). The dark-audio palette was reference only; the
  brief's cream/ink and black/red palettes won.
  - **Palettes** (`ui/theme/AppThemes.kt`, `swissColorScheme`, `brutalColorScheme`, light + dark). Swiss light
    bg/surface `#FFFFFF`, ink `#111111`, accent `#E30613`, hairline `#DADADA`, greys `#F5F5F5`/`#EFEFEF`;
    dark bg `#0B0B0B`, surface `#101010`, ink `#F5F5F5`, accent `#FF5A5F`, hairline `#333333`. Brutalism light
    bg/surface `#FFF8E7`, ink/border `#111111`, hot pink `#FF2E93`, cobalt `#0047FF`, electric yellow `#FFE600`,
    mint `#00E5A0`; dark bg `#0B0B0B`, surface `#141414`, ink/border `#FAFAFA`, pink `#FF4DA6`, blue `#6B91FF`,
    mint `#33FFC1`. Text roles clear 4.5:1 on their own surface (ink on cream ≈18:1; ink on the bright accents
    ≥4.5:1).
  - **Shapes**: `AppShapes`/Material `Shapes` — Swiss `SwissShapes` 0/1/2dp and cards/artwork/chips 0–2dp;
    Brutalism `BrutalShapes` 1/2/3/4/6dp and cards 3–6dp. `appCorner` also caps hard-coded radii at 2dp (Swiss)
    and 4dp (Brutalism), so sheets/dialogs follow the style; other themes keep their exact previous radii.
  - **Type** (`ui/theme/Typo.kt`): new `AppTypeStyle` + `LocalAppTypeStyle`, provided by `AppTheme` and passed
    explicitly when it builds Material typography. Swiss: system sans, Bold/Black headings, titleLarge 27sp,
    headlineLarge 26sp, tightening letter-spacing −0.5/−0.7sp. Brutalism: system sans Black display/headlines,
    ExtraBold titles, Medium body, near-neutral tracking. `LocalAppFontFamily` still carries the face, so every
    screen using `typo()` follows.
  - **`Modifier.brutalFrame(selected)`** (`ui/theme/ThemeDesign.kt`): gated on `AppThemeFamily.BRUTALISM`; draws a
    solid shadow rect offset 4dp down-right, then the content, then a 2.5dp `Stroke` in `outline`. No blur/elevation.
    Selected/pressed translates content+frame 3dp towards the shadow, shrinking the visible band to ~1dp. Shadow is
    `#111111` on light and the ink colour (white) on dark, where black would vanish. Call sites mirror Retro's
    `pixelFrame`: `ChipGroup` (chips), `AppBottomNavigationBar` (flat nav indicator + Search FAB), `AdapterItems`
    (mood cards), `WrappedEntryCard`, `RadioMixBar` (thumb; frame placed outside the fill). Cards drop their 6dp
    elevation under Brutalism.
  - **Chips**: `AppChipStyle.SWISS` — transparent with a 1dp hairline, fills with `onSurface` (black light / white
    dark) and `onPrimary` label when selected. `AppChipStyle.BRUTAL` — filled `surfaceVariant`/`primary`, 2dp ink
    border both states, plus `brutalFrame`.
  - **Picker** (`ui/screen/home/ThemePicker.kt`): two new swatches. Swiss draws a white/near-black card with the
    accent bar and two ink text rules; Brutalism draws a flat colour block with a 2dp ink border and a 4dp hard
    offset shadow. Labels `theme_color_swiss` "Swiss" and `theme_color_brutalism` "Neo-Brutalism" in
    `composeResources/values/strings.xml`. The independent Accent override still replaces primary/secondary/tertiary.
  - **Home** (`ui/screen/home/HomeScreen.kt`): both themes use the flat (no artwork-gradient) header. Desktop shell
    picks up both palettes through `usesThemedShell()`.
  - Core commit for the ids: `439fa44` (`THEME_COLOR_SWISS`, `THEME_COLOR_BRUTALISM`).
  - **Upstream files touched, for the next sync**: `core/domain/.../DataStoreManager.kt` (two constants),
    `ui/theme/Theme.kt`, `ui/theme/Typo.kt`, `ui/component/ChipGroup.kt`, `ui/component/AppBottomNavigationBar.kt`,
    `ui/component/AdapterItems.kt`, `ui/component/RadioMixBar.kt`, `ui/component/WrappedEntryCard.kt`,
    `ui/screen/home/HomeScreen.kt`, `composeResources/values/strings.xml`. Private: `ui/theme/ThemeDesign.kt`,
    `ui/theme/AppThemes.kt`, `ui/screen/home/ThemePicker.kt`.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **Retro Pixel becomes a modern pixel theme (2026-10-26).**
  - **The skill** (`~/.claude/skills/ui-ux-pro-max`, read `SKILL.md`, queried `--domain style`
    “modern pixel art ui refined” / “pixel art” and `--domain icons` “icon stroke weight thin
    crisp”, `--domain ux` “bottom navigation selected indicator”): the `pixel-art` entry asks for
    pixel fonts, sharp no-anti-alias edges, a limited palette and hard pixel borders, but its
    “blocky UI / 4px pixel border / blocky layout” checklist is what made Retro chunky. Its
    Minimalism & Swiss entry and the icon guidance (24px outline icons at `regular`/`thin` weight,
    one family per surface) were used to restrain it: keep the pixel *detail* in glyphs, corners
    and a single accent, drop the heavy frames, shadows and oversized controls. Nothing was
    persisted from the skill and no package was installed.
  - **Pixel icons** (`ui/component/PixelIcon.kt`): the sprite grid now follows the icon size. At
    ≤20dp it stays 16×16; at standard 24dp (nav, top bar, menu rows, player controls) it is a
    24×24 grid. One sprite pixel is about 1dp: the cell is rounded to whole device pixels and the
    grid takes as many cells as fit the requested size exactly (24dp at 2.75× is 22 cells of 3px),
    so the icon keeps its nominal size instead of shrinking to a floored 16-cell sprite. Coverage
    thresholds are 0.34 on the coarse grid (slightly thinner than the old 0.3) and 0.46 on the
    fine grid, so a 1dp Material stroke stays one cell thin and diagonals stop fattening into
    blobs; sampling went from 4× to 6× per cell for a better coverage estimate. The sprite is
    cached per (vector, grid, coverage); `rememberPixelatedPainter` uses the fine grid. Other
    themes still get the plain Material `Icon`.
  - **Navigation** (`ui/component/AppBottomNavigationBar.kt`): the selected tab no longer gets
    `pixelFrame` — no notched border, hard shadow or corner brackets. The indicator is a 14%-alpha
    `primary` wash with the stepped `navIndicator` corners, plus a 16×2dp `primary` pixel bar at its
    bottom edge; the selected icon is `primary`, unselected `onSurfaceVariant`, labels stay VT323 at
    their normal size. The Search FAB is a flat square-ish button with a thin 1-unit pixel border
    (`pixelFrame(shadow = false)`, `primary` when selected, `outline` otherwise) and no drop shadow.
    The nav rail uses `NavigationRailItemDefaults.colors` in the same language — 14%-alpha primary
    indicator, primary selected icon/label, `onSurfaceVariant` unselected, no grey filter — instead
    of the Material secondary-container pill. Retro motion is still `snap()`.
  - **Three-dots sheet** (`ui/component/ModalBottomSheet.kt`): every icon row already draws through
    `ThemedIcon`, so the fine grid gives `ActionButton` its 24dp icon at normal stroke weight with
    no frames or shadows; row height (48dp) and 20dp/10dp padding are unchanged, labels stay
    `labelSmall` (VT323). The heart in `CheckBoxActionButton` is 24dp under Retro (still 30dp for
    the other themes), matching the rows around it. The download progress ring is unchanged.
  - **Pixel frames** (`ui/theme/ThemeDesign.kt`): `pixelFrame` unit is now round(1dp) in whole
    device pixels, floored at 2px only at ≤2× density (3px instead of the old 4px at 2.75×), the
    non-selected hard shadow is drawn at 55% alpha, and a new `shadow = false` parameter lets a
    caller drop it. Notched corners and the four selected corner brackets stay; chips, mood cards
    and Wrapped cards keep using the frame, the nav no longer does.
  - **Upstream files touched, for the next sync**: `ui/component/PixelIcon.kt`,
    `ui/component/AppBottomNavigationBar.kt`, `ui/component/ModalBottomSheet.kt`,
    `ui/theme/ThemeDesign.kt` and `gradle/libs.versions.toml` (2.4.74 / 144). No `core/` changes.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **Retro Pixel: photos stay sharp, nav icons at full size (2026-10-26).** Two follow-ups to the Retro Pixel work,
  both gated so every other theme is untouched.
  - **Artwork no longer pixelates** (`ui/component/ArtworkImage.kt`): the Retro-only branch that decoded covers at
    `pixelLongSide` (48dp for list rows, 96dp for Now Playing, canvas and backdrop) and drew them with
    `FilterQuality.None` is gone. Every theme now gets a plain `AsyncImage` with Coil's default `FilterQuality.Low`;
    the URL and disk-cache behaviour are unchanged, and no Retro request/decode size is ever built. `pixelLongSide`
    stays in the signature (ignored) so the 60 artwork call sites did not change. Icons still pixelate through
    `ThemedIcon`; a grep for `FilterQuality.None`, `pixelLongSide` and `retroDither` found no other photo
    pixelation (`retroDither` only paints the app ground and the mood-card background).
  - **Nav icons are Material's 24dp again** (`ui/component/PixelIcon.kt`): Retro icons took their size from the
    parent's bounded constraints — the 64dp nav tab slot or the rail indicator — instead of Material `Icon`'s 24dp,
    and then drew the sprite at `cellPx × grid`, the grid rounded to whole device pixels. That made the bottom bar,
    the flat Android bar, the nav rail and the Search FAB render at a size of their own. `ThemedIcon` without an
    explicit modifier now applies `Modifier.size(24.dp)` (a caller's own size still wins, and `size` still coerces
    to the parent exactly like `Icon`), and the pixel bitmap is always stretched to that full box with
    `FilterQuality.None` instead of being drawn at the rounded cell size. Nav icons therefore keep the default
    theme's rendered size and position, drawn with the fine 24×24 sprite; the light nav indicator is unchanged.
  - Files touched: `ui/component/ArtworkImage.kt`, `ui/component/PixelIcon.kt`, `gradle/libs.versions.toml`
    (2.4.75 / 145). No `core/` changes.
  - Not verified on a device. ComposeApp JVM and Android compilation pass.
- **ANC voice matches its label; Retro nav rounder, with a subtle glitch (2026-10-26).**
  - **The mismatch** (`ui/screen/player/HeadsetControls.kt`): the slider kept the dragged value
    as a `Float`, rounded it separately for the readout, the write and the voice, and
    `onValueChangeFinished` announced a `value` captured from the last composition. A tap (or the
    last drag frame) can finish before that composition applies, so the clip was chosen from the
    previous percent while the readout redrew the new one — a 30% label with a 32% voice. The
    headset read-back was not the cause: `HeadsetRepositoryImpl.setStrength` and
    `Momentum4Headset.setStrength` already coerce an `Int` and write the exact
    `100 - strength` level, no float rounding.
  - **Fix**: drag state is an `Int?` (`draggedPercent`); the `Slider` has `steps = 99`, so the
    thumb has 101 whole-percent stops; one `percent` Int (coerced 0..100) now drives the label,
    the semantics, `repository.setStrength(percent)` and the release announcement. The finished
    callback reads the live state at release instead of a composition value, and the fallback TTS
    sentence is built from the raw `headset_percent_spoken` template with that same Int, so it
    cannot lag either. The Retro `RetroSegmentedTrack`/`RetroSliderThumb` branch is unchanged and
    sits on the same `percent`.
  - **Retro nav shapes** (`ui/theme/ThemeDesign.kt`, `ui/component/AppBottomNavigationBar.kt`):
    `navBar` is now `PixelCornerShape(32.dp, step = 2.dp)` (a 64dp bar, so a near-pill cut into
    ~16 stair steps), `navIndicator` and `searchButton` are `PixelCornerShape(28.dp, 2.dp)` (56dp,
    ~14 steps). Steps stay on whole device pixels via the existing `snapPx`. The flat bar
    (`FlatTabBar`, also used by the liquid-glass-off Android bar) and its sliding indicator pick
    the shapes up from `LocalAppShapes`; the Search FAB's square `pixelFrame` was replaced with a
    1dp outline on the stepped shape (a square frame around a capsule would break its
    silhouette). The nav rail hides Material's indicator and draws the same 56x32 stepped pill
    behind the 24dp icon via `drawBehind`, so layout and icon size are untouched. Other themes keep
    their exact shapes.
  - **Retro glitch** (`ui/theme/ThemeDesign.kt`, `Modifier.retroGlitch()`; applied to the Retro
    nav capsule in `FlatTabBar`): a `LaunchedEffect` sleeps a random 8–14s, then for a random
    120–180ms two tinted copies of the content (secondary pink + tertiary cyan, 28% alpha,
    `BlendMode.SrcIn`) are drawn via `saveLayer` at ±1–2dp (whole device pixels) behind the normal
    content, so only a thin chromatic fringe shows and labels stay fully readable. The burst flag
    is read in `drawWithContent`, so an idle screen costs no per-frame work and a burst invalidates
    one draw, not the composition. No layout, clip, touch target or other theme changes.
  - **Skill guidance** (`~/.claude/skills/ui-ux-pro-max`): `--domain style "glitch effect subtle"`
    returned Cyberpunk UI and Retro-Futurism — glitch offsets are acceptable but must be subtle
    (their variable is a 0.3s glitch), with reduced-motion called out; `--domain ux "motion
    reduced"` returned Reduced Motion / Excessive Motion / Motion Sensitivity (severity High:
    honour the motion preference, animate 1–2 key elements per view). There is no reduced-motion
    setting in the app, so this uses one element, a 120–180ms burst, no skew/glow, and the lowest
    amplitude and alpha.
  - Files touched: `ui/screen/player/HeadsetControls.kt`, `ui/theme/ThemeDesign.kt`,
    `ui/component/AppBottomNavigationBar.kt`, `gradle/libs.versions.toml` (2.4.76 / 146). No
    `core/` changes. Not verified on a device. ComposeApp JVM and Android compilation pass.
