package com.maxrave.simpmusic.ui.component

import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.compose.AsyncImagePainter

/**
 * Album/song/playlist/artist artwork.
 *
 * Every theme gets the same draw as [AsyncImage] with Coil's default [FilterQuality.Low]. The
 * Retro Pixel theme used to decode a tiny bitmap here and upscale it with [FilterQuality.None],
 * which turned covers and backdrops into chunky hard pixels; that was removed at the user's
 * request, so photos stay sharp under Retro too. Icons are unchanged and still pixelate through
 * [ThemedIcon].
 *
 * Drop-in replacement for `AsyncImage` in artwork call sites: same named parameters, same defaults.
 * [pixelLongSide] is kept only so existing call sites compile; it no longer has any effect.
 */
@Composable
fun ArtworkImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    placeholder: Painter? = null,
    error: Painter? = null,
    fallback: Painter? = error,
    onLoading: ((AsyncImagePainter.State.Loading) -> Unit)? = null,
    onSuccess: ((AsyncImagePainter.State.Success) -> Unit)? = null,
    onError: ((AsyncImagePainter.State.Error) -> Unit)? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    alpha: Float = 1f,
    colorFilter: ColorFilter? = null,
    clipToBounds: Boolean = true,
    @Suppress("UNUSED_PARAMETER") pixelLongSide: Dp = 48.dp,
) {
    AsyncImage(
        model = model,
        contentDescription = contentDescription,
        modifier = modifier,
        placeholder = placeholder,
        error = error,
        fallback = fallback,
        onLoading = onLoading,
        onSuccess = onSuccess,
        onError = onError,
        alignment = alignment,
        contentScale = contentScale,
        alpha = alpha,
        colorFilter = colorFilter,
        filterQuality = FilterQuality.Low,
        clipToBounds = clipToBounds,
    )
}
