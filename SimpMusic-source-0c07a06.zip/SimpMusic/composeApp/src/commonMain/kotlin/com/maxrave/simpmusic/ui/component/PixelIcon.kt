package com.maxrave.simpmusic.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily
import kotlin.math.roundToInt

/**
 * Retro Pixel's icons are rasterised into a sprite grid and then drawn with no smoothing.
 * A 24×24 grid at the standard icon size makes the picture read as a crisp pixel-art version of
 * the Material symbol at its normal weight; the coarser 16×16 grid is kept only for small icons
 * (≤20dp), where 24 cells would disappear into the screen pixels. The grid is only the sprite's
 * resolution: the bitmap is always scaled to the full requested box with [FilterQuality.None],
 * so the icon keeps exactly the size Material's 24dp [Icon] would have (nav bars, rail, Search
 * FAB), even when the grid does not divide into the box in whole device pixels.
 */
private const val COARSE_GRID = 16
private const val FINE_GRID = 24

/** The vector is rendered this many times larger, then reduced to hard on/off pixels. */
private const val SAMPLE_SCALE = 6

/**
 * A cell becomes a solid pixel when this much of it was covered by the vector. Anything less is
 * dropped, which removes the grey anti-aliased fringe that made the old icons look blurry. The
 * fine grid uses a higher threshold so a 1dp Material stroke stays one cell thin instead of
 * swelling into a bold blob; the coarse grid needs slightly less to keep small glyphs readable.
 */
private const val COARSE_COVERAGE = 0.34f
private const val FINE_COVERAGE = 0.46f

/** Below this grid size an icon is drawn as [COARSE_GRID]; at or above it, as a fine sprite. */
private const val FINE_GRID_THRESHOLD = 20

/**
 * Private copy: every icon under the Retro Pixel theme is drawn as a coarse pixel grid instead of
 * a smooth vector, the way an 8-bit icon set would look. Other themes get the normal Material icon.
 * The pixel grid is cached per vector; tinting and scaling stay at draw time.
 */
@Composable
fun ThemedIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    if (LocalAppThemeFamily.current == AppThemeFamily.RETRO) {
        PixelIcon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    } else {
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint,
        )
    }
}

@Composable
private fun PixelIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier,
    tint: Color,
) {
    val painter = rememberVectorPainter(imageVector)
    val density = LocalDensity.current
    // Material's Icon always draws its painter at the vector's 24dp intrinsic size unless the
    // caller's own modifier sizes it; it ignores the bounds its parent happens to hand it. Retro
    // must do the same, otherwise a nav tab's 64dp-tall slot (or the rail indicator) would decide
    // the icon size. Callers that do pass a Modifier.size keep it, and size() still coerces to
    // whatever the parent allows, exactly like Icon.
    val sized = if (modifier == Modifier) Modifier.size(24.dp) else modifier
    BoxWithConstraints(modifier = sized) {
        val bounded = constraints.hasBoundedWidth && constraints.hasBoundedHeight
        val side = if (bounded) minOf(maxWidth, maxHeight) else 24.dp
        val sidePx = with(density) { side.toPx() }.toInt().coerceAtLeast(1)
        // One sprite pixel is about 1dp: pick the cell size in whole device pixels, then let the
        // grid take as many cells as fit the icon. 24dp at 2.75× becomes 22 cells of 3px. The
        // sprite is only the resolution — it is drawn at the full side below, never at cellPx ×
        // grid, so a grid that misses the box by a rounding pixel does not shrink the icon.
        val targetGrid = if (side <= 20.dp) COARSE_GRID else FINE_GRID
        val cellPx = (sidePx.toFloat() / targetGrid).roundToInt().coerceAtLeast(1)
        val grid = (sidePx / cellPx).coerceIn(8, 40)
        val coverage = if (grid >= FINE_GRID_THRESHOLD) FINE_COVERAGE else COARSE_COVERAGE
        val pixelated = remember(imageVector, grid, coverage) { pixelate(painter, grid, coverage) }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Image(
                bitmap = pixelated,
                contentDescription = contentDescription,
                modifier = Modifier.size(side),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(tint),
                filterQuality = FilterQuality.None,
            )
        }
    }
}

/**
 * The same hard-edged pixel mask for a painter that is drawn directly rather than through
 * [ThemedIcon] — the radio-mix slider's end icons, for example.
 */
@Composable
internal fun rememberPixelatedPainter(painter: Painter): Painter {
    val bitmap = remember(painter) { pixelate(painter, FINE_GRID, FINE_COVERAGE) }
    return remember(bitmap) { BitmapPainter(bitmap, filterQuality = FilterQuality.None) }
}

/**
 * Render the vector large, measure how much of each grid cell it covers, and paint a fresh bitmap
 * with fully opaque or fully transparent pixels. The result has no soft edges for the upscaler to
 * smear, so an icon stays crisp at every size.
 */
private fun pixelate(
    painter: Painter,
    grid: Int,
    coverage: Float,
): ImageBitmap {
    val sampleGrid = grid * SAMPLE_SCALE
    val sample = ImageBitmap(sampleGrid, sampleGrid)
    CanvasDrawScope().draw(
        density = Density(1f),
        layoutDirection = LayoutDirection.Ltr,
        canvas = Canvas(sample),
        size = Size(sampleGrid.toFloat(), sampleGrid.toFloat()),
    ) {
        with(painter) {
            draw(Size(sampleGrid.toFloat(), sampleGrid.toFloat()))
        }
    }
    val source = sample.toPixelMap()
    val cell = SAMPLE_SCALE
    val pixels = ImageBitmap(grid, grid)
    CanvasDrawScope().draw(
        density = Density(1f),
        layoutDirection = LayoutDirection.Ltr,
        canvas = Canvas(pixels),
        size = Size(grid.toFloat(), grid.toFloat()),
    ) {
        for (y in 0 until grid) {
            for (x in 0 until grid) {
                var alpha = 0f
                for (sampleY in 0 until cell) {
                    for (sampleX in 0 until cell) {
                        alpha += source[x * cell + sampleX, y * cell + sampleY].alpha
                    }
                }
                alpha /= (cell * cell).toFloat()
                if (alpha >= coverage) {
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(x.toFloat(), y.toFloat()),
                        size = Size(1f, 1f),
                    )
                }
            }
        }
    }
    return pixels
}
