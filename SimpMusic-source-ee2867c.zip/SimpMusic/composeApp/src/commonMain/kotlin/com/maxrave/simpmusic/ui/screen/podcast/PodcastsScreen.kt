package com.maxrave.simpmusic.ui.screen.podcast

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.maxrave.domain.data.model.podcast.FeedPodcast
import com.maxrave.domain.data.model.podcast.PodcastSuggestion
import com.maxrave.simpmusic.ui.icon.Refresh
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.navigation.destination.podcast.PodcastFeedDestination
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.PodcastFeedsViewModel
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.podcasts_add_failed
import simpmusic.composeapp.generated.resources.podcasts_because
import simpmusic.composeapp.generated.resources.podcasts_empty
import simpmusic.composeapp.generated.resources.podcasts_follow
import simpmusic.composeapp.generated.resources.podcasts_new_episodes
import simpmusic.composeapp.generated.resources.podcasts_privacy
import simpmusic.composeapp.generated.resources.podcasts_recommended
import simpmusic.composeapp.generated.resources.podcasts_refresh
import simpmusic.composeapp.generated.resources.podcasts_retry
import simpmusic.composeapp.generated.resources.podcasts_starters
import simpmusic.composeapp.generated.resources.podcasts_suggestions_failed
import simpmusic.composeapp.generated.resources.podcasts_tab
import simpmusic.composeapp.generated.resources.podcasts_yours

/**
 * Private copy: the Podcasts tab. Podcasts are followed by pasting an address (RSS feed, podcast
 * page, YouTube channel or playlist); their newest episodes are listed together, and podcasts
 * like them are suggested from Apple's public directory.
 */
@Composable
fun PodcastsScreen(
    innerPadding: PaddingValues,
    navController: NavController,
    onScrolling: (onTop: Boolean) -> Unit = {},
    viewModel: PodcastFeedsViewModel = koinViewModel(),
) {
    val podcasts by viewModel.podcasts.collectAsStateWithLifecycle()
    val latest by viewModel.latest.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val suggestions by viewModel.suggestions.collectAsStateWithLifecycle()
    val adding by viewModel.adding.collectAsStateWithLifecycle()
    val addError by viewModel.addError.collectAsStateWithLifecycle()
    val refreshing by viewModel.refreshing.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val searching by viewModel.searching.collectAsStateWithLifecycle()
    val nowPlaying by viewModel.nowPlayingVideoId.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { viewModel.openTab() }

    val listState = rememberLazyListState()
    val atTop by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }
    LaunchedEffect(listState) { snapshotFlow { atTop }.collect { onScrolling(it) } }

    val byId = remember(podcasts) { podcasts.orEmpty().associateBy { it.id } }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = innerPadding.calculateBottomPadding() + 24.dp),
    ) {
        item(key = "header") {
            Row(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .padding(start = 16.dp, end = 8.dp, top = 16.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(Res.string.podcasts_tab),
                    style = typo().titleLarge.copy(fontSize = 30.sp, lineHeight = 34.sp),
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.weight(1f),
                )
                if (!podcasts.isNullOrEmpty()) {
                    if (refreshing) {
                        CircularProgressIndicator(modifier = Modifier.padding(12.dp).size(22.dp), strokeWidth = 2.dp)
                    } else {
                        IconButton(onClick = viewModel::refresh) {
                            Icon(SimpIcons.Refresh, contentDescription = stringResource(Res.string.podcasts_refresh))
                        }
                    }
                }
            }
        }
        item(key = "add") {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Private copy: one bar. A name searches Apple's directory as it is typed; an address
                // turns the lens into a +, which follows it.
                PodcastBar(
                    adding = adding != null,
                    searching = searching,
                    onQueryChange = viewModel::search,
                    onAdd = { input ->
                        viewModel.add(input) { podcast -> navController.navigate(PodcastFeedDestination(podcastId = podcast.id)) }
                    },
                )
                searchResults.forEach { suggestion ->
                    PodcastSearchResultRow(
                        title = suggestion.title,
                        author = suggestion.author,
                        imageUrl = suggestion.imageUrl,
                    ) {
                        viewModel.add(suggestion.feedUrl) { podcast -> navController.navigate(PodcastFeedDestination(podcastId = podcast.id)) }
                    }
                }
                addError?.let { error ->
                    Text(
                        text = stringResource(Res.string.podcasts_add_failed, error),
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 24.dp).clickable { viewModel.clearAddError() },
                    )
                }
            }
        }

        val followed = podcasts
        when {
            followed == null -> {
                item(key = "loading") {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                }
            }

            followed.isEmpty() -> {
                item(key = "empty") {
                    MutedText(stringResource(Res.string.podcasts_empty), Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
                }
            }

            else -> {
                item(key = "yours") {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        SectionHeader(stringResource(Res.string.podcasts_yours))
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            items(followed, key = { it.id }) { podcast ->
                                PodcastCard(podcast) { navController.navigate(PodcastFeedDestination(podcastId = podcast.id)) }
                            }
                        }
                    }
                }
                if (latest.isNotEmpty()) {
                    item(key = "latest-header") {
                        Spacer(Modifier.height(12.dp))
                        SectionHeader(stringResource(Res.string.podcasts_new_episodes))
                    }
                    itemsIndexed(latest, key = { _, episode -> "latest-" + episode.id }) { index, episode ->
                        EpisodeRow(
                            episode = episode,
                            podcastTitle = byId[episode.podcastId]?.title,
                            progress = progress[episode.id],
                            playing = nowPlaying == episode.id,
                        ) { viewModel.playLatest(index) }
                    }
                }
            }
        }

        item(key = "suggestions") {
            Column {
                Spacer(Modifier.height(16.dp))
                SectionHeader(
                    stringResource(if (podcasts.isNullOrEmpty()) Res.string.podcasts_starters else Res.string.podcasts_recommended),
                )
                when (val state = suggestions) {
                    PodcastFeedsViewModel.Suggestions.Loading -> {
                        Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    }

                    PodcastFeedsViewModel.Suggestions.Failed -> {
                        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            MutedText(stringResource(Res.string.podcasts_suggestions_failed), Modifier.weight(1f))
                            Text(
                                text = stringResource(Res.string.podcasts_retry),
                                style = typo().labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.clip(CircleShape).clickable { viewModel.loadSuggestions() }.padding(12.dp),
                            )
                        }
                    }

                    is PodcastFeedsViewModel.Suggestions.Ready -> {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            items(state.list, key = { it.feedUrl }) { suggestion ->
                                SuggestionCard(
                                    suggestion = suggestion,
                                    adding = adding == suggestion.feedUrl,
                                    onOpen = { navController.navigate(PodcastFeedDestination(feedUrl = suggestion.feedUrl)) },
                                    onFollow = { viewModel.add(suggestion.feedUrl) },
                                )
                            }
                        }
                    }
                }
            }
        }
        item(key = "privacy") {
            MutedText(stringResource(Res.string.podcasts_privacy), Modifier.padding(horizontal = 24.dp, vertical = 20.dp))
        }
    }
}

@Composable
private fun PodcastCard(
    podcast: FeedPodcast,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier.width(128.dp).clip(PodcastArtShape).clickable { onClick() },
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Artwork(podcast.imageUrl, 128.dp)
        Text(
            text = podcast.title,
            style = typo().labelMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        podcast.author?.let { MutedText(it, maxLines = 1) }
    }
}

@Composable
private fun SuggestionCard(
    suggestion: PodcastSuggestion,
    adding: Boolean,
    onOpen: () -> Unit,
    onFollow: () -> Unit,
) {
    Column(
        modifier = Modifier.width(148.dp).clip(PodcastArtShape).clickable { onOpen() },
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Artwork(suggestion.imageUrl, 148.dp)
        Text(
            text = suggestion.title,
            style = typo().labelMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        suggestion.author?.let { MutedText(it, maxLines = 1) }
        MutedText(stringResource(Res.string.podcasts_because, suggestion.because), maxLines = 1)
        Box(
            modifier =
                Modifier
                    .height(34.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable(enabled = !adding) { onFollow() }
                    .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (adding) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text(stringResource(Res.string.podcasts_follow), style = typo().labelMedium, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}
