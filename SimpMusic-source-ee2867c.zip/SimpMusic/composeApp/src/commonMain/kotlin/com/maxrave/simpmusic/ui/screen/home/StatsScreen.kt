package com.maxrave.simpmusic.ui.screen.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.maxrave.common.RequestLog
import com.maxrave.domain.data.model.headset.BatteryPoint
import com.maxrave.domain.repository.HeadsetRepository
import com.maxrave.simpmusic.expect.networkHistory
import com.maxrave.simpmusic.ui.icon.ArrowBackIosNew
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.seed
import com.maxrave.simpmusic.ui.theme.typo
import kotlinx.coroutines.delay
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import kotlin.time.Instant
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.statistics
import simpmusic.composeapp.generated.resources.statistics_headphones
import simpmusic.composeapp.generated.resources.statistics_network
import simpmusic.composeapp.generated.resources.statistics_no_data
import simpmusic.composeapp.generated.resources.statistics_peak
import simpmusic.composeapp.generated.resources.statistics_requests
import simpmusic.composeapp.generated.resources.statistics_requests_empty
import simpmusic.composeapp.generated.resources.clear

/**
 * Private copy: graphs of the headphones' battery over time and of the download speed over time.
 * Both are drawn from history kept on the device (the battery readings the app already saves, and
 * the download samples the player takes while playing); nothing is sent anywhere.
 */
@Composable
fun StatsScreen(
    innerPadding: PaddingValues,
    navController: NavController,
) {
    val headsetRepository: HeadsetRepository = koinInject()
    val headsetState by headsetRepository.state.collectAsStateWithLifecycle()
    var battery by remember { mutableStateOf(emptyList<BatteryPoint>()) }
    var network by remember { mutableStateOf(emptyList<Pair<Long, Long>>()) }
    // Refreshed while the screen is open, so the graphs follow a song that is playing.
    LaunchedEffect(headsetState.name) {
        while (true) {
            battery = headsetRepository.batteryHistory()
            network = networkHistory()
            delay(5_000)
        }
    }

    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            IconButton(onClick = { navController.navigateUp() }) {
                Icon(SimpIcons.ArrowBackIosNew, contentDescription = null)
            }
            Text(stringResource(Res.string.statistics), style = typo().titleMedium)
        }
        ChartSection(
            title = stringResource(Res.string.statistics_headphones),
            points = battery.map { it.elapsedMs to it.percent.toLong() },
        ) { "$it%" }
        ChartSection(
            title = stringResource(Res.string.statistics_network),
            points = network,
            format = ::speedText,
        )
        RequestLogSection()
    }
}

/**
 * Temporary (private copy): the last requests the app made, from [RequestLog] — which Ktor clients
 * report to through `RequestLogPlugin`. Removed together with it; see .claude/CLAUDE.md,
 * "Temporary request log".
 */
@Composable
private fun RequestLogSection() {
    val requests by RequestLog.entries.collectAsStateWithLifecycle()
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Text(stringResource(Res.string.statistics_requests), style = typo().labelMedium, modifier = Modifier.weight(1f))
        if (requests.isNotEmpty()) {
            TextButton(onClick = { RequestLog.clear() }) {
                Text(stringResource(Res.string.clear), style = typo().labelMedium)
            }
        }
    }
    if (requests.isEmpty()) {
        Text(
            stringResource(Res.string.statistics_requests_empty),
            style = typo().bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.padding(vertical = 4.dp),
        )
        return
    }
    requests.take(60).forEach { request ->
        val statusCode = request.status
        val status = statusCode?.toString() ?: request.detail.orEmpty()
        Text(
            text = "${request.method} ${request.where}",
            style = typo().bodySmall,
            modifier = Modifier.padding(top = 4.dp),
        )
        val failed = statusCode == null || statusCode >= 400
        Text(
            text = listOf(status, "${request.millis} ms", clockText(request.atMillis)).filter { it.isNotEmpty() }.joinToString(" · "),
            style = typo().bodySmall,
            color =
                if (failed) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                },
        )
    }
}

/** "14:03:21" from epoch milliseconds, without pulling a formatter into this screen. */
private fun clockText(atMillis: Long): String {
    val time = Instant.fromEpochMilliseconds(atMillis).toLocalDateTime(TimeZone.currentSystemDefault())
    fun pad(value: Int) = value.toString().padStart(2, '0')
    return "${pad(time.hour)}:${pad(time.minute)}:${pad(time.second)}"
}

@Composable
private fun ChartSection(
    title: String,
    points: List<Pair<Long, Long>>,
    format: (Long) -> String,
) {
    Text(title, style = typo().labelMedium, modifier = Modifier.padding(top = 12.dp))
    if (points.size < 2) {
        Text(
            stringResource(Res.string.statistics_no_data),
            style = typo().bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.padding(vertical = 4.dp),
        )
        return
    }
    val maxY = points.maxOf { it.second }.coerceAtLeast(1)
    val maxX = points.last().first.coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val grid = Color.White.copy(alpha = 0.12f)
        drawLine(grid, Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), strokeWidth = 1f)
        val path = Path()
        points.forEachIndexed { i, (x, y) ->
            val px = size.width * (x.toFloat() / maxX)
            val py = size.height * (1f - (y.toFloat() / maxY))
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(path, seed, style = Stroke(2.5f))
    }
    Text(
        text = stringResource(Res.string.statistics_peak, format(maxY)),
        style = typo().bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
    )
}

/** "2.4 MB/s" or "640 kbps". */
private fun speedText(bitsPerSecond: Long): String =
    when {
        bitsPerSecond >= 1_000_000 -> "${(bitsPerSecond / 100_000) / 10.0} MB/s"
        else -> "${(bitsPerSecond + 500) / 1000} kbps"
    }
