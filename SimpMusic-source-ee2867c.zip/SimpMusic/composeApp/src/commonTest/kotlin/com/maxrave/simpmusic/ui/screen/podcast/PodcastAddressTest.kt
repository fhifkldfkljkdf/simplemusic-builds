package com.maxrave.simpmusic.ui.screen.podcast

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/**
 * The one podcast bar turns its lens into a + only for text that is really an address, so a search
 * for a name is never mistaken for a link (and a pasted link is never sent to the directory as a
 * search term).
 */
class PodcastAddressTest {
    @Test
    fun `addresses are addresses`() {
        assertTrue(looksLikeAddress("https://feeds.example.com/rss"))
        assertTrue(looksLikeAddress("http://example.com/feed.xml"))
        assertTrue(looksLikeAddress("https://www.youtube.com/@somechannel"))
        assertTrue(looksLikeAddress("youtube.com/channel/UCabcdefghijklmnopqrstuv"))
        assertTrue(looksLikeAddress("www.youtube.com/playlist?list=PL123"))
        assertTrue(looksLikeAddress("music.youtube.com/@artist"))
        assertTrue(looksLikeAddress("youtu.be/abc"))
        assertTrue(looksLikeAddress("@somechannel"))
        assertTrue(looksLikeAddress("feeds.example.com/rss"))
        assertTrue(looksLikeAddress("  https://example.com  "))
    }

    @Test
    fun `names are not addresses`() {
        assertFalse(looksLikeAddress(""))
        assertFalse(looksLikeAddress("   "))
        assertFalse(looksLikeAddress("The Daily"))
        assertFalse(looksLikeAddress("serial"))
        assertFalse(looksLikeAddress("90s hip hop"))
        assertFalse(looksLikeAddress("Mr Robot"))
        assertFalse(looksLikeAddress("@ab"))
        assertFalse(looksLikeAddress("youtube"))
    }
}
