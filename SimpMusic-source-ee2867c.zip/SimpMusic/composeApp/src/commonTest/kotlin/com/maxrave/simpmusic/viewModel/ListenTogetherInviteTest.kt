package com.maxrave.simpmusic.viewModel

import com.maxrave.simpmusic.viewModel.ListenTogetherViewModel.Companion.inviteLink
import com.maxrave.simpmusic.viewModel.ListenTogetherViewModel.Companion.parseDirectHints
import com.maxrave.simpmusic.viewModel.ListenTogetherViewModel.Companion.parseRoomCode
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class ListenTogetherInviteTest {
    @Test
    fun theInviteLinkReadsBackAsItsCode() {
        assertEquals("AB12CD34", parseRoomCode(inviteLink("AB12CD34")))
    }

    @Test
    fun theDesktopRewriteOfTheLinkStillCarriesTheCode() {
        // DesktopDeepLinkHandler turns simpmusic://listen-together?... into this before App.kt sees it.
        assertEquals("AB12CD34", parseRoomCode("https://simpmusic.org/app/listen-together?code=ab12cd34"))
        assertEquals("AB12CD34", parseRoomCode("simpmusic://listen-together?code=AB12CD34&from=qr"))
    }

    @Test
    fun aCodeOnItsOwnIsAccepted() {
        assertEquals("AB12CD34", parseRoomCode(" ab12cd34 "))
    }

    @Test
    fun theHostsLocalAddressesRideAlong() {
        val link = inviteLink("AB12CD34", listOf("192.168.1.20:41234", "100.101.1.2:41234"))
        assertEquals("simpmusic://listen-together?code=AB12CD34&lan=192.168.1.20:41234,100.101.1.2:41234", link)
        assertEquals("AB12CD34", parseRoomCode(link))
        assertEquals(listOf("192.168.1.20:41234", "100.101.1.2:41234"), parseDirectHints(link))
        // Desktop's rewrite of the link keeps them too.
        assertEquals(listOf("10.0.0.5:5000"), parseDirectHints("https://simpmusic.org/app/listen-together?code=AB12CD34&lan=10.0.0.5:5000"))
    }

    @Test
    fun anInviteWithoutAddressesOrWithJunkHasNone() {
        assertEquals(emptyList(), parseDirectHints(inviteLink("AB12CD34")))
        assertEquals(listOf("10.0.0.5:5000"), parseDirectHints("simpmusic://listen-together?code=AB12CD34&lan=evil.example:80,10.0.0.5:5000"))
        assertEquals(emptyList(), parseDirectHints("simpmusic://listen-together?code=AB12CD34&lan=1.2.3:4"))
    }

    @Test
    fun anythingElseIsNotARoom() {
        assertNull(parseRoomCode("simpmusic://watch?v=dQw4w9WgXcQ"))
        assertNull(parseRoomCode("simpmusic://listen-together?code=SHORT"))
        assertNull(parseRoomCode("simpmusic://listen-together?code=AB12CD345"))
        assertNull(parseRoomCode("https://example.com/?code=AB12CD34"))
        assertNull(parseRoomCode("Join my SimpMusic room"))
    }
}
