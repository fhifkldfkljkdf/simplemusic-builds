package com.maxrave.media3.upgrade

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * What one player is playing, reduced to what lining two copies of a song up needs. Private copy.
 *
 * Fed by [TappingAudioSink] on the player's playback thread with the decoded PCM exactly as the
 * decoder handed it over, each buffer stamped with its presentation time. Kept: the last
 * [CAPACITY_SECONDS] as mono, low-passed and decimated to about 8 kHz ([outputRate]), every sample
 * carrying its own time — so a window can be cut at any time, from either copy, whatever rate each
 * was decoded at. Also kept: the sink's own reading of what is being heard right now, with the
 * moment it was read ([positionAt]).
 *
 * Costs nothing until [arm]ed: the buffers are allocated on arming and dropped on [disarm], and an
 * unarmed tap only answers one volatile read per buffer.
 *
 * Written on the playback thread, read from another; every access holds [lock].
 */
class AnalysisTap {
    @Volatile
    var armed: Boolean = false
        private set

    private val lock = Any()

    // Input format, as the sink was configured.
    private var inputRate = 0
    private var channels = 0
    private var encoding = ENCODING_NONE

    // Decimation: an odd-length windowed-sinc low-pass, evaluated every `factor`-th input frame.
    private var factor = 1
    private var taps = FloatArray(0)
    private var delayLine = FloatArray(0)
    private var delayPos = 0
    private var phase = 0
    private var groupDelayUs = 0.0

    // History ring.
    private var samples = FloatArray(0)
    private var times = LongArray(0)
    private var head = 0
    private var size = 0

    // Continuity: where the next buffer is expected to start.
    private var expectedNextUs = Long.MIN_VALUE

    // Position readings: (position in presentation time, elapsed realtime when read), both in µs.
    private val positionUs = LongArray(POSITION_SLOTS)
    private val positionWallUs = LongArray(POSITION_SLOTS)
    private var positionCount = 0
    private var positionHead = 0

    /** Rate of the decimated history, or 0 before the first format. */
    val outputRate: Double
        get() = synchronized(lock) { if (inputRate == 0) 0.0 else inputRate.toDouble() / factor }

    fun arm() {
        synchronized(lock) {
            if (armed) return
            allocate()
            armed = true
        }
    }

    fun disarm() {
        synchronized(lock) {
            armed = false
            samples = FloatArray(0)
            times = LongArray(0)
            size = 0
            head = 0
            positionCount = 0
        }
    }

    /** The sink was configured for [sampleRate] Hz, [channelCount] channels of [pcmEncoding]. */
    fun configure(
        pcmEncoding: Int,
        sampleRate: Int,
        channelCount: Int,
    ) {
        synchronized(lock) {
            val supported = pcmEncoding == ENCODING_PCM_16BIT || pcmEncoding == ENCODING_PCM_FLOAT
            encoding = if (supported) pcmEncoding else ENCODING_NONE
            if (sampleRate == inputRate && channelCount == channels && taps.isNotEmpty()) {
                resetFilter()
                return
            }
            inputRate = sampleRate
            channels = channelCount
            factor = max(1, floor(sampleRate / TARGET_RATE).toInt())
            taps = lowPass(sampleRate, factor)
            groupDelayUs = (taps.size - 1) / 2.0 * 1_000_000.0 / sampleRate
            delayLine = FloatArray(taps.size)
            resetFilter()
            if (armed) allocate()
        }
    }

    /** A seek or a new stream: what came before is not continuous with what comes next. */
    fun flush() {
        synchronized(lock) {
            resetFilter()
            size = 0
            head = 0
            positionCount = 0
        }
    }

    /** One buffer of decoded PCM whose first frame is presented at [presentationTimeUs]. */
    fun feed(
        buffer: ByteBuffer,
        presentationTimeUs: Long,
    ) {
        if (!armed) return
        synchronized(lock) {
            if (!armed || encoding == ENCODING_NONE || channels <= 0 || inputRate <= 0) return
            val bytesPerSample = if (encoding == ENCODING_PCM_FLOAT) 4 else 2
            val frameBytes = bytesPerSample * channels
            val data = buffer.duplicate().order(ByteOrder.nativeOrder())
            val frames = data.remaining() / frameBytes
            if (frames <= 0) return
            if (expectedNextUs != Long.MIN_VALUE && abs(presentationTimeUs - expectedNextUs) > GAP_TOLERANCE_US) {
                // Not the continuation of the previous buffer: start the filter afresh.
                resetFilter()
            }
            val usPerFrame = 1_000_000.0 / inputRate
            var position = data.position()
            for (frame in 0 until frames) {
                var mono = 0f
                for (channel in 0 until channels) {
                    mono +=
                        if (encoding == ENCODING_PCM_FLOAT) {
                            data.getFloat(position)
                        } else {
                            data.getShort(position) / 32768f
                        }
                    position += bytesPerSample
                }
                delayLine[delayPos] = mono / channels
                delayPos = if (delayPos + 1 == delayLine.size) 0 else delayPos + 1
                phase++
                if (phase >= factor && filled()) {
                    phase = 0
                    val timeUs = presentationTimeUs + (frame * usPerFrame - groupDelayUs)
                    push(convolve(), timeUs.roundToLong())
                } else if (phase >= factor) {
                    phase = 0
                }
                primed++
            }
            expectedNextUs = presentationTimeUs + (frames * usPerFrame).roundToLong()
        }
    }

    /** The sink read [positionUs] as what is being heard now, at elapsed realtime [wallUs]. */
    fun recordPosition(
        positionUs: Long,
        wallUs: Long,
    ) {
        if (!armed) return
        synchronized(lock) {
            this.positionUs[positionHead] = positionUs
            positionWallUs[positionHead] = wallUs
            positionHead = (positionHead + 1) % POSITION_SLOTS
            if (positionCount < POSITION_SLOTS) positionCount++
        }
    }

    /**
     * What is being heard at elapsed realtime [wallUs], in presentation time: the median of the
     * recent readings, each carried forward to [wallUs] at normal speed. Null without readings
     * from the last [POSITION_MAX_AGE_US], or when they disagree (the stream jumped).
     */
    fun positionAt(wallUs: Long): Long? {
        synchronized(lock) {
            if (positionCount < MIN_POSITION_READINGS) return null
            val projected = ArrayList<Long>(positionCount)
            for (i in 0 until positionCount) {
                val age = wallUs - positionWallUs[i]
                if (age < 0 || age > POSITION_MAX_AGE_US) continue
                projected += positionUs[i] + age
            }
            if (projected.size < MIN_POSITION_READINGS) return null
            projected.sort()
            val median = projected[projected.size / 2]
            // Readings that disagree by more than a few milliseconds mean a seek or a speed change
            // landed among them; ask again later rather than average across it.
            if (projected.last() - projected.first() > POSITION_SPREAD_US) return null
            return median
        }
    }

    /** The time span the history covers, or null when it is empty. */
    fun span(): LongRange? =
        synchronized(lock) {
            if (size == 0) return null
            times[index(0)]..times[index(size - 1)]
        }

    /**
     * [count] samples at exactly [rate] Hz starting at presentation time [startUs], interpolated
     * from the history. Null when the history does not cover all of it without a gap.
     */
    fun window(
        startUs: Long,
        count: Int,
        rate: Int,
    ): FloatArray? {
        synchronized(lock) {
            if (size < 2 || count <= 0) return null
            val stepUs = 1_000_000.0 / rate
            val endUs = startUs + ((count - 1) * stepUs).roundToLong()
            if (startUs < times[index(0)] || endUs > times[index(size - 1)]) return null
            val maxGapUs = 1.5 * 1_000_000.0 * factor / inputRate
            val out = FloatArray(count)
            var i = lowerBound(startUs)
            for (k in 0 until count) {
                val t = startUs + k * stepUs
                while (i < size - 2 && times[index(i + 1)] <= t) i++
                val t0 = times[index(i)]
                val t1 = times[index(i + 1)]
                if (t1 - t0 > maxGapUs || t < t0) return null
                val fraction = if (t1 == t0) 0.0 else (t - t0) / (t1 - t0)
                val s0 = samples[index(i)]
                val s1 = samples[index(i + 1)]
                out[k] = (s0 + (s1 - s0) * fraction).toFloat()
            }
            return out
        }
    }

    private var primed = 0

    private fun filled(): Boolean = primed >= taps.size

    private fun resetFilter() {
        delayLine.fill(0f)
        delayPos = 0
        phase = 0
        primed = 0
        expectedNextUs = Long.MIN_VALUE
    }

    private fun allocate() {
        val rate = if (inputRate == 0) TARGET_RATE else inputRate.toDouble() / factor
        val capacity = (rate * CAPACITY_SECONDS).toInt() + 16
        if (samples.size != capacity) {
            samples = FloatArray(capacity)
            times = LongArray(capacity)
        }
        size = 0
        head = 0
    }

    private fun push(
        value: Float,
        timeUs: Long,
    ) {
        if (samples.isEmpty()) return
        // Out-of-order time would break the binary search; a seek would have flushed first.
        if (size > 0 && timeUs <= times[index(size - 1)]) {
            size = 0
            head = 0
        }
        val slot: Int
        if (size < samples.size) {
            slot = index(size)
            size++
        } else {
            slot = head
            head = (head + 1) % samples.size
        }
        samples[slot] = value
        times[slot] = timeUs
    }

    private fun convolve(): Float {
        // delayPos points at the oldest sample; the filter is symmetric, so direction is moot.
        var acc = 0f
        var p = delayPos
        for (t in taps.indices) {
            acc += taps[t] * delayLine[p]
            p = if (p + 1 == delayLine.size) 0 else p + 1
        }
        return acc
    }

    private fun index(i: Int): Int = (head + i) % samples.size

    private fun lowerBound(timeUs: Long): Int {
        var lo = 0
        var hi = size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (times[index(mid)] <= timeUs) lo = mid else hi = mid - 1
        }
        return lo
    }

    companion object {
        /** About this many samples per second are kept, whatever the stream's own rate. */
        const val TARGET_RATE = 8000.0
        const val CAPACITY_SECONDS = 36

        /** Pass band of the decimation filter; the aligner only reads up to 3.5 kHz. */
        private const val CUTOFF_HZ = 3600.0

        /** Taps per unit of decimation: long enough that what folds back lands above 3.5 kHz. */
        private const val TAPS_PER_FACTOR = 26

        private const val GAP_TOLERANCE_US = 2_000L
        private const val POSITION_SLOTS = 24
        private const val MIN_POSITION_READINGS = 6
        private const val POSITION_MAX_AGE_US = 400_000L
        private const val POSITION_SPREAD_US = 8_000L

        /** `C.ENCODING_*` values, repeated so this class needs nothing from Android to be tested. */
        const val ENCODING_PCM_16BIT = 2
        const val ENCODING_PCM_FLOAT = 4
        private const val ENCODING_NONE = -1

        /** A Blackman-windowed sinc low-pass for [rate] Hz, unity gain at DC. */
        internal fun lowPass(
            rate: Int,
            factor: Int,
        ): FloatArray {
            val length = (TAPS_PER_FACTOR * factor) or 1
            val fc = CUTOFF_HZ / rate
            val middle = (length - 1) / 2.0
            val taps = DoubleArray(length)
            var sum = 0.0
            for (n in 0 until length) {
                val x = n - middle
                val sinc = if (x == 0.0) 2 * fc else sin(2 * PI * fc * x) / (PI * x)
                val window = 0.42 - 0.5 * cos(2 * PI * n / (length - 1)) + 0.08 * cos(4 * PI * n / (length - 1))
                taps[n] = sinc * window
                sum += taps[n]
            }
            return FloatArray(length) { (taps[it] / sum).toFloat() }
        }

        private fun Double.roundToLong(): Long = kotlin.math.round(this).toLong()
    }
}
