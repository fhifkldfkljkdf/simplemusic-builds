package com.maxrave.media3.upgrade

import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.maxrave.logger.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * Moves a playing song onto another copy of itself with nothing to hear. Private copy.
 *
 * The other copy is opened in a second player, muted, a little behind the first. Both players'
 * decoded audio is tapped ([AnalysisTap]); [StreamAligner] finds where the second copy sits against
 * the first, the second player is moved (a seek, then small speed changes while it is still muted)
 * until both sinks are within [ALIGNED_US] of the same moment of the song, the levels are matched,
 * and only then does an [CROSSFADE_MS] crossfade hand over. Two copies of one master line up to
 * the sample, so that crossfade is inaudible; anything that does not line up is never crossfaded.
 *
 * Every step can say no — the copies differ, the new source is slow, the user did something —
 * and then nothing has changed: the second player is released and the song plays on as it was.
 *
 * Runs on the players' application thread (main); only the correlation leaves it.
 */
@UnstableApi
internal class SeamlessSourceSwitch(
    /** True while switching still makes sense: same song, same player, playing, no crossfade. */
    private val stillValid: () -> Boolean,
    /** The user's volume, read at every step so a change during the switch is honoured. */
    private val userVolume: () -> Float,
) {
    class Candidate(
        val player: ExoPlayer,
        val tap: AnalysisTap,
        /** Whatever else the caller needs back with the player (its crossfade filter). */
        val extra: Any?,
    )

    sealed interface Outcome {
        /**
         * The new player is playing, audible and aligned; the old one is silent and still
         * attached. The caller must make the new one current now, in this same main-thread turn.
         */
        data class Switched(
            val candidate: Candidate,
            /** New player position minus old player position, for the same moment of the song. */
            val timelineOffsetMs: Long,
            /** The volume factor the new player was brought in at; the caller keeps it for the rest of the song. */
            val volumeFactor: Float,
        ) : Outcome

        data class Failed(
            val reason: String,
            /** False when the two copies do not line up: trying again on this song is pointless. */
            val worthRetrying: Boolean,
        ) : Outcome
    }

    /**
     * Brings [mediaItem] — the same song, asking for the other source — in under [current].
     * [current]'s tap must already be armed, with history ([MIN_REFERENCE_US]) or time to gather it.
     */
    suspend fun run(
        current: ExoPlayer,
        currentTap: AnalysisTap,
        mediaItem: MediaItem,
        newCandidate: () -> Candidate,
        tag: String,
    ): Outcome {
        val deadline = SystemClock.elapsedRealtime() + BUDGET_MS
        val candidate = newCandidate()
        val next = candidate.player
        val nextTap = candidate.tap
        var failure: PlaybackException? = null
        val errorListener =
            object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    failure = error
                }
            }
        next.addListener(errorListener)
        var handedOver = false
        try {
            nextTap.arm()
            next.volume = 0f
            next.setMediaItem(mediaItem)
            next.playbackParameters = PlaybackParameters(1f, 1f)
            next.skipSilenceEnabled = false
            next.prepare()
            next.seekTo((current.currentPosition - LEAD_MS).coerceAtLeast(0L))
            next.playWhenReady = true

            // 1. Enough of both to compare.
            val gathered =
                waitFor(deadline) {
                    failure == null &&
                        next.isPlaying &&
                        (nextTap.span()?.let { it.last - it.first } ?: 0L) >= CANDIDATE_US &&
                        (currentTap.span()?.let { it.last - it.first } ?: 0L) >= MIN_REFERENCE_US
                }
            if (!gathered) return fail(failure?.let { "the new source failed: ${it.errorCodeName}" } ?: "not enough audio in time", failure == null)

            // 2. Where the new copy sits against the one playing.
            val alignment =
                withContext(Dispatchers.Default) { align(currentTap, nextTap) }
                    ?: return fail("the two copies do not line up (another master or transfer)", worthRetrying = false)
            Logger.d(tag, "Aligned: offset ${alignment.offsetUs} µs, level ${"%.2f".format(alignment.gainDb)} dB, ${alignment.matches}")
            if (abs(alignment.gainDb) > MAX_GAIN_DB) return fail("levels differ by ${alignment.gainDb} dB", worthRetrying = false)

            // 3. Bring the new player onto the same moment, while it is still muted.
            if (!converge(current, currentTap, next, nextTap, alignment.offsetUs, deadline) { failure == null }) {
                return fail(failure?.let { "the new source failed: ${it.errorCodeName}" } ?: "could not line the players up", failure == null)
            }

            // 4. The new source must keep up, or the switch would trade quality for stutter.
            val buffered = waitFor(deadline) { failure == null && next.totalBufferedDuration >= MIN_BUFFERED_MS }
            if (!buffered) return fail("the new source loads too slowly", worthRetrying = true)
            if (!stillValid()) return fail("playback changed", worthRetrying = true)

            // 5. Levels: the quieter copy decides, approached slowly enough not to be heard.
            val factor = 10.0.pow(-abs(alignment.gainDb) / 20).toFloat()
            var currentFactor = 1f
            var nextFactor = 1f
            if (alignment.gainDb > LEVEL_TOLERANCE_DB) {
                // The new copy is quieter: bring the old one down to it first, at no more than a
                // quarter of a decibel a second — slow enough that the change itself is not heard.
                val rampMs = (abs(alignment.gainDb) * 4_000).toLong().coerceIn(4_000, 24_000)
                if (!ramp(rampMs, deadline + rampMs) { t -> current.volume = userVolume() * (1 - t * (1 - factor)) }) {
                    current.volume = userVolume()
                    return fail("playback changed", worthRetrying = true)
                }
                currentFactor = factor
            } else if (alignment.gainDb < -LEVEL_TOLERANCE_DB) {
                // The new copy is louder: bring it in at the old one's level, raised later.
                nextFactor = factor
            }

            // 6. A last check that nothing drifted, then the handover.
            val drift = errorUs(currentTap, nextTap, alignment.offsetUs)
            if (drift == null || abs(drift) > ALIGNED_US * 2 || !stillValid()) {
                current.volume = userVolume()
                return fail("the players drifted apart", worthRetrying = true)
            }
            val steps = CROSSFADE_MS / CROSSFADE_STEP_MS
            for (i in 1..steps) {
                val t = i.toFloat() / steps
                // Linear, not equal-power: the two signals are the same signal, so their
                // amplitudes add and a linear fade keeps the sum constant.
                current.volume = userVolume() * currentFactor * (1 - t)
                next.volume = userVolume() * nextFactor * t
                delay(CROSSFADE_STEP_MS.toLong())
            }
            val offsetMs = timelineOffsetMs(current, next)
            handedOver = true
            Logger.w(tag, "Switched sources mid-song: timeline offset $offsetMs ms, new level ×$nextFactor")
            return Outcome.Switched(candidate, offsetMs, nextFactor)
        } finally {
            next.removeListener(errorListener)
            nextTap.disarm()
            if (!handedOver) {
                // The playing player's tap stays armed: a later attempt (a source picked in the
                // sheet) needs its history.
                current.volume = userVolume()
                runCatching {
                    next.stop()
                    next.release()
                }
            }
        }
    }

    private fun fail(
        reason: String,
        worthRetrying: Boolean,
    ): Outcome.Failed = Outcome.Failed(reason, worthRetrying)

    private fun align(
        currentTap: AnalysisTap,
        nextTap: AnalysisTap,
    ): StreamAligner.Alignment? {
        val refSpan = currentTap.span() ?: return null
        val candSpan = nextTap.span() ?: return null
        val refStart = maxOf(refSpan.first, refSpan.last - MAX_REFERENCE_US)
        val refCount = ((refSpan.last - refStart) * StreamAligner.RATE / 1_000_000L).toInt() - 2
        val reference = currentTap.window(refStart, refCount, StreamAligner.RATE) ?: return null
        val windowSamples = StreamAligner.WINDOW_SECONDS * StreamAligner.RATE
        val first = maxOf(candSpan.first, candSpan.last - CANDIDATE_US)
        val windows =
            StreamAligner.windowStarts(first, candSpan.last, WINDOWS).map { start ->
                (nextTap.window(start, windowSamples, StreamAligner.RATE) ?: return null) to start
            }
        return StreamAligner.align(reference, refStart, windows)
    }

    /**
     * How far ahead the new player is of where it should be, in µs: positive when it plays a
     * moment of the song the old one has yet to reach. Null without fresh position readings.
     */
    private fun errorUs(
        currentTap: AnalysisTap,
        nextTap: AnalysisTap,
        offsetUs: Long,
    ): Long? {
        val now = SystemClock.elapsedRealtimeNanos() / 1000
        val a = currentTap.positionAt(now) ?: return null
        val b = nextTap.positionAt(now) ?: return null
        return b - a - offsetUs
    }

    private suspend fun converge(
        current: ExoPlayer,
        currentTap: AnalysisTap,
        next: ExoPlayer,
        nextTap: AnalysisTap,
        offsetUs: Long,
        deadline: Long,
        healthy: () -> Boolean,
    ): Boolean {
        var settledReadings = 0
        var corrections = 0
        while (corrections <= MAX_CORRECTIONS) {
            if (!stillValid() || !healthy() || SystemClock.elapsedRealtime() > deadline) return false
            delay(SETTLE_MS)
            // No answer while the readings straddle a seek or a speed change: just ask again.
            val error = errorUs(currentTap, nextTap, offsetUs) ?: continue
            when {
                abs(error) <= ALIGNED_US -> {
                    settledReadings++
                    if (settledReadings >= 2) return true
                }

                abs(error) > SEEK_ABOVE_US -> {
                    settledReadings = 0
                    corrections++
                    next.seekTo((next.currentPosition - error / 1000).coerceAtLeast(0L))
                    waitFor(deadline) { next.isPlaying && healthy() }
                    delay(AFTER_SEEK_MS)
                }

                else -> {
                    settledReadings = 0
                    corrections++
                    // Speed the muted player up or slow it down until it has made up the error.
                    val speed = (1.0 - error.toDouble() / NUDGE_US).coerceIn(1 - MAX_NUDGE, 1 + MAX_NUDGE).toFloat()
                    val forMs = (abs(error) / abs(1.0 - speed) / 1000).roundToLong().coerceIn(100, 4_000)
                    next.playbackParameters = PlaybackParameters(speed, 1f)
                    delay(forMs)
                    next.playbackParameters = PlaybackParameters(1f, 1f)
                    delay(AFTER_NUDGE_MS)
                }
            }
        }
        return false
    }

    private suspend fun waitFor(
        deadline: Long,
        condition: () -> Boolean,
    ): Boolean {
        while (SystemClock.elapsedRealtime() < deadline) {
            if (!stillValid()) return false
            if (condition()) return true
            delay(POLL_MS)
        }
        return false
    }

    /** Runs [apply] from 0 to 1 over [durationMs]; false when playback changed meanwhile. */
    private suspend fun ramp(
        durationMs: Long,
        deadline: Long,
        apply: (Float) -> Unit,
    ): Boolean {
        val start = SystemClock.elapsedRealtime()
        while (true) {
            if (!stillValid() || SystemClock.elapsedRealtime() > deadline) return false
            val t = ((SystemClock.elapsedRealtime() - start).toFloat() / durationMs).coerceAtMost(1f)
            apply(t)
            if (t >= 1f) return true
            delay(RAMP_STEP_MS)
        }
    }

    /** The two players' positions differ by this for the same moment of the song. */
    private fun timelineOffsetMs(
        current: ExoPlayer,
        next: ExoPlayer,
    ): Long {
        var sum = 0L
        repeat(3) { sum += next.currentPosition - current.currentPosition }
        return sum / 3
    }

    companion object {
        /** Everything, from opening the new copy to the handover, must fit in this. */
        const val BUDGET_MS = 40_000L

        /** The new player starts this far behind, so its audio is already in the old one's history. */
        private const val LEAD_MS = 2_000L
        private const val CANDIDATE_US = 9_500_000L
        const val MIN_REFERENCE_US = 18_000_000L
        private const val MAX_REFERENCE_US = 28_000_000L
        private const val WINDOWS = 3

        /**
         * Within this, the two copies are the same sound: what is left of the difference is a comb
         * filter whose first notch sits above 300 Hz, heard for 80 ms of a fade.
         */
        private const val ALIGNED_US = 1_500L
        private const val SEEK_ABOVE_US = 150_000L
        private const val NUDGE_US = 2_000_000.0
        private const val MAX_NUDGE = 0.05
        private const val MAX_CORRECTIONS = 10
        private const val SETTLE_MS = 400L
        private const val AFTER_SEEK_MS = 1_500L
        private const val AFTER_NUDGE_MS = 900L
        private const val MIN_BUFFERED_MS = 20_000L
        private const val MAX_GAIN_DB = 6.0
        private const val LEVEL_TOLERANCE_DB = 0.4
        private const val CROSSFADE_MS = 80
        private const val CROSSFADE_STEP_MS = 10
        private const val RAMP_STEP_MS = 50L
        private const val POLL_MS = 100L
    }
}
