package com.maxrave.media3.service.mediasourcefactory

import androidx.core.net.toUri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.SimpleCache
import com.maxrave.common.MERGING_DATA_TYPE
import com.maxrave.domain.data.entities.NewFormatEntity
import com.maxrave.domain.data.entities.isArchiveLossless
import com.maxrave.domain.data.entities.otherSourceCacheKey
import com.maxrave.domain.data.model.podcast.FeedIds
import com.maxrave.domain.data.player.LiveStreamRegistry
import com.maxrave.domain.data.player.PlaybackSource
import com.maxrave.domain.data.player.PlaybackStream
import com.maxrave.domain.data.player.SourceKind
import com.maxrave.domain.extension.now
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.repository.StreamRepository
import com.maxrave.logger.Logger
import com.maxrave.media3.extension.isFullyCached
import com.maxrave.media3.upgrade.UpgradeRefusals
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.IOException

/**
 * Turns a song's placeholder into the address a player reads, for [PinnedResolvingDataSource].
 * Private copy; the video branch and the cache branches are upstream's.
 *
 * A new stream picks its source for a quick start: the song's own download or full cache, a
 * lossless file already found (Hi-Fi sound), a still-fresh YouTube address, or a fresh lookup —
 * never a search that could take seconds. A stream that has started keeps its source for good: a
 * renewed address for the same file when the old one expires, else an error the player retries.
 * A player can also ask for one source by name through its media item ([StreamRequest]): that is
 * how a seamless upgrade and the sources sheet open a particular copy.
 */
@UnstableApi
internal class StreamResolver(
    private val downloadCache: SimpleCache,
    private val playerCache: SimpleCache,
    private val dataStoreManager: DataStoreManager,
    private val streamRepository: StreamRepository,
    private val coroutineScope: CoroutineScope,
) : PinnedResolvingDataSource.Resolver {
    override fun resolve(
        dataSpec: DataSpec,
        pin: StreamPin?,
    ): ResolvedSpec {
        val mediaId = dataSpec.key ?: error("No media id")
        val videoId = mediaId.removePrefix(MERGING_DATA_TYPE.VIDEO)
        // A live broadcast reached a progressive source that was built before it was known to be
        // live; failing it is what gets the track rebuilt as HLS — see LiveStreamDetectedException.
        if (LiveStreamRegistry.isLive(videoId)) throw LiveStreamDetectedException(videoId)
        if (mediaId.startsWith(MERGING_DATA_TYPE.VIDEO)) return ResolvedSpec(resolveVideo(dataSpec, mediaId, videoId), null)
        val request = StreamRequest.parse(dataSpec.uri.toString())

        if (pin is StreamPin.Remote) {
            val stream = continueWith(videoId, pin.stream)
            return ResolvedSpec(open(dataSpec, mediaId, stream), StreamPin.Remote(stream))
        }

        // A followed RSS podcast's episode: the feed's own file, never YouTube.
        if (FeedIds.isFeedEpisode(videoId)) {
            val stream = runBlocking(Dispatchers.IO) { streamRepository.feedEpisodeStream(videoId) } ?: unresolved(mediaId)
            if (request.publishes) streamRepository.publishPlayingSource(videoId, stream.source)
            return ResolvedSpec(open(dataSpec, mediaId, stream), StreamPin.Remote(stream))
        }

        // YouTube's own download or cache is YouTube: asking for YouTube (the sound of a music
        // video) still plays from the device.
        if (pin == StreamPin.Local || (pin == null && (request.kind == null || request.kind == SourceKind.YOUTUBE))) {
            local(dataSpec, mediaId, videoId)?.let { spec ->
                if (pin == null && request.publishes) publishLocal(videoId)
                return ResolvedSpec(spec, StreamPin.Local)
            }
            if (pin == StreamPin.Local) {
                // The cached bytes went away mid-song (eviction, "clear cache"). They were YouTube's,
                // so YouTube's stream is the one that continues them.
                val stream = runBlocking(Dispatchers.IO) { streamRepository.streamFrom(videoId, SourceKind.YOUTUBE) } ?: unresolved(mediaId)
                return ResolvedSpec(open(dataSpec, mediaId, stream), StreamPin.Remote(stream))
            }
        }

        val stream =
            runBlocking(Dispatchers.IO) {
                when (val kind = request.kind) {
                    null -> quickStart(videoId, request.waitedFor)
                    SourceKind.DOWNLOADED -> null
                    else -> streamRepository.streamFrom(videoId, kind)
                }
            }
        // getStream above is where a live broadcast is first recognised. Its HLS playlist URL must
        // not be read as a file, so this source fails and the track is rebuilt as HLS.
        if (LiveStreamRegistry.isLive(videoId)) throw LiveStreamDetectedException(videoId)
        stream ?: unresolved(mediaId)
        Logger.w("Stream", "$videoId starts from ${stream.source.kind}${if (request.kind != null) " (asked for)" else ""}")
        if (request.publishes) streamRepository.publishPlayingSource(videoId, stream.source)
        // A prefetch asks for an opening by its length; a file that starts with a cover gets the
        // cover on top, so what is cached is audio and not only the picture.
        val spec =
            if (request.prefetch && stream.audioOffset > 0 && dataSpec.length != C.LENGTH_UNSET.toLong()) {
                dataSpec.buildUpon().setLength(dataSpec.length + stream.audioOffset).build()
            } else {
                dataSpec
            }
        return ResolvedSpec(open(spec, mediaId, stream), StreamPin.Remote(stream))
    }

    /**
     * The first source that can start now, without a search that could take seconds.
     *
     * A known lossless file is the copy to play, but when someone is waiting ([waitedFor]) and its
     * opening is not cached, a still-fresh YouTube address starts sooner: archive.org answers through
     * a redirect to a storage node and a new TLS handshake, about a second before the first byte. The
     * song then starts on YouTube and the seamless upgrade moves it onto the lossless file — unless
     * that move was already refused for this song ([UpgradeRefusals]).
     */
    private suspend fun quickStart(
        videoId: String,
        waitedFor: Boolean,
    ): PlaybackStream? {
        streamRepository.knownLossless(videoId)?.let { lossless ->
            if (!waitedFor || openingCached(lossless, videoId) || UpgradeRefusals.contains(videoId)) return lossless
            return freshYouTube(videoId) ?: lossless
        }
        // Not known yet: looked for in the background, for a later upgrade (and later plays).
        streamRepository.searchLossless(videoId)
        freshYouTube(videoId)?.let { return it }
        val url =
            streamRepository
                .getStream(dataStoreManager, videoId, isDownloading = false, isVideo = false)
                .lastOrNull() ?: return null
        if (LiveStreamRegistry.isLive(videoId)) return null
        Logger.w("Stream", "Audio")
        return streamRepository.describeStream(videoId, url)
    }

    /** The song's saved YouTube address while it is still good, else null. */
    private suspend fun freshYouTube(videoId: String): PlaybackStream? {
        val row = streamRepository.getNewFormat(videoId).lastOrNull() ?: return null
        val url = row.audioUrl
        // A row written by an older build can hold an archive match under the song's own key.
        if (url == null || row.expiredTime <= now() || row.isArchiveLossless) return null
        Logger.w("Stream", "Audio from format")
        // Checking costs a connection to Google's servers before the song can start. An address the
        // extraction or an earlier check found playable minutes ago, on this network, is opened
        // straight away; if it fails after all, the player's error path fetches a fresh one.
        if (!streamRepository.isRecentlyVerified(url)) {
            val is403Url = streamRepository.is403Url(url).firstOrNull() != false
            Logger.d("Stream", "is 403 $is403Url")
            if (is403Url) return null
            streamRepository.markVerified(url)
        }
        return streamRepository.describeStream(videoId, url)
    }

    /** Whether the opening of [stream] is on disk already (the upcoming-song prefetch put it there). */
    private fun openingCached(
        stream: PlaybackStream,
        mediaId: String,
    ): Boolean {
        val key = otherSourceCacheKey(stream, mediaId) ?: return false
        // Counted from where the audio starts: a file can open with megabytes of cover picture.
        val needed = stream.audioOffset + OPENING_BYTES
        return playerCache.getCachedBytes(key, 0, needed) >= needed
    }

    /** The same file as [stream], renewed if its address is about to expire. */
    private fun continueWith(
        videoId: String,
        stream: PlaybackStream,
    ): PlaybackStream {
        if (stream.expiresAtMs - System.currentTimeMillis() > RENEW_MARGIN_MS) return stream
        Logger.w("Stream", "Renewing the ${stream.source.kind} address of $videoId")
        return runBlocking(Dispatchers.IO) { streamRepository.renewStream(videoId, stream) }
            ?: throw IOException("The ${stream.source.kind} stream of $videoId cannot be renewed")
    }

    /** Upstream's two cache branches: the song downloaded, or already cached in full. */
    private fun local(
        dataSpec: DataSpec,
        mediaId: String,
        videoId: String,
    ): DataSpec? {
        if (downloadCache.isFullyCached(mediaId, dataSpec.position)) {
            // Only on the first chunk: the subrange below makes the resolver run once per
            // chunk, and updateFormat is a fire-and-forget youTube.player() call with no
            // in-flight dedup, so leaving it ungated would fan out one request per 5 MiB.
            if (dataSpec.position == 0L) coroutineScope.launch(Dispatchers.IO) { streamRepository.updateFormat(videoId) }
            Logger.w("Stream", "Downloaded $mediaId")
            return dataSpec.subrange(dataSpec.uriPositionOffset, CHUNK_LENGTH)
        }
        if (playerCache.isFullyCached(mediaId, dataSpec.position)) {
            if (dataSpec.position == 0L) coroutineScope.launch(Dispatchers.IO) { streamRepository.updateFormat(videoId) }
            Logger.w("Stream", "Cached $mediaId")
            // Every byte is on disk right now, so CacheDataSource can serve this chunk without
            // ever reaching upstream, and the bare media id is safe as the URI — but only for ONE
            // chunk: a bare id routes to FileDataSource, and a cache that shrinks under a longer
            // read would fail with FileNotFoundException. Capping to the chunk forces a re-check
            // at every chunk boundary, which falls back to a real address.
            return dataSpec.subrange(dataSpec.uriPositionOffset, CHUNK_LENGTH)
        }
        return null
    }

    private fun publishLocal(videoId: String) {
        coroutineScope.launch(Dispatchers.IO) {
            val row = streamRepository.getNewFormat(videoId).lastOrNull()
            val downloaded = downloadCache.isFullyCached(videoId, 0)
            streamRepository.publishPlayingSource(
                videoId,
                PlaybackSource(
                    kind = if (downloaded) SourceKind.DOWNLOADED else SourceKind.YOUTUBE,
                    codec = row?.codecLabel(),
                    bitrateBps = row?.bitrate,
                    sampleRateHz = row?.sampleRate,
                ),
            )
        }
    }

    private fun open(
        dataSpec: DataSpec,
        mediaId: String,
        stream: PlaybackStream,
    ): DataSpec {
        var url = stream.url
        // A googlevideo `range=` parameter names a byte range itself; past the first chunk the
        // request's own Range header must decide, so it goes (upstream read later chunks from the
        // format row, which never had it).
        if (dataSpec.position > 0 && stream.source.kind == SourceKind.YOUTUBE) url = url.replace(RANGE_PARAM, "")
        val spec = dataSpec.withUri(url.toUri())
        val key = otherSourceCacheKey(stream, mediaId)
        val keyed = if (key != null) spec.buildUpon().setKey(key).build() else spec
        // Only YouTube is read a chunk at a time (googlevideo slows long reads down). Its containers
        // (WebM, MP4) know their own size, so a chunk's end reads as a cut, and the loader opens the
        // next chunk. FLAC and MP3 have no such size: their extractors take a chunk's end as the end
        // of the song, and size their seeking by it. A lossless file stopped after 5 MiB (about 46 s,
        // 13 s behind a large embedded cover), an Audius song after about two minutes. Those sources
        // are read in one go from where the player asks, which also gives the player their real length.
        if (stream.source.kind != SourceKind.YOUTUBE) return keyed
        // A read that asked for less than a chunk (the upcoming-song prefetch) gets no more.
        val length = if (dataSpec.length == C.LENGTH_UNSET.toLong()) CHUNK_LENGTH else minOf(dataSpec.length, CHUNK_LENGTH)
        return keyed.subrange(dataSpec.uriPositionOffset, length)
    }

    /** Upstream's video branch, unchanged: the video track of a merged source. */
    private fun resolveVideo(
        dataSpec: DataSpec,
        mediaId: String,
        id: String,
    ): DataSpec {
        if (downloadCache.isFullyCached(mediaId, dataSpec.position) || playerCache.isFullyCached(mediaId, dataSpec.position)) {
            return dataSpec.subrange(dataSpec.uriPositionOffset, CHUNK_LENGTH)
        }
        var resolved: DataSpec? = null
        runBlocking(Dispatchers.IO) {
            streamRepository.getNewFormat(id).lastOrNull()?.let {
                val videoUrl = it.videoUrl
                if (videoUrl != null && it.expiredTime > now()) {
                    Logger.w("Stream", "Video from format")
                    val is403Url = streamRepository.is403Url(videoUrl).firstOrNull() != false
                    if (!is403Url) {
                        resolved = dataSpec.withUri(videoUrl.toUri()).subrange(dataSpec.uriPositionOffset, CHUNK_LENGTH)
                        return@runBlocking
                    }
                }
            }
            streamRepository
                .getStream(dataStoreManager, id, isDownloading = false, isVideo = true)
                .lastOrNull()
                ?.let {
                    Logger.w("Stream", "Video")
                    resolved = dataSpec.withUri(it.toUri()).subrange(dataSpec.uriPositionOffset, CHUNK_LENGTH)
                }
        }
        if (LiveStreamRegistry.isLive(id)) throw LiveStreamDetectedException(id)
        return resolved ?: unresolved(mediaId)
    }

    private fun unresolved(mediaId: String): Nothing {
        Logger.e("Stream", "Failed to resolve stream URL for $mediaId")
        throw IOException("Failed to resolve stream URL for $mediaId")
    }

    companion object {
        const val CHUNK_LENGTH = 10 * 512 * 1024L

        /**
         * About nine seconds of a CD-quality FLAC (roughly 900 kbps), cached, before a song someone
         * is waiting for starts on the lossless file rather than on YouTube. archive.org takes 1.0 to
         * 1.6 s to send its first byte; 256 KiB, the old bar, is two seconds of FLAC, so a song could
         * run out of what was cached and stop for a moment right after starting.
         */
        private const val OPENING_BYTES = 1024 * 1024L

        /** An address this close to expiring is renewed before the next chunk is fetched with it. */
        private const val RENEW_MARGIN_MS = 30_000L
        private val RANGE_PARAM = Regex("&range=[^&]*")

        private fun NewFormatEntity.codecLabel(): String? =
            codecs?.let {
                when {
                    it.contains("opus", ignoreCase = true) -> "OPUS"
                    it.contains("mp4a", ignoreCase = true) -> "AAC"
                    else -> it.uppercase()
                }
            }
    }
}
