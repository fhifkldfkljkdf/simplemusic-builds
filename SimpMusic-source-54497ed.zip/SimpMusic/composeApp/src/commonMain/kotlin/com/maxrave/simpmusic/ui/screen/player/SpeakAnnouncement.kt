package com.maxrave.simpmusic.ui.screen.player

/**
 * Reads [text] out loud where the platform can (Android's TextToSpeech). A no-op elsewhere, so a
 * caller never needs to know which platform it runs on; it must never throw.
 */
expect fun speakAnnouncement(text: String)
