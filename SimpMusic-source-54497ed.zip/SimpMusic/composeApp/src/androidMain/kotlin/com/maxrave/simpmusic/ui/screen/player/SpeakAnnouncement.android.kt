package com.maxrave.simpmusic.ui.screen.player

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import com.maxrave.logger.Logger
import org.koin.mp.KoinPlatform.getKoin
import java.util.Locale

private const val TAG = "SpeakAnnouncement"
private const val UTTERANCE_ID = "simpmusic-announcement"

/**
 * One TextToSpeech engine for the whole process: creating one is slow, and a value spoken seconds
 * after the slider was released is worse than one not spoken at all.
 */
private object Speaker {
    private val lock = Any()
    private var engine: TextToSpeech? = null
    private var starting = false
    private var ready = false

    // The value to say once init finishes; the newest one wins, since only the last matters.
    private var pending: String? = null

    fun speak(text: String) {
        try {
            synchronized(lock) {
                pending = text
                if (!ready) {
                    start()
                    return
                }
                speakPending()
            }
        } catch (t: Throwable) {
            Logger.e(TAG, "Could not speak announcement: ${t.message}", t)
        }
    }

    private fun start() {
        if (starting) return
        starting = true
        try {
            val context = getKoin().get<Context>()
            val created = TextToSpeech(context.applicationContext, ::onInit)
            engine = created
        } catch (t: Throwable) {
            starting = false
            pending = null
            Logger.e(TAG, "Could not create the text to speech engine: ${t.message}", t)
        }
    }

    private fun onInit(status: Int) {
        synchronized(lock) {
            starting = false
            val tts = engine
            if (status != TextToSpeech.SUCCESS || tts == null) {
                pending = null
                Logger.w(TAG, "Text to speech is unavailable (status $status)")
                // Release the dead engine, so a later call can try a fresh one.
                runCatching { tts?.shutdown() }
                engine = null
                return
            }
            try {
                val language = tts.setLanguage(Locale.getDefault())
                if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US)
                }
                // Accessibility speech: the engine takes transient audio focus that may duck, so
                // the music dips under the announcement instead of stopping.
                tts.setAudioAttributes(
                    AudioAttributes
                        .Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                ready = true
                speakPending()
            } catch (t: Throwable) {
                Logger.e(TAG, "Could not set up text to speech: ${t.message}", t)
            }
        }
    }

    private fun speakPending() {
        val tts = engine ?: return
        val text = pending ?: return
        pending = null
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }
}

actual fun speakAnnouncement(text: String) {
    Speaker.speak(text)
}
