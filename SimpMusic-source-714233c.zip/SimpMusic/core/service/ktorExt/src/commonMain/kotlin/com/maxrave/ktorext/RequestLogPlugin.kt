package com.maxrave.ktorext

import com.maxrave.common.LoggedRequest
import com.maxrave.common.RequestLog
import io.ktor.client.HttpClientConfig
import io.ktor.client.plugins.api.Send
import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.http.Url
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Clock
import kotlin.time.TimeSource

/**
 * Temporary (private copy): every request a client built with this plugin sends lands in
 * [RequestLog], which the Stats screen lists — what the app is asking, where, how long it took and
 * what came back. Meant to be removed: drop the `logRequests()` lines in the clients, delete this
 * file and the store, and the Stats screen section (see .claude/CLAUDE.md, "Temporary request log").
 *
 * Nothing here may break a request: the plugin only records, and a failure is swallowed.
 */
val RequestLogPlugin =
    createClientPlugin("RequestLogPlugin") {
        on(Send) { request ->
            val started = TimeSource.Monotonic.markNow()
            try {
                val call = proceed(request)
                record(
                    method = call.request.method.value,
                    url = call.request.url.toString(),
                    status = call.response.status.value,
                    millis = started.elapsedNow().inWholeMilliseconds,
                    detail = null,
                )
                call
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                record(
                    method = request.method.value,
                    url = request.url.toString(),
                    status = null,
                    millis = started.elapsedNow().inWholeMilliseconds,
                    detail = t.message?.take(120) ?: t::class.simpleName,
                )
                throw t
            }
        }
    }

/** Temporary: have this client report its requests to `RequestLog`, which the Stats screen lists. */
fun HttpClientConfig<*>.logRequests() {
    install(RequestLogPlugin)
}

private fun record(
    method: String,
    url: String,
    status: Int?,
    millis: Long,
    detail: String?,
) {
    try {
        RequestLog.record(
            LoggedRequest(
                atMillis = Clock.System.now().toEpochMilliseconds(),
                method = method,
                where = where(url),
                status = status,
                millis = millis,
                detail = detail,
            ),
        )
    } catch (_: Throwable) {
        // Recording is never worth taking a request down for.
    }
}

/** `host/path`, without the scheme, the query or a path so long it stops being readable. */
private fun where(url: String): String {
    val parsed = runCatching { Url(url) }.getOrNull() ?: return url.take(80)
    val path = parsed.encodedPath
    return if (path.length <= 60) parsed.host + path else parsed.host + path.take(57) + "…"
}
