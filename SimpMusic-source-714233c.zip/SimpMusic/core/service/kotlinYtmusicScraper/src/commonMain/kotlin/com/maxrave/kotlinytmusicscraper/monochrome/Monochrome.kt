package com.maxrave.kotlinytmusicscraper.monochrome

import com.maxrave.ktorext.getEngine
import com.maxrave.ktorext.logRequests
import com.maxrave.domain.data.player.FlacIdentity
import com.maxrave.kotlinytmusicscraper.matching.RecordingMatcher
import com.maxrave.logger.Logger
import io.ktor.client.HttpClient
import io.ktor.client.engine.ProxyConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.utils.io.readRemaining
import kotlinx.io.readByteArray
import kotlinx.serialization.json.Json

/**
 * Monochrome as a lossless source: Hi-Res FLAC streamed whole from Monochrome's track streamer
 * (`tracks.monochrome.st`, the Rust port of binimum/hifi-api, playing TIDAL's catalog). No account
 * and no key.
 *
 * Like [com.maxrave.kotlinytmusicscraper.audius.Audius] this is tried while Hi-Fi sound is on and
 * only leaves YouTube for a file it has read: [check] fetches the stream's opening and refuses it
 * unless it is FLAC, so a streamer that answers with an error page is a miss, not a broken song.
 * TIDAL has the official release of most music, so coverage is far wider than the Internet
 * Archive's; both are lossless and are looked for at the same time.
 */
class Monochrome {
    private val json = Json { ignoreUnknownKeys = true }

    var proxy: ProxyConfig? = null
        set(value) {
            if (field == value) return
            field = value
            client.close()
            client = createClient()
        }

    private var client = createClient()

    private fun createClient() =
        HttpClient(getEngine()) {
            logRequests()
            expectSuccess = true
            install(HttpTimeout) {
                requestTimeoutMillis = REQUEST_TIMEOUT_MS
                connectTimeoutMillis = REQUEST_TIMEOUT_MS
            }
            if (proxy != null) {
                engine {
                    proxy = this@Monochrome.proxy
                }
            }
        }

    /** The same recording as the song, as a FLAC stream, or a failure when there is none. */
    suspend fun findStream(
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): Result<MonochromeTrack> =
        runCatching {
            val query = RecordingMatcher.query(title, artists)
            require(query.isNotBlank()) { "Nothing to search for" }
            val body =
                client
                    .get(SEARCH_URL) {
                        header("User-Agent", USER_AGENT)
                        parameter("q", query)
                        parameter("limit", SEARCH_LIMIT)
                    }.bodyAsText()
            val candidates = MonochromeCandidates.candidates(json.parseToJsonElement(body))
            for (track in RecordingMatcher.ranked(candidates, title, artists, durationSeconds).take(MAX_PROBES)) {
                val checked = check(track, title, artists, durationSeconds) ?: continue
                Logger.d(TAG, "Matched \"$title\" to Monochrome ${track.id} \"${track.title}\" by ${track.artists.firstOrNull()}")
                return@runCatching checked
            }
            error("No Monochrome FLAC matches \"$title\"")
        }

    /**
     * [track] once its stream's opening was read and is the song, or null when it is not. The listing
     * is not enough: the streamer has served another recording under a track's id (Pixies' "Where Is
     * My Mind?" as Nathan Lambertson's cover, 191 s against 235), so the file's own STREAMINFO and
     * tags are what decide ([FlacIdentity]).
     */
    private suspend fun check(
        track: MonochromeTrack,
        title: String,
        artists: List<String>,
        durationSeconds: Long,
    ): MonochromeTrack? {
        val result =
            runCatching {
                client
                    .prepareGet(streamUrl(track.id)) {
                        header("User-Agent", USER_AGENT)
                        header("Range", "bytes=0-${PROBE_BYTES - 1}")
                    }.execute { response ->
                        // A ranged answer carries the whole file's size in Content-Range; without a
                        // range it is Content-Length. From it and the song's length comes the file's
                        // average bitrate, which is the only bitrate a FLAC can be given.
                        val total =
                            response.headers["Content-Range"]?.substringAfterLast('/')?.toLongOrNull()
                                ?: response.headers["Content-Length"]?.toLongOrNull()
                                ?: 0L
                        response.bodyAsChannel().readRemaining(PROBE_BYTES.toLong()).readByteArray() to total
                    }
            }.getOrElse {
                Logger.d(TAG, "Monochrome ${track.id} could not be read: ${it.message}")
                return null
            }
        val identity = FlacIdentity.read(result.first)
        if (identity == null) {
            Logger.d(TAG, "Monochrome ${track.id} did not answer with FLAC")
            return null
        }
        // The song's length when YouTube gave one, else the length the listing claims.
        val length = durationSeconds.takeIf { it > 0 } ?: track.durationMs?.let { it / 1000 } ?: 0
        identity.mismatch(title, artists, length, track.isrc)?.let { why ->
            Logger.w(TAG, "Monochrome ${track.id} serves another recording than \"${track.title}\": $why")
            return null
        }
        val bitrate =
            result.second
                .takeIf { it > 0 && durationSeconds > 0 }
                ?.let { ((it * 8) / durationSeconds).toInt() }
                ?.takeIf { it > 0 }
        return track.copy(bitrateBps = bitrate)
    }

    /** The track's stream: a whole FLAC file, served by the API. It does not expire. */
    fun streamUrl(trackId: String): String = "$BASE_URL/track/$trackId"

    companion object {
        private const val TAG = "Monochrome"

        /** Monochrome's public track streamer. */
        const val BASE_URL = "https://tracks.monochrome.st"

        private const val SEARCH_URL = "$BASE_URL/search/tracks"
        private const val USER_AGENT = "SimpMusic (private build)"
        private const val REQUEST_TIMEOUT_MS = 10_000L
        private const val SEARCH_LIMIT = 10
        private const val MAX_PROBES = 2

        /** STREAMINFO and the tags behind it: what the file says it is. */
        private const val PROBE_BYTES = FlacIdentity.PROBE_BYTES

        /** Whether [url] is a Monochrome stream address made by [streamUrl]. */
        fun isStreamUrl(url: String): Boolean = url.startsWith("$BASE_URL/track/")
    }
}
