# SimpMusic web server — sync API (contract shared by web server and Android app)

Base URL: http://<host>:3000. Auth: header `Authorization: Bearer <token>`. The token is generated
on first start, stored in /data/token, printed in the logs and shown in the web UI's Settings → "Pair phone",
together with a QR code of `simpmusic://server-sync?u=<base url>&t=<token>`.

All timestamps are epoch milliseconds. Conflict rule: last write wins per entity by `updatedAt`.
Deletions are tombstones (`deleted: true`).

## Entities
Song      { videoId, title, artists: [{name, id?}], album?: {name, id?}, durationSeconds?, thumbnail?, isVideo?, updatedAt }
Like      { videoId, liked: boolean, updatedAt }
Playlist  { id (uuid, created by whichever side made it), title, thumbnail?, trackIds: [videoId], youtubePlaylistId?, deleted?, updatedAt }
History   { videoId, playedAt, listenedSeconds }        (append-only, deduped by videoId+playedAt)
Follow    { channelId, name, thumbnail?, followed: boolean, updatedAt }
Session   { deviceName, videoId, positionMs, isPlaying, queue: [videoId], queueIndex, updatedAt }

## Endpoints
GET  /api/sync/ping                       -> { ok, serverName, version }
POST /api/sync/push   body { deviceId, songs[], likes[], playlists[], history[], follows[] }
                      -> { accepted counts, serverTime }
GET  /api/sync/pull?since=<ms>            -> { songs[], likes[], playlists[], history[], follows[], serverTime }
                      (everything changed on the server after `since`, including changes made in the web UI)
PUT  /api/session     body Session        (the device currently playing reports itself, every ~10 s and on change)
GET  /api/session                         -> latest Session or null   ("continue on this device")
