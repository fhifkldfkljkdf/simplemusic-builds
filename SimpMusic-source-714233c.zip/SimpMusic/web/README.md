# SimpMusic Web

A self-hosted web counterpart of the [SimpMusic](https://github.com/maxrave-dev/SimpMusic) Android app
(a YouTube Music client). It browses YouTube Music with [`youtubei.js`](https://github.com/LuanRT/YouTube.js),
plays audio through a same-origin proxy, stores the library in SQLite and shares likes, playlists,
follows, history and the current playback session with the phone through [SYNC_API.md](./SYNC_API.md).

Designed for an x86 home server on the LAN, behind no authentication for the UI itself; only the
sync API is guarded by a pairing token.

## Features

- **Browse** — YouTube Music home feed, search with live suggestions and Songs / Albums / Artists /
  Playlists / Videos tabs, album pages, artist pages (top songs, albums, singles, related), YouTube
  playlist pages, moods & genres, charts.
- **Player** — persistent bottom bar plus an expandable Now Playing sheet: queue with reorder/remove,
  play next, add to queue, shuffle, repeat off/all/one, seek, volume, Media Session integration and
  keyboard shortcuts (`Space` play/pause, `←/→` seek 5 s, `↑/↓` volume, `M` mute, `N`/`P` next/previous).
- **Radio** — "Start radio" on any track uses the YouTube Music automix (`RDAMVM<videoId>`) and keeps
  extending the queue when it reaches the end.
- **Lyrics** — synced lyrics from [LRCLIB](https://lrclib.net), shown karaoke-style and clickable to
  seek; plain lyrics as a fallback.
- **Library** — liked songs, local playlists (create / rename / delete / add / remove), followed
  artists, playback history. Every edit is stamped `updatedAt = now`, so the phone picks it up on its
  next sync.
- **Phone pairing** — token plus QR code (`simpmusic://server-sync?u=<base url>&t=<token>`) in
  Settings.
- **Session handoff** — while playing, the web player reports itself as `Web` every 10 s. When the
  phone has a newer session, a "Continue from …" banner loads that queue and seeks to its position.

## Quick start (Docker)

```bash
cd web
docker compose up -d --build
```

Open <http://<server-ip>:3000>. The database and token live in the `simpmusic-data` volume mounted at
`/data`. The container runs as a non-root user (uid 1001); if you bind-mount a host directory instead
of the named volume, make it writable by uid 1001.

Environment:

| Variable     | Default        | Meaning                                                              |
| ------------ | -------------- | -------------------------------------------------------------------- |
| `DATA_DIR`   | `/data` (image) / `./data` (dev) | Directory for `simpmusic.db` and `token`.       |
| `PUBLIC_URL` | *unset*        | Base URL for the pairing QR. Unset = the request's `Host` header.    |
| `SYNC_TOKEN` | *unset*        | Fixed pairing token instead of generating `DATA_DIR/token`.          |
| `DB_PATH`    | `DATA_DIR/simpmusic.db` | Override the SQLite file location.                          |

## Development

```bash
cd web
npm install
npm run dev          # http://localhost:3000, data in ./data
```

Production without Docker:

```bash
npm run build
DATA_DIR=/srv/simpmusic PORT=3000 node .next/standalone/server.js
```

`next start` also works, but the image uses the standalone output.

## Pairing the phone

1. Open **Settings** in the web UI (or the log line printed at first start) — it shows the server
   URL, the token and a QR code.
2. In the SimpMusic app open **Settings → Server sync** and scan the QR (or type the URL and token).
3. Pair. The app pushes its library, the server pulls it into the web UI, and both keep syncing —
   last write wins per entity, deletions are tombstones.

The QR encodes `simpmusic://server-sync?u=<base url>&t=<token>`; the base URL comes from
`PUBLIC_URL` when set, otherwise from the request host. If you use a reverse proxy, make sure
`X-Forwarded-Host`/`X-Forwarded-Proto` are forwarded or set `PUBLIC_URL`.

## Audio

Browsers cannot play `googlevideo.com` URLs cross-origin, so `/api/stream/[videoId]` resolves the
best audio-only format with `youtubei.js` (WEB_REMIX first, then the ANDROID / IOS / TV clients if the
signature cannot be deciphered), caches the URL in memory until its `expire` timestamp and proxies
the bytes. `Range` requests are forwarded, so seeking works and the response is `206 Partial
Content` with the upstream `Content-Type` and `Content-Range`.

YouTube can rate-limit or block a datacenter/VPN IP. If playback fails with HTTP 403/502, check the
server log and try a residential connection or a proxy (not built in).

## Storage and backup

- `DATA_DIR/simpmusic.db` — SQLite (WAL) with songs, likes, playlists, history, follows and the last
  session. Back it up together with `DATA_DIR/token`, or use `sqlite3 .backup`.
- `DATA_DIR/token` — the pairing token (`SYNC_TOKEN` overrides it).
- `/api/sync/pull?since=` returns everything changed on the server after a timestamp, including web
  edits, so the phone and the browser converge.

## Layout

```
web/
├── src/app/                 App Router pages and API routes
│   ├── api/sync/{ping,push,pull}   SYNC_API.md endpoints (bearer token)
│   ├── api/session          token-guarded session get/put for the phone
│   ├── api/internal/session open session get/put used by the web player
│   ├── api/stream/[videoId] audio proxy (Range-capable)
│   ├── api/yt/*             search, suggestions, radio, queue metadata
│   ├── api/library/*        likes, playlists, history, follows, summary
│   ├── api/lyrics           LRCLIB lookup
│   └── page.tsx, search, album, artist, playlist, moods, browse, charts, library, settings
├── src/components/          player providers, bottom bar, now playing, cards, rows
├── src/lib/                 db + sync merge, youtubei.js wrapper, LRCLIB, helpers
├── Dockerfile               multi-stage node:22-bookworm-slim, standalone, non-root
├── docker-compose.yml
└── SYNC_API.md              the contract shared with the Android client
```

## Notes

- Single user, no accounts. The UI is open to anyone who can reach the port; put it behind a
  firewall or reverse proxy if the network is not trusted. The token only protects the sync API.
- SQLite writes go through `better-sqlite3` (synchronous, single process). One instance per database.
- YouTube Music data is unofficial; `youtubei.js` can break when YouTube changes its player, and
  stream URLs expire (they are re-resolved automatically).
