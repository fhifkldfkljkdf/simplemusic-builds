import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

/** Where the SQLite database and the pairing token live. */
export function dataDir(): string {
  return process.env.DATA_DIR?.trim() || path.join(process.cwd(), "data");
}

export function ensureDataDir(): string {
  const dir = dataDir();
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

let cachedToken: string | null = null;

/**
 * The pairing token. Generated once on first start and stored next to the
 * database (`/data/token` in Docker), exactly as described in SYNC_API.md.
 */
export function getToken(): string {
  if (cachedToken) return cachedToken;
  if (process.env.SYNC_TOKEN?.trim()) {
    cachedToken = process.env.SYNC_TOKEN.trim();
    return cachedToken;
  }
  const file = path.join(ensureDataDir(), "token");
  try {
    const existing = fs.readFileSync(file, "utf8").trim();
    if (existing) {
      cachedToken = existing;
      return existing;
    }
  } catch {
    // first start
  }
  const token = crypto.randomBytes(24).toString("hex");
  fs.writeFileSync(file, token + "\n", { mode: 0o600 });
  cachedToken = token;
  console.log(`[simpmusic-web] pairing token written to ${file}: ${token}`);
  return token;
}

export const SERVER_NAME = "SimpMusic Web";
export const SERVER_VERSION = "1.0.0";
