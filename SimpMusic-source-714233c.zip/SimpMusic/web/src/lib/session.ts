import { putSession } from "./db";
import { json } from "./http";
import type { ServerSyncSession } from "./types";

/** Shared by the token-guarded /api/session and the web UI's /api/internal/session. */
export async function saveSession(request: Request) {
  let body: ServerSyncSession;
  try {
    body = (await request.json()) as ServerSyncSession;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  if (!body || typeof body.videoId !== "string" || !body.videoId) {
    return json({ error: "videoId required" }, 400);
  }
  putSession({
    deviceName: typeof body.deviceName === "string" && body.deviceName ? body.deviceName : "Unknown",
    videoId: body.videoId,
    positionMs: Number(body.positionMs) || 0,
    isPlaying: !!body.isPlaying,
    queue: Array.isArray(body.queue) ? body.queue.filter((value) => typeof value === "string") : [],
    queueIndex: Number(body.queueIndex) || 0,
    updatedAt: Number(body.updatedAt) || Date.now(),
  });
  return json({ ok: true });
}
