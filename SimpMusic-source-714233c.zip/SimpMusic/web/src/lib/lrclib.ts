import type { Track } from "./types";

interface Lyrics {
  syncedLyrics: string | null;
  plainLyrics: string | null;
  instrumental: boolean;
}

interface CacheEntry {
  at: number;
  value: Lyrics | null;
}

declare global {
  // eslint-disable-next-line no-var
  var __simpmusicLyricsCache: Map<string, CacheEntry> | undefined;
}

const TTL = 6 * 60 * 60 * 1000;
const UA = "SimpMusic-Web/1.0.0 (self-hosted; https://github.com/maxrave-dev/SimpMusic)";

function cache(): Map<string, CacheEntry> {
  if (!globalThis.__simpmusicLyricsCache) globalThis.__simpmusicLyricsCache = new Map();
  return globalThis.__simpmusicLyricsCache;
}

function toLyrics(data: any): Lyrics | null {
  if (!data || typeof data !== "object") return null;
  const synced = typeof data.syncedLyrics === "string" ? data.syncedLyrics : null;
  const plain = typeof data.plainLyrics === "string" ? data.plainLyrics : null;
  if (!synced && !plain) return null;
  return { syncedLyrics: synced, plainLyrics: plain, instrumental: !!data.instrumental };
}

/** LRCLIB sometimes holds placeholder records ("probe") for a title; don't show those. */
function isUsable(lyrics: Lyrics | null): boolean {
  if (!lyrics) return false;
  if (lyrics.instrumental) return true;
  const text = lyrics.plainLyrics ?? lyrics.syncedLyrics ?? "";
  const lines = text.split(/\r?\n/).filter((line) => line.trim().length > 0);
  return text.length > 80 || lines.length > 2;
}

async function lrclib(path: string, params: Record<string, string>): Promise<any> {
  const url = new URL(`https://lrclib.net${path}`);
  for (const [key, value] of Object.entries(params)) {
    if (value) url.searchParams.set(key, value);
  }
  const response = await fetch(url, {
    headers: { "User-Agent": UA, Accept: "application/json" },
    signal: AbortSignal.timeout(10_000),
    cache: "no-store",
  });
  if (!response.ok) return null;
  return response.json();
}

/** Synced lyrics from LRCLIB (https://lrclib.net/docs). Exact match first, then search. */
export async function getLyrics(track: Track): Promise<Lyrics | null> {
  const key = track.videoId;
  const cached = cache().get(key);
  if (cached && Date.now() - cached.at < TTL) return cached.value;

  const artist = track.artists?.map((a) => a.name).join(", ") ?? "";
  const params = {
    track_name: track.title,
    artist_name: artist,
    album_name: track.album?.name ?? "",
    duration: track.duration ? String(Math.round(track.duration)) : "",
  };

  let result: Lyrics | null = null;
  try {
    result = toLyrics(await lrclib("/api/get", params));
    if (!isUsable(result)) {
      const found = await lrclib("/api/search", {
        track_name: params.track_name,
        artist_name: params.artist_name,
      });
      if (Array.isArray(found) && found.length) {
        const withTiming = found.filter((entry) => entry?.syncedLyrics);
        const pool = withTiming.length ? withTiming : found;
        const best = track.duration
          ? [...pool].sort(
              (a, b) =>
                Math.abs((a?.duration ?? 0) - (track.duration ?? 0)) -
                Math.abs((b?.duration ?? 0) - (track.duration ?? 0))
            )[0]
          : pool[0];
        result = toLyrics(best);
      }
    }
  } catch {
    result = null;
  }

  cache().set(key, { at: Date.now(), value: result });
  return result;
}
