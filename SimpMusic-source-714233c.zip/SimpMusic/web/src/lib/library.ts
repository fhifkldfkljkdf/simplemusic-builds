import crypto from "node:crypto";
import {
  bumpChangedAt,
  ensureSong,
  followedArtists,
  getLocalPlaylist,
  getLocalPlaylists,
  getSongs,
  historyTracks,
  insertHistory,
  likedIds,
  likedTracks,
  setFollow,
  setLike,
  songToTrack,
  stats,
  writeLocalPlaylist,
} from "./db";
import type { LocalPlaylist, ServerSyncFollow, ServerSyncPlaylist, ServerSyncSong, Track } from "./types";

/** Library reads/writes made from the web UI. Every write is stamped `Date.now()` so the phone
 *  pulls it on its next sync (last write wins). */

export function listLikedTracks(): Track[] {
  return likedTracks().map(songToTrack);
}

export function listPlaylists(): ServerSyncPlaylist[] {
  return getLocalPlaylists(false);
}

export function listHistory(limit = 200) {
  return historyTracks(limit);
}

export function listFollows(): ServerSyncFollow[] {
  return followedArtists();
}

export function summary() {
  return {
    likedIds: likedIds(),
    followedIds: followedArtists().map((f) => f.channelId),
    playlists: getLocalPlaylists(false).map((p) => ({
      id: p.id,
      title: p.title,
      trackIds: p.trackIds,
      thumbnail: p.thumbnail ?? null,
    })),
    stats: stats(),
  };
}

export function setLiked(track: Track, liked: boolean): void {
  ensureSong(track);
  setLike(track.videoId, liked);
}

export function recordPlayback(track: Track, listenedSeconds: number, playedAt = Date.now()): boolean {
  ensureSong(track);
  const changedAt = bumpChangedAt(playedAt);
  return insertHistory(
    { videoId: track.videoId, playedAt, listenedSeconds: Math.max(0, Math.round(listenedSeconds)) },
    changedAt
  );
}

export function setFollowed(follow: {
  channelId: string;
  name: string;
  thumbnail?: string | null;
  followed: boolean;
}): void {
  setFollow(
    {
      channelId: follow.channelId,
      name: follow.name,
      thumbnail: follow.thumbnail ?? null,
      followed: follow.followed,
      updatedAt: Date.now(),
    },
    Date.now()
  );
}

export function createPlaylist(title: string, track?: Track): ServerSyncPlaylist {
  const now = Date.now();
  if (track) ensureSong(track, now);
  const playlist: ServerSyncPlaylist = {
    id: crypto.randomUUID(),
    title: title.trim() || "New playlist",
    thumbnail: track?.thumbnail ?? null,
    trackIds: track ? [track.videoId] : [],
    deleted: false,
    updatedAt: now,
  };
  writeLocalPlaylist(playlist, now, bumpChangedAt(now));
  return playlist;
}

export function createPlaylistFromTracks(
  title: string,
  tracks: Track[],
  youtubePlaylistId?: string | null
): ServerSyncPlaylist {
  const now = Date.now();
  for (const track of tracks) ensureSong(track, now);
  const trackIds: string[] = [];
  for (const track of tracks) {
    if (!trackIds.includes(track.videoId)) trackIds.push(track.videoId);
  }
  const playlist: ServerSyncPlaylist = {
    id: crypto.randomUUID(),
    title: title.trim() || "Imported playlist",
    thumbnail: tracks.find((t) => t.thumbnail)?.thumbnail ?? null,
    trackIds,
    youtubePlaylistId: youtubePlaylistId ?? null,
    deleted: false,
    updatedAt: now,
  };
  writeLocalPlaylist(playlist, now, bumpChangedAt(now));
  return playlist;
}

export function renamePlaylist(id: string, title: string): ServerSyncPlaylist | null {
  const existing = getLocalPlaylist(id);
  if (!existing || existing.deleted) return null;
  const now = Date.now();
  const updated: ServerSyncPlaylist = { ...existing, title: title.trim() || existing.title, updatedAt: now };
  writeLocalPlaylist(updated, now, bumpChangedAt(now));
  return updated;
}

export function deletePlaylist(id: string): boolean {
  const existing = getLocalPlaylist(id);
  if (!existing) return false;
  const now = Date.now();
  writeLocalPlaylist({ ...existing, deleted: true, updatedAt: now }, now, bumpChangedAt(now));
  return true;
}

export function addTrackToPlaylist(id: string, track: Track): ServerSyncPlaylist | null {
  const existing = getLocalPlaylist(id);
  if (!existing || existing.deleted) return null;
  const now = Date.now();
  ensureSong(track, now);
  if (existing.trackIds.includes(track.videoId)) return existing;
  const updated: ServerSyncPlaylist = {
    ...existing,
    trackIds: [...existing.trackIds, track.videoId],
    thumbnail: existing.thumbnail ?? track.thumbnail ?? null,
    updatedAt: now,
  };
  writeLocalPlaylist(updated, now, bumpChangedAt(now));
  return updated;
}

export function removeTrackFromPlaylist(id: string, videoId: string): ServerSyncPlaylist | null {
  const existing = getLocalPlaylist(id);
  if (!existing || existing.deleted) return null;
  const now = Date.now();
  const updated: ServerSyncPlaylist = {
    ...existing,
    trackIds: existing.trackIds.filter((t) => t !== videoId),
    updatedAt: now,
  };
  writeLocalPlaylist(updated, now, bumpChangedAt(now));
  return updated;
}

export function playlistTracks(playlist: ServerSyncPlaylist): Track[] {
  const songs = new Map(getSongs(playlist.trackIds).map((s) => [s.videoId, s] as [string, ServerSyncSong]));
  return playlist.trackIds
    .map((id) => songs.get(id))
    .filter((s): s is ServerSyncSong => !!s)
    .map(songToTrack);
}

export type { LocalPlaylist };
