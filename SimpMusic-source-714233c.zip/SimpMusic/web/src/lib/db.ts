import Database from "better-sqlite3";
import path from "node:path";
import { ensureDataDir } from "./paths";
import type {
  AlbumRef,
  ArtistRef,
  ServerSyncFollow,
  ServerSyncHistory,
  ServerSyncLike,
  ServerSyncPlaylist,
  ServerSyncSession,
  ServerSyncSong,
  Track,
} from "./types";

let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (db) return db;
  const dir = ensureDataDir();
  const file = process.env.DB_PATH?.trim() || path.join(dir, "simpmusic.db");
  const connection = new Database(file);
  connection.pragma("journal_mode = WAL");
  connection.pragma("synchronous = NORMAL");
  connection.pragma("foreign_keys = OFF");
  connection.pragma("busy_timeout = 5000");
  migrate(connection);
  db = connection;
  return db;
}

function migrate(connection: Database.Database) {
  connection.exec(`
    CREATE TABLE IF NOT EXISTS songs (
      video_id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      artists TEXT NOT NULL DEFAULT '[]',
      album TEXT,
      duration_seconds INTEGER,
      thumbnail TEXT,
      is_video INTEGER,
      updated_at INTEGER NOT NULL DEFAULT 0,
      changed_at INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS likes (
      video_id TEXT PRIMARY KEY,
      liked INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      changed_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS playlists (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      thumbnail TEXT,
      track_ids TEXT NOT NULL DEFAULT '[]',
      youtube_playlist_id TEXT,
      deleted INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL,
      changed_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS history (
      video_id TEXT NOT NULL,
      played_at INTEGER NOT NULL,
      listened_seconds INTEGER NOT NULL DEFAULT 0,
      changed_at INTEGER NOT NULL,
      PRIMARY KEY (video_id, played_at)
    );
    CREATE TABLE IF NOT EXISTS follows (
      channel_id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      thumbnail TEXT,
      followed INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      changed_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS session (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      device_name TEXT NOT NULL,
      video_id TEXT NOT NULL,
      position_ms INTEGER NOT NULL,
      is_playing INTEGER NOT NULL,
      queue TEXT NOT NULL DEFAULT '[]',
      queue_index INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS songs_changed ON songs(changed_at);
    CREATE INDEX IF NOT EXISTS likes_changed ON likes(changed_at);
    CREATE INDEX IF NOT EXISTS playlists_changed ON playlists(changed_at);
    CREATE INDEX IF NOT EXISTS history_changed ON history(changed_at);
    CREATE INDEX IF NOT EXISTS follows_changed ON follows(changed_at);
  `);
}

// ---- change clock ---------------------------------------------------------------------------
// `since` in /api/sync/pull is wall clock ms, but an entity may arrive carrying an old
// `updatedAt` (the phone's favourite time from years ago). Pull therefore filters on the server
// side `changed_at`, a strictly increasing stamp, while the wire still carries `updatedAt`.

type MetaRow = { value: string };

export function maxChangedAt(): number {
  const row = getDb().prepare("SELECT value FROM meta WHERE key = 'max_changed_at'").get() as MetaRow | undefined;
  return row ? Number(row.value) || 0 : 0;
}

/** Must be called before writing rows that share one stamp. Monotonic across restarts. */
export function bumpChangedAt(now = Date.now()): number {
  const next = Math.max(now, maxChangedAt() + 1);
  getDb()
    .prepare("INSERT INTO meta(key, value) VALUES('max_changed_at', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
    .run(String(next));
  return next;
}

/** A value a client can safely store as its next `since`. Stored stamps stay >= this. */
export function serverClock(now = Date.now()): number {
  return Math.max(now, maxChangedAt());
}

// ---- row mappers ----------------------------------------------------------------------------

interface SongRow {
  video_id: string;
  title: string;
  artists: string;
  album: string | null;
  duration_seconds: number | null;
  thumbnail: string | null;
  is_video: number | null;
  updated_at: number;
  changed_at: number;
}

function parseArtists(raw: string): ArtistRef[] {
  try {
    const value = JSON.parse(raw);
    if (!Array.isArray(value)) return [];
    return value
      .map((a) => (typeof a === "string" ? { name: a } : { name: String(a?.name ?? ""), id: a?.id ?? null }))
      .filter((a) => a.name);
  } catch {
    return [];
  }
}

function parseAlbum(raw: string | null): AlbumRef | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw);
    if (typeof value === "string") return { name: value };
    if (value?.name) return { name: String(value.name), id: value.id ?? null };
    return null;
  } catch {
    return null;
  }
}

export function songFromRow(row: SongRow): ServerSyncSong {
  return {
    videoId: row.video_id,
    title: row.title,
    artists: parseArtists(row.artists),
    album: parseAlbum(row.album),
    durationSeconds: row.duration_seconds,
    thumbnail: row.thumbnail,
    isVideo: row.is_video == null ? null : !!row.is_video,
    updatedAt: row.updated_at,
  };
}

export function songToTrack(song: ServerSyncSong): Track {
  return {
    videoId: song.videoId,
    title: song.title,
    artists: song.artists,
    album: song.album ?? null,
    duration: song.durationSeconds ?? null,
    thumbnail: song.thumbnail ?? null,
    isVideo: song.isVideo ?? null,
  };
}

export function trackToSong(track: Track, updatedAt: number): ServerSyncSong {
  return {
    videoId: track.videoId,
    title: track.title,
    artists: track.artists ?? [],
    album: track.album ?? null,
    durationSeconds: track.duration ?? null,
    thumbnail: track.thumbnail ?? null,
    isVideo: track.isVideo ?? null,
    updatedAt,
  };
}

/**
 * Insert or update a song. Returns true when something was written. Last write wins on
 * `updatedAt`; equal timestamps are not rewritten (no sync churn).
 */
export function upsertSong(song: ServerSyncSong, changedAt: number): boolean {
  const result = getDb()
    .prepare(
      `INSERT INTO songs (video_id, title, artists, album, duration_seconds, thumbnail, is_video, updated_at, changed_at)
       VALUES (@videoId, @title, @artists, @album, @durationSeconds, @thumbnail, @isVideo, @updatedAt, @changedAt)
       ON CONFLICT(video_id) DO UPDATE SET
         title = excluded.title,
         artists = excluded.artists,
         album = excluded.album,
         duration_seconds = excluded.duration_seconds,
         thumbnail = excluded.thumbnail,
         is_video = excluded.is_video,
         updated_at = excluded.updated_at,
         changed_at = excluded.changed_at
       WHERE excluded.updated_at > songs.updated_at`
    )
    .run({
      videoId: song.videoId,
      title: song.title,
      artists: JSON.stringify(song.artists ?? []),
      album: song.album ? JSON.stringify(song.album) : null,
      durationSeconds: song.durationSeconds ?? null,
      thumbnail: song.thumbnail ?? null,
      isVideo: song.isVideo == null ? null : song.isVideo ? 1 : 0,
      updatedAt: song.updatedAt,
      changedAt,
    });
  return result.changes > 0;
}

/** Metadata-only refresh used by web edits; never touches sync timestamps. */
export function touchSongMetadata(song: ServerSyncSong): void {
  getDb()
    .prepare(
      `UPDATE songs SET title = @title, artists = @artists, album = @album,
       duration_seconds = @durationSeconds, thumbnail = @thumbnail, is_video = @isVideo
       WHERE video_id = @videoId`
    )
    .run({
      videoId: song.videoId,
      title: song.title,
      artists: JSON.stringify(song.artists ?? []),
      album: song.album ? JSON.stringify(song.album) : null,
      durationSeconds: song.durationSeconds ?? null,
      thumbnail: song.thumbnail ?? null,
      isVideo: song.isVideo == null ? null : song.isVideo ? 1 : 0,
    });
}

/** Make sure a row exists for a track played/liked in the web UI. */
export function ensureSong(track: Track, now = Date.now()): void {
  const existing = getDb().prepare("SELECT video_id FROM songs WHERE video_id = ?").get(track.videoId) as
    | { video_id: string }
    | undefined;
  if (existing) {
    touchSongMetadata(trackToSong(track, now));
    return;
  }
  upsertSong(trackToSong(track, now), bumpChangedAt(now));
}

export function getSong(videoId: string): ServerSyncSong | null {
  const row = getDb().prepare("SELECT * FROM songs WHERE video_id = ?").get(videoId) as SongRow | undefined;
  return row ? songFromRow(row) : null;
}

export function getSongs(videoIds: string[]): ServerSyncSong[] {
  if (!videoIds.length) return [];
  const unique = Array.from(new Set(videoIds));
  const placeholders = unique.map(() => "?").join(",");
  const rows = getDb()
    .prepare(`SELECT * FROM songs WHERE video_id IN (${placeholders})`)
    .all(...unique) as SongRow[];
  const byId = new Map(rows.map((row) => [row.video_id, songFromRow(row)]));
  return videoIds.map((id) => byId.get(id)).filter((s): s is ServerSyncSong => !!s);
}

// ---- likes ----------------------------------------------------------------------------------

interface LikeRow {
  video_id: string;
  liked: number;
  updated_at: number;
  changed_at: number;
}

export function upsertLike(like: ServerSyncLike, changedAt: number): boolean {
  const result = getDb()
    .prepare(
      `INSERT INTO likes (video_id, liked, updated_at, changed_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(video_id) DO UPDATE SET liked = excluded.liked, updated_at = excluded.updated_at, changed_at = excluded.changed_at
       WHERE excluded.updated_at > likes.updated_at`
    )
    .run(like.videoId, like.liked ? 1 : 0, like.updatedAt, changedAt);
  return result.changes > 0;
}

export function setLike(videoId: string, liked: boolean, now = Date.now()): void {
  const changedAt = bumpChangedAt(now);
  getDb()
    .prepare(
      `INSERT INTO likes (video_id, liked, updated_at, changed_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(video_id) DO UPDATE SET liked = excluded.liked, updated_at = excluded.updated_at, changed_at = excluded.changed_at`
    )
    .run(videoId, liked ? 1 : 0, now, changedAt);
}

export function likedIds(): string[] {
  const rows = getDb().prepare("SELECT video_id FROM likes WHERE liked = 1 ORDER BY updated_at DESC").all() as {
    video_id: string;
  }[];
  return rows.map((r) => r.video_id);
}

export function isLiked(videoId: string): boolean {
  const row = getDb().prepare("SELECT liked FROM likes WHERE video_id = ?").get(videoId) as
    | { liked: number }
    | undefined;
  return !!row?.liked;
}

export function likedTracks(limit = 5000): ServerSyncSong[] {
  const rows = getDb()
    .prepare(
      `SELECT s.* FROM songs s JOIN likes l ON l.video_id = s.video_id
       WHERE l.liked = 1 ORDER BY l.updated_at DESC LIMIT ?`
    )
    .all(limit) as SongRow[];
  return rows.map(songFromRow);
}

// ---- playlists ------------------------------------------------------------------------------

interface PlaylistRow {
  id: string;
  title: string;
  thumbnail: string | null;
  track_ids: string;
  youtube_playlist_id: string | null;
  deleted: number;
  updated_at: number;
  changed_at: number;
}

export function playlistFromRow(row: PlaylistRow): ServerSyncPlaylist {
  let trackIds: string[] = [];
  try {
    const parsed = JSON.parse(row.track_ids);
    if (Array.isArray(parsed)) trackIds = parsed.map(String);
  } catch {
    trackIds = [];
  }
  return {
    id: row.id,
    title: row.title,
    thumbnail: row.thumbnail,
    trackIds,
    youtubePlaylistId: row.youtube_playlist_id,
    deleted: !!row.deleted,
    updatedAt: row.updated_at,
  };
}

export function upsertPlaylist(playlist: ServerSyncPlaylist, changedAt: number): boolean {
  const result = getDb()
    .prepare(
      `INSERT INTO playlists (id, title, thumbnail, track_ids, youtube_playlist_id, deleted, updated_at, changed_at)
       VALUES (@id, @title, @thumbnail, @trackIds, @youtubePlaylistId, @deleted, @updatedAt, @changedAt)
       ON CONFLICT(id) DO UPDATE SET
         title = excluded.title,
         thumbnail = excluded.thumbnail,
         track_ids = excluded.track_ids,
         youtube_playlist_id = excluded.youtube_playlist_id,
         deleted = excluded.deleted,
         updated_at = excluded.updated_at,
         changed_at = excluded.changed_at
       WHERE excluded.updated_at > playlists.updated_at`
    )
    .run({
      id: playlist.id,
      title: playlist.title,
      thumbnail: playlist.thumbnail ?? null,
      trackIds: JSON.stringify(playlist.trackIds ?? []),
      youtubePlaylistId: playlist.youtubePlaylistId ?? null,
      deleted: playlist.deleted ? 1 : 0,
      updatedAt: playlist.updatedAt,
      changedAt,
    });
  return result.changes > 0;
}

export function getLocalPlaylists(includeDeleted = false): ServerSyncPlaylist[] {
  const rows = getDb()
    .prepare(
      `SELECT * FROM playlists ${includeDeleted ? "" : "WHERE deleted = 0"} ORDER BY updated_at DESC`
    )
    .all() as PlaylistRow[];
  return rows.map(playlistFromRow);
}

export function getLocalPlaylist(id: string): ServerSyncPlaylist | null {
  const row = getDb().prepare("SELECT * FROM playlists WHERE id = ?").get(id) as PlaylistRow | undefined;
  return row ? playlistFromRow(row) : null;
}

export function writeLocalPlaylist(playlist: ServerSyncPlaylist, now = Date.now(), changedAt = bumpChangedAt(now)): void {
  getDb()
    .prepare(
      `INSERT INTO playlists (id, title, thumbnail, track_ids, youtube_playlist_id, deleted, updated_at, changed_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         title = excluded.title, thumbnail = excluded.thumbnail, track_ids = excluded.track_ids,
         youtube_playlist_id = excluded.youtube_playlist_id, deleted = excluded.deleted,
         updated_at = excluded.updated_at, changed_at = excluded.changed_at`
    )
    .run(
      playlist.id,
      playlist.title,
      playlist.thumbnail ?? null,
      JSON.stringify(playlist.trackIds ?? []),
      playlist.youtubePlaylistId ?? null,
      playlist.deleted ? 1 : 0,
      now,
      changedAt
    );
}

// ---- history --------------------------------------------------------------------------------

interface HistoryRow {
  video_id: string;
  played_at: number;
  listened_seconds: number;
  changed_at: number;
}

export function insertHistory(entry: ServerSyncHistory, changedAt: number): boolean {
  const result = getDb()
    .prepare(
      `INSERT INTO history (video_id, played_at, listened_seconds, changed_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(video_id, played_at) DO NOTHING`
    )
    .run(entry.videoId, entry.playedAt, entry.listenedSeconds ?? 0, changedAt);
  return result.changes > 0;
}

export function historyEntries(limit = 200): ServerSyncHistory[] {
  const rows = getDb()
    .prepare("SELECT * FROM history ORDER BY played_at DESC LIMIT ?")
    .all(limit) as HistoryRow[];
  return rows.map((r) => ({ videoId: r.video_id, playedAt: r.played_at, listenedSeconds: r.listened_seconds }));
}

export function historyTracks(limit = 200): { track: ServerSyncSong; playedAt: number; listenedSeconds: number }[] {
  const entries = historyEntries(limit);
  const songs = new Map(getSongs(entries.map((e) => e.videoId)).map((s) => [s.videoId, s]));
  return entries
    .filter((e) => songs.has(e.videoId))
    .map((e) => ({ track: songs.get(e.videoId)!, playedAt: e.playedAt, listenedSeconds: e.listenedSeconds }));
}

// ---- follows --------------------------------------------------------------------------------

interface FollowRow {
  channel_id: string;
  name: string;
  thumbnail: string | null;
  followed: number;
  updated_at: number;
  changed_at: number;
}

export function followFromRow(row: FollowRow): ServerSyncFollow {
  return {
    channelId: row.channel_id,
    name: row.name,
    thumbnail: row.thumbnail,
    followed: !!row.followed,
    updatedAt: row.updated_at,
  };
}

export function upsertFollow(follow: ServerSyncFollow, changedAt: number): boolean {
  const result = getDb()
    .prepare(
      `INSERT INTO follows (channel_id, name, thumbnail, followed, updated_at, changed_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(channel_id) DO UPDATE SET name = excluded.name, thumbnail = excluded.thumbnail,
         followed = excluded.followed, updated_at = excluded.updated_at, changed_at = excluded.changed_at
       WHERE excluded.updated_at > follows.updated_at`
    )
    .run(follow.channelId, follow.name, follow.thumbnail ?? null, follow.followed ? 1 : 0, follow.updatedAt, changedAt);
  return result.changes > 0;
}

export function setFollow(follow: ServerSyncFollow, now = Date.now()): void {
  const changedAt = bumpChangedAt(now);
  getDb()
    .prepare(
      `INSERT INTO follows (channel_id, name, thumbnail, followed, updated_at, changed_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(channel_id) DO UPDATE SET name = excluded.name, thumbnail = excluded.thumbnail,
         followed = excluded.followed, updated_at = excluded.updated_at, changed_at = excluded.changed_at`
    )
    .run(follow.channelId, follow.name, follow.thumbnail ?? null, follow.followed ? 1 : 0, now, changedAt);
}

export function followedArtists(): ServerSyncFollow[] {
  const rows = getDb().prepare("SELECT * FROM follows WHERE followed = 1 ORDER BY name").all() as FollowRow[];
  return rows.map(followFromRow);
}

export function followedIds(): string[] {
  const rows = getDb().prepare("SELECT channel_id FROM follows WHERE followed = 1").all() as {
    channel_id: string;
  }[];
  return rows.map((r) => r.channel_id);
}

// ---- session --------------------------------------------------------------------------------

export function getSession(): ServerSyncSession | null {
  const row = getDb().prepare("SELECT * FROM session WHERE id = 1").get() as
    | {
        device_name: string;
        video_id: string;
        position_ms: number;
        is_playing: number;
        queue: string;
        queue_index: number;
        updated_at: number;
      }
    | undefined;
  if (!row) return null;
  let queue: string[] = [];
  try {
    const parsed = JSON.parse(row.queue);
    if (Array.isArray(parsed)) queue = parsed.map(String);
  } catch {
    queue = [];
  }
  return {
    deviceName: row.device_name,
    videoId: row.video_id,
    positionMs: row.position_ms,
    isPlaying: !!row.is_playing,
    queue,
    queueIndex: row.queue_index,
    updatedAt: row.updated_at,
  };
}

export function putSession(session: ServerSyncSession): void {
  getDb()
    .prepare(
      `INSERT INTO session (id, device_name, video_id, position_ms, is_playing, queue, queue_index, updated_at)
       VALUES (1, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET device_name = excluded.device_name, video_id = excluded.video_id,
         position_ms = excluded.position_ms, is_playing = excluded.is_playing, queue = excluded.queue,
         queue_index = excluded.queue_index, updated_at = excluded.updated_at
       WHERE excluded.updated_at >= session.updated_at`
    )
    .run(
      session.deviceName,
      session.videoId,
      Math.max(0, Math.round(session.positionMs)),
      session.isPlaying ? 1 : 0,
      JSON.stringify(session.queue ?? []),
      Math.max(0, Math.round(session.queueIndex ?? 0)),
      session.updatedAt
    );
}

// ---- pull -----------------------------------------------------------------------------------

export function pullChanges(since: number, serverTime: number) {
  const connection = getDb();
  const songs = (
    connection.prepare("SELECT * FROM songs WHERE changed_at > ? AND changed_at <= ?").all(since, serverTime) as SongRow[]
  ).map(songFromRow);
  const likes = (
    connection.prepare("SELECT * FROM likes WHERE changed_at > ? AND changed_at <= ?").all(since, serverTime) as LikeRow[]
  ).map((row) => ({ videoId: row.video_id, liked: !!row.liked, updatedAt: row.updated_at }));
  const playlists = (
    connection.prepare("SELECT * FROM playlists WHERE changed_at > ? AND changed_at <= ?").all(since, serverTime) as PlaylistRow[]
  ).map(playlistFromRow);
  const history = (
    connection.prepare("SELECT * FROM history WHERE changed_at > ? AND changed_at <= ? ORDER BY played_at").all(since, serverTime) as HistoryRow[]
  ).map((row) => ({ videoId: row.video_id, playedAt: row.played_at, listenedSeconds: row.listened_seconds }));
  const follows = (
    connection.prepare("SELECT * FROM follows WHERE changed_at > ? AND changed_at <= ?").all(since, serverTime) as FollowRow[]
  ).map(followFromRow);
  return { songs, likes, playlists, history, follows };
}

export function stats() {
  const connection = getDb();
  const count = (sql: string) => (connection.prepare(sql).get() as { n: number }).n;
  return {
    songs: count("SELECT COUNT(*) AS n FROM songs"),
    likes: count("SELECT COUNT(*) AS n FROM likes WHERE liked = 1"),
    playlists: count("SELECT COUNT(*) AS n FROM playlists WHERE deleted = 0"),
    history: count("SELECT COUNT(*) AS n FROM history"),
    follows: count("SELECT COUNT(*) AS n FROM follows WHERE followed = 1"),
  };
}
