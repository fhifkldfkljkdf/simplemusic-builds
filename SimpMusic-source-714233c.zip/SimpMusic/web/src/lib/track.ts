import type { AlbumRef, ArtistRef, Track } from "./types";

/** Validate a Track posted by the web UI. */
export function parseTrack(value: unknown): Track | null {
  if (!value || typeof value !== "object") return null;
  const v = value as Record<string, unknown>;
  if (typeof v.videoId !== "string" || !/^[A-Za-z0-9_-]{6,20}$/.test(v.videoId)) return null;
  const artists: ArtistRef[] = Array.isArray(v.artists)
    ? v.artists
        .map((a): ArtistRef | null => {
          if (typeof a === "string") return a ? { name: a } : null;
          if (a && typeof a === "object" && typeof (a as { name?: unknown }).name === "string") {
            const ref = a as { name: string; id?: string };
            return { name: ref.name, id: typeof ref.id === "string" ? ref.id : null };
          }
          return null;
        })
        .filter((a): a is ArtistRef => !!a)
    : [];
  let album: AlbumRef | null = null;
  if (v.album && typeof v.album === "object" && typeof (v.album as { name?: unknown }).name === "string") {
    album = { name: (v.album as { name: string }).name, id: (v.album as { id?: string }).id ?? null };
  }
  return {
    videoId: v.videoId,
    title: typeof v.title === "string" && v.title ? v.title : v.videoId,
    artists,
    album,
    duration: typeof v.duration === "number" && v.duration > 0 ? Math.round(v.duration) : null,
    thumbnail: typeof v.thumbnail === "string" ? v.thumbnail : null,
    isVideo: typeof v.isVideo === "boolean" ? v.isVideo : null,
  };
}
