/**
 * Shared types. The ServerSync types mirror
 * core/domain ServerSyncModels.kt field for field, because the Android client
 * serialises them directly (kotlinx.serialization, unknown keys ignored).
 */

export interface ArtistRef {
  name: string;
  id?: string | null;
}

export interface AlbumRef {
  name: string;
  id?: string | null;
}

/** A playable track as used by the web UI. */
export interface Track {
  videoId: string;
  title: string;
  artists: ArtistRef[];
  album?: AlbumRef | null;
  /** duration in seconds */
  duration?: number | null;
  thumbnail?: string | null;
  isVideo?: boolean | null;
}

export interface ServerSyncSong {
  videoId: string;
  title: string;
  artists: ArtistRef[];
  album?: AlbumRef | null;
  durationSeconds?: number | null;
  thumbnail?: string | null;
  isVideo?: boolean | null;
  updatedAt: number;
}

export interface ServerSyncLike {
  videoId: string;
  liked: boolean;
  updatedAt: number;
}

export interface ServerSyncPlaylist {
  id: string;
  title: string;
  thumbnail?: string | null;
  trackIds: string[];
  youtubePlaylistId?: string | null;
  deleted?: boolean;
  updatedAt: number;
}

export interface ServerSyncHistory {
  videoId: string;
  playedAt: number;
  listenedSeconds: number;
}

export interface ServerSyncFollow {
  channelId: string;
  name: string;
  thumbnail?: string | null;
  followed: boolean;
  updatedAt: number;
}

export interface ServerSyncSession {
  deviceName: string;
  videoId: string;
  positionMs: number;
  isPlaying: boolean;
  queue: string[];
  queueIndex: number;
  updatedAt: number;
}

export interface ServerSyncPushRequest {
  deviceId: string;
  songs?: ServerSyncSong[];
  likes?: ServerSyncLike[];
  playlists?: ServerSyncPlaylist[];
  history?: ServerSyncHistory[];
  follows?: ServerSyncFollow[];
}

export interface ServerSyncPullResponse {
  songs: ServerSyncSong[];
  likes: ServerSyncLike[];
  playlists: ServerSyncPlaylist[];
  history: ServerSyncHistory[];
  follows: ServerSyncFollow[];
  serverTime: number;
}

/** Card shown in a shelf or grid. */
export type CardKind = "song" | "video" | "album" | "artist" | "playlist" | "genre";

export interface Card {
  kind: CardKind;
  /** videoId for songs/videos, browseId for album/artist/playlist, params bucket for genre */
  id: string;
  title: string;
  subtitle?: string;
  thumbnail?: string;
  params?: string;
  track?: Track;
}

export interface Shelf {
  title: string;
  items: Card[];
}

export interface LocalPlaylist {
  id: string;
  title: string;
  thumbnail?: string | null;
  trackIds: string[];
  youtubePlaylistId?: string | null;
  updatedAt: number;
  deleted?: boolean;
}
