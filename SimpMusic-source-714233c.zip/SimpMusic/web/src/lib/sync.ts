import {
  bumpChangedAt,
  insertHistory,
  pullChanges,
  serverClock,
  upsertFollow,
  upsertLike,
  upsertPlaylist,
  upsertSong,
} from "./db";
import type { ServerSyncPullResponse, ServerSyncPushRequest } from "./types";

export interface PushResult {
  accepted: { songs: number; likes: number; playlists: number; history: number; follows: number };
  serverTime: number;
}

const isString = (v: unknown): v is string => typeof v === "string" && v.length > 0;

/**
 * Apply a phone's push with per-entity last-write-wins. Returns how many rows actually
 * changed (a re-push of unchanged data is accepted but counts zero).
 */
export function applyPush(body: ServerSyncPushRequest): PushResult {
  const now = Date.now();
  const changedAt = bumpChangedAt(now);
  const accepted = { songs: 0, likes: 0, playlists: 0, history: 0, follows: 0 };

  for (const song of body.songs ?? []) {
    if (!isString(song?.videoId) || !isString(song?.title)) continue;
    const ok = upsertSong(
      {
        videoId: song.videoId,
        title: song.title,
        artists: Array.isArray(song.artists) ? song.artists : [],
        album: song.album ?? null,
        durationSeconds: typeof song.durationSeconds === "number" ? song.durationSeconds : null,
        thumbnail: song.thumbnail ?? null,
        isVideo: song.isVideo ?? null,
        updatedAt: Number(song.updatedAt) || now,
      },
      changedAt
    );
    if (ok) accepted.songs++;
  }

  for (const like of body.likes ?? []) {
    if (!isString(like?.videoId)) continue;
    const ok = upsertLike(
      { videoId: like.videoId, liked: !!like.liked, updatedAt: Number(like.updatedAt) || now },
      changedAt
    );
    if (ok) accepted.likes++;
  }

  for (const playlist of body.playlists ?? []) {
    if (!isString(playlist?.id)) continue;
    const ok = upsertPlaylist(
      {
        id: playlist.id,
        title: playlist.title ?? "Playlist",
        thumbnail: playlist.thumbnail ?? null,
        trackIds: Array.isArray(playlist.trackIds) ? playlist.trackIds.filter(isString) : [],
        youtubePlaylistId: playlist.youtubePlaylistId ?? null,
        deleted: !!playlist.deleted,
        updatedAt: Number(playlist.updatedAt) || now,
      },
      changedAt
    );
    if (ok) accepted.playlists++;
  }

  for (const entry of body.history ?? []) {
    if (!isString(entry?.videoId) || !entry?.playedAt) continue;
    const ok = insertHistory(
      {
        videoId: entry.videoId,
        playedAt: Number(entry.playedAt) || now,
        listenedSeconds: Number(entry.listenedSeconds) || 0,
      },
      changedAt
    );
    if (ok) accepted.history++;
  }

  for (const follow of body.follows ?? []) {
    if (!isString(follow?.channelId) || !isString(follow?.name)) continue;
    const ok = upsertFollow(
      {
        channelId: follow.channelId,
        name: follow.name,
        thumbnail: follow.thumbnail ?? null,
        followed: !!follow.followed,
        updatedAt: Number(follow.updatedAt) || now,
      },
      changedAt
    );
    if (ok) accepted.follows++;
  }

  // Both shapes are sent: `accepted` is the grouped object, the flat keys are what a
  // hand-written client most likely reads ("accepted counts"). Extra keys are ignored by the app.
  return { accepted, ...accepted, serverTime: Date.now() };
}

export function pullSince(sinceRaw: string | null): ServerSyncPullResponse {
  const since = Math.max(0, Number(sinceRaw ?? "0") || 0);
  // Capture the clock before querying so a write that lands mid-request is not skipped:
  // it is excluded here (changed_at > serverTime) and picked up on the next pull (since = serverTime).
  const serverTime = serverClock();
  const changes = pullChanges(since, serverTime);
  return { ...changes, serverTime };
}
