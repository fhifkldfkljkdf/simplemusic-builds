import type { ArtistRef, Card, CardKind, Shelf, Track } from "./types";

/* Helpers that turn youtubei.js parsed classes (and raw renderer JSON for pages that only the
 * music client can serve, like charts and mood genres) into the small Card/Track model the UI uses. */

export function textOf(value: unknown): string {
  if (value == null) return "";
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    const obj = value as Record<string, unknown> & { toString?: () => string };
    if (typeof obj.text === "string") return obj.text;
    if (Array.isArray(obj.runs)) {
      return obj.runs
        .map((run) => (typeof run?.text === "string" ? run.text : ""))
        .join("");
    }
    if (typeof obj.toString === "function") {
      const rendered = obj.toString();
      if (rendered && rendered !== "[object Object]") return rendered;
    }
  }
  return "";
}

export function thumbOf(value: unknown): string | undefined {
  if (!value) return undefined;
  const v = value as Record<string, unknown>;
  const list: unknown[] = Array.isArray(value)
    ? value
    : Array.isArray(v.contents)
      ? (v.contents as unknown[])
      : Array.isArray(v.thumbnails)
        ? (v.thumbnails as unknown[])
        : typeof v.url === "string"
          ? [value]
          : [];
  if (!list.length) return undefined;
  const withUrl = list.filter((t): t is { url: string; width?: number; height?: number } => {
    return !!t && typeof (t as { url?: unknown }).url === "string";
  });
  if (!withUrl.length) return undefined;
  withUrl.sort((a, b) => (b.width ?? 0) * (b.height ?? 0) - (a.width ?? 0) * (a.height ?? 0));
  return withUrl[0].url;
}

function artistsOf(value: unknown): ArtistRef[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((a) => {
      if (typeof a === "string") return { name: a };
      const name = textOf((a as { name?: unknown })?.name);
      if (!name) return null;
      const id = (a as { channel_id?: string; id?: string })?.channel_id ?? (a as { id?: string })?.id ?? null;
      return { name, id };
    })
    .filter((a): a is ArtistRef => !!a);
}

function durationOf(item: Record<string, unknown>): number | null {
  const duration = item.duration as { seconds?: number; text?: string } | undefined;
  if (duration && typeof duration.seconds === "number") return duration.seconds;
  const fromText = textOf(duration);
  if (fromText && /^\d+:\d{2}$/.test(fromText)) {
    const [m, s] = fromText.split(":").map(Number);
    return m * 60 + s;
  }
  return null;
}

export function stripPlaylistPrefix(id: string): string {
  return id.startsWith("VL") ? id.slice(2) : id;
}

const KIND_BY_ITEM_TYPE: Record<string, CardKind> = {
  album: "album",
  artist: "artist",
  playlist: "playlist",
  song: "song",
  video: "video",
};

const KIND_BY_PAGE_TYPE: Record<string, CardKind> = {
  MUSIC_PAGE_TYPE_ALBUM: "album",
  MUSIC_PAGE_TYPE_ARTIST: "artist",
  MUSIC_PAGE_TYPE_PLAYLIST: "playlist",
  MUSIC_PAGE_TYPE_USER_CHANNEL: "artist",
};

/** Map a parsed youtubei.js list item (MusicResponsiveListItem / MusicTwoRowItem / …). */
export function cardFromParsed(item: unknown): Card | null {
  if (!item || typeof item !== "object") return null;
  const node = item as Record<string, any>;
  const type = String(node.type ?? "");

  if (type === "MusicNavigationButton") {
    const endpoint = node.endpoint?.payload;
    return {
      kind: "genre",
      id: String(endpoint?.browseId ?? "FEmusic_moods_and_genres_category"),
      params: endpoint?.params,
      title: textOf(node.button_text),
    };
  }

  if (type === "PlaylistPanelVideo") {
    const videoId = String(node.video_id ?? node.id ?? "");
    if (!videoId) return null;
    return {
      kind: "song",
      id: videoId,
      title: textOf(node.title),
      subtitle: artistsOf(node.artists).map((a) => a.name).join(", ") || textOf(node.author),
      thumbnail: thumbOf(node.thumbnail),
      track: {
        videoId,
        title: textOf(node.title),
        artists: artistsOf(node.artists),
        album: node.album ? { name: textOf(node.album) } : null,
        duration: durationOf(node),
        thumbnail: thumbOf(node.thumbnail),
      },
    };
  }

  if (type !== "MusicResponsiveListItem" && type !== "MusicTwoRowItem") return null;

  const itemType = String(node.item_type ?? "");
  const id = String(node.id ?? "");
  const title = textOf(node.title) || String(node.name ?? "");
  if (!id || !title) return null;
  const thumbnail = thumbOf(node.thumbnail);
  const subtitle = textOf(node.subtitle);

  let kind = KIND_BY_ITEM_TYPE[itemType];
  if (!kind) {
    const pageType = node.endpoint?.payload?.browseEndpointContextSupportedConfigs
      ?.browseEndpointContextMusicConfig?.pageType as string | undefined;
    if (pageType && KIND_BY_PAGE_TYPE[pageType]) kind = KIND_BY_PAGE_TYPE[pageType];
  }
  if (!kind) kind = node.endpoint?.name === "watchEndpoint" ? "song" : "playlist";

  if (kind === "artist") {
    return { kind, id, title, subtitle, thumbnail };
  }
  if (kind === "album" || kind === "playlist") {
    return { kind, id: kind === "playlist" ? stripPlaylistPrefix(id) : id, title, subtitle, thumbnail };
  }

  const artists = artistsOf(node.artists);
  const track: Track = {
    videoId: id,
    title,
    artists,
    album: node.album ? { name: textOf(node.album.name ?? node.album), id: node.album.id ?? null } : null,
    duration: durationOf(node),
    thumbnail,
    isVideo: kind === "video" || itemType === "video",
  };
  return { kind, id, title, subtitle: subtitle || artists.map((a) => a.name).join(", "), thumbnail, track };
}

export function shelfFromParsed(section: unknown): Shelf | null {
  if (!section || typeof section !== "object") return null;
  const node = section as Record<string, any>;
  const title = textOf(node.header?.title ?? node.title);
  const contents: unknown[] = Array.isArray(node.contents) ? node.contents : [];
  if (!contents.length) return null;
  const items = contents.map(cardFromParsed).filter((c): c is Card => !!c);
  if (!items.length) return null;
  return { title, items };
}

// ---- raw renderer JSON (charts, moods & genres, genre pages) --------------------------------

function rawRuns(value: unknown): string {
  return textOf(value);
}

function rawThumb(node: Record<string, any>): string | undefined {
  return thumbOf(node.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails);
}

function rawBrowseEndpoint(node: Record<string, any>): { browseId?: string; params?: string; pageType?: string } {
  const endpoint = node.navigationEndpoint ?? node.clickCommand;
  const browse = endpoint?.browseEndpoint ?? endpoint?.navigationEndpoint?.browseEndpoint;
  const pageType = browse?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType as
    | string
    | undefined;
  return { browseId: browse?.browseId, params: browse?.params, pageType };
}

function rawVideoId(node: Record<string, any>): string | undefined {
  return (
    node.playlistItemData?.videoId ??
    node.navigationEndpoint?.watchEndpoint?.videoId ??
    node.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint
      ?.watchEndpoint?.videoId
  );
}

function rawFlexRuns(node: Record<string, any>, index: number): string {
  const column = node.flexColumns?.[index];
  return rawRuns(column?.musicResponsiveListItemFlexColumnRenderer?.text);
}

function rawArtists(node: Record<string, any>): ArtistRef[] {
  const column = node.flexColumns?.[1];
  const runs: any[] = column?.musicResponsiveListItemFlexColumnRenderer?.text?.runs ?? [];
  const artists: ArtistRef[] = [];
  for (const run of runs) {
    const browseId = run?.navigationEndpoint?.browseEndpoint?.browseId;
    if (typeof browseId === "string" && browseId.startsWith("UC") && run?.text) {
      artists.push({ name: String(run.text), id: browseId });
    }
  }
  return artists;
}

export function cardFromRawItem(item: unknown): Card | null {
  if (!item || typeof item !== "object") return null;
  const node = item as Record<string, unknown>;

  const navigationButton = node.musicNavigationButtonRenderer as Record<string, any> | undefined;
  if (navigationButton) {
    const endpoint = navigationButton.clickCommand?.browseEndpoint;
    return {
      kind: "genre",
      id: String(endpoint?.browseId ?? "FEmusic_moods_and_genres_category"),
      params: endpoint?.params,
      title: rawRuns(navigationButton.buttonText),
    };
  }

  const twoRow = node.musicTwoRowItemRenderer as Record<string, any> | undefined;
  if (twoRow) {
    const browse = rawBrowseEndpoint(twoRow);
    const watchId = twoRow.navigationEndpoint?.watchEndpoint?.videoId as string | undefined;
    const title = rawRuns(twoRow.title);
    const subtitle = rawRuns(twoRow.subtitle);
    const thumbnail = rawThumb(twoRow);
    if (watchId && title) {
      return {
        kind: "video",
        id: watchId,
        title,
        subtitle,
        thumbnail,
        track: { videoId: watchId, title, artists: [], duration: null, thumbnail, isVideo: true },
      };
    }
    if (!browse.browseId || !title) return null;
    const pageType = browse.pageType;
    const kind: CardKind = (pageType && KIND_BY_PAGE_TYPE[pageType]) || "playlist";
    const id = kind === "playlist" ? stripPlaylistPrefix(browse.browseId) : browse.browseId;
    return { kind, id, title, subtitle, thumbnail };
  }

  const responsive = node.musicResponsiveListItemRenderer as Record<string, any> | undefined;
  if (responsive) {
    const browse = rawBrowseEndpoint(responsive);
    const videoId = rawVideoId(responsive);
    const title = rawFlexRuns(responsive, 0);
    const subtitle = rawFlexRuns(responsive, 1);
    const thumbnail = rawThumb(responsive);
    if (videoId && title) {
      const artists = rawArtists(responsive);
      const fixed = responsive.fixedColumns?.[0]?.musicResponsiveListItemFixedColumnRenderer?.text;
      const durationText = rawRuns(fixed);
      let duration: number | null = null;
      if (/^\d+:\d{2}$/.test(durationText)) {
        const [m, s] = durationText.split(":").map(Number);
        duration = m * 60 + s;
      }
      return {
        kind: "song",
        id: videoId,
        title,
        subtitle: subtitle || artists.map((a) => a.name).join(", "),
        thumbnail,
        track: { videoId, title, artists, duration, thumbnail, isVideo: false },
      };
    }
    if (browse.browseId && title) {
      const kind: CardKind = (browse.pageType && KIND_BY_PAGE_TYPE[browse.pageType]) || "artist";
      return { kind, id: browse.browseId, title, subtitle, thumbnail };
    }
  }

  return null;
}

export function sectionsFromRaw(data: any): Shelf[] {
  const sections: any[] =
    data?.contents?.singleColumnBrowseResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
      ?.contents ??
    data?.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer?.contents ??
    [];

  const shelves: Shelf[] = [];
  for (const section of sections) {
    const key = Object.keys(section ?? {})[0];
    if (!key) continue;
    const renderer = section[key];
    const title =
      textOf(renderer?.header?.musicCarouselShelfBasicHeaderRenderer?.title) ||
      textOf(renderer?.header?.musicShelfRenderer?.title) ||
      textOf(renderer?.header?.gridHeaderRenderer?.title) ||
      textOf(renderer?.title);
    const rawItems: unknown[] = renderer?.contents ?? renderer?.items ?? [];
    const items = rawItems.map(cardFromRawItem).filter((c): c is Card => !!c);
    if (items.length) shelves.push({ title, items });
  }
  return shelves.filter((s) => s.items.length > 0);
}
