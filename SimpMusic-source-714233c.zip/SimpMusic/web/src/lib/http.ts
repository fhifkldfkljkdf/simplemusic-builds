import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { getToken, SERVER_NAME, SERVER_VERSION } from "./paths";

/** Bearer guard for /api/sync/* and /api/session. */
export function isAuthorized(request: Request): boolean {
  const header = request.headers.get("authorization") ?? "";
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  if (!match) return false;
  const provided = Buffer.from(match[1].trim());
  const expected = Buffer.from(getToken());
  if (provided.length !== expected.length) return false;
  return crypto.timingSafeEqual(provided, expected);
}

export function unauthorized(): NextResponse {
  return NextResponse.json({ error: "unauthorized" }, { status: 401 });
}

export function json(data: unknown, status = 200): NextResponse {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

export function serverInfo() {
  return { ok: true, serverName: SERVER_NAME, version: SERVER_VERSION };
}
