import { Innertube, Platform } from "youtubei.js";
import { getSongs, songToTrack } from "./db";
import { cardFromParsed, sectionsFromRaw, shelfFromParsed, stripPlaylistPrefix, textOf, thumbOf } from "./map";
import type { Card, Shelf, Track } from "./types";

declare global {
  // eslint-disable-next-line no-var
  var __simpmusicInnertube: Promise<Innertube> | undefined;
  // eslint-disable-next-line no-var
  var __simpmusicAudioCache: Map<string, CachedAudio> | undefined;
  // eslint-disable-next-line no-var
  var __simpmusicOembedCache: Map<string, Track | null> | undefined;
}

/**
 * youtubei.js no longer bundles a JS interpreter; YouTube's player script must be run to
 * decipher stream URLs. Running it through `Function` is the documented Node setup.
 */
let evaluatorInstalled = false;
function installEvaluator() {
  if (evaluatorInstalled) return;
  (Platform.shim as unknown as { eval: (data: { output: string }) => Promise<unknown> }).eval = async (data) =>
    new Function(data.output)();
  evaluatorInstalled = true;
}

/** YouTube occasionally hangs; never let a page render wait forever. */
function limit<T>(promise: Promise<T>, ms = 25_000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      const timer = setTimeout(() => reject(new Error("YouTube request timed out")), ms);
      if (typeof timer.unref === "function") timer.unref();
    }),
  ]);
}

export function getInnertube(): Promise<Innertube> {
  installEvaluator();
  if (!globalThis.__simpmusicInnertube) {
    globalThis.__simpmusicInnertube = limit(
      Innertube.create({
        lang: "en",
        location: "US",
        retrieve_innertube_config: false,
      }),
      40_000
    ).catch((error) => {
      globalThis.__simpmusicInnertube = undefined;
      throw error;
    });
  }
  return globalThis.__simpmusicInnertube;
}

// ---- browsing -------------------------------------------------------------------------------

export async function getHome(): Promise<Shelf[]> {
  const yt = await getInnertube();
  const feed = await limit(yt.music.getHomeFeed());
  const sections: unknown[] = (feed.sections as unknown[]) ?? [];
  return sections
    .map(shelfFromParsed)
    .filter((shelf): shelf is Shelf => !!shelf && !!shelf.title);
}

const SEARCH_PLURAL: Record<string, string> = {
  song: "songs",
  album: "albums",
  artist: "artists",
  playlist: "playlists",
  video: "videos",
};

export async function searchMusic(query: string, type = "song"): Promise<Shelf[]> {
  const yt = await getInnertube();
  const result = (await limit(yt.music.search(query, { type } as never))) as unknown as Record<string, any>;
  const key = SEARCH_PLURAL[type] ?? "songs";
  const holder = result[key];
  const items: unknown[] = holder?.contents ?? holder?.items ?? [];
  const cards = items.map(cardFromParsed).filter((c): c is Card => !!c);
  if (cards.length) return [{ title: "", items: cards }];
  const fromSections: unknown[] = result.sections ?? [];
  return fromSections
    .map(shelfFromParsed)
    .filter((shelf): shelf is Shelf => !!shelf);
}

export interface AlbumPage {
  id: string;
  title: string;
  subtitle: string;
  artist: string;
  thumbnail?: string;
  tracks: Track[];
  shelves: Shelf[];
}

export async function getAlbum(id: string): Promise<AlbumPage> {
  const yt = await getInnertube();
  const album = await limit(yt.music.getAlbum(id));
  const header = album.header as unknown as Record<string, any>;
  const contents = (album.contents as unknown[]) ?? [];
  const tracks = contents
    .map(cardFromParsed)
    .filter((c): c is Card => !!c && !!c.track)
    .map((c) => c.track!) as Track[];
  const sections = album.sections as unknown[] | undefined;
  return {
    id,
    title: textOf(header.title),
    subtitle: textOf(header.subtitle),
    artist: textOf(header.author?.name) || textOf(header.strapline_text_one),
    thumbnail: thumbOf(header.thumbnail) ?? tracks.find((t) => t.thumbnail)?.thumbnail ?? undefined,
    tracks,
    shelves: (sections ?? []).map(shelfFromParsed).filter((s): s is Shelf => !!s && !!s.title),
  };
}

export interface ArtistPage {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  thumbnail?: string;
  topSongs: Track[];
  shelves: Shelf[];
}

export async function getArtist(id: string): Promise<ArtistPage> {
  const yt = await getInnertube();
  const page = await limit(yt.music.getArtist(id));
  const header = page.header as unknown as Record<string, any>;
  const sections = (page.sections as unknown[]) ?? [];
  const shelves = sections.map(shelfFromParsed).filter((s): s is Shelf => !!s);
  const top = shelves.find((s) => /top songs/i.test(s.title)) ?? shelves[0];
  const topSongs = (top?.items ?? [])
    .map((c) => c.track)
    .filter((t): t is Track => !!t);
  return {
    id,
    title: textOf(header.title),
    subtitle: textOf(header.subtitle),
    description: textOf(header.description),
    thumbnail: thumbOf(header.thumbnail),
    topSongs,
    shelves: shelves.filter((s) => !/top songs/i.test(s.title)),
  };
}

export interface PlaylistPage {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  description: string;
  thumbnail?: string;
  tracks: Track[];
}

export async function getYoutubePlaylist(id: string): Promise<PlaylistPage> {
  const yt = await getInnertube();
  const page = await limit(yt.music.getPlaylist(stripPlaylistPrefix(id)));
  const header = page.header as unknown as Record<string, any>;
  const contents = (page.contents as unknown[]) ?? [];
  const tracks = contents
    .map(cardFromParsed)
    .filter((c): c is Card => !!c && !!c.track)
    .map((c) => c.track!) as Track[];
  return {
    id: stripPlaylistPrefix(id),
    title: textOf(header.title),
    subtitle: textOf(header.subtitle),
    author: textOf(header.author?.name) || textOf(header.strapline_text_one),
    description: textOf(header.description),
    thumbnail: thumbOf(header.thumbnail) ?? tracks.find((t) => t.thumbnail)?.thumbnail ?? undefined,
    tracks,
  };
}

export async function getExplore(): Promise<Shelf[]> {
  const yt = await getInnertube();
  const page = await limit(yt.music.getExplore());
  const sections = (page.sections as unknown[]) ?? [];
  return sections.map(shelfFromParsed).filter((s): s is Shelf => !!s);
}

/** Charts are only served over the music (WEB_REMIX) browse client; the high-level API has no
 *  getCharts, so the raw response is mapped. */
export async function getCharts(): Promise<Shelf[]> {
  const yt = await getInnertube();
  try {
    const response = await limit(
      yt.actions.execute("/browse", {
        browseId: "FEmusic_charts",
        client: "YTMUSIC",
      } as never)
    );
    const shelves = sectionsFromRaw((response as { data: unknown }).data);
    if (shelves.length) return shelves;
  } catch {
    // fall through to trending
  }
  const explore = await getExplore();
  return explore.filter((s) => /trending|new albums|new music/i.test(s.title));
}

export async function getMoodsAndGenres(): Promise<Shelf[]> {
  const yt = await getInnertube();
  const response = await limit(
    yt.actions.execute("/browse", {
      browseId: "FEmusic_moods_and_genres",
      client: "YTMUSIC",
    } as never)
  );
  return sectionsFromRaw((response as { data: unknown }).data);
}

export async function browseMusic(browseId: string, params?: string): Promise<Shelf[]> {
  const yt = await getInnertube();
  const response = await limit(
    yt.actions.execute("/browse", {
      browseId,
      params,
      client: "YTMUSIC",
    } as never)
  );
  return sectionsFromRaw((response as { data: unknown }).data);
}

export async function getSuggestions(query: string): Promise<string[]> {
  const yt = await getInnertube();
  const sections = (await limit(yt.music.getSearchSuggestions(query))) as unknown as Array<{ contents?: unknown[] }>;
  const seen = new Set<string>();
  const suggestions: string[] = [];
  for (const section of sections) {
    for (const item of section.contents ?? []) {
      const node = item as Record<string, any>;
      const value = node.suggestion?.text ?? node.suggestion?.toString?.() ?? textOf(node.suggestion);
      const text = typeof value === "string" ? value : "";
      if (text && !seen.has(text)) {
        seen.add(text);
        suggestions.push(text);
      }
    }
  }
  return suggestions.slice(0, 10);
}

export async function getRadio(videoId: string): Promise<Track[]> {
  const yt = await getInnertube();
  const panel = await limit(yt.music.getUpNext(videoId, `RDAMVM${videoId}` as never));
  const items = (panel.contents as unknown[]) ?? [];
  return items
    .map(cardFromParsed)
    .filter((c): c is Card => !!c && !!c.track && c.track.videoId !== videoId)
    .map((c) => c.track!) as Track[];
}

// ---- audio resolution -----------------------------------------------------------------------

interface CachedAudio {
  url: string;
  expiresAt: number;
  contentType: string;
}

function audioCache(): Map<string, CachedAudio> {
  if (!globalThis.__simpmusicAudioCache) globalThis.__simpmusicAudioCache = new Map();
  return globalThis.__simpmusicAudioCache;
}

function pickAudioFormat(info: any): any | null {
  const adaptive: any[] = info?.streaming_data?.adaptive_formats ?? [];
  const audio = adaptive.filter((f) => f?.has_audio && !f?.has_video);
  if (!audio.length) return null;
  const mp4 = audio.filter((f) => String(f.mime_type ?? "").includes("mp4"));
  const pool = mp4.length ? mp4 : audio;
  pool.sort((a, b) => (b.bitrate ?? 0) - (a.bitrate ?? 0));
  return pool[0] ?? null;
}

async function decipherUrl(format: any, yt: Innertube): Promise<string | null> {
  if (typeof format?.url === "string" && format.url) return format.url;
  if (typeof format?.decipher === "function") {
    const result = await format.decipher(yt.session.player);
    if (typeof result === "string" && result) return result;
    if (result && typeof result.url === "string") return result.url;
  }
  return null;
}

function expiryOf(url: string, info: any): number {
  try {
    const expire = Number(new URL(url).searchParams.get("expire"));
    if (expire) return expire * 1000;
  } catch {
    // ignore malformed
  }
  const dataExpires = Number(info?.streaming_data?.expires);
  if (dataExpires) return dataExpires * 1000;
  return Date.now() + 60 * 60 * 1000;
}

/**
 * Resolve the best audio-only URL for a video. WEB_REMIX (the YouTube Music client) is tried
 * first, then the ANDROID / IOS / TV clients if it fails or the signature cannot be deciphered.
 * Resolved URLs are cached in memory until their `expire` timestamp.
 */
export async function resolveAudio(videoId: string): Promise<CachedAudio> {
  const cached = audioCache().get(videoId);
  if (cached && cached.expiresAt > Date.now() + 20_000) return cached;

  const yt = await getInnertube();
  const attempts: Array<{ name: string; run: () => Promise<any> }> = [
    { name: "WEB_REMIX", run: () => yt.music.getInfo(videoId) },
    { name: "ANDROID", run: () => yt.getInfo(videoId, { client: "ANDROID" } as never) },
    { name: "IOS", run: () => yt.getInfo(videoId, { client: "IOS" } as never) },
    { name: "TV", run: () => yt.getInfo(videoId, { client: "TVHTML5" } as never) },
  ];

  let lastError: unknown;
  for (const attempt of attempts) {
    try {
      const info = await attempt.run();
      const format = pickAudioFormat(info);
      if (!format) {
        lastError = new Error(`${attempt.name}: no audio format`);
        continue;
      }
      const url = await decipherUrl(format, yt);
      if (!url) {
        lastError = new Error(`${attempt.name}: no deciphered url`);
        continue;
      }
      const resolved: CachedAudio = {
        url,
        expiresAt: expiryOf(url, info),
        contentType: String(format.mime_type ?? "audio/mp4").split(";")[0].trim() || "audio/mp4",
      };
      audioCache().set(videoId, resolved);
      for (const [key, value] of audioCache()) {
        if (value.expiresAt < Date.now()) audioCache().delete(key);
      }
      return resolved;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Could not resolve audio stream");
}

export function forgetAudio(videoId: string) {
  audioCache().delete(videoId);
}

// ---- queue metadata -------------------------------------------------------------------------

function oembedCache(): Map<string, Track | null> {
  if (!globalThis.__simpmusicOembedCache) globalThis.__simpmusicOembedCache = new Map();
  return globalThis.__simpmusicOembedCache;
}

async function oembedTrack(videoId: string): Promise<Track | null> {
  const cache = oembedCache();
  if (cache.has(videoId)) return cache.get(videoId) ?? null;
  try {
    const response = await fetch(
      `https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}&format=json`,
      { signal: AbortSignal.timeout(6000), cache: "no-store" }
    );
    if (!response.ok) throw new Error(String(response.status));
    const data = (await response.json()) as { title?: string; author_name?: string; thumbnail_url?: string };
    const track: Track = {
      videoId,
      title: data.title || videoId,
      artists: data.author_name ? [{ name: data.author_name }] : [],
      thumbnail: data.thumbnail_url ?? null,
    };
    cache.set(videoId, track);
    return track;
  } catch {
    cache.set(videoId, null);
    return null;
  }
}

/**
 * Metadata for the queue of a session handoff. Library rows (pushed by the phone, or written by
 * the web) win; anything missing is filled from YouTube's oEmbed endpoint. Ids always come back
 * in the requested order so the queue index stays valid.
 */
export async function tracksByIds(ids: string[]): Promise<Track[]> {
  const known = new Map(getSongs(ids).map((song) => [song.videoId, songToTrack(song)] as const));
  const missing = ids.filter((id) => !known.has(id));
  await Promise.all(
    missing.slice(0, 60).map(async (id) => {
      const track = await oembedTrack(id);
      if (track) known.set(id, track);
    })
  );
  return ids.map(
    (id) => known.get(id) ?? { videoId: id, title: id, artists: [], thumbnail: null }
  );
}
