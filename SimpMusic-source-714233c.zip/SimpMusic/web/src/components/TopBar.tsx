"use client";

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Icon } from "./Icons";
import { MobileNav } from "./Sidebar";

export function TopBar() {
  const router = useRouter();
  const pathname = usePathname();
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [open, setOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement | null>(null);

  // Reflect the ?q= of the current search page without useSearchParams (layout-wide usage).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    setQuery(params.get("q") ?? "");
  }, [pathname]);

  useEffect(() => {
    if (query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    const handle = window.setTimeout(() => {
      fetch(`/api/yt/suggest?q=${encodeURIComponent(query.trim())}`)
        .then((response) => response.json())
        .then((data: { suggestions?: string[] }) => {
          setSuggestions(data.suggestions ?? []);
          setOpen(true);
        })
        .catch(() => setSuggestions([]));
    }, 220);
    return () => window.clearTimeout(handle);
  }, [query]);

  useEffect(() => {
    const onDown = (event: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const submit = (value: string) => {
    const trimmed = value.trim();
    if (!trimmed) return;
    setOpen(false);
    router.push(`/search?q=${encodeURIComponent(trimmed)}&type=songs`);
  };

  return (
    <header className="sticky top-0 z-20 border-b border-white/5 bg-[#0b0b0f]/90 backdrop-blur">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2 md:hidden">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-white">
            <Icon name="music" size={18} />
          </span>
          <span className="text-base font-bold text-white">
            Simp<span className="text-accent">Music</span>
          </span>
        </Link>

        <div className="relative ml-auto w-full max-w-xl md:ml-0" ref={boxRef}>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              submit(query);
            }}
          >
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted">
              <Icon name="search" size={18} />
            </span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onFocus={() => suggestions.length && setOpen(true)}
              onKeyDown={(event) => {
                if (event.key === "Escape") setOpen(false);
              }}
              placeholder="Search songs, albums, artists…"
              aria-label="Search"
              className="w-full rounded-full border border-white/10 bg-surface py-2.5 pl-10 pr-4 text-sm text-white outline-none transition placeholder:text-muted focus:border-white/25"
            />
          </form>
          {open && suggestions.length ? (
            <div className="absolute inset-x-0 top-full z-30 mt-2 overflow-hidden rounded-xl border border-white/10 bg-elevated py-1 shadow-2xl">
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  className="flex w-full items-center gap-3 px-4 py-2 text-left text-sm text-white/90 hover:bg-white/10"
                  onClick={() => {
                    setQuery(suggestion);
                    submit(suggestion);
                  }}
                >
                  <Icon name="search" size={14} className="text-muted" />
                  <span className="truncate">{suggestion}</span>
                </button>
              ))}
            </div>
          ) : null}
        </div>
      </div>
      <MobileNav />
    </header>
  );
}
