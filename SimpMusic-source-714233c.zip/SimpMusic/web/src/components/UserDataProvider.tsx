"use client";

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { Track } from "@/lib/types";

export interface PlaylistMeta {
  id: string;
  title: string;
  trackIds: string[];
  thumbnail: string | null;
}

interface UserDataValue {
  likedIds: Set<string>;
  followedIds: Set<string>;
  playlists: PlaylistMeta[];
  ready: boolean;
  isLiked: (videoId: string) => boolean;
  toggleLike: (track: Track) => Promise<void>;
  isFollowed: (channelId: string) => boolean;
  toggleFollow: (artist: { channelId: string; name: string; thumbnail?: string | null }) => Promise<void>;
  createPlaylist: (title: string, track?: Track) => Promise<PlaylistMeta | null>;
  addToPlaylist: (playlistId: string, track: Track) => Promise<void>;
  removeFromPlaylist: (playlistId: string, videoId: string) => Promise<void>;
  renamePlaylist: (playlistId: string, title: string) => Promise<void>;
  deletePlaylist: (playlistId: string) => Promise<void>;
  refresh: () => Promise<void>;
}

const UserDataContext = createContext<UserDataValue | null>(null);

export function useUserData(): UserDataValue {
  const context = useContext(UserDataContext);
  if (!context) throw new Error("useUserData must be used inside UserDataProvider");
  return context;
}

interface SummaryResponse {
  likedIds: string[];
  followedIds: string[];
  playlists: PlaylistMeta[];
}

export function UserDataProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [followedIds, setFollowedIds] = useState<Set<string>>(new Set());
  const [playlists, setPlaylists] = useState<PlaylistMeta[]>([]);
  const [ready, setReady] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/library/summary", { cache: "no-store" });
      const data = (await response.json()) as SummaryResponse;
      setLikedIds(new Set(data.likedIds ?? []));
      setFollowedIds(new Set(data.followedIds ?? []));
      setPlaylists(data.playlists ?? []);
      setReady(true);
    } catch {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const isLiked = useCallback((videoId: string) => likedIds.has(videoId), [likedIds]);
  const isFollowed = useCallback((channelId: string) => followedIds.has(channelId), [followedIds]);

  const toggleLike = useCallback(
    async (track: Track) => {
      const next = !likedIds.has(track.videoId);
      setLikedIds((current) => {
        const copy = new Set(current);
        if (next) copy.add(track.videoId);
        else copy.delete(track.videoId);
        return copy;
      });
      try {
        const response = await fetch("/api/library/likes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ videoId: track.videoId, liked: next, track }),
        });
        if (!response.ok) throw new Error("failed");
        router.refresh();
      } catch {
        setLikedIds((current) => {
          const copy = new Set(current);
          if (next) copy.delete(track.videoId);
          else copy.add(track.videoId);
          return copy;
        });
      }
    },
    [likedIds, router]
  );

  const toggleFollow = useCallback(
    async (artist: { channelId: string; name: string; thumbnail?: string | null }) => {
      const next = !followedIds.has(artist.channelId);
      setFollowedIds((current) => {
        const copy = new Set(current);
        if (next) copy.add(artist.channelId);
        else copy.delete(artist.channelId);
        return copy;
      });
      try {
        const response = await fetch("/api/library/follows", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...artist, followed: next }),
        });
        if (!response.ok) throw new Error("failed");
        router.refresh();
      } catch {
        setFollowedIds((current) => {
          const copy = new Set(current);
          if (next) copy.delete(artist.channelId);
          else copy.add(artist.channelId);
          return copy;
        });
      }
    },
    [followedIds, router]
  );

  const createPlaylist = useCallback(
    async (title: string, track?: Track): Promise<PlaylistMeta | null> => {
      try {
        const response = await fetch("/api/library/playlists", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title, track }),
        });
        const data = (await response.json()) as { playlist?: { id: string; title: string; trackIds: string[]; thumbnail?: string | null } };
        if (!response.ok || !data.playlist) return null;
        const created: PlaylistMeta = {
          id: data.playlist.id,
          title: data.playlist.title,
          trackIds: data.playlist.trackIds ?? [],
          thumbnail: data.playlist.thumbnail ?? null,
        };
        setPlaylists((current) => [created, ...current]);
        router.refresh();
        return created;
      } catch {
        return null;
      }
    },
    [router]
  );

  const addToPlaylist = useCallback(
    async (playlistId: string, track: Track) => {
      setPlaylists((current) =>
        current.map((playlist) =>
          playlist.id === playlistId && !playlist.trackIds.includes(track.videoId)
            ? { ...playlist, trackIds: [...playlist.trackIds, track.videoId] }
            : playlist
        )
      );
      try {
        await fetch(`/api/library/playlists/${encodeURIComponent(playlistId)}/tracks`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ track }),
        });
        router.refresh();
      } catch {
        /* leave the optimistic state; refresh will correct it */
      }
    },
    [router]
  );

  const removeFromPlaylist = useCallback(
    async (playlistId: string, videoId: string) => {
      setPlaylists((current) =>
        current.map((playlist) =>
          playlist.id === playlistId
            ? { ...playlist, trackIds: playlist.trackIds.filter((id) => id !== videoId) }
            : playlist
        )
      );
      try {
        await fetch(
          `/api/library/playlists/${encodeURIComponent(playlistId)}/tracks?videoId=${encodeURIComponent(videoId)}`,
          { method: "DELETE" }
        );
        router.refresh();
      } catch {
        /* ignore */
      }
    },
    [router]
  );

  const renamePlaylist = useCallback(
    async (playlistId: string, title: string) => {
      setPlaylists((current) => current.map((p) => (p.id === playlistId ? { ...p, title } : p)));
      try {
        await fetch(`/api/library/playlists/${encodeURIComponent(playlistId)}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title }),
        });
        router.refresh();
      } catch {
        /* ignore */
      }
    },
    [router]
  );

  const deletePlaylist = useCallback(
    async (playlistId: string) => {
      setPlaylists((current) => current.filter((p) => p.id !== playlistId));
      try {
        await fetch(`/api/library/playlists/${encodeURIComponent(playlistId)}`, { method: "DELETE" });
        router.refresh();
      } catch {
        /* ignore */
      }
    },
    [router]
  );

  const value = useMemo<UserDataValue>(
    () => ({
      likedIds,
      followedIds,
      playlists,
      ready,
      isLiked,
      toggleLike,
      isFollowed,
      toggleFollow,
      createPlaylist,
      addToPlaylist,
      removeFromPlaylist,
      renamePlaylist,
      deletePlaylist,
      refresh,
    }),
    [
      likedIds,
      followedIds,
      playlists,
      ready,
      isLiked,
      toggleLike,
      isFollowed,
      toggleFollow,
      createPlaylist,
      addToPlaylist,
      removeFromPlaylist,
      renamePlaylist,
      deletePlaylist,
      refresh,
    ]
  );

  return <UserDataContext.Provider value={value}>{children}</UserDataContext.Provider>;
}
