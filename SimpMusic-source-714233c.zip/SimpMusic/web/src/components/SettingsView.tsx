"use client";

import React, { useEffect, useState } from "react";
import { CopyButton } from "./Interactions";

interface ServerData {
  serverName: string;
  version: string;
  baseUrl: string;
  token: string;
  pairLink: string;
  qr: string;
  dataDir: string;
  dbPath: string | null;
  publicUrl: string | null;
  stats: { songs: number; likes: number; playlists: number; history: number; follows: number };
  session: {
    deviceName: string;
    videoId: string;
    positionMs: number;
    isPlaying: boolean;
    queue: string[];
    queueIndex: number;
    updatedAt: number;
  } | null;
}

function formatDate(ms: number): string {
  try {
    return new Date(ms).toLocaleString();
  } catch {
    return "";
  }
}

export function SettingsView() {
  const [data, setData] = useState<ServerData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/server", { cache: "no-store" })
      .then((response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.json() as Promise<ServerData>;
      })
      .then((value) => {
        if (!cancelled) setData(value);
      })
      .catch((caught: Error) => {
        if (!cancelled) setError(caught.message);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (error) {
    return (
      <p className="rounded-xl border border-accent/30 bg-accent/10 p-4 text-sm text-white/80">
        Could not read the server settings: {error}
      </p>
    );
  }

  if (!data) {
    return <p className="text-sm text-muted">Loading pairing details…</p>;
  }

  return (
    <div>
      <section className="mb-8 rounded-2xl border border-white/10 bg-surface p-5 sm:p-6">
        <div className="flex flex-col gap-6 lg:flex-row">
          <div className="flex flex-col items-center gap-3">
            <div className="rounded-xl bg-white p-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={data.qr} alt="Pairing QR code" className="h-52 w-52" />
            </div>
            <p className="text-center text-xs text-muted">Scan in SimpMusic → Settings → Server sync</p>
          </div>

          <div className="min-w-0 flex-1">
            <h2 className="text-lg font-bold text-white">Pair phone</h2>
            <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-white/80">
              <li>Open the SimpMusic app on the same network.</li>
              <li>Go to Settings → Server sync and scan the QR, or enter the address and token.</li>
              <li>Press Pair — the app pulls this server&apos;s library and starts pushing its own.</li>
            </ol>

            <div className="mt-5 space-y-3">
              <div>
                <p className="mb-1 text-xs uppercase tracking-wide text-muted">Server URL</p>
                <div className="flex items-center gap-2">
                  <code className="min-w-0 flex-1 overflow-x-auto rounded-md border border-white/10 bg-black/30 px-3 py-2 text-sm text-white">
                    {data.baseUrl}
                  </code>
                  <CopyButton value={data.baseUrl} />
                </div>
              </div>
              <div>
                <p className="mb-1 text-xs uppercase tracking-wide text-muted">Pairing token</p>
                <div className="flex items-center gap-2">
                  <code className="min-w-0 flex-1 overflow-x-auto rounded-md border border-white/10 bg-black/30 px-3 py-2 font-mono text-sm text-white">
                    {data.token}
                  </code>
                  <CopyButton value={data.token} />
                </div>
                <p className="mt-1 text-xs text-muted">
                  Stored in <code>{data.dataDir}/token</code> and printed in the server log on first start. Set{" "}
                  <code>SYNC_TOKEN</code> to override it.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-surface p-5">
          <h2 className="mb-3 text-lg font-bold text-white">Server</h2>
          <div className="space-y-1.5 text-sm">
            <Row label="Name" value={data.serverName} />
            <Row label="Version" value={data.version} />
            <Row label="Base URL" value={data.baseUrl} />
            <Row label="Public URL override" value={data.publicUrl || "—"} />
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-surface p-5">
          <h2 className="mb-3 text-lg font-bold text-white">Storage</h2>
          <div className="space-y-1.5 text-sm">
            <Row label="Data directory" value={data.dataDir} />
            <Row label="Database" value={data.dbPath || `${data.dataDir}/simpmusic.db`} />
            <Row label="Songs" value={String(data.stats.songs)} />
            <Row label="Likes" value={String(data.stats.likes)} />
            <Row label="Playlists" value={String(data.stats.playlists)} />
            <Row label="History entries" value={String(data.stats.history)} />
            <Row label="Followed artists" value={String(data.stats.follows)} />
          </div>
        </div>
      </section>

      <section className="mb-8 rounded-2xl border border-white/10 bg-surface p-5 sm:p-6">
        <h2 className="text-lg font-bold text-white">Last playback session</h2>
        {data.session ? (
          <div className="mt-3 space-y-1.5 text-sm">
            <Row label="Device" value={data.session.deviceName} />
            <Row label="Video" value={data.session.videoId} />
            <Row label="Position" value={`${Math.round(data.session.positionMs / 1000)}s`} />
            <Row label="Playing" value={data.session.isPlaying ? "yes" : "no"} />
            <Row label="Queue" value={`${data.session.queue.length} tracks (index ${data.session.queueIndex})`} />
            <Row label="Updated" value={formatDate(data.session.updatedAt)} />
          </div>
        ) : (
          <p className="mt-2 text-sm text-muted">No device has reported a session yet.</p>
        )}
        <p className="mt-3 text-xs text-muted">
          The web player reports itself as “Web” every 10 seconds while playing. When the phone reports a newer
          session, a “Continue from …” banner appears in the web player.
        </p>
      </section>

      <section className="rounded-2xl border border-white/10 bg-surface p-5 sm:p-6">
        <h2 className="text-lg font-bold text-white">Testing the sync API</h2>
        <p className="mt-2 text-sm text-muted">
          The endpoints in <code>web/SYNC_API.md</code> are guarded by the token above.
        </p>
        <pre className="mt-3 overflow-x-auto rounded-md border border-white/10 bg-black/40 p-3 text-xs text-white/80">
{`curl -H "Authorization: Bearer ${data.token}" ${data.baseUrl}/api/sync/ping
curl -H "Authorization: Bearer ${data.token}" "${data.baseUrl}/api/sync/pull?since=0"`}
        </pre>
      </section>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="shrink-0 text-xs uppercase tracking-wide text-muted">{label}</span>
      <span className="min-w-0 break-all text-right text-white/90">{value}</span>
    </div>
  );
}
