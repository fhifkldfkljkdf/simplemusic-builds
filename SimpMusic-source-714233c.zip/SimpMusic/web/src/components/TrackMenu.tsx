"use client";

import React, { useEffect, useRef, useState } from "react";
import { Icon } from "./Icons";
import { usePlayer } from "./player/PlayerProvider";
import { useUserData } from "./UserDataProvider";
import type { Track } from "@/lib/types";

export function TrackMenu({
  track,
  playlistId,
  onRemove,
}: {
  track: Track;
  playlistId?: string;
  onRemove?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  const { playNext, addToQueue, startRadio } = usePlayer();
  const { playlists, isLiked, toggleLike, addToPlaylist, createPlaylist } = useUserData();

  useEffect(() => {
    if (!open) return;
    const onDown = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label="More options"
        title="More options"
        className="grid h-9 w-9 place-items-center rounded-full text-muted transition hover:bg-white/10 hover:text-white"
        onClick={(event) => {
          event.stopPropagation();
          setOpen((value) => !value);
        }}
      >
        <Icon name="more" size={18} />
      </button>
      {open ? (
        <div
          className="absolute right-0 z-50 mt-1 w-60 overflow-hidden rounded-xl border border-white/10 bg-elevated py-1 text-sm shadow-2xl"
          onClick={(event) => event.stopPropagation()}
        >
          <MenuItem
            label="Play next"
            icon="queue"
            onClick={() => {
              playNext(track);
              setOpen(false);
            }}
          />
          <MenuItem
            label="Add to queue"
            icon="add"
            onClick={() => {
              addToQueue(track);
              setOpen(false);
            }}
          />
          <MenuItem
            label="Start radio"
            icon="radio"
            onClick={() => {
              void startRadio(track);
              setOpen(false);
            }}
          />
          <MenuItem
            label={isLiked(track.videoId) ? "Remove from liked songs" : "Add to liked songs"}
            icon="heart"
            onClick={() => {
              void toggleLike(track);
              setOpen(false);
            }}
          />
          {playlistId && onRemove ? (
            <MenuItem
              label="Remove from playlist"
              icon="delete"
              onClick={() => {
                onRemove();
                setOpen(false);
              }}
            />
          ) : null}
          <div className="my-1 border-t border-white/10" />
          <p className="px-3 py-1 text-xs uppercase tracking-wide text-muted">Add to playlist</p>
          <div className="max-h-40 overflow-y-auto">
            {playlists.length === 0 ? <p className="px-3 py-1 text-xs text-muted">No playlists yet</p> : null}
            {playlists.map((playlist) => (
              <MenuItem
                key={playlist.id}
                label={playlist.title}
                icon={playlist.trackIds.includes(track.videoId) ? "check" : "add"}
                onClick={() => {
                  void addToPlaylist(playlist.id, track);
                  setOpen(false);
                }}
              />
            ))}
          </div>
          <MenuItem
            label="New playlist…"
            icon="add"
            onClick={() => {
              const title = window.prompt("Playlist name", track.artists?.[0]?.name ?? "New playlist");
              if (title?.trim()) void createPlaylist(title.trim(), track);
              setOpen(false);
            }}
          />
        </div>
      ) : null}
    </div>
  );
}

function MenuItem({
  label,
  icon,
  onClick,
}: {
  label: string;
  icon: Parameters<typeof Icon>[0]["name"];
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className="flex w-full items-center gap-3 px-3 py-2 text-left text-white/90 transition hover:bg-white/10"
      onClick={onClick}
    >
      <Icon name={icon} size={16} className="text-muted" />
      <span className="truncate">{label}</span>
    </button>
  );
}
