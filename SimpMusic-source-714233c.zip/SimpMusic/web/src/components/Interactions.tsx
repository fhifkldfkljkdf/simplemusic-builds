"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { Icon } from "./Icons";
import { TrackList } from "./TrackList";
import { useUserData } from "./UserDataProvider";

export function CopyButton({ value, label = "Copy" }: { value: string; label?: string }) {
  const [copied, setCopied] = React.useState(false);
  return (
    <button
      type="button"
      className="flex items-center gap-2 rounded-md border border-white/15 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-white/10"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1600);
        } catch {
          window.prompt("Copy this", value);
        }
      }}
    >
      <Icon name={copied ? "check" : "queue"} size={14} />
      {copied ? "Copied" : label}
    </button>
  );
}

export function CreatePlaylistForm() {
  const { createPlaylist } = useUserData();
  const [title, setTitle] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  return (
    <form
      className="flex flex-wrap items-center gap-2"
      onSubmit={async (event) => {
        event.preventDefault();
        if (!title.trim() || busy) return;
        setBusy(true);
        await createPlaylist(title.trim());
        setTitle("");
        setBusy(false);
      }}
    >
      <input
        value={title}
        onChange={(event) => setTitle(event.target.value)}
        placeholder="New playlist name"
        className="w-56 rounded-md border border-white/10 bg-surface px-3 py-2 text-sm text-white outline-none placeholder:text-muted focus:border-white/25"
      />
      <button
        type="submit"
        disabled={!title.trim() || busy}
        className="flex items-center gap-2 rounded-md bg-accent px-4 py-2 text-sm font-semibold text-white disabled:opacity-40"
      >
        <Icon name="add" size={16} />
        Create
      </button>
    </form>
  );
}

export function PlaylistActions({ playlistId, title }: { playlistId: string; title: string }) {
  const { renamePlaylist, deletePlaylist } = useUserData();
  const router = useRouter();
  return (
    <div className="flex items-center gap-1">
      <button
        type="button"
        className="rounded-full px-3 py-1.5 text-xs text-muted hover:bg-white/10 hover:text-white"
        onClick={() => {
          const next = window.prompt("Rename playlist", title);
          if (next?.trim()) void renamePlaylist(playlistId, next.trim());
        }}
      >
        Rename
      </button>
      <button
        type="button"
        className="grid h-8 w-8 place-items-center rounded-full text-muted hover:bg-white/10 hover:text-accent"
        aria-label="Delete playlist"
        onClick={() => {
          if (window.confirm(`Delete "${title}"? It will be removed from the phone too.`)) {
            void deletePlaylist(playlistId).then(() => router.push("/library?tab=playlists"));
          }
        }}
      >
        <Icon name="delete" size={16} />
      </button>
    </div>
  );
}

export function ImportPlaylistButton({
  title,
  tracks,
  youtubePlaylistId,
}: {
  title: string;
  tracks: { videoId: string }[];
  youtubePlaylistId: string;
}) {
  const { refresh } = useUserData();
  const [state, setState] = React.useState<"idle" | "busy" | "done">("idle");
  return (
    <button
      type="button"
      disabled={state !== "idle" || !tracks.length}
      className="flex items-center gap-2 rounded-full border border-white/20 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-white/10 disabled:opacity-50"
      onClick={async () => {
        setState("busy");
        try {
          await fetch("/api/library/playlists", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, tracks, youtubePlaylistId }),
          });
          await refresh();
          setState("done");
        } catch {
          setState("idle");
        }
      }}
    >
      <Icon name={state === "done" ? "check" : "add"} size={16} />
      {state === "done" ? "Saved" : state === "busy" ? "Saving…" : "Save to library"}
    </button>
  );
}

export function PlaylistTracks({
  playlistId,
  tracks,
}: {
  playlistId: string;
  tracks: import("@/lib/types").Track[];
}) {
  const { removeFromPlaylist } = useUserData();
  return (
    <TrackList
      tracks={tracks}
      playlistId={playlistId}
      showAlbum
      onRemove={(track) => void removeFromPlaylist(playlistId, track.videoId)}
    />
  );
}
