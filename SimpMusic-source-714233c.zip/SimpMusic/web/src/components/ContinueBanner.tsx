"use client";

import React from "react";
import { Icon } from "./Icons";
import { usePlayer } from "./player/PlayerProvider";

export function ContinueBanner() {
  const { remoteSession, continueSession, dismissRemoteSession } = usePlayer();
  if (!remoteSession) return null;
  return (
    <div className="fixed bottom-24 left-1/2 z-40 w-[min(92vw,460px)] -translate-x-1/2 rounded-xl border border-white/10 bg-elevated/95 p-4 shadow-2xl backdrop-blur">
      <div className="flex items-start gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-accent/20 text-accent">
          <Icon name="music" size={18} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-white">Continue from {remoteSession.deviceName}</p>
          <p className="mt-0.5 truncate text-xs text-muted">
            {remoteSession.queue.length} track queue • paused at {Math.round(remoteSession.positionMs / 1000)}s
          </p>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              className="rounded-full bg-accent px-4 py-1.5 text-xs font-semibold text-white hover:brightness-110"
              onClick={() => void continueSession()}
            >
              Continue here
            </button>
            <button
              type="button"
              className="rounded-full border border-white/15 px-4 py-1.5 text-xs font-medium text-white hover:bg-white/10"
              onClick={dismissRemoteSession}
            >
              Dismiss
            </button>
          </div>
        </div>
        <button type="button" className="icon-btn" onClick={dismissRemoteSession} aria-label="Dismiss">
          <Icon name="close" size={16} />
        </button>
      </div>
    </div>
  );
}
