"use client";

import React from "react";
import { Icon } from "./Icons";
import { useUserData } from "./UserDataProvider";

export function FollowButton({
  channelId,
  name,
  thumbnail,
}: {
  channelId: string;
  name: string;
  thumbnail?: string | null;
}) {
  const { isFollowed, toggleFollow } = useUserData();
  const followed = isFollowed(channelId);
  if (!channelId) return null;
  return (
    <button
      type="button"
      className={`flex items-center gap-2 rounded-full px-5 py-2 text-sm font-semibold transition ${
        followed
          ? "border border-white/20 text-white hover:bg-white/10"
          : "bg-white text-black hover:brightness-90"
      }`}
      onClick={() => void toggleFollow({ channelId, name, thumbnail })}
    >
      <Icon name={followed ? "check" : "add"} size={16} />
      {followed ? "Following" : "Follow"}
    </button>
  );
}
