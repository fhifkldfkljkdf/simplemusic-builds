"use client";

import React from "react";
import { PlayerProvider } from "./player/PlayerProvider";
import { UserDataProvider } from "./UserDataProvider";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <PlayerProvider>
      <UserDataProvider>{children}</UserDataProvider>
    </PlayerProvider>
  );
}
