"use client";

import React from "react";
import { TrackRow } from "./TrackRow";
import type { Track } from "@/lib/types";

export function TrackList({
  tracks,
  playlistId,
  showAlbum = false,
  showIndex = true,
  empty = "Nothing here yet.",
  onRemove,
}: {
  tracks: Track[];
  playlistId?: string;
  showAlbum?: boolean;
  showIndex?: boolean;
  empty?: string;
  onRemove?: (track: Track) => void;
}) {
  if (!tracks.length) {
    return <p className="rounded-lg border border-white/10 bg-surface px-4 py-8 text-center text-sm text-muted">{empty}</p>;
  }
  return (
    <div className="flex flex-col">
      {tracks.map((track, index) => (
        <TrackRow
          key={`${track.videoId}-${index}`}
          track={track}
          index={index}
          tracks={tracks}
          playlistId={playlistId}
          showAlbum={showAlbum}
          showIndex={showIndex}
          onRemove={onRemove ? () => onRemove(track) : undefined}
        />
      ))}
    </div>
  );
}
