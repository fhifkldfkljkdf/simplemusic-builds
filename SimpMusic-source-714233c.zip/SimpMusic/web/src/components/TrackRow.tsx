"use client";

import React from "react";
import { LikeButton } from "./LikeButton";
import { TrackMenu } from "./TrackMenu";
import { usePlayer } from "./player/PlayerProvider";
import { artistNames, formatTime } from "@/lib/format";
import type { Track } from "@/lib/types";

export function TrackRow({
  track,
  index,
  tracks,
  playlistId,
  showAlbum = false,
  showIndex = true,
  onRemove,
}: {
  track: Track;
  index: number;
  tracks: Track[];
  playlistId?: string;
  showAlbum?: boolean;
  showIndex?: boolean;
  onRemove?: () => void;
}) {
  const { playTracks, current, isPlaying, toggle } = usePlayer();
  const active = current?.videoId === track.videoId;

  return (
    <div
      role="button"
      tabIndex={0}
      className={`group flex items-center gap-3 rounded-md px-2 py-2 transition hover:bg-white/5 ${
        active ? "bg-white/5" : ""
      }`}
      onClick={() => {
        if (active) toggle();
        else playTracks(tracks, index);
      }}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          if (active) toggle();
          else playTracks(tracks, index);
        }
      }}
    >
      {showIndex ? (
        <span className="hidden w-6 shrink-0 text-center text-sm text-muted sm:block">
          {active ? (
            <span className="inline-flex text-accent">
              <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
                {isPlaying ? (
                  <path fill="currentColor" d="M6 5h4v14H6zm8 0h4v14h-4z" />
                ) : (
                  <path fill="currentColor" d="M8 5v14l11-7z" />
                )}
              </svg>
            </span>
          ) : (
            index + 1
          )}
        </span>
      ) : null}

      <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded bg-elevated sm:h-9 sm:w-9">
        {track.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={track.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <div className="grid h-full w-full place-items-center text-muted">♪</div>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <p className={`truncate text-sm font-medium ${active ? "text-accent" : "text-white"}`} title={track.title}>
          {track.title}
        </p>
        <p className="truncate text-xs text-muted">
          {artistNames(track.artists) || track.album?.name || (track.isVideo ? "Video" : "")}
        </p>
      </div>

      {showAlbum && track.album?.name ? (
        <p className="hidden w-1/4 shrink-0 truncate text-xs text-muted lg:block">{track.album.name}</p>
      ) : null}

      <span className="hidden w-12 shrink-0 text-right text-xs text-muted md:block">
        {formatTime(track.duration ?? 0)}
      </span>

      <div className="flex shrink-0 items-center">
        <LikeButton track={track} />
        <TrackMenu track={track} playlistId={playlistId} onRemove={onRemove} />
      </div>
    </div>
  );
}
