"use client";

import React from "react";
import { Icon } from "../Icons";
import { LikeButton } from "../LikeButton";
import { usePlayer } from "./PlayerProvider";
import { artistNames, cn, formatTimeMs } from "@/lib/format";

export function ProgressBar({
  position,
  duration,
  onSeek,
  className,
}: {
  position: number;
  duration: number;
  onSeek: (ms: number) => void;
  className?: string;
}) {
  const value = duration > 0 ? Math.min(position, duration) : 0;
  return (
    <input
      type="range"
      min={0}
      max={duration || 1}
      step={250}
      value={value}
      aria-label="Seek"
      className={cn("player-range", className)}
      onChange={(event) => onSeek(Number(event.target.value))}
      onClick={(event) => event.stopPropagation()}
    />
  );
}

export function PlayerBar() {
  const {
    current,
    isPlaying,
    position,
    duration,
    volume,
    muted,
    shuffle,
    repeat,
    toggle,
    next,
    previous,
    seek,
    setVolume,
    toggleMute,
    toggleShuffle,
    cycleRepeat,
    setNowPlayingOpen,
    nowPlayingOpen,
  } = usePlayer();

  if (!current) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-30 border-t border-white/10 bg-[#101014]/95 backdrop-blur">
      <div className="mx-auto flex h-[72px] max-w-[1800px] items-center gap-3 px-3 sm:h-20 sm:px-5">
        <button
          type="button"
          className="flex min-w-0 flex-1 items-center gap-3 text-left md:w-72 md:flex-none"
          onClick={() => setNowPlayingOpen(!nowPlayingOpen)}
          title="Open now playing"
        >
          <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded bg-elevated">
            {current.thumbnail ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={current.thumbnail} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="grid h-full w-full place-items-center text-muted">
                <Icon name="music" />
              </div>
            )}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-white">{current.title}</p>
            <p className="truncate text-xs text-muted">{artistNames(current.artists)}</p>
          </div>
        </button>

        <div className="hidden shrink-0 items-center md:flex">
          <LikeButton track={current} className="hidden lg:grid" />
          <button type="button" className="icon-btn hidden lg:grid" onClick={toggleShuffle} aria-label="Shuffle" title="Shuffle">
            <Icon name="shuffle" size={18} className={shuffle ? "text-accent" : undefined} />
          </button>
          <button type="button" className="icon-btn" onClick={previous} aria-label="Previous" title="Previous">
            <Icon name="previous" size={20} />
          </button>
          <button
            type="button"
            className="mx-1 grid h-11 w-11 place-items-center rounded-full bg-white text-black transition hover:scale-105"
            onClick={toggle}
            aria-label={isPlaying ? "Pause" : "Play"}
          >
            <Icon name={isPlaying ? "pause" : "play"} size={22} />
          </button>
          <button type="button" className="icon-btn" onClick={next} aria-label="Next" title="Next">
            <Icon name="next" size={20} />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={cycleRepeat}
            aria-label="Repeat"
            title={repeat === "off" ? "Repeat off" : repeat === "all" ? "Repeat all" : "Repeat one"}
          >
            <Icon
              name={repeat === "one" ? "repeat_one" : "repeat"}
              size={18}
              className={repeat === "off" ? "text-muted" : "text-accent"}
            />
          </button>
        </div>

        <div className="hidden flex-1 flex-col items-center gap-1 px-4 md:flex">
          <ProgressBar position={position} duration={duration} onSeek={seek} className="w-full max-w-xl" />
          <div className="flex w-full max-w-xl justify-between text-[11px] text-muted">
            <span>{formatTimeMs(position)}</span>
            <span>{formatTimeMs(duration)}</span>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1 md:w-52 md:justify-end">
          <button type="button" className="icon-btn md:hidden" onClick={toggle} aria-label={isPlaying ? "Pause" : "Play"}>
            <Icon name={isPlaying ? "pause" : "play"} size={22} />
          </button>
          <button type="button" className="icon-btn md:hidden" onClick={next} aria-label="Next">
            <Icon name="next" size={20} />
          </button>
          <button type="button" className="icon-btn hidden lg:grid" onClick={toggleMute} aria-label="Mute" title="Mute">
            <Icon name={muted || volume === 0 ? "volume_off" : "volume"} size={18} />
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={muted ? 0 : volume}
            aria-label="Volume"
            className="player-range hidden w-24 lg:block"
            onChange={(event) => setVolume(Number(event.target.value))}
          />
          <button
            type="button"
            className="icon-btn"
            onClick={() => setNowPlayingOpen(!nowPlayingOpen)}
            aria-label="Queue"
            title="Queue"
          >
            <Icon name="queue" size={20} className={nowPlayingOpen ? "text-accent" : undefined} />
          </button>
          <button
            type="button"
            className="icon-btn hidden sm:grid"
            onClick={() => setNowPlayingOpen(!nowPlayingOpen)}
            aria-label="Expand player"
            title="Expand player"
          >
            <Icon name={nowPlayingOpen ? "chevron_down" : "chevron_up"} size={22} />
          </button>
        </div>
      </div>
      <div className="md:hidden">
        <ProgressBar position={position} duration={duration} onSeek={seek} className="w-full" />
      </div>
    </div>
  );
}
