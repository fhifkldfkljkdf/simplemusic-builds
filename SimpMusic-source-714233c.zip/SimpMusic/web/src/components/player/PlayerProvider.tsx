"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { ServerSyncSession, Track } from "@/lib/types";

type RepeatMode = "off" | "all" | "one";

interface PlayerState {
  queue: Track[];
  index: number;
  isPlaying: boolean;
  position: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  radioSeed: string | null;
}

export interface PlayerContextValue extends PlayerState {
  current: Track | null;
  nowPlayingOpen: boolean;
  remoteSession: ServerSyncSession | null;
  setNowPlayingOpen: (open: boolean) => void;
  playTracks: (tracks: Track[], startIndex?: number, options?: { radioSeed?: string | null; play?: boolean }) => void;
  playTrack: (track: Track) => void;
  startRadio: (track: Track) => Promise<void>;
  addToQueue: (track: Track) => void;
  playNext: (track: Track) => void;
  removeFromQueue: (index: number) => void;
  moveInQueue: (from: number, to: number) => void;
  jumpTo: (index: number) => void;
  toggle: () => void;
  next: () => void;
  previous: () => void;
  seek: (ms: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  continueSession: () => Promise<void>;
  dismissRemoteSession: () => void;
}

const PlayerContext = createContext<PlayerContextValue | null>(null);

export function usePlayer(): PlayerContextValue {
  const context = useContext(PlayerContext);
  if (!context) throw new Error("usePlayer must be used inside PlayerProvider");
  return context;
}

const SESSION_INTERVAL = 10_000;
const REMOTE_POLL = 20_000;

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [queue, setQueue] = useState<Track[]>([]);
  const [index, setIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [radioSeed, setRadioSeed] = useState<string | null>(null);
  const [nowPlayingOpen, setNowPlayingOpen] = useState(false);
  const [remoteSession, setRemoteSession] = useState<ServerSyncSession | null>(null);

  const current = queue[index] ?? null;

  const stateRef = useRef<PlayerState>({
    queue: [],
    index: 0,
    isPlaying: false,
    position: 0,
    duration: 0,
    volume: 0.8,
    muted: false,
    shuffle: false,
    repeat: "off",
    radioSeed: null,
  });
  stateRef.current = { queue, index, isPlaying, position, duration, volume, muted, shuffle, repeat, radioSeed };

  const autoplayRef = useRef(false);
  const pendingSeekRef = useRef<number | null>(null);
  const ownSessionAtRef = useRef(0);
  const extendingRef = useRef(false);
  const historyRef = useRef<{ videoId: string; listened: number; sent: boolean; startedAt: number } | null>(null);

  // ---- audio element ------------------------------------------------------------------------
  useEffect(() => {
    const audio = new Audio();
    audio.preload = "auto";
    audio.volume = 0.8;
    audioRef.current = audio;

    const onTime = () => {
      setPosition(audio.currentTime * 1000);
      if (historyRef.current) historyRef.current.listened = Math.max(historyRef.current.listened, audio.currentTime);
      if ("mediaSession" in navigator && Number.isFinite(audio.duration)) {
        try {
          navigator.mediaSession.setPositionState({
            duration: audio.duration || 0,
            playbackRate: audio.playbackRate || 1,
            position: Math.min(audio.currentTime || 0, audio.duration || 0),
          });
        } catch {
          /* unsupported */
        }
      }
    };
    const onMeta = () => {
      setDuration(Number.isFinite(audio.duration) ? audio.duration * 1000 : 0);
      if (pendingSeekRef.current != null) {
        audio.currentTime = Math.max(0, pendingSeekRef.current / 1000);
        setPosition(pendingSeekRef.current);
        pendingSeekRef.current = null;
      }
    };
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onEnded = () => endedRef.current();
    const onError = () => {
      setIsPlaying(false);
    };
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("durationchange", onMeta);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);

    const stored = typeof window !== "undefined" ? Number(window.localStorage.getItem("simpmusic.volume")) : NaN;
    if (Number.isFinite(stored) && stored >= 0 && stored <= 1) {
      setVolumeState(stored);
      audio.volume = stored;
    }

    return () => {
      audio.pause();
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("durationchange", onMeta);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
      audioRef.current = null;
    };
  }, []);

  // ---- load current track --------------------------------------------------------------------
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !current) return;
    audio.src = `/api/stream/${current.videoId}`;
    setPosition(0);
    setDuration((current.duration ?? 0) * 1000);
    if (autoplayRef.current) {
      void audio.play().catch(() => setIsPlaying(false));
    }
    if ("mediaSession" in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: current.title,
        artist: current.artists?.map((a) => a.name).join(", ") || "",
        album: current.album?.name ?? "",
        artwork: current.thumbnail
          ? [
              { src: current.thumbnail, sizes: "512x512", type: "image/jpeg" },
            ]
          : [],
      });
    }
    // History: flush whatever was playing before switching.
    const previous = historyRef.current;
    if (previous && previous.videoId !== current.videoId && !previous.sent) flushHistoryRef.current(previous);
    historyRef.current = { videoId: current.videoId, listened: 0, sent: false, startedAt: Date.now() };
  }, [current?.videoId]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---- volume ---------------------------------------------------------------------------------
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = volume;
    audio.muted = muted;
    try {
      window.localStorage.setItem("simpmusic.volume", String(volume));
    } catch {
      /* private mode */
    }
  }, [volume, muted]);

  // ---- history --------------------------------------------------------------------------------
  const flushHistoryRef = useRef<(entry: { videoId: string; listened: number; sent: boolean }) => void>(() => {});
  useEffect(() => {
    flushHistoryRef.current = (entry) => {
      if (entry.sent || entry.listened < 5) return;
      const track = stateRef.current.queue.find((t) => t.videoId === entry.videoId);
      if (!track) return;
      entry.sent = true;
      void fetch("/api/library/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ track, listenedSeconds: Math.round(entry.listened) }),
        keepalive: true,
      }).catch(() => undefined);
    };
  }, []);

  const flushHistory = useCallback(() => {
    const entry = historyRef.current;
    if (entry) flushHistoryRef.current(entry);
  }, []);

  // ---- radio extension ------------------------------------------------------------------------
  const extendRadio = useCallback(async (): Promise<Track[]> => {
    const seed = stateRef.current.radioSeed;
    if (!seed || extendingRef.current) return [];
    extendingRef.current = true;
    try {
      const response = await fetch(`/api/yt/radio?videoId=${encodeURIComponent(seed)}`);
      const data = (await response.json()) as { tracks?: Track[] };
      const known = new Set(stateRef.current.queue.map((t) => t.videoId));
      const extra = (data.tracks ?? []).filter((t) => !known.has(t.videoId));
      if (extra.length) setQueue((previous) => [...previous, ...extra]);
      return extra;
    } catch {
      return [];
    } finally {
      extendingRef.current = false;
    }
  }, []);

  useEffect(() => {
    if (!radioSeed) return;
    if (queue.length === 0) return;
    if (index >= queue.length - 2 && queue.length < 400) void extendRadio();
  }, [index, queue.length, radioSeed, extendRadio]);

  // ---- transport ------------------------------------------------------------------------------
  const jumpTo = useCallback((nextIndex: number) => {
    const { queue: currentQueue } = stateRef.current;
    if (nextIndex < 0 || nextIndex >= currentQueue.length) return;
    autoplayRef.current = true;
    setIndex(nextIndex);
  }, []);

  const nextRef = useRef<() => void>(() => {});
  const endedRef = useRef<() => void>(() => {});

  const next = useCallback(() => {
    const { queue: q, index: i, repeat: r } = stateRef.current;
    if (!q.length) return;
    if (i + 1 < q.length) {
      autoplayRef.current = true;
      setIndex(i + 1);
      return;
    }
    if (r === "all") {
      autoplayRef.current = true;
      setIndex(0);
      return;
    }
    if (stateRef.current.radioSeed) {
      void extendRadio().then((extra) => {
        if (extra.length) {
          autoplayRef.current = true;
          setIndex(i + 1);
        }
      });
      return;
    }
    const audio = audioRef.current;
    audio?.pause();
    setIsPlaying(false);
  }, [extendRadio]);

  useEffect(() => {
    nextRef.current = next;
  }, [next]);

  useEffect(() => {
    endedRef.current = () => {
      const state = stateRef.current;
      const entry = historyRef.current;
      if (entry && !entry.sent) flushHistoryRef.current(entry);
      if (state.repeat === "one") {
        const audio = audioRef.current;
        if (audio) {
          audio.currentTime = 0;
          void audio.play().catch(() => undefined);
        }
        return;
      }
      nextRef.current();
    };
  }, []);

  const previous = useCallback(() => {
    const audio = audioRef.current;
    if (audio && audio.currentTime > 3) {
      audio.currentTime = 0;
      setPosition(0);
      return;
    }
    const { index: i } = stateRef.current;
    if (i > 0) {
      autoplayRef.current = true;
      setIndex(i - 1);
    } else if (audio) {
      audio.currentTime = 0;
      setPosition(0);
    }
  }, []);

  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const audio = audioRef.current;
    try {
      navigator.mediaSession.setActionHandler("play", () => void audio?.play());
      navigator.mediaSession.setActionHandler("pause", () => audio?.pause());
      navigator.mediaSession.setActionHandler("previoustrack", () => previous());
      navigator.mediaSession.setActionHandler("nexttrack", () => nextRef.current());
      navigator.mediaSession.setActionHandler("seekto", (details) => {
        if (details.seekTime != null && audio) audio.currentTime = details.seekTime;
      });
      navigator.mediaSession.setActionHandler("seekbackward", () => {
        if (audio) audio.currentTime = Math.max(0, audio.currentTime - 10);
      });
      navigator.mediaSession.setActionHandler("seekforward", () => {
        if (audio) audio.currentTime = Math.min(audio.duration || Infinity, audio.currentTime + 10);
      });
    } catch {
      /* some browsers reject unsupported actions */
    }
    return () => {
      if (!("mediaSession" in navigator)) return;
      for (const action of [
        "play",
        "pause",
        "previoustrack",
        "nexttrack",
        "seekto",
        "seekbackward",
        "seekforward",
      ] as MediaSessionAction[]) {
        try {
          navigator.mediaSession.setActionHandler(action, null);
        } catch {
          /* ignore */
        }
      }
    };
  }, [previous]);

  const toggle = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!stateRef.current.queue.length) return;
    if (audio.paused) {
      autoplayRef.current = true;
      void audio.play().catch(() => undefined);
    } else {
      audio.pause();
      flushHistory();
    }
  }, [flushHistory]);

  const seek = useCallback((ms: number) => {
    const audio = audioRef.current;
    const safe = Math.max(0, ms);
    if (!audio) return;
    if (audio.readyState >= 1 && Number.isFinite(audio.duration)) {
      audio.currentTime = Math.min(safe / 1000, audio.duration || safe / 1000);
      setPosition(safe);
    } else {
      pendingSeekRef.current = safe;
      setPosition(safe);
    }
  }, []);

  const setVolume = useCallback((value: number) => {
    setVolumeState(Math.min(1, Math.max(0, value)));
    setMuted(false);
  }, []);

  const toggleMute = useCallback(() => setMuted((m) => !m), []);

  const toggleShuffle = useCallback(() => {
    const enabling = !stateRef.current.shuffle;
    setShuffle(enabling);
    if (!enabling) return;
    setQueue((q) => {
      const head = q.slice(0, stateRef.current.index + 1);
      const tail = q.slice(stateRef.current.index + 1);
      for (let k = tail.length - 1; k > 0; k--) {
        const j = Math.floor(Math.random() * (k + 1));
        [tail[k], tail[j]] = [tail[j], tail[k]];
      }
      return [...head, ...tail];
    });
  }, []);

  const cycleRepeat = useCallback(() => {
    setRepeat((mode) => (mode === "off" ? "all" : mode === "all" ? "one" : "off"));
  }, []);

  // ---- queue operations -----------------------------------------------------------------------
  const playTracks = useCallback(
    (tracks: Track[], startIndex = 0, options?: { radioSeed?: string | null; play?: boolean }) => {
      if (!tracks.length) return;
      const safeIndex = Math.min(Math.max(0, startIndex), tracks.length - 1);
      autoplayRef.current = options?.play !== false;
      pendingSeekRef.current = null;
      setQueue(tracks);
      setIndex(safeIndex);
      setRadioSeed(options?.radioSeed ?? null);
      setPosition(0);
      setIsPlaying(options?.play !== false);
    },
    []
  );

  const playTrack = useCallback(
    (track: Track) => {
      playTracks([track], 0);
    },
    [playTracks]
  );

  const startRadio = useCallback(
    async (track: Track) => {
      try {
        const response = await fetch(`/api/yt/radio?videoId=${encodeURIComponent(track.videoId)}`);
        const data = (await response.json()) as { tracks?: Track[] };
        const tracks = [track, ...(data.tracks ?? []).filter((t) => t.videoId !== track.videoId)];
        playTracks(tracks, 0, { radioSeed: track.videoId });
        setNowPlayingOpen(false);
      } catch {
        playTrack(track);
      }
    },
    [playTracks, playTrack]
  );

  const addToQueue = useCallback((track: Track) => {
    setQueue((q) => (q.some((t) => t.videoId === track.videoId) ? q : [...q, track]));
  }, []);

  const playNext = useCallback((track: Track) => {
    setQueue((q) => {
      const without = q.filter((t) => t.videoId !== track.videoId);
      const insertAt = Math.min(stateRef.current.index + 1, without.length);
      return [...without.slice(0, insertAt), track, ...without.slice(insertAt)];
    });
  }, []);

  const removeFromQueue = useCallback(
    (removeIndex: number) => {
      const { index: currentIndex, queue: currentQueue } = stateRef.current;
      if (removeIndex < 0 || removeIndex >= currentQueue.length) return;
      const nextQueue = currentQueue.filter((_, i) => i !== removeIndex);
      if (!nextQueue.length) {
        audioRef.current?.pause();
        setQueue([]);
        setIndex(0);
        setIsPlaying(false);
        return;
      }
      if (removeIndex < currentIndex) setIndex(currentIndex - 1);
      else if (removeIndex === currentIndex) {
        autoplayRef.current = stateRef.current.isPlaying;
        setIndex(Math.min(currentIndex, nextQueue.length - 1));
      }
      setQueue(nextQueue);
    },
    []
  );

  const moveInQueue = useCallback((from: number, to: number) => {
    const { queue: currentQueue, index: currentIndex } = stateRef.current;
    if (from < 0 || from >= currentQueue.length || to < 0 || to >= currentQueue.length || from === to) return;
    const copy = [...currentQueue];
    const [item] = copy.splice(from, 1);
    copy.splice(to, 0, item);
    setQueue(copy);
    if (currentIndex === from) setIndex(to);
    else if (from < currentIndex && to >= currentIndex) setIndex(currentIndex - 1);
    else if (from > currentIndex && to <= currentIndex) setIndex(currentIndex + 1);
  }, []);

  // ---- session publishing ---------------------------------------------------------------------
  const publishSession = useCallback(() => {
    const state = stateRef.current;
    const track = state.queue[state.index];
    const audio = audioRef.current;
    if (!track || !audio) return;
    const now = Date.now();
    ownSessionAtRef.current = Math.max(ownSessionAtRef.current, now);
    const session: ServerSyncSession = {
      deviceName: "Web",
      videoId: track.videoId,
      positionMs: Math.round((audio.currentTime || 0) * 1000),
      isPlaying: !audio.paused,
      queue: state.queue.map((t) => t.videoId),
      queueIndex: state.index,
      updatedAt: now,
    };
    void fetch("/api/internal/session", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(session),
      keepalive: true,
    }).catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!current) return;
    publishSession();
    const id = window.setInterval(publishSession, SESSION_INTERVAL);
    return () => window.clearInterval(id);
  }, [current?.videoId, publishSession]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!current) return;
    const id = window.setTimeout(publishSession, 500);
    return () => window.clearTimeout(id);
  }, [isPlaying, publishSession, current]);

  // ---- session handoff ------------------------------------------------------------------------
  const checkRemote = useCallback(async () => {
    try {
      const response = await fetch("/api/internal/session", { cache: "no-store" });
      const session = (await response.json()) as ServerSyncSession | null;
      if (!session) return;
      if (session.deviceName === "Web") return;
      if (session.updatedAt <= ownSessionAtRef.current) return;
      setRemoteSession((existing) => (existing && existing.updatedAt >= session.updatedAt ? existing : session));
    } catch {
      /* server unreachable */
    }
  }, []);

  useEffect(() => {
    void checkRemote();
    const id = window.setInterval(() => void checkRemote(), REMOTE_POLL);
    return () => window.clearInterval(id);
  }, [checkRemote]);

  const continueSession = useCallback(async () => {
    const session = remoteSession;
    if (!session) return;
    try {
      const response = await fetch(`/api/yt/tracks?ids=${session.queue.map(encodeURIComponent).join(",")}`);
      const data = (await response.json()) as { tracks?: Track[] };
      const tracks = data.tracks ?? [];
      if (tracks.length) {
        const startIndex = Math.min(Math.max(0, session.queueIndex), tracks.length - 1);
        playTracks(tracks, startIndex, { radioSeed: null, play: session.isPlaying });
        pendingSeekRef.current = Math.max(0, session.positionMs);
        setPosition(Math.max(0, session.positionMs));
      }
    } catch {
      /* ignore */
    }
    ownSessionAtRef.current = Math.max(ownSessionAtRef.current, session.updatedAt);
    setRemoteSession(null);
  }, [remoteSession, playTracks]);

  const dismissRemoteSession = useCallback(() => {
    ownSessionAtRef.current = Math.max(ownSessionAtRef.current, Date.now());
    setRemoteSession(null);
  }, []);

  // ---- keyboard -------------------------------------------------------------------------------
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target) {
        const tag = target.tagName?.toLowerCase();
        if (tag === "input" || tag === "textarea" || tag === "select" || target.isContentEditable) return;
      }
      const audio = audioRef.current;
      switch (event.key) {
        case " ":
          event.preventDefault();
          toggle();
          break;
        case "ArrowRight":
          if (audio) {
            event.preventDefault();
            audio.currentTime = Math.min(audio.duration || Infinity, audio.currentTime + 5);
          }
          break;
        case "ArrowLeft":
          if (audio) {
            event.preventDefault();
            audio.currentTime = Math.max(0, audio.currentTime - 5);
          }
          break;
        case "ArrowUp":
          event.preventDefault();
          setVolume(stateRef.current.volume + 0.05);
          break;
        case "ArrowDown":
          event.preventDefault();
          setVolume(stateRef.current.volume - 0.05);
          break;
        case "m":
        case "M":
          toggleMute();
          break;
        case "n":
        case "N":
          nextRef.current();
          break;
        case "p":
        case "P":
          previous();
          break;
        default:
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, setVolume, toggleMute, previous]);

  const value = useMemo<PlayerContextValue>(
    () => ({
      queue,
      index,
      current,
      isPlaying,
      position,
      duration,
      volume,
      muted,
      shuffle,
      repeat,
      radioSeed,
      nowPlayingOpen,
      remoteSession,
      setNowPlayingOpen,
      playTracks,
      playTrack,
      startRadio,
      addToQueue,
      playNext,
      removeFromQueue,
      moveInQueue,
      jumpTo,
      toggle,
      next,
      previous,
      seek,
      setVolume,
      toggleMute,
      toggleShuffle,
      cycleRepeat,
      continueSession,
      dismissRemoteSession,
    }),
    [
      queue,
      index,
      current,
      isPlaying,
      position,
      duration,
      volume,
      muted,
      shuffle,
      repeat,
      radioSeed,
      nowPlayingOpen,
      remoteSession,
      playTracks,
      playTrack,
      startRadio,
      addToQueue,
      playNext,
      removeFromQueue,
      moveInQueue,
      jumpTo,
      toggle,
      next,
      previous,
      seek,
      setVolume,
      toggleMute,
      toggleShuffle,
      cycleRepeat,
      continueSession,
      dismissRemoteSession,
    ]
  );

  return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}
