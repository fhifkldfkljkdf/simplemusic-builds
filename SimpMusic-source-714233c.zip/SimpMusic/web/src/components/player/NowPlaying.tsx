"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { usePlayer } from "./PlayerProvider";
import { Icon } from "../Icons";
import { LikeButton } from "../LikeButton";
import { ProgressBar } from "./PlayerBar";
import { artistNames, formatTimeMs } from "@/lib/format";
import Link from "next/link";

interface LrcLine {
  at: number;
  text: string;
}

function parseLrc(source: string | null): LrcLine[] {
  if (!source) return [];
  const lines: LrcLine[] = [];
  for (const raw of source.split(/\r?\n/)) {
    const stamps = [...raw.matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)];
    if (!stamps.length) continue;
    const text = raw.replace(/\[[^\]]*\]/g, "").trim();
    if (!text) continue;
    for (const stamp of stamps) {
      const minutes = Number(stamp[1]);
      const seconds = Number(stamp[2].replace(":", "."));
      lines.push({ at: (minutes * 60 + seconds) * 1000, text });
    }
  }
  return lines.sort((a, b) => a.at - b.at);
}

function LyricsPane() {
  const { current, position, seek } = usePlayer();
  const [state, setState] = useState<{ loading: boolean; synced: string | null; plain: string | null }>({
    loading: false,
    synced: null,
    plain: null,
  });
  const containerRef = useRef<HTMLDivElement | null>(null);
  const activeRef = useRef<HTMLParagraphElement | null>(null);

  useEffect(() => {
    if (!current) return;
    let cancelled = false;
    setState({ loading: true, synced: null, plain: null });
    const params = new URLSearchParams({
      videoId: current.videoId,
      title: current.title,
      artist: artistNames(current.artists),
      album: current.album?.name ?? "",
      duration: String(current.duration ?? 0),
    });
    fetch(`/api/lyrics?${params.toString()}`)
      .then((response) => response.json())
      .then((data: { syncedLyrics?: string | null; plainLyrics?: string | null }) => {
        if (cancelled) return;
        setState({ loading: false, synced: data.syncedLyrics ?? null, plain: data.plainLyrics ?? null });
      })
      .catch(() => {
        if (!cancelled) setState({ loading: false, synced: null, plain: null });
      });
    return () => {
      cancelled = true;
    };
  }, [current?.videoId]); // eslint-disable-line react-hooks/exhaustive-deps

  const lines = useMemo(() => parseLrc(state.synced), [state.synced]);
  const activeIndex = useMemo(() => {
    if (!lines.length) return -1;
    let active = -1;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].at <= position + 120) active = i;
      else break;
    }
    return active;
  }, [lines, position]);

  useEffect(() => {
    if (activeIndex < 0) return;
    const container = containerRef.current;
    const element = activeRef.current;
    if (!container || !element) return;
    const top = element.offsetTop - container.clientHeight / 2 + element.clientHeight / 2;
    container.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
  }, [activeIndex]);

  if (state.loading) return <p className="p-6 text-sm text-muted">Looking up lyrics…</p>;

  if (lines.length) {
    return (
      <div ref={containerRef} className="h-full overflow-y-auto px-6 py-8 text-center">
        {lines.map((line, index) => (
          <p
            key={`${line.at}-${index}`}
            ref={index === activeIndex ? activeRef : null}
            onClick={() => seek(line.at)}
            className={`cursor-pointer px-2 py-2 text-lg leading-snug transition ${
              index === activeIndex
                ? "scale-[1.03] font-semibold text-white"
                : index < activeIndex
                  ? "text-white/35"
                  : "text-white/55 hover:text-white/80"
            }`}
          >
            {line.text}
          </p>
        ))}
      </div>
    );
  }

  if (state.plain) {
    return (
      <div className="h-full overflow-y-auto whitespace-pre-line px-6 py-8 text-center text-base leading-relaxed text-white/70">
        {state.plain}
      </div>
    );
  }

  return <p className="p-6 text-sm text-muted">No lyrics found on LRCLIB for this track.</p>;
}

export function NowPlaying() {
  const {
    current,
    isPlaying,
    position,
    duration,
    volume,
    muted,
    shuffle,
    repeat,
    queue,
    index,
    nowPlayingOpen,
    setNowPlayingOpen,
    toggle,
    next,
    previous,
    seek,
    setVolume,
    toggleMute,
    toggleShuffle,
    cycleRepeat,
    jumpTo,
    removeFromQueue,
    moveInQueue,
    radioSeed,
  } = usePlayer();
  const [tab, setTab] = useState<"queue" | "lyrics">("queue");
  const dragIndex = useRef<number | null>(null);

  useEffect(() => {
    if (!nowPlayingOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setNowPlayingOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [nowPlayingOpen, setNowPlayingOpen]);

  if (!nowPlayingOpen || !current) return null;

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-gradient-to-b from-[#241a1d] via-[#121216] to-[#0b0b0f]">
      <div className="flex items-center justify-between px-4 py-3 sm:px-6">
        <button
          type="button"
          className="icon-btn"
          onClick={() => setNowPlayingOpen(false)}
          aria-label="Collapse player"
          title="Collapse"
        >
          <Icon name="chevron_down" size={24} />
        </button>
        <p className="text-xs uppercase tracking-widest text-muted">
          {radioSeed ? "Radio" : "Now playing"}
        </p>
        <div className="w-9" />
      </div>

      <div className="mx-auto flex min-h-0 w-full max-w-6xl flex-1 flex-col gap-6 px-4 pb-6 sm:px-6 lg:flex-row">
        <div className="flex shrink-0 flex-col items-center lg:w-[42%] lg:items-start">
          <div className="aspect-square w-full max-w-[320px] overflow-hidden rounded-xl shadow-2xl">
            {current.thumbnail ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={current.thumbnail} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="grid h-full w-full place-items-center bg-elevated text-muted">
                <Icon name="music" size={64} />
              </div>
            )}
          </div>

          <div className="mt-5 flex w-full max-w-[420px] items-start gap-2">
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-2xl font-bold text-white">{current.title}</h1>
              <p className="truncate text-sm text-muted">
                {current.album?.id ? (
                  <Link href={`/album/${encodeURIComponent(current.album.id)}`} className="hover:underline">
                    {artistNames(current.artists)}
                  </Link>
                ) : (
                  artistNames(current.artists)
                )}
                {current.album?.name ? ` • ${current.album.name}` : ""}
              </p>
            </div>
            <LikeButton track={current} size={22} />
          </div>

          <div className="mt-5 w-full max-w-[420px]">
            <ProgressBar position={position} duration={duration} onSeek={seek} className="w-full" />
            <div className="flex justify-between text-[11px] text-muted">
              <span>{formatTimeMs(position)}</span>
              <span>{formatTimeMs(duration)}</span>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button type="button" className="icon-btn" onClick={toggleShuffle} aria-label="Shuffle">
              <Icon name="shuffle" size={20} className={shuffle ? "text-accent" : "text-muted"} />
            </button>
            <button type="button" className="icon-btn" onClick={previous} aria-label="Previous">
              <Icon name="previous" size={26} />
            </button>
            <button
              type="button"
              className="grid h-14 w-14 place-items-center rounded-full bg-white text-black transition hover:scale-105"
              onClick={toggle}
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              <Icon name={isPlaying ? "pause" : "play"} size={28} />
            </button>
            <button type="button" className="icon-btn" onClick={next} aria-label="Next">
              <Icon name="next" size={26} />
            </button>
            <button type="button" className="icon-btn" onClick={cycleRepeat} aria-label="Repeat">
              <Icon
                name={repeat === "one" ? "repeat_one" : "repeat"}
                size={20}
                className={repeat === "off" ? "text-muted" : "text-accent"}
              />
            </button>
          </div>

          <div className="mt-4 hidden w-full max-w-[420px] items-center gap-2 lg:flex">
            <button type="button" className="icon-btn" onClick={toggleMute} aria-label="Mute">
              <Icon name={muted || volume === 0 ? "volume_off" : "volume"} size={18} />
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={muted ? 0 : volume}
              aria-label="Volume"
              className="player-range w-40"
              onChange={(event) => setVolume(Number(event.target.value))}
            />
          </div>
        </div>

        <div className="flex min-h-0 flex-1 flex-col rounded-xl border border-white/10 bg-black/20">
          <div className="flex items-center gap-2 border-b border-white/10 px-3 py-2">
            <button
              type="button"
              onClick={() => setTab("queue")}
              className={`flex items-center gap-2 rounded-full px-4 py-1.5 text-sm ${
                tab === "queue" ? "bg-white/15 text-white" : "text-muted hover:text-white"
              }`}
            >
              <Icon name="queue" size={16} />
              Queue
            </button>
            <button
              type="button"
              onClick={() => setTab("lyrics")}
              className={`flex items-center gap-2 rounded-full px-4 py-1.5 text-sm ${
                tab === "lyrics" ? "bg-white/15 text-white" : "text-muted hover:text-white"
              }`}
            >
              <Icon name="lyrics" size={16} />
              Lyrics
            </button>
            <span className="ml-auto pr-2 text-xs text-muted">{queue.length} tracks</span>
          </div>

          {tab === "queue" ? (
            <div className="min-h-0 flex-1 overflow-y-auto p-2">
              {queue.map((track, queueIndex) => (
                <div
                  key={`${track.videoId}-${queueIndex}`}
                  draggable
                  onDragStart={() => {
                    dragIndex.current = queueIndex;
                  }}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={() => {
                    if (dragIndex.current != null) moveInQueue(dragIndex.current, queueIndex);
                    dragIndex.current = null;
                  }}
                  className={`group flex items-center gap-3 rounded-md px-2 py-2 ${
                    queueIndex === index ? "bg-white/10" : "hover:bg-white/5"
                  }`}
                >
                  <button
                    type="button"
                    className="min-w-0 flex-1 text-left"
                    onClick={() => jumpTo(queueIndex)}
                  >
                    <p
                      className={`truncate text-sm ${
                        queueIndex === index ? "font-semibold text-accent" : "text-white"
                      }`}
                    >
                      {track.title}
                    </p>
                    <p className="truncate text-xs text-muted">{artistNames(track.artists)}</p>
                  </button>
                  <div className="flex shrink-0 items-center opacity-0 transition group-hover:opacity-100">
                    <button
                      type="button"
                      className="icon-btn hidden sm:grid"
                      onClick={() => moveInQueue(queueIndex, Math.max(0, queueIndex - 1))}
                      aria-label="Move up"
                    >
                      <Icon name="chevron_up" size={16} />
                    </button>
                    <button
                      type="button"
                      className="icon-btn hidden sm:grid"
                      onClick={() => moveInQueue(queueIndex, Math.min(queue.length - 1, queueIndex + 1))}
                      aria-label="Move down"
                    >
                      <Icon name="chevron_down" size={16} />
                    </button>
                    <button
                      type="button"
                      className="icon-btn"
                      onClick={() => removeFromQueue(queueIndex)}
                      aria-label="Remove from queue"
                    >
                      <Icon name="close" size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="min-h-0 flex-1">
              <LyricsPane />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
