"use client";

import React from "react";
import { Icon } from "./Icons";
import { useUserData } from "./UserDataProvider";
import type { Track } from "@/lib/types";
import { cn } from "@/lib/format";

export function LikeButton({ track, size = 18, className }: { track: Track; size?: number; className?: string }) {
  const { isLiked, toggleLike } = useUserData();
  const liked = isLiked(track.videoId);
  return (
    <button
      type="button"
      aria-label={liked ? "Remove from liked songs" : "Add to liked songs"}
      title={liked ? "Remove from liked songs" : "Add to liked songs"}
      className={cn(
        "grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/10",
        liked ? "text-accent" : "text-muted hover:text-white",
        className
      )}
      onClick={(event) => {
        event.stopPropagation();
        void toggleLike(track);
      }}
    >
      <Icon name="heart" size={size} />
    </button>
  );
}
