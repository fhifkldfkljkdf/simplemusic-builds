"use client";

import React from "react";
import { Icon } from "./Icons";
import { usePlayer } from "./player/PlayerProvider";
import type { Track } from "@/lib/types";

export function PlayAllButton({
  tracks,
  radioSeed,
  label = "Play all",
}: {
  tracks: Track[];
  radioSeed?: string;
  label?: string;
}) {
  const { playTracks } = usePlayer();
  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        type="button"
        disabled={!tracks.length}
        className="flex items-center gap-2 rounded-full bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:brightness-110 disabled:opacity-40"
        onClick={() => playTracks(tracks, 0, { radioSeed: radioSeed ?? null })}
      >
        <Icon name="play" size={18} />
        {label}
      </button>
      <button
        type="button"
        disabled={!tracks.length}
        className="flex items-center gap-2 rounded-full border border-white/20 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-white/10 disabled:opacity-40"
        onClick={() => {
          const shuffled = [...tracks];
          for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
          }
          playTracks(shuffled, 0, { radioSeed: null });
        }}
      >
        <Icon name="shuffle" size={16} />
        Shuffle
      </button>
      {radioSeed ? (
        <button
          type="button"
          className="flex items-center gap-2 rounded-full border border-white/20 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-white/10"
          onClick={() => playTracks(tracks, 0, { radioSeed })}
        >
          <Icon name="radio" size={16} />
          Radio
        </button>
      ) : null}
    </div>
  );
}
