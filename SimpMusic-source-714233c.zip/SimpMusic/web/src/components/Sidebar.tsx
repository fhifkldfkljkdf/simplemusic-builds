"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon, type IconName } from "./Icons";

const NAV: Array<{ href: string; label: string; icon: IconName }> = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/moods", label: "Explore", icon: "compass" },
  { href: "/charts", label: "Charts", icon: "chart" },
  { href: "/library", label: "Library", icon: "library" },
  { href: "/settings", label: "Settings", icon: "settings" },
];

export function Sidebar() {
  const pathname = usePathname() || "/";
  return (
    <aside className="fixed inset-y-0 left-0 z-20 hidden w-60 flex-col border-r border-white/10 bg-[#0e0e12] px-3 py-5 md:flex">
      <Link href="/" className="mb-6 flex items-center gap-2 px-3">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-white">
          <Icon name="music" size={18} />
        </span>
        <span className="text-lg font-bold tracking-tight text-white">
          Simp<span className="text-accent">Music</span>
        </span>
      </Link>

      <nav className="flex flex-col gap-1">
        {NAV.map((item) => {
          const active =
            item.href === "/"
              ? pathname === "/"
              : pathname === item.href || pathname.startsWith(`${item.href}/`) || (item.href === "/moods" && pathname.startsWith("/browse"));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                active ? "bg-white/10 text-white" : "text-muted hover:bg-white/5 hover:text-white"
              }`}
            >
              <Icon name={item.icon} size={20} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto rounded-xl border border-white/10 bg-surface p-3">
        <p className="text-sm font-semibold text-white">Phone sync</p>
        <p className="mt-1 text-xs leading-relaxed text-muted">
          Pair the Android app to share likes, playlists and playback.
        </p>
        <Link
          href="/settings"
          className="mt-3 flex items-center justify-center gap-2 rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-white hover:brightness-110"
        >
          <Icon name="qr" size={14} />
          Pair phone
        </Link>
      </div>
    </aside>
  );
}

export function MobileNav() {
  const pathname = usePathname() || "/";
  return (
    <nav className="flex gap-1 overflow-x-auto px-2 py-2 md:hidden">
      {NAV.map((item) => {
        const active =
          item.href === "/" ? pathname === "/" : pathname === item.href || pathname.startsWith(`${item.href}/`);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium ${
              active ? "bg-white/15 text-white" : "text-muted"
            }`}
          >
            <Icon name={item.icon} size={14} />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
