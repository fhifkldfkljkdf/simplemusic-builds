/**
 * Runs once when the server boots: create the pairing token and the data directory then, so the
 * token is in the log before the first request (SYNC_API.md: "generated on first start, printed
 * in the logs").
 */
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { getToken } = await import("./lib/paths");
    getToken();
  }
}
