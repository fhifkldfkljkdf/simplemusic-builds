import { CardGrid } from "@/components/Cards";
import { getCharts } from "@/lib/youtube";
import type { Shelf } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function ChartsPage() {
  let shelves: Shelf[] = [];
  let error: string | null = null;
  try {
    shelves = await getCharts();
  } catch (caught) {
    error = (caught as Error).message;
  }

  return (
    <div>
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">YouTube Music</p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">Charts</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">Top songs, videos and artists, straight from YouTube Music.</p>
      </header>

      {error ? (
        <p className="rounded-xl border border-accent/30 bg-accent/10 p-4 text-sm text-white/80">{error}</p>
      ) : null}

      {!error && shelves.length === 0 ? (
        <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">No charts available right now.</p>
      ) : null}

      {shelves.map((shelf, index) => (
        <section key={`${shelf.title}-${index}`} className="mb-10">
          <h2 className="mb-4 text-xl font-bold text-white">{shelf.title}</h2>
          <CardGrid items={shelf.items} />
        </section>
      ))}
    </div>
  );
}
