import { json } from "@/lib/http";
import { getSuggestions } from "@/lib/youtube";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const query = (new URL(request.url).searchParams.get("q") ?? "").trim();
  if (!query) return json({ suggestions: [] });
  try {
    return json({ suggestions: await getSuggestions(query) });
  } catch {
    return json({ suggestions: [] });
  }
}
