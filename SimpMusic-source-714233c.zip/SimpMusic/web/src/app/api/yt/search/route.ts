import { json } from "@/lib/http";
import { searchMusic } from "@/lib/youtube";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const TYPES = new Set(["song", "album", "artist", "playlist", "video"]);

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const query = (params.get("q") ?? "").trim();
  const type = params.get("type") ?? "song";
  if (!query) return json({ shelves: [] });
  if (!TYPES.has(type)) return json({ error: "invalid type" }, 400);
  try {
    return json({ shelves: await searchMusic(query, type) });
  } catch (error) {
    return json({ error: (error as Error).message, shelves: [] }, 502);
  }
}
