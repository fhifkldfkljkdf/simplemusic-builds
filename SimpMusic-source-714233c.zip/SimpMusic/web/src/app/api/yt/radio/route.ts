import { json } from "@/lib/http";
import { getRadio } from "@/lib/youtube";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const videoId = new URL(request.url).searchParams.get("videoId") ?? "";
  if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) return json({ error: "invalid videoId", tracks: [] }, 400);
  try {
    return json({ tracks: await getRadio(videoId) });
  } catch (error) {
    return json({ error: (error as Error).message, tracks: [] }, 502);
  }
}
