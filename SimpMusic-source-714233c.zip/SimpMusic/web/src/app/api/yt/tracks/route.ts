import { json } from "@/lib/http";
import { tracksByIds } from "@/lib/youtube";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const idsParam = new URL(request.url).searchParams.get("ids") ?? "";
  const ids = idsParam
    .split(",")
    .map((id) => id.trim())
    .filter((id) => /^[A-Za-z0-9_-]{11}$/.test(id))
    .slice(0, 100);
  if (!ids.length) return json({ tracks: [] });
  const tracks = await tracksByIds(ids);
  return json({ tracks });
}
