import { getSession } from "@/lib/db";
import { json } from "@/lib/http";
import { saveSession } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Same session endpoints without the bearer guard: the web UI is open on the LAN and talks to
 *  these internal routes, while the phone uses the token-guarded /api/session. */
export async function GET() {
  return json(getSession());
}

export async function PUT(request: Request) {
  return saveSession(request);
}
