import { json } from "@/lib/http";
import { getLyrics } from "@/lib/lrclib";
import type { Track } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const videoId = params.get("videoId") ?? "";
  const title = (params.get("title") ?? "").trim();
  const artist = (params.get("artist") ?? "").trim();
  const album = (params.get("album") ?? "").trim();
  const duration = Number(params.get("duration") ?? "0") || 0;
  if (!videoId || !title) return json({ error: "title and videoId required" }, 400);

  const track: Track = {
    videoId,
    title,
    artists: artist ? [{ name: artist }] : [],
    album: album ? { name: album } : null,
    duration,
  };
  const lyrics = await getLyrics(track);
  return json(lyrics ?? { syncedLyrics: null, plainLyrics: null, instrumental: false });
}
