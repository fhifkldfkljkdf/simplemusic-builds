import { getSession } from "@/lib/db";
import { isAuthorized, json, unauthorized } from "@/lib/http";
import { saveSession } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** The latest session reported by any device, or null. Guarded by the pairing token. */
export async function GET(request: Request) {
  if (!isAuthorized(request)) return unauthorized();
  return json(getSession());
}

export async function PUT(request: Request) {
  if (!isAuthorized(request)) return unauthorized();
  return saveSession(request);
}
