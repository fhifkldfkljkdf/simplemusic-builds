import { forgetAudio, resolveAudio } from "@/lib/youtube";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const USER_AGENT =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

/**
 * Proxies an audio stream. Browsers cannot play googlevideo URLs directly (CORS and the
 * Range/opaque-origin rules), so bytes are relayed here. Range requests are forwarded and the
 * upstream 206 / Content-Range / Content-Type are preserved, which is what seeking needs.
 */
export async function GET(request: Request, context: { params: Promise<{ videoId: string }> }) {
  const { videoId } = await context.params;
  if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) {
    return new Response(JSON.stringify({ error: "invalid video id" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const range = request.headers.get("range");
  let resolved;
  try {
    resolved = await resolveAudio(videoId);
  } catch (error) {
    return new Response(
      JSON.stringify({ error: "stream unavailable", detail: (error as Error).message }),
      { status: 502, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } }
    );
  }

  const upstreamHeaders: Record<string, string> = {
    "User-Agent": USER_AGENT,
    Accept: "*/*",
  };
  if (range) upstreamHeaders.Range = range;

  let upstream: Response;
  try {
    upstream = await fetch(resolved.url, {
      headers: upstreamHeaders,
      cache: "no-store",
      redirect: "follow",
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: "upstream failed", detail: (error as Error).message }), {
      status: 502,
      headers: { "Content-Type": "application/json" },
    });
  }

  // A cached URL can expire or be rejected mid-way; drop it and resolve once more.
  if ([403, 410].includes(upstream.status)) {
    forgetAudio(videoId);
    try {
      const retry = await resolveAudio(videoId);
      upstream = await fetch(retry.url, { headers: upstreamHeaders, cache: "no-store", redirect: "follow" });
    } catch {
      // report the original upstream status below
    }
  }

  if (!upstream.ok && upstream.status !== 206) {
    return new Response(JSON.stringify({ error: "upstream rejected", status: upstream.status }), {
      status: upstream.status === 403 ? 403 : 502,
      headers: { "Content-Type": "application/json" },
    });
  }

  const headers = new Headers();
  for (const name of ["content-type", "content-length", "content-range", "accept-ranges", "etag", "last-modified"]) {
    const value = upstream.headers.get(name);
    if (value) headers.set(name, value);
  }
  if (!headers.has("content-type")) headers.set("content-type", resolved.contentType);
  if (!headers.has("accept-ranges")) headers.set("accept-ranges", "bytes");
  headers.set("cache-control", "no-store");

  return new Response(upstream.body, { status: upstream.status, headers });
}
