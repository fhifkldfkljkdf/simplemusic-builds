import { json } from "@/lib/http";
import { addTrackToPlaylist, removeTrackFromPlaylist } from "@/lib/library";
import { parseTrack } from "@/lib/track";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  const track = parseTrack(body.track);
  if (!track) return json({ error: "invalid track" }, 400);
  const playlist = addTrackToPlaylist(id, track);
  if (!playlist) return json({ error: "not found" }, 404);
  return json({ ok: true, playlist });
}

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const videoId = new URL(request.url).searchParams.get("videoId") ?? "";
  if (!videoId) return json({ error: "videoId required" }, 400);
  const playlist = removeTrackFromPlaylist(id, videoId);
  if (!playlist) return json({ error: "not found" }, 404);
  return json({ ok: true, playlist });
}
