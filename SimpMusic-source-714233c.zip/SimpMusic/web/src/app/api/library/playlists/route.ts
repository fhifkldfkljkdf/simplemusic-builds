import { json } from "@/lib/http";
import { createPlaylist, createPlaylistFromTracks, listPlaylists } from "@/lib/library";
import { parseTrack } from "@/lib/track";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return json({ playlists: listPlaylists() });
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  const title = typeof body.title === "string" ? body.title.trim() : "";
  if (!title) return json({ error: "title required" }, 400);

  if (Array.isArray(body.tracks)) {
    const tracks = body.tracks.map(parseTrack).filter((track): track is NonNullable<typeof track> => !!track);
    const playlist = createPlaylistFromTracks(
      title,
      tracks,
      typeof body.youtubePlaylistId === "string" ? body.youtubePlaylistId : null
    );
    return json({ ok: true, playlist });
  }

  const playlist = createPlaylist(title, parseTrack(body.track) ?? undefined);
  return json({ ok: true, playlist });
}
