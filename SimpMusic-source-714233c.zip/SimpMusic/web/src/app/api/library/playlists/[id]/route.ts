import { getLocalPlaylist } from "@/lib/db";
import { json } from "@/lib/http";
import { deletePlaylist, playlistTracks, renamePlaylist } from "@/lib/library";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const playlist = getLocalPlaylist(id);
  if (!playlist || playlist.deleted) return json({ error: "not found" }, 404);
  return json({ playlist, tracks: playlistTracks(playlist) });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  const title = typeof body.title === "string" ? body.title.trim() : "";
  if (!title) return json({ error: "title required" }, 400);
  const playlist = renamePlaylist(id, title);
  if (!playlist) return json({ error: "not found" }, 404);
  return json({ ok: true, playlist });
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!deletePlaylist(id)) return json({ error: "not found" }, 404);
  return json({ ok: true });
}
