import { json } from "@/lib/http";
import { recordPlayback } from "@/lib/library";
import { parseTrack } from "@/lib/track";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  const track = parseTrack(body.track);
  if (!track) return json({ error: "invalid track" }, 400);
  const listened = Number(body.listenedSeconds) || 0;
  recordPlayback(track, listened);
  return json({ ok: true });
}
