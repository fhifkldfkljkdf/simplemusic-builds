import { getSong, songToTrack } from "@/lib/db";
import { json } from "@/lib/http";
import { setLiked } from "@/lib/library";
import { parseTrack } from "@/lib/track";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  const videoId = typeof body.videoId === "string" ? body.videoId : "";
  if (!videoId) return json({ error: "videoId required" }, 400);
  const liked = !!body.liked;
  const parsed = parseTrack(body.track);
  const stored = getSong(videoId);
  const track = parsed ?? (stored ? songToTrack(stored) : { videoId, title: videoId, artists: [] });
  setLiked(track, liked);
  return json({ ok: true, liked });
}
