import { json } from "@/lib/http";
import { listFollows, setFollowed } from "@/lib/library";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return json({ follows: listFollows() });
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  const channelId = typeof body.channelId === "string" ? body.channelId : "";
  const name = typeof body.name === "string" ? body.name : "";
  if (!channelId || !name) return json({ error: "channelId and name required" }, 400);
  setFollowed({
    channelId,
    name,
    thumbnail: typeof body.thumbnail === "string" ? body.thumbnail : null,
    followed: !!body.followed,
  });
  return json({ ok: true, followed: !!body.followed });
}
