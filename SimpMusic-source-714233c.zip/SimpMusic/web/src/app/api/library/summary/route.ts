import { json } from "@/lib/http";
import { summary } from "@/lib/library";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return json(summary());
}
