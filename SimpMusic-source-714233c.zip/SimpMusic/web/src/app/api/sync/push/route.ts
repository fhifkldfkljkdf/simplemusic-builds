import { isAuthorized, json, unauthorized } from "@/lib/http";
import { applyPush } from "@/lib/sync";
import type { ServerSyncPushRequest } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!isAuthorized(request)) return unauthorized();
  let body: ServerSyncPushRequest;
  try {
    body = (await request.json()) as ServerSyncPushRequest;
  } catch {
    return json({ error: "invalid json" }, 400);
  }
  if (!body || typeof body !== "object") return json({ error: "invalid body" }, 400);
  const result = applyPush(body);
  return json(result);
}
