import { isAuthorized, json, unauthorized } from "@/lib/http";
import { pullSince } from "@/lib/sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!isAuthorized(request)) return unauthorized();
  const since = new URL(request.url).searchParams.get("since");
  return json(pullSince(since));
}
