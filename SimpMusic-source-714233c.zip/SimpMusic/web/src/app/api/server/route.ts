import QRCode from "qrcode";
import { getSession, stats } from "@/lib/db";
import { json } from "@/lib/http";
import { dataDir, getToken, SERVER_NAME, SERVER_VERSION } from "@/lib/paths";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Server info + pairing material for the settings screen. Request-scoped so the base URL is the
 *  address the browser actually used (or PUBLIC_URL when configured). */
export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const configured = process.env.PUBLIC_URL?.trim();
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? requestUrl.host;
  const proto = request.headers.get("x-forwarded-proto") ?? requestUrl.protocol.replace(":", "") ?? "http";
  const baseUrl = (configured || `${proto}://${host}`).replace(/\/+$/, "");
  const token = getToken();
  const pairLink = `simpmusic://server-sync?u=${encodeURIComponent(baseUrl)}&t=${token}`;
  const qr = await QRCode.toDataURL(pairLink, {
    margin: 1,
    width: 420,
    color: { dark: "#000000", light: "#ffffff" },
  });

  return json({
    serverName: SERVER_NAME,
    version: SERVER_VERSION,
    baseUrl,
    token,
    pairLink,
    qr,
    dataDir: dataDir(),
    dbPath: process.env.DB_PATH || null,
    publicUrl: configured || null,
    stats: stats(),
    session: getSession(),
  });
}
