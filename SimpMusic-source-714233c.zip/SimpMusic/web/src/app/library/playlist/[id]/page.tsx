import Link from "next/link";
import { notFound } from "next/navigation";
import { Icon } from "@/components/Icons";
import { PlaylistActions, PlaylistTracks } from "@/components/Interactions";
import { PlayAllButton } from "@/components/PlayAllButton";
import { getLocalPlaylist } from "@/lib/db";
import { playlistTracks } from "@/lib/library";

export const dynamic = "force-dynamic";

export default async function LocalPlaylistPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const playlist = getLocalPlaylist(decodeURIComponent(id));
  if (!playlist || playlist.deleted) notFound();

  const tracks = playlistTracks(playlist);

  return (
    <div>
      <header className="mb-8 flex flex-col gap-6 sm:flex-row sm:items-end">
        <div className="h-44 w-44 shrink-0 overflow-hidden rounded-lg bg-elevated shadow-2xl sm:h-52 sm:w-52">
          {playlist.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={playlist.thumbnail} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="grid h-full w-full place-items-center text-muted">
              <Icon name="library" size={48} />
            </div>
          )}
        </div>
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-[0.2em] text-muted">Local playlist</p>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-5xl">{playlist.title}</h1>
          <p className="mt-2 text-sm text-muted">
            {tracks.length} tracks • synced to the phone
            {playlist.youtubePlaylistId ? " • saved from YouTube Music" : ""}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <PlayAllButton tracks={tracks} />
            <PlaylistActions playlistId={playlist.id} title={playlist.title} />
          </div>
        </div>
      </header>

      <PlaylistTracks playlistId={playlist.id} tracks={tracks} />

      <p className="mt-6 text-xs text-muted">
        <Link href="/library?tab=playlists" className="hover:text-white">
          ← Back to playlists
        </Link>
      </p>
    </div>
  );
}
