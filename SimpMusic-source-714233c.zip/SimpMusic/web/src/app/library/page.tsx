import Link from "next/link";
import { CardGrid } from "@/components/Cards";
import { CreatePlaylistForm, PlaylistActions } from "@/components/Interactions";
import { Icon } from "@/components/Icons";
import { PlayAllButton } from "@/components/PlayAllButton";
import { TrackList } from "@/components/TrackList";
import { stats } from "@/lib/db";
import { listFollows, listHistory, listLikedTracks, listPlaylists } from "@/lib/library";
import type { Card } from "@/lib/types";

export const dynamic = "force-dynamic";

type Tab = "liked" | "playlists" | "artists" | "history";

export default async function LibraryPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab: rawTab } = await searchParams;
  const tab: Tab = (["liked", "playlists", "artists", "history"] as const).includes(rawTab as Tab)
    ? (rawTab as Tab)
    : "liked";

  const counts = stats();
  const tabs: Array<{ key: Tab; label: string; count: number }> = [
    { key: "liked", label: "Liked songs", count: counts.likes },
    { key: "playlists", label: "Playlists", count: counts.playlists },
    { key: "artists", label: "Artists", count: counts.follows },
    { key: "history", label: "History", count: counts.history },
  ];

  return (
    <div>
      <header className="mb-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Your collection</p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">Library</h1>
        <p className="mt-2 text-sm text-muted">Everything here syncs with the phone through the pairing token.</p>
      </header>

      <div className="mb-8 flex flex-wrap gap-2">
        {tabs.map((item) => (
          <Link
            key={item.key}
            href={`/library?tab=${item.key}`}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
              item.key === tab ? "bg-white text-black" : "border border-white/15 text-muted hover:bg-white/10 hover:text-white"
            }`}
          >
            {item.label}
            <span className={`ml-2 text-xs ${item.key === tab ? "text-black/60" : "text-muted"}`}>{item.count}</span>
          </Link>
        ))}
      </div>

      {tab === "liked" ? <LikedTab /> : null}
      {tab === "playlists" ? <PlaylistsTab /> : null}
      {tab === "artists" ? <ArtistsTab /> : null}
      {tab === "history" ? <HistoryTab /> : null}
    </div>
  );
}

function LikedTab() {
  const tracks = listLikedTracks();
  return (
    <div>
      <div className="mb-4">
        <PlayAllButton tracks={tracks} />
      </div>
      <TrackList
        tracks={tracks}
        showAlbum
        empty="No liked songs yet. Tap the heart on any track — the phone will see it too."
      />
    </div>
  );
}

function PlaylistsTab() {
  const playlists = listPlaylists();
  return (
    <div>
      <div className="mb-6">
        <CreatePlaylistForm />
      </div>
      {playlists.length === 0 ? (
        <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">
          No local playlists yet. Create one above, or save a YouTube Music playlist from its page.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {playlists.map((playlist) => (
            <div key={playlist.id} className="rounded-xl border border-white/10 bg-surface p-3">
              <Link href={`/library/playlist/${encodeURIComponent(playlist.id)}`} className="group block">
                <div className="mb-3 aspect-square overflow-hidden rounded-lg bg-elevated">
                  {playlist.thumbnail ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={playlist.thumbnail}
                      alt=""
                      className="h-full w-full object-cover transition group-hover:scale-105"
                    />
                  ) : (
                    <div className="grid h-full w-full place-items-center text-muted">
                      <Icon name="library" size={32} />
                    </div>
                  )}
                </div>
                <p className="truncate text-sm font-medium text-white" title={playlist.title}>
                  {playlist.title}
                </p>
                <p className="text-xs text-muted">{playlist.trackIds.length} tracks</p>
              </Link>
              <div className="mt-2 flex justify-end">
                <PlaylistActions playlistId={playlist.id} title={playlist.title} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ArtistsTab() {
  const follows = listFollows();
  const cards: Card[] = follows.map((follow) => ({
    kind: "artist",
    id: follow.channelId,
    title: follow.name,
    subtitle: "Following",
    thumbnail: follow.thumbnail ?? undefined,
  }));
  return cards.length ? (
    <CardGrid items={cards} />
  ) : (
    <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">
      No followed artists yet. Open an artist and press Follow.
    </p>
  );
}

function HistoryTab() {
  const entries = listHistory(300);
  return (
    <TrackList
      tracks={entries.map((entry) => entry.track)}
      showAlbum
      empty="Nothing played yet."
    />
  );
}
