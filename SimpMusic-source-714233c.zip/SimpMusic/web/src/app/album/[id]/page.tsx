import Link from "next/link";
import { ShelfRow } from "@/components/Cards";
import { PlayAllButton } from "@/components/PlayAllButton";
import { TrackList } from "@/components/TrackList";
import { formatTime } from "@/lib/format";
import { getAlbum } from "@/lib/youtube";

export const dynamic = "force-dynamic";

export default async function AlbumPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let album: Awaited<ReturnType<typeof getAlbum>> | null = null;
  let error: string | null = null;
  try {
    album = await getAlbum(decodeURIComponent(id));
  } catch (caught) {
    error = (caught as Error).message;
  }

  if (!album) {
    return (
      <div className="rounded-xl border border-accent/30 bg-accent/10 p-6 text-sm">
        <p className="font-semibold text-white">Could not load this album</p>
        <p className="mt-1 text-muted">{error}</p>
      </div>
    );
  }

  const artistId = album.tracks.find((track) => track.artists?.[0]?.id)?.artists?.[0]?.id;
  const totalSeconds = album.tracks.reduce((sum, track) => sum + (track.duration ?? 0), 0);

  return (
    <div>
      <header className="mb-8 flex flex-col gap-6 sm:flex-row sm:items-end">
        <div className="h-44 w-44 shrink-0 overflow-hidden rounded-lg bg-elevated shadow-2xl sm:h-52 sm:w-52">
          {album.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={album.thumbnail} alt="" className="h-full w-full object-cover" />
          ) : null}
        </div>
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-[0.2em] text-muted">Album</p>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-5xl">{album.title}</h1>
          <p className="mt-2 text-sm text-muted">
            {artistId ? (
              <Link href={`/artist/${encodeURIComponent(artistId)}`} className="text-white hover:underline">
                {album.artist}
              </Link>
            ) : (
              album.artist
            )}
            {album.subtitle ? ` • ${album.subtitle}` : ""}
            {album.tracks.length ? ` • ${album.tracks.length} tracks` : ""}
            {totalSeconds ? ` • ${formatTime(totalSeconds)}` : ""}
          </p>
          <div className="mt-4">
            <PlayAllButton tracks={album.tracks} />
          </div>
        </div>
      </header>

      <TrackList tracks={album.tracks} showAlbum={false} empty="This album has no playable tracks." />

      <div className="mt-10 space-y-2">
        {album.shelves.map((shelf, index) => (
          <ShelfRow key={`${shelf.title}-${index}`} shelf={shelf} />
        ))}
      </div>
    </div>
  );
}
