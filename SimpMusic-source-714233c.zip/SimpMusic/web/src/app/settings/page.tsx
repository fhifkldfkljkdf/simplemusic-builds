import { SettingsView } from "@/components/SettingsView";

export const dynamic = "force-dynamic";

export default function SettingsPage() {
  return (
    <div className="max-w-4xl">
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Server</p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">Settings</h1>
        <p className="mt-2 text-sm text-muted">
          Pair the SimpMusic Android app with this server so likes, playlists, follows, history and the
          playback position stay in step.
        </p>
      </header>
      <SettingsView />
    </div>
  );
}
