import { ImportPlaylistButton } from "@/components/Interactions";
import { PlayAllButton } from "@/components/PlayAllButton";
import { TrackList } from "@/components/TrackList";
import { formatTime } from "@/lib/format";
import { getYoutubePlaylist } from "@/lib/youtube";

export const dynamic = "force-dynamic";

export default async function YoutubePlaylistPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let playlist: Awaited<ReturnType<typeof getYoutubePlaylist>> | null = null;
  let error: string | null = null;
  try {
    playlist = await getYoutubePlaylist(decodeURIComponent(id));
  } catch (caught) {
    error = (caught as Error).message;
  }

  if (!playlist) {
    return (
      <div className="rounded-xl border border-accent/30 bg-accent/10 p-6 text-sm">
        <p className="font-semibold text-white">Could not load this playlist</p>
        <p className="mt-1 text-muted">{error}</p>
      </div>
    );
  }

  const totalSeconds = playlist.tracks.reduce((sum, track) => sum + (track.duration ?? 0), 0);

  return (
    <div>
      <header className="mb-8 flex flex-col gap-6 sm:flex-row sm:items-end">
        <div className="h-44 w-44 shrink-0 overflow-hidden rounded-lg bg-elevated shadow-2xl sm:h-52 sm:w-52">
          {playlist.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={playlist.thumbnail} alt="" className="h-full w-full object-cover" />
          ) : null}
        </div>
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-[0.2em] text-muted">YouTube Music playlist</p>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-5xl">{playlist.title}</h1>
          <p className="mt-2 text-sm text-muted">
            {playlist.author ? `${playlist.author} • ` : ""}
            {playlist.subtitle} • {playlist.tracks.length} tracks
            {totalSeconds ? ` • ${formatTime(totalSeconds)}` : ""}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <PlayAllButton tracks={playlist.tracks} />
            <ImportPlaylistButton
              title={playlist.title}
              tracks={playlist.tracks}
              youtubePlaylistId={playlist.id}
            />
          </div>
        </div>
      </header>

      {playlist.description ? (
        <p className="mb-6 line-clamp-3 max-w-3xl whitespace-pre-line text-sm text-muted">{playlist.description}</p>
      ) : null}

      <TrackList tracks={playlist.tracks} showAlbum empty="This playlist has no playable tracks." />
    </div>
  );
}
