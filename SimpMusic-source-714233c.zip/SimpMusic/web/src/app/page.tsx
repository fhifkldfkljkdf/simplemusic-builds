import Link from "next/link";
import { ShelfRow } from "@/components/Cards";
import { getHome } from "@/lib/youtube";
import type { Shelf } from "@/lib/types";

export const dynamic = "force-dynamic";

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 5) return "Good night";
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

export default async function HomePage() {
  let shelves: Shelf[] = [];
  let error: string | null = null;
  try {
    shelves = await getHome();
  } catch (caught) {
    error = (caught as Error).message;
  }

  return (
    <div>
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">YouTube Music</p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">{greeting()}</h1>
        <div className="mt-4 flex flex-wrap gap-2 text-xs">
          <Link href="/moods" className="rounded-full border border-white/15 px-3 py-1.5 text-muted hover:bg-white/10 hover:text-white">
            Moods &amp; genres
          </Link>
          <Link href="/charts" className="rounded-full border border-white/15 px-3 py-1.5 text-muted hover:bg-white/10 hover:text-white">
            Charts
          </Link>
          <Link href="/library" className="rounded-full border border-white/15 px-3 py-1.5 text-muted hover:bg-white/10 hover:text-white">
            Your library
          </Link>
        </div>
      </header>

      {error ? (
        <div className="mb-8 rounded-xl border border-accent/30 bg-accent/10 p-4 text-sm text-white/80">
          <p className="font-semibold text-white">Could not load the YouTube Music home feed</p>
          <p className="mt-1 break-words text-xs text-muted">{error}</p>
          <p className="mt-2 text-xs text-muted">
            Check the container&apos;s network access, or try search — it uses the same API.
          </p>
        </div>
      ) : null}

      {!error && shelves.length === 0 ? (
        <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">
          YouTube Music returned no home shelves for this region.
        </p>
      ) : null}

      {shelves.map((shelf, index) => (
        <ShelfRow key={`${shelf.title}-${index}`} shelf={shelf} />
      ))}
    </div>
  );
}
