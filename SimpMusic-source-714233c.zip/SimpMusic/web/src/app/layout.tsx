import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "@/components/Providers";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { PlayerBar } from "@/components/player/PlayerBar";
import { NowPlaying } from "@/components/player/NowPlaying";
import { ContinueBanner } from "@/components/ContinueBanner";

export const metadata: Metadata = {
  title: "SimpMusic Web",
  description: "Self-hosted YouTube Music player that syncs with the SimpMusic Android app",
};

export const viewport: Viewport = {
  themeColor: "#0b0b0f",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body>
        <Providers>
          <Sidebar />
          <div className="min-h-screen md:pl-60">
            <TopBar />
            <main className="mx-auto w-full max-w-[1800px] px-4 pb-32 pt-6 sm:px-6 lg:px-8">{children}</main>
          </div>
          <PlayerBar />
          <NowPlaying />
          <ContinueBanner />
        </Providers>
      </body>
    </html>
  );
}
