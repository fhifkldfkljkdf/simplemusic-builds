import Link from "next/link";
import { CardGrid } from "@/components/Cards";
import { browseMusic } from "@/lib/youtube";
import type { Shelf } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function BrowsePage({
  searchParams,
}: {
  searchParams: Promise<{ browseId?: string; params?: string; title?: string }>;
}) {
  const { browseId, params, title } = await searchParams;

  if (!browseId) {
    return (
      <div className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">
        Pick a mood or genre on the{" "}
        <Link href="/moods" className="text-white underline">
          Explore
        </Link>{" "}
        page.
      </div>
    );
  }

  let shelves: Shelf[] = [];
  let error: string | null = null;
  try {
    shelves = await browseMusic(browseId, params || undefined);
  } catch (caught) {
    error = (caught as Error).message;
  }

  return (
    <div>
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">
          <Link href="/moods" className="hover:text-white">
            Explore
          </Link>{" "}
          / Moods &amp; genres
        </p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          {title || "Browse"}
        </h1>
      </header>

      {error ? (
        <p className="rounded-xl border border-accent/30 bg-accent/10 p-4 text-sm text-white/80">{error}</p>
      ) : null}

      {!error && shelves.length === 0 ? (
        <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">
          YouTube Music returned nothing for this category.
        </p>
      ) : null}

      {shelves.map((shelf, index) => (
        <section key={`${shelf.title}-${index}`} className="mb-10">
          {shelf.title ? <h2 className="mb-4 text-xl font-bold text-white">{shelf.title}</h2> : null}
          <CardGrid items={shelf.items} />
        </section>
      ))}
    </div>
  );
}
