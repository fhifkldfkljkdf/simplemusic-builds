import { ShelfRow } from "@/components/Cards";
import { FollowButton } from "@/components/FollowButton";
import { PlayAllButton } from "@/components/PlayAllButton";
import { TrackList } from "@/components/TrackList";
import { getArtist } from "@/lib/youtube";

export const dynamic = "force-dynamic";

export default async function ArtistPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let artist: Awaited<ReturnType<typeof getArtist>> | null = null;
  let error: string | null = null;
  try {
    artist = await getArtist(decodeURIComponent(id));
  } catch (caught) {
    error = (caught as Error).message;
  }

  if (!artist) {
    return (
      <div className="rounded-xl border border-accent/30 bg-accent/10 p-6 text-sm">
        <p className="font-semibold text-white">Could not load this artist</p>
        <p className="mt-1 text-muted">{error}</p>
      </div>
    );
  }

  return (
    <div>
      <header className="mb-8 flex flex-col gap-6 sm:flex-row sm:items-end">
        <div className="h-40 w-40 shrink-0 overflow-hidden rounded-full bg-elevated shadow-2xl sm:h-48 sm:w-48">
          {artist.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={artist.thumbnail} alt="" className="h-full w-full object-cover" />
          ) : null}
        </div>
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-[0.2em] text-muted">Artist</p>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-5xl">{artist.title}</h1>
          <p className="mt-2 text-sm text-muted">{artist.subtitle}</p>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <PlayAllButton tracks={artist.topSongs} label="Play top songs" />
            <FollowButton channelId={artist.id} name={artist.title} thumbnail={artist.thumbnail} />
          </div>
        </div>
      </header>

      <section className="mb-10">
        <h2 className="mb-3 text-xl font-bold text-white">Top songs</h2>
        <TrackList tracks={artist.topSongs} showAlbum empty="No top songs." />
      </section>

      {artist.shelves.map((shelf, index) => (
        <ShelfRow key={`${shelf.title}-${index}`} shelf={shelf} />
      ))}
    </div>
  );
}
