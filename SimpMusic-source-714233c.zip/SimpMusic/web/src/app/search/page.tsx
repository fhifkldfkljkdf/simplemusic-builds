import Link from "next/link";
import { CardGrid } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import { searchMusic } from "@/lib/youtube";
import type { Card, Shelf, Track } from "@/lib/types";

export const dynamic = "force-dynamic";

const TABS: Array<{ key: string; label: string; type: string }> = [
  { key: "songs", label: "Songs", type: "song" },
  { key: "albums", label: "Albums", type: "album" },
  { key: "artists", label: "Artists", type: "artist" },
  { key: "playlists", label: "Playlists", type: "playlist" },
  { key: "videos", label: "Videos", type: "video" },
];

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; type?: string }>;
}) {
  const params = await searchParams;
  const query = (params.q ?? "").trim();
  const tab = TABS.find((t) => t.key === params.type) ?? TABS[0];

  let shelves: Shelf[] = [];
  let error: string | null = null;
  if (query) {
    try {
      shelves = await searchMusic(query, tab.type);
    } catch (caught) {
      error = (caught as Error).message;
    }
  }

  const cards: Card[] = shelves.flatMap((shelf) => shelf.items);
  const tracks: Track[] = cards.map((card) => card.track).filter((track): track is Track => !!track);

  return (
    <div>
      <header className="mb-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Search</p>
        <h1 className="mt-1 text-2xl font-bold text-white sm:text-3xl">
          {query ? `Results for “${query}”` : "Search YouTube Music"}
        </h1>
      </header>

      <div className="mb-8 flex flex-wrap gap-2">
        {TABS.map((item) => (
          <Link
            key={item.key}
            href={`/search?q=${encodeURIComponent(query)}&type=${item.key}`}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
              item.key === tab.key ? "bg-white text-black" : "border border-white/15 text-muted hover:bg-white/10 hover:text-white"
            }`}
          >
            {item.label}
          </Link>
        ))}
      </div>

      {!query ? (
        <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">
          Type something in the search bar above — songs, albums, artists, playlists or videos.
        </p>
      ) : null}

      {error ? (
        <p className="rounded-xl border border-accent/30 bg-accent/10 p-4 text-sm text-white/80">{error}</p>
      ) : null}

      {query && !error && cards.length === 0 ? (
        <p className="rounded-xl border border-white/10 bg-surface p-6 text-sm text-muted">No results.</p>
      ) : null}

      {tab.key === "songs" || tab.key === "videos" ? (
        tracks.length ? <TrackList tracks={tracks} showAlbum /> : null
      ) : (
        cards.length ? <CardGrid items={cards} /> : null
      )}
    </div>
  );
}
