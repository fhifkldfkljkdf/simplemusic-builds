import Link from "next/link";
import { CardGrid } from "@/components/Cards";
import { getExplore, getMoodsAndGenres } from "@/lib/youtube";
import type { Shelf } from "@/lib/types";

export const dynamic = "force-dynamic";

function GenreShelf({ shelf }: { shelf: Shelf }) {
  return (
    <section className="mb-9">
      {shelf.title ? <h2 className="mb-4 text-xl font-bold text-white">{shelf.title}</h2> : null}
      <div className="flex flex-wrap gap-2">
        {shelf.items.map((item, index) => (
          <Link
            key={`${item.id}-${item.title}-${index}`}
            href={`/browse?browseId=${encodeURIComponent(item.id)}&params=${encodeURIComponent(item.params ?? "")}&title=${encodeURIComponent(item.title)}`}
            className="rounded-full border border-white/15 bg-surface px-4 py-2 text-sm text-white/90 transition hover:border-white/30 hover:bg-white/10"
          >
            {item.title}
          </Link>
        ))}
      </div>
    </section>
  );
}

export default async function MoodsPage() {
  let moodShelves: Shelf[] = [];
  let exploreShelves: Shelf[] = [];
  let error: string | null = null;
  try {
    [moodShelves, exploreShelves] = await Promise.all([getMoodsAndGenres(), getExplore()]);
  } catch (caught) {
    error = (caught as Error).message;
  }

  const exploreWithoutMoods = exploreShelves.filter((shelf) => !/moods/i.test(shelf.title));

  return (
    <div>
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Explore</p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">Moods &amp; genres</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Browse playlists picked by YouTube Music for a mood or a genre. Open one and press play — the queue
          follows you into the app on your phone.
        </p>
      </header>

      {error ? (
        <p className="rounded-xl border border-accent/30 bg-accent/10 p-4 text-sm text-white/80">{error}</p>
      ) : null}

      {moodShelves.map((shelf, index) => (
        <GenreShelf key={`mood-${shelf.title}-${index}`} shelf={shelf} />
      ))}

      {exploreWithoutMoods.map((shelf, index) => (
        <section key={`explore-${shelf.title}-${index}`} className="mb-10">
          <h2 className="mb-4 text-xl font-bold text-white">{shelf.title}</h2>
          <CardGrid items={shelf.items} />
        </section>
      ))}
    </div>
  );
}
