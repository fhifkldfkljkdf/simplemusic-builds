package com.maxrave.simpmusic.ui.screen.other

import com.maxrave.simpmusic.ui.theme.appCorner
import com.maxrave.simpmusic.ui.component.ThemedIcon
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.kyant.backdrop.highlight.Highlight
import com.maxrave.common.Config
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.data.model.home.Content
import com.maxrave.domain.data.model.searchResult.songs.Artist
import com.maxrave.domain.mediaservice.handler.PlaylistType
import com.maxrave.domain.mediaservice.handler.QueueData
import com.maxrave.domain.utils.toSongEntity
import com.maxrave.simpmusic.expect.shareUrl
import com.maxrave.simpmusic.expect.ui.MediaPlayerView
import com.maxrave.simpmusic.expect.ui.layerBackdrop
import com.maxrave.simpmusic.expect.ui.rememberBackdrop
import com.maxrave.simpmusic.expect.ui.toImageBitmap
import com.maxrave.simpmusic.extension.artworkScrimBrush
import com.maxrave.simpmusic.extension.barBlurStyle
import com.maxrave.simpmusic.extension.getColorFromPalette
import com.maxrave.simpmusic.extension.getScreenSizeInfo
import com.maxrave.simpmusic.extension.getStringBlocking
import com.maxrave.simpmusic.extension.hexToColorOrNull
import com.maxrave.simpmusic.extension.rgbFactor
import com.maxrave.simpmusic.extension.rememberPaletteColor
import com.maxrave.simpmusic.extension.toSquareThumbnailUrl
import com.maxrave.simpmusic.ui.component.AddToPlaylistModalBottomSheet
import com.maxrave.simpmusic.ui.component.CenterLoadingBox
import com.maxrave.simpmusic.ui.component.rememberHolderPainter
import com.maxrave.simpmusic.ui.component.DescriptionView
import com.maxrave.simpmusic.ui.component.EndOfPage
import com.maxrave.simpmusic.ui.component.HomeItemArtist
import com.maxrave.simpmusic.ui.component.HomeItemContentPlaylist
import com.maxrave.simpmusic.ui.component.HomeItemVideo
import com.maxrave.simpmusic.ui.component.LiquidGlassIconButton
import com.maxrave.simpmusic.ui.component.NowPlayingBottomSheet
import com.maxrave.simpmusic.ui.component.SongFullWidthItems
import com.maxrave.simpmusic.ui.component.liquidGlass
import com.maxrave.simpmusic.ui.component.selection.SelectedSongsBottomSheet
import com.maxrave.simpmusic.ui.component.selection.SongSelectionState
import com.maxrave.simpmusic.ui.component.selection.SongSelectionTopAppBar
import com.maxrave.simpmusic.ui.component.selection.rememberSongSelectionState
import com.maxrave.simpmusic.ui.icon.ArrowBackIosNew
import com.maxrave.simpmusic.ui.icon.Check
import com.maxrave.simpmusic.ui.icon.IosShare
import com.maxrave.simpmusic.ui.icon.Movie
import com.maxrave.simpmusic.ui.icon.MovieOff
import com.maxrave.simpmusic.ui.icon.PersonAdd
import com.maxrave.simpmusic.ui.icon.Sensors
import com.maxrave.simpmusic.ui.icon.Shuffle
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.navigation.destination.library.LibraryDynamicPlaylistDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.AlbumDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.ArtistDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.MoreAlbumsDestination
import com.maxrave.simpmusic.ui.navigation.destination.list.PlaylistDestination
import com.maxrave.simpmusic.ui.screen.library.LibraryDynamicPlaylistType
import com.maxrave.simpmusic.ui.theme.typo
import com.maxrave.simpmusic.viewModel.ArtistScreenState
import com.maxrave.simpmusic.viewModel.ArtistViewModel
import com.maxrave.simpmusic.viewModel.SharedViewModel
import com.maxrave.simpmusic.viewModel.SongSelectionViewModel
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.pluralStringResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.albums
import simpmusic.composeapp.generated.resources.baseline_favorite_24
import simpmusic.composeapp.generated.resources.description
import simpmusic.composeapp.generated.resources.error
import simpmusic.composeapp.generated.resources.featured_inArtist
import simpmusic.composeapp.generated.resources.liked_songs
import simpmusic.composeapp.generated.resources.liked_songs_by
import simpmusic.composeapp.generated.resources.liked_songs_count
import simpmusic.composeapp.generated.resources.more
import simpmusic.composeapp.generated.resources.no_description
import simpmusic.composeapp.generated.resources.popular
import simpmusic.composeapp.generated.resources.related_artists
import simpmusic.composeapp.generated.resources.share
import simpmusic.composeapp.generated.resources.singles
import simpmusic.composeapp.generated.resources.unknown
import simpmusic.composeapp.generated.resources.videos

@Composable
@ExperimentalMaterial3Api
fun ArtistScreen(
    channelId: String,
    viewModel: ArtistViewModel = koinViewModel(),
    sharedViewModel: SharedViewModel = koinInject(),
    navController: NavController,
) {
    val artistScreenState by viewModel.artistScreenState.collectAsStateWithLifecycle()
    val isFollowed by viewModel.followed.collectAsStateWithLifecycle()
    val artistMotion by viewModel.artistMotion.collectAsStateWithLifecycle()
    // Header plays the artist's animated artwork by default; the top-right toggle swaps it for
    // their picture. Keyed on the channel, so opening a different artist starts as video again —
    // keyed on a url it would not reset between two artists whose videos are both absent.
    var showHeaderVideo by rememberSaveable(channelId) { mutableStateOf(true) }
    val shareTitle = stringResource(Res.string.share)
    val artistLogo by viewModel.artistLogo.collectAsStateWithLifecycle()

    val playingTrack by remember {
        sharedViewModel.nowPlayingState.map { it?.track?.videoId }
    }.collectAsState(null)

    // Choosing song to show Bottom sheet
    var choosingTrack by remember {
        mutableStateOf<Track?>(null)
    }
    var showBottomSheet by remember {
        mutableStateOf(false)
    }

    val selectionState = rememberSongSelectionState()
    val selectionViewModel: SongSelectionViewModel = koinViewModel()
    var showSelectionSheet by rememberSaveable { mutableStateOf(false) }
    var showSelectionAddToPlaylist by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(channelId) {
        if (channelId != artistScreenState.data.channelId) {
            viewModel.browseArtist(channelId)
        }
    }

    // Apple Music-inspired immersive treatment. The header adapts to the window's aspect ratio
    // alone, not to the platform: a portrait window keeps the square artwork frame, a landscape
    // one (including every desktop window) uses a half-viewport-tall frame instead.
    val screenInfo = getScreenSizeInfo()
    val isPortrait = screenInfo.wDP < screenInfo.hDP
    // Apple Music publishes no tall cut for an artist, so the square rendition fills the square
    // portrait frame and the wide one the banner-shaped landscape frame. Each stands in for the
    // other when it is missing on its own: a rendition of the wrong shape still beats no video.
    val headerVideoUrl =
        artistMotion
            ?.let {
                if (isPortrait) {
                    it.squareVideoUrl ?: it.wideVideoUrl
                } else {
                    it.wideVideoUrl ?: it.squareVideoUrl
                }
            }?.takeIf { showHeaderVideo }

    // Palette extraction from the artist artwork (portrait Apple-style only).
    val paletteState = com.kmpalette.rememberPaletteState()
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    var paletteGeneratedFor by remember { mutableStateOf<String?>(null) }
    val currentImageUrl = (artistScreenState as? ArtistScreenState.Success)?.data?.imageUrl

    LaunchedEffect(bitmap) {
        val bm = bitmap
        if (bm != null && currentImageUrl != null && paletteGeneratedFor != currentImageUrl) {
            paletteState.generate(bm)
            paletteGeneratedFor = currentImageUrl
        }
    }

    // Apple Music-style page background from the artwork's dominant tone, held and faded (see UIExt.rememberPaletteColor).
    val mutedPaletteBg = rememberPaletteColor(paletteState.palette)
    // Tint for the description card, matching the non-portrait CollapsingToolbar color.
    val sectionTint = rememberPaletteColor(paletteState.palette) { it.getColorFromPalette() }

    // Accent color for the action buttons, sourced from the artist name-logo image's dominant
    // color (hidden catalog). Falls back to white until the logo loads (or if none exists), and
    // fades to the logo's colour instead of snapping when it does.
    val artistAccent by animateColorAsState(
        targetValue = artistLogo?.bgColorHex?.hexToColorOrNull() ?: Color.White,
        animationSpec = tween(500),
        label = "artistAccent",
    )

    val hazeState = rememberHazeState()
    val lazyState = rememberLazyListState()
    val firstItemVisible by remember {
        derivedStateOf { lazyState.firstVisibleItemIndex == 0 }
    }
    var shouldHideTopBar by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(firstItemVisible) {
        shouldHideTopBar = !firstItemVisible
    }

    Crossfade(artistScreenState) { state ->
        when (state) {
            is ArtistScreenState.Loading -> {
                Box(Modifier.fillMaxSize()) {
                    CenterLoadingBox(
                        Modifier
                            .align(Alignment.Center),
                    )
                }
            }

            is ArtistScreenState.Success -> {
                // ---- Apple Music style (mobile portrait only) ----
                Box(Modifier.fillMaxSize()) {
                    LazyColumn(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .background(mutedPaletteBg)
                                .hazeSource(hazeState),
                        state = lazyState,
                    ) {
                        item(contentType = "header") {
                            Column(
                                // Negative spacing pulls the action row up into the header AND
                                // shrinks the layout, so there's no leftover gap before "Popular"
                                // (unlike Modifier.offset, which only moves pixels, not layout).
                                verticalArrangement = Arrangement.spacedBy((-36).dp),
                            ) {
                                // Edge-to-edge artwork (the artist's video plays on top of it when available).
                                // Glass back button MUST be a sibling of the backdrop source
                                // (not a child) to avoid render feedback loop / RuntimeShader crash.
                                val artworkBackdrop = rememberBackdrop(Color.Black)
                                // Portrait fills a SQUARE frame, so the URL is clamped to a square
                                // size there (logic from commit 5e596c5b). Landscape keeps YouTube's
                                // own wide banner (e.g. w2880-h1200) instead: squaring the source
                                // first would make the Crop below throw away most of its height.
                                val headerImageUrl =
                                    state.data.imageUrl?.let {
                                        if (isPortrait) it.toSquareThumbnailUrl() else it
                                    }
                                Box(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .then(
                                                if (isPortrait) {
                                                    Modifier.aspectRatio(1f)
                                                } else {
                                                    // The banner's own shape, so it is shown whole instead of
                                                    // cropped into a fixed hDP/2 strip. 2.4:1 (YouTube's
                                                    // w2880-h1200) until it decodes; a square bitmap left over
                                                    // from portrait is ignored so the frame never goes square.
                                                    Modifier.aspectRatio(
                                                        bitmap?.takeIf { it.width > it.height }?.let { it.width.toFloat() / it.height } ?: 2.4f,
                                                    )
                                                },
                                            ),
                                ) {
                                    // Inner Box — backdrop SOURCE (artwork + video + overlays, NO glass)
                                    Box(modifier = Modifier.fillMaxSize().clipToBounds().layerBackdrop(artworkBackdrop)) {
                                        // Media layer (video + artwork). The video draws a black shutter
                                        // until its first frame, so the artwork stays ON TOP of it until
                                        // then and only fades out after — hiding the artwork the moment the
                                        // video's url arrived flashed the header black.
                                        Box(modifier = Modifier.fillMaxSize()) {
                                            var videoShown by remember(headerVideoUrl) { mutableStateOf(false) }
                                            val artworkAlpha by animateFloatAsState(
                                                targetValue = if (headerVideoUrl != null && videoShown) 0f else 1f,
                                                animationSpec = tween(500),
                                                label = "artistArtworkOverVideo",
                                            )
                                            // The artist's animated artwork plays AS the background when
                                            // there is one; otherwise the static artwork above shows.
                                            headerVideoUrl?.let { videoUrl ->
                                                // cropToBounds center scale-to-covers it into the header
                                                // frame (ContentScale.Crop): true video aspect ratio, no
                                                // stretch, overflow clipped — which is what absorbs the
                                                // difference between the rendition and the frame.
                                                MediaPlayerView(
                                                    url = videoUrl,
                                                    modifier = Modifier.fillMaxSize(),
                                                    cropToBounds = true,
                                                    onFirstFrame = { videoShown = true },
                                                )
                                            }
                                            AsyncImage(
                                                model =
                                                    ImageRequest
                                                        .Builder(LocalPlatformContext.current)
                                                        .data(headerImageUrl)
                                                        .diskCachePolicy(CachePolicy.ENABLED)
                                                        .memoryCachePolicy(CachePolicy.ENABLED)
                                                        .diskCacheKey(headerImageUrl)
                                                        .memoryCacheKey(headerImageUrl)
                                                        .crossfade(550)
                                                        .build(),
                                                placeholder = rememberHolderPainter(),
                                                error = rememberHolderPainter(),
                                                contentDescription = null,
                                                // FillWidth fits the square source into the square portrait
                                                // frame. The landscape frame takes the banner's own aspect,
                                                // so Crop trims nothing once it has decoded.
                                                contentScale =
                                                    if (isPortrait) ContentScale.FillWidth else ContentScale.Crop,
                                                // Always decoded so the page background color can be extracted
                                                // from the artwork palette, even when the video is playing.
                                                onSuccess = {
                                                    bitmap = it.result.image.toImageBitmap()
                                                },
                                                // Faded out (but still decoded above) once the video has drawn
                                                // its first frame. No video -> artwork is shown.
                                                modifier =
                                                    Modifier
                                                        .fillMaxSize()
                                                        .graphicsLayer { alpha = artworkAlpha },
                                            )
                                            // The artwork's bottom 200dp melts into the page through a
                                            // Modifier.blur copy of it, faded in by a DstIn gradient. At
                                            // the top of the ramp the copy is fully transparent, so there
                                            // is no seam — haze's HazeProgressive drew a visible line
                                            // there on Android (and crashes on skiko). Below Android 12
                                            // blur is a no-op and the copy is pixel-identical to the
                                            // artwork, leaving just the colour scrim. Fades with the
                                            // artwork, and is dropped once the video has taken over.
                                            if (artworkAlpha > 0f) {
                                                AsyncImage(
                                                    model =
                                                        ImageRequest
                                                            .Builder(LocalPlatformContext.current)
                                                            .data(headerImageUrl)
                                                            .crossfade(550)
                                                            .build(),
                                                    contentDescription = null,
                                                    contentScale =
                                                        if (isPortrait) ContentScale.FillWidth else ContentScale.Crop,
                                                    modifier =
                                                        Modifier
                                                            .fillMaxSize()
                                                            .graphicsLayer {
                                                                compositingStrategy = CompositingStrategy.Offscreen
                                                                alpha = artworkAlpha
                                                            }.drawWithContent {
                                                                drawContent()
                                                                drawRect(
                                                                    brush =
                                                                        Brush.verticalGradient(
                                                                            colors = listOf(Color.Transparent, Color.Black),
                                                                            startY = size.height - 200.dp.toPx(),
                                                                            endY = size.height,
                                                                        ),
                                                                    blendMode = BlendMode.DstIn,
                                                                )
                                                            }.blur(32.dp),
                                                )
                                            }
                                        } // end media layer
                                        // 5% black over the artwork/video, under the fade and scrim, so
                                        // a bright photo sits back a little behind the title.
                                        Box(
                                            modifier =
                                                Modifier
                                                    .fillMaxSize()
                                                    .background(Color.Black.copy(alpha = 0.05f)),
                                        )
                                        // Color scrim is a SEPARATE, taller box: the blur stays at 200dp so
                                        // its cost doesn't grow, while the color gets 70% of the artwork
                                        // to ramp over. A short ramp means a steep alpha, and a steep
                                        // alpha is what reads as a visible edge. 70% of the frame's own
                                        // height in both orientations — measured off the frame, since the
                                        // landscape one now follows the banner rather than the window.
                                        Box(
                                            modifier =
                                                Modifier
                                                    .fillMaxWidth()
                                                    .fillMaxHeight(0.7f)
                                                    .align(Alignment.BottomCenter)
                                                    .background(artworkScrimBrush(mutedPaletteBg)),
                                        )
                                        // Artist name (TEXT for now — logo image is roadmap) + subscriber · view
                                        Column(
                                            modifier =
                                                Modifier
                                                    .align(Alignment.BottomCenter)
                                                    // Lift the name + subtitle together with the action row.
                                                    .offset(y = (-36).dp)
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 20.dp)
                                                    .padding(bottom = 16.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                        ) {
                                            val logo = artistLogo
                                            // The name stays as text until the logo image has actually
                                            // loaded, then the two cross-fade and the box eases to the
                                            // logo's height. Swapping on the logo's url alone blanked the
                                            // line until the image arrived and then popped it in. Saveable,
                                            // so coming back to the page shows the logo straight away.
                                            var logoLoaded by rememberSaveable(logo?.logoUrl) { mutableStateOf(false) }
                                            val logoAlpha by animateFloatAsState(
                                                targetValue = if (logo != null && logoLoaded) 1f else 0f,
                                                animationSpec = tween(500),
                                                label = "artistNameLogo",
                                            )
                                            Box(
                                                modifier = Modifier.fillMaxWidth().animateContentSize(),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                if (logoAlpha < 1f) {
                                                    Text(
                                                        text = state.data.title ?: stringResource(Res.string.unknown),
                                                        style = typo().titleLarge,
                                                        color = Color.White,
                                                        maxLines = 2,
                                                        textAlign = TextAlign.Center,
                                                        modifier = Modifier.graphicsLayer { alpha = 1f - logoAlpha },
                                                    )
                                                }
                                                if (logo != null) {
                                                    // Artist name rendered as a logo image (hidden catalog),
                                                    // in place of the plain-text title.
                                                    AsyncImage(
                                                        model = logo.logoUrl,
                                                        contentDescription = state.data.title,
                                                        contentScale = ContentScale.Fit,
                                                        onSuccess = { logoLoaded = true },
                                                        modifier =
                                                            Modifier
                                                                .fillMaxWidth(0.7f)
                                                                .heightIn(max = 84.dp)
                                                                .graphicsLayer { alpha = logoAlpha },
                                                    )
                                                }
                                            }
                                            val meta =
                                                listOfNotNull(
                                                    state.data.subscribers?.takeIf { it.isNotBlank() },
                                                    state.data.playCount?.takeIf { it.isNotBlank() },
                                                ).joinToString(" · ")
                                            if (meta.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = meta,
                                                    style = typo().bodyMedium,
                                                    color = Color(0xC4FFFFFF),
                                                    textAlign = TextAlign.Center,
                                                )
                                            }
                                        }
                                    }
                                    // Back button — liquid glass, sibling of the backdrop source.
                                    LiquidGlassIconButton(
                                        backdrop = artworkBackdrop,
                                        imageVector = SimpIcons.ArrowBackIosNew,
                                        shape = appCorner(24.dp),
                                        // Matching the other three headers: the pill-style directional rim, thickened
                                        // from the 0.5.dp default so it stays visible around a 48dp circle.
                                        highlight = Highlight(width = 1.dp),
                                        modifier =
                                            Modifier
                                                .align(Alignment.TopStart)
                                                .padding(12.dp)
                                                .windowInsetsPadding(WindowInsets.statusBars)
                                                .size(48.dp),
                                    ) {
                                        navController.navigateUp()
                                    }
                                    // Top-right pill mirroring the back button, shaped like the
                                    // Playlist header's: [video ⇄ picture] when the artist has an animated
                                    // artwork, then share. A sibling of the backdrop source, like the back button.
                                    Row(
                                        modifier =
                                            Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(12.dp)
                                                .windowInsetsPadding(WindowInsets.statusBars)
                                                .height(48.dp)
                                                .liquidGlass(artworkBackdrop, appCorner(24.dp)),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        if (artistMotion != null) {
                                            IconButton(onClick = { showHeaderVideo = !showHeaderVideo }) {
                                                ThemedIcon(
                                                    imageVector = if (showHeaderVideo) SimpIcons.MovieOff else SimpIcons.Movie,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                )
                                            }
                                        }
                                        IconButton(
                                            onClick = { shareUrl(shareTitle, "https://music.youtube.com/channel/$channelId") },
                                        ) {
                                            ThemedIcon(SimpIcons.IosShare, contentDescription = shareTitle, tint = Color.White)
                                        }
                                    }
                                }

                                // Apple Music-style action row: [Radio][Shuffle pill][Follow] centered.
                                // In SimpMusic "play" an artist == shuffle, so the big middle button is Shuffle.
                                Row(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 32.dp)
                                            .padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    // Radio — side button: outlined accent (yellow) circle with an
                                    // accent-tinted icon over a transparent fill, matching the reference.
                                    Box(
                                        modifier =
                                            Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .border(1.5.dp, artistAccent, CircleShape)
                                                .clickable {
                                                    val param = state.data.radioParam
                                                    if (param != null) {
                                                        viewModel.onRadioClick(param)
                                                    } else {
                                                        viewModel.makeToast(runBlocking { getString(Res.string.error) })
                                                    }
                                                },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        ThemedIcon(
                                            imageVector = SimpIcons.Sensors,
                                            contentDescription = "Radio",
                                            tint = artistAccent,
                                            modifier = Modifier.size(22.dp),
                                        )
                                    }
                                    // Shuffle — primary "play" for an artist. Circular icon button filled
                                    // with the artist accent (white fallback); icon uses the dark page
                                    // background color so it stays legible on a bright accent.
                                    Box(
                                        modifier =
                                            Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .background(artistAccent)
                                                .clickable {
                                                    val param = state.data.shuffleParam
                                                    if (param != null) {
                                                        viewModel.onShuffleClick(param)
                                                    } else {
                                                        viewModel.makeToast(runBlocking { getString(Res.string.error) })
                                                    }
                                                },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        ThemedIcon(
                                            imageVector = SimpIcons.Shuffle,
                                            contentDescription = "Shuffle",
                                            tint = mutedPaletteBg,
                                            modifier = Modifier.size(28.dp),
                                        )
                                    }
                                    // Follow — side button matching Radio: outlined accent (yellow)
                                    // circle when not following; fills with the accent (icon flips to
                                    // the dark page bg) once followed, so the state reads at a glance.
                                    Box(
                                        modifier =
                                            Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(if (isFollowed) artistAccent else Color.Transparent)
                                                .border(1.5.dp, artistAccent, CircleShape)
                                                .clickable {
                                                    viewModel.updateFollowed(
                                                        if (isFollowed) 0 else 1,
                                                        state.data.channelId ?: return@clickable,
                                                    )
                                                },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        ThemedIcon(
                                            imageVector = if (isFollowed) SimpIcons.Check else SimpIcons.PersonAdd,
                                            contentDescription = if (isFollowed) "Followed" else "Follow",
                                            tint = if (isFollowed) mutedPaletteBg else artistAccent,
                                            modifier = Modifier.size(22.dp),
                                        )
                                    }
                                }
                            }
                        }
                        item(contentType = "sections") {
                            ArtistSections(
                                channelId = channelId,
                                state = state,
                                selectionState = selectionState,
                                playingTrack = playingTrack,
                                descriptionTint = sectionTint,
                                navController = navController,
                                viewModel = viewModel,
                                sharedViewModel = sharedViewModel,
                                onTrackMore = { track ->
                                    choosingTrack = track
                                    showBottomSheet = true
                                },
                            )
                        }
                    }

                    // Haze top bar appears once the header scrolls away.
                    AnimatedVisibility(
                        visible = shouldHideTopBar && !selectionState.isActive,
                        enter = fadeIn() + slideInVertically(),
                        exit = fadeOut() + slideOutVertically(),
                    ) {
                        TopAppBar(
                            title = {
                                Text(
                                    text = state.data.title ?: "",
                                    style = typo().titleMedium,
                                    maxLines = 1,
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .wrapContentHeight(align = Alignment.CenterVertically)
                                            .basicMarquee(
                                                iterations = Int.MAX_VALUE,
                                                animationMode = MarqueeAnimationMode.Immediately,
                                            ).focusable(),
                                )
                            },
                            navigationIcon = {
                                Box(Modifier.padding(horizontal = 5.dp)) {
                                    IconButton(onClick = { navController.navigateUp() }) {
                                        ThemedIcon(
                                            imageVector = SimpIcons.ArrowBackIosNew,
                                            contentDescription = "Back",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp),
                                        )
                                    }
                                }
                            },
                            colors =
                                TopAppBarDefaults.topAppBarColors(
                                    containerColor = Color.Transparent,
                                ),
                            modifier =
                                Modifier.hazeBlur(HazeInput.Sources(hazeState), barBlurStyle(mutedPaletteBg, 0.55f)),
                        )
                    }
                }

                AnimatedVisibility(
                    visible = selectionState.isActive,
                    enter = fadeIn() + slideInVertically(),
                    exit = fadeOut() + slideOutVertically(),
                ) {
                    SongSelectionTopAppBar(
                        state = selectionState,
                        onSelectAll = {
                            selectionState.toggleSelectAll(
                                (artistScreenState as? ArtistScreenState.Success)
                                    ?.data
                                    ?.popularSongs
                                    ?.map { it.videoId }
                                    ?: emptyList(),
                            )
                        },
                        onOpenActions = { showSelectionSheet = true },
                        containerColor = Color.Black,
                    )
                }
                if (showSelectionSheet) {
                    val selectedIds = selectionState.selected.toList()
                    SelectedSongsBottomSheet(
                        count = selectedIds.size,
                        onDismiss = { showSelectionSheet = false },
                        onPlayNext = {
                            selectionViewModel.playNext(selectedIds)
                            selectionState.exit()
                        },
                        onAddToQueue = {
                            selectionViewModel.addToQueue(selectedIds)
                            selectionState.exit()
                        },
                        onAddToPlaylist = { showSelectionAddToPlaylist = true },
                        onDownload = {
                            selectionViewModel.download(selectedIds)
                            selectionState.exit()
                        },
                        onAddToFavorite = {
                            selectionViewModel.addToFavorite(selectedIds)
                            selectionState.exit()
                        },
                    )
                }
                if (showSelectionAddToPlaylist) {
                    val selectedIds = selectionState.selected.toList()
                    val localPlaylists by selectionViewModel.listLocalPlaylist.collectAsStateWithLifecycle()
                    AddToPlaylistModalBottomSheet(
                        isBottomSheetVisible = true,
                        listLocalPlaylist = localPlaylists,
                        listYouTubePlaylist = emptyList(),
                        onDismiss = { showSelectionAddToPlaylist = false },
                        onClick = { playlist ->
                            selectionViewModel.addToPlaylist(playlist.id, selectedIds)
                            selectionState.exit()
                        },
                        onYTPlaylistClick = {},
                    )
                }
                if (showBottomSheet && choosingTrack != null) {
                    NowPlayingBottomSheet(
                        onDismiss = {
                            showBottomSheet = false
                            choosingTrack = null
                        },
                        navController = navController,
                        song = choosingTrack?.toSongEntity(),
                    )
                }
            }

            is ArtistScreenState.Error -> {
                viewModel.makeToast(state.message ?: stringResource(Res.string.error))
                navController.navigateUp()
            }
        }
    }
}

/**
 * Shared artist body (Popular → Description). Used by both the portrait Apple-Music layout
 * and the existing CollapsingToolbar layout, so the sections themselves stay untouched.
 */
@Composable
private fun ArtistSections(
    channelId: String,
    state: ArtistScreenState.Success,
    selectionState: SongSelectionState,
    playingTrack: String?,
    descriptionTint: Color,
    navController: NavController,
    viewModel: ArtistViewModel,
    sharedViewModel: SharedViewModel,
    onTrackMore: (Track) -> Unit,
) {
    val likedSongCount by viewModel.likedSongCount.collectAsStateWithLifecycle()
    Column {
        // Liked songs by this artist (issue #2524), shaped like Spotify's section: a heading, then
        // the artist's picture wearing the liked heart beside the count. Shown only once at least
        // one song is liked; opens the full list with the route's channelId, the id it was counted by.
        androidx.compose.animation.AnimatedVisibility(likedSongCount > 0) {
            LikedSongsSection(
                imageUrl = state.data.imageUrl?.toSquareThumbnailUrl(),
                count = likedSongCount,
                artistName = state.data.title.orEmpty(),
                onClick = {
                    navController.navigate(
                        LibraryDynamicPlaylistDestination(
                            type = LibraryDynamicPlaylistType.ArtistLiked(channelId).toStringParams(),
                        ),
                    )
                },
            )
        }

        // Popular Songs
        AnimatedVisibility(state.data.popularSongs.isNotEmpty()) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(Res.string.popular),
                        style = typo().labelMedium,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = {
                            val id = state.data.listSongParam
                            if (id != null) {
                                navController.navigate(PlaylistDestination(id))
                            } else {
                                viewModel.makeToast(runBlocking { getString(Res.string.error) })
                            }
                        },
                        colors =
                            ButtonDefaults
                                .textButtonColors()
                                .copy(
                                    contentColor = Color.White,
                                ),
                    ) {
                        Text(stringResource(Res.string.more), style = typo().bodySmall)
                    }
                }
                state.data.popularSongs.forEach { song ->
                    SongFullWidthItems(
                        forceDark = true,                        track = song,
                        isPlaying = song.videoId == playingTrack,
                        modifier = Modifier.fillMaxWidth(),
                        onMoreClickListener = {
                            onTrackMore(song)
                        },
                        onClickListener = {
                            val firstQueue: Track = song
                            viewModel.setQueueData(
                                QueueData.Data(
                                    listTracks = arrayListOf(firstQueue),
                                    firstPlayedTrack = firstQueue,
                                    playlistId = "RDAMVM${song.videoId}",
                                    playlistName = "\"${state.data.title ?: ""}\" ${getStringBlocking(Res.string.popular)}",
                                    playlistType = PlaylistType.RADIO,
                                    continuation = null,
                                ),
                            )
                            viewModel.loadMediaItem(
                                firstQueue,
                                type = Config.SONG_CLICK,
                            )
                        },
                        onAddToQueue = {
                            sharedViewModel.addListToQueue(
                                arrayListOf(song),
                            )
                        },
                        selectionMode = selectionState.isActive,
                        isSelected = selectionState.isSelected(song.videoId),
                        onLongClick = { selectionState.start(it) },
                        onSelectToggle = { selectionState.toggle(it) },
                    )
                }
            }
        }

        // Singles
        AnimatedVisibility(
            state.data.singles != null &&
                state.data.singles!!
                    .results
                    .isNotEmpty(),
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(Res.string.singles),
                        style = typo().labelMedium,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = {
                            if (state.data.channelId != null) {
                                val id = "MPAD${state.data.channelId}"
                                navController.navigate(
                                    MoreAlbumsDestination(
                                        id = id,
                                        type = MoreAlbumsDestination.SINGLE_TYPE,
                                    ),
                                )
                            } else {
                                viewModel.makeToast(getStringBlocking(Res.string.error))
                            }
                        },
                        colors =
                            ButtonDefaults
                                .textButtonColors()
                                .copy(
                                    contentColor = Color.White,
                                ),
                    ) {
                        Text(stringResource(Res.string.more), style = typo().bodySmall)
                    }
                }
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                    items(state.data.singles?.results ?: emptyList()) { single ->
                        HomeItemContentPlaylist(
                            forceDark = true,                            onClick = {
                                navController.navigate(
                                    AlbumDestination(
                                        single.browseId,
                                    ),
                                )
                            },
                            data = single,
                            thumbSize = 180.dp,
                        )
                    }
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                }
            }
        }

        // Albums
        AnimatedVisibility(
            state.data.albums != null &&
                state.data.albums!!
                    .results
                    .isNotEmpty(),
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(Res.string.albums),
                        style = typo().labelMedium,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = {
                            if (state.data.channelId != null) {
                                val id = "MPAD${state.data.channelId}"
                                navController.navigate(
                                    MoreAlbumsDestination(
                                        id = id,
                                        type = MoreAlbumsDestination.ALBUM_TYPE,
                                    ),
                                )
                            } else {
                                viewModel.makeToast(getStringBlocking(Res.string.error))
                            }
                        },
                        colors =
                            ButtonDefaults
                                .textButtonColors()
                                .copy(
                                    contentColor = Color.White,
                                ),
                    ) {
                        Text(stringResource(Res.string.more), style = typo().bodySmall)
                    }
                }
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                    items(state.data.albums?.results ?: emptyList()) { album ->
                        HomeItemContentPlaylist(
                            forceDark = true,                            onClick = {
                                navController.navigate(
                                    AlbumDestination(
                                        browseId = album.browseId,
                                    ),
                                )
                            },
                            data = album,
                            thumbSize = 180.dp,
                        )
                    }
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                }
            }
        }

        // Videos
        AnimatedVisibility(
            state.data.video != null &&
                state.data.video!!
                    .video
                    .isNotEmpty(),
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(Res.string.videos),
                        style = typo().labelMedium,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = {
                            val videoListParam = state.data.video?.videoListParam
                            if (videoListParam != null) {
                                navController.navigate(
                                    PlaylistDestination(
                                        videoListParam,
                                    ),
                                )
                            } else {
                                viewModel.makeToast(getStringBlocking(Res.string.error))
                            }
                        },
                        colors =
                            ButtonDefaults
                                .textButtonColors()
                                .copy(
                                    contentColor = Color.White,
                                ),
                    ) {
                        Text(stringResource(Res.string.more), style = typo().bodySmall)
                    }
                }
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                    items(state.data.video?.video ?: emptyList()) { video ->
                        HomeItemVideo(
                            forceDark = true,                            onClick = {
                                val firstQueue: Track = video
                                viewModel.setQueueData(
                                    QueueData.Data(
                                        listTracks = arrayListOf(firstQueue),
                                        firstPlayedTrack = firstQueue,
                                        playlistId = "RDAMVM${video.videoId}",
                                        playlistName = (state.data.title ?: "") + getStringBlocking(Res.string.videos),
                                        playlistType = PlaylistType.RADIO,
                                        continuation = null,
                                    ),
                                )
                                viewModel.loadMediaItem(
                                    firstQueue,
                                    type = Config.VIDEO_CLICK,
                                )
                            },
                            onLongClick = {
                                onTrackMore(video)
                            },
                            data =
                                Content(
                                    album = null,
                                    artists = video.artists,
                                    description = null,
                                    isExplicit = video.isExplicit,
                                    playlistId = null,
                                    browseId = null,
                                    thumbnails = video.thumbnails ?: emptyList(),
                                    title = video.title,
                                    videoId = video.videoId,
                                    views = video.views,
                                ),
                        )
                    }
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                }
            }
        }

        // Feature on
        AnimatedVisibility(state.data.featuredOn.isNotEmpty()) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(Res.string.featured_inArtist),
                        style = typo().labelMedium,
                        color = Color.White,
                        modifier =
                            Modifier
                                .weight(1f)
                                .padding(vertical = 10.dp),
                    )
                }
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                    items(state.data.featuredOn) { feature ->
                        HomeItemContentPlaylist(
                            forceDark = true,                            onClick = {
                                navController.navigate(
                                    PlaylistDestination(
                                        feature.id,
                                    ),
                                )
                            },
                            data = feature,
                            thumbSize = 180.dp,
                        )
                    }
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                }
            }
        }

        // Related
        AnimatedVisibility(
            state.data.related != null &&
                state.data.related!!
                    .results
                    .isNotEmpty(),
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(Res.string.related_artists),
                        style = typo().labelMedium,
                        color = Color.White,
                        modifier =
                            Modifier
                                .weight(1f)
                                .padding(vertical = 10.dp),
                    )
                }
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                    items(state.data.related?.results ?: emptyList()) { related ->
                        HomeItemArtist(
                            forceDark = true,                            onClick = {
                                navController.navigate(
                                    ArtistDestination(
                                        channelId = related.browseId,
                                    ),
                                )
                            },
                            data =
                                Content(
                                    album = null,
                                    artists =
                                        listOf(
                                            Artist(
                                                id = related.browseId,
                                                name = related.title,
                                            ),
                                        ),
                                    description = related.subscribers,
                                    isExplicit = null,
                                    playlistId = null,
                                    browseId = related.browseId,
                                    thumbnails = related.thumbnails,
                                    title = related.title,
                                    videoId = null,
                                    views = null,
                                    durationSeconds = null,
                                    radio = null,
                                ),
                        )
                    }
                    item {
                        Spacer(Modifier.size(10.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 20.dp),
        ) {
            Text(
                text = stringResource(Res.string.description),
                style = typo().labelMedium,
                color = Color.White,
                modifier =
                    Modifier
                        .weight(1f)
                        .padding(vertical = 12.dp),
            )
        }
        val urlHandler = LocalUriHandler.current
        ElevatedCard(
            modifier = Modifier.padding(horizontal = 20.dp),
            shape = appCorner(8.dp),
            colors =
                CardDefaults.elevatedCardColors().copy(
                    containerColor = descriptionTint.rgbFactor(0.5f),
                ),
        ) {
            DescriptionView(
                modifier = Modifier.padding(16.dp),
                text = state.data.description ?: stringResource(Res.string.no_description),
                limitLine = 5,
                onTimeClicked = {},
                onURLClicked = { url ->
                    urlHandler.openUri(url)
                },
            )
        }
        EndOfPage()
    }
}

/**
 * "Liked songs" as a section of its own: the heading, then the artist's picture wearing the liked
 * heart beside "3 songs" / "By <artist>". The whole block opens
 * [LibraryDynamicPlaylistType.ArtistLiked]. Heading and text colours follow the sections around it,
 * which draw white on the artwork-tinted page.
 */
@Composable
private fun LikedSongsSection(
    imageUrl: String?,
    count: Int,
    artistName: String,
    onClick: () -> Unit,
) {
    Column {
        // No "More" button beside it, so the padding stands in for the height the TextButton gives
        // the Popular and Singles headings.
        Text(
            text = stringResource(Res.string.liked_songs),
            style = typo().labelMedium,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
                    .padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Box(modifier = Modifier.size(48.dp)) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                )
                Image(
                    painter = painterResource(Res.drawable.baseline_favorite_24),
                    contentDescription = null,
                    modifier =
                        Modifier
                            .align(Alignment.BottomEnd)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .padding(3.dp),
                )
            }
            Column(modifier = Modifier.padding(start = 12.dp)) {
                Text(
                    text = pluralStringResource(Res.plurals.liked_songs_count, count, count),
                    style = typo().titleSmall,
                    color = Color.White,
                    maxLines = 1,
                )
                Text(
                    text = stringResource(Res.string.liked_songs_by, artistName),
                    style = typo().bodySmall,
                    color = Color(0xC4FFFFFF),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
