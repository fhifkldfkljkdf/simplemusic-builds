package com.maxrave.simpmusic.ui.component

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.VectorPainter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.mediaservice.handler.MediaPlayerHandler
import com.maxrave.domain.mediaservice.handler.RadioMix
import com.maxrave.domain.mediaservice.handler.RadioQueueTrim
import com.maxrave.simpmusic.ui.icon.AutoAwesome
import com.maxrave.simpmusic.ui.icon.History
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.AppThemeFamily
import com.maxrave.simpmusic.ui.theme.LocalAppShapes
import com.maxrave.simpmusic.ui.theme.LocalAppThemeFamily
import com.maxrave.simpmusic.ui.theme.typo
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.radio_discovery_familiar
import simpmusic.composeapp.generated.resources.radio_discovery_new
import simpmusic.composeapp.generated.resources.radio_mix
import simpmusic.composeapp.generated.resources.radio_mix_mix
import simpmusic.composeapp.generated.resources.radio_mix_mostly_familiar
import simpmusic.composeapp.generated.resources.radio_mix_mostly_new
import kotlin.math.abs
import kotlin.math.roundToInt

/** The slider moves in tenths, so every stored value is one of 0.0, 0.1 … 1.0 exactly. */
private const val STEPS = 10

private fun Float.toStep(): Int = (coerceIn(0f, 1f) * STEPS).roundToInt()

/** Snaps to a tenth, so 0.8 is stored as the same float [RadioMix] compares against. */
fun Float.snapRadioMix(): Float = toStep() / STEPS.toFloat()

/**
 * Words for a slider position. "New" starts exactly where [RadioMix.startsWithNewOnly] does, so the
 * label never promises only-new songs while Start radio would still mix in known ones.
 */
fun radioMixLabel(discovery: Float): StringResource =
    when (discovery.toStep()) {
        in 8..STEPS -> Res.string.radio_discovery_new
        7 -> Res.string.radio_mix_mostly_new
        in 4..6 -> Res.string.radio_mix_mix
        3 -> Res.string.radio_mix_mostly_familiar
        else -> Res.string.radio_discovery_familiar
    }

@Immutable
data class RadioMixSliderColors(
    /** The filled part runs from [fillStart] at the familiar end to [fillEnd] at the new end. */
    val fillStart: Color,
    val fillEnd: Color,
    /** Icons and stop marks drawn on the filled part. */
    val onFill: Color,
    val track: Color,
    /** Icons and stop marks drawn on the empty part. */
    val onTrack: Color,
    val handle: Color,
    val label: Color,
    val value: Color,
)

object RadioMixSliderDefaults {
    @Composable
    fun colors(): RadioMixSliderColors {
        val surface = rememberSurfaceDarkColors()
        val scheme = MaterialTheme.colorScheme
        return RadioMixSliderColors(
            fillStart = scheme.tertiary,
            fillEnd = scheme.primary,
            onFill = scheme.onPrimary,
            track = surface.content.copy(alpha = 0.10f),
            onTrack = surface.content.copy(alpha = 0.55f),
            handle = surface.content,
            label = surface.subtitle,
            value = surface.content,
        )
    }
}

private val TRACK_HEIGHT = 36.dp
private val HANDLE_HEIGHT = 48.dp
private val HANDLE_WIDTH = 4.dp
private val HANDLE_GAP = 5.dp
private val INNER_CORNER = 3.dp
private val ICON_SIZE = 18.dp
private val ICON_INSET = 11.dp
private val STOP_RADIUS = 2.dp

/** How a theme draws the mix: sharp or rounded ends, a gradient or solid fill, and a blocky
 * Retro track split into its ten steps. */
private data class RadioMixLook(
    val square: Boolean = false,
    val segmented: Boolean = false,
    val solidFill: Boolean = false,
    val pixelIcons: Boolean = false,
    val showStop: Boolean = true,
    val handleWidth: Dp = HANDLE_WIDTH,
)

private fun radioMixLook(family: AppThemeFamily): RadioMixLook =
    when (family) {
        AppThemeFamily.RETRO ->
            RadioMixLook(
                square = true,
                segmented = true,
                pixelIcons = true,
                showStop = false,
                handleWidth = 12.dp,
            )
        AppThemeFamily.AMOLED ->
            RadioMixLook(
                square = true,
                solidFill = true,
                showStop = false,
                handleWidth = 6.dp,
            )
        AppThemeFamily.SPOTIFY ->
            RadioMixLook(
                solidFill = true,
                showStop = false,
                handleWidth = 6.dp,
            )
        AppThemeFamily.APPLE_MUSIC ->
            RadioMixLook(handleWidth = 5.dp)
        AppThemeFamily.OCEAN ->
            RadioMixLook(handleWidth = 5.dp)
        else -> RadioMixLook()
    }

/**
 * How familiar a radio's songs should be: a tall rounded track filled up to a slim handle, a clock
 * at the familiar end and sparkles at the new end, a tick on each step. It is Material's [Slider]
 * underneath, so dragging, tapping, keys and accessibility behave like every other slider.
 *
 * [onValueChange] fires while dragging; commit in [onValueChangeFinished].
 */
@Composable
fun RadioMixSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: RadioMixSliderColors = RadioMixSliderDefaults.colors(),
) {
    val interaction = remember { MutableInteractionSource() }
    val dragged by interaction.collectIsDraggedAsState()
    val pressed by interaction.collectIsPressedAsState()
    val touching = dragged || pressed
    val handleScale by animateFloatAsState(if (touching) 1.12f else 1f, label = "handle")
    val haptics = LocalHapticFeedback.current
    val step = value.toStep()
    val touchingNow by rememberUpdatedState(touching)
    LaunchedEffect(step) {
        if (touchingNow) haptics.performHapticFeedback(HapticFeedbackType.SegmentFrequentTick)
    }
    val stateText = stringResource(radioMixLabel(value))
    val look = radioMixLook(LocalAppThemeFamily.current)
    val handleShape = if (look.square) LocalAppShapes.current.cardSmall else CircleShape
    Slider(
        value = value,
        onValueChange = onValueChange,
        onValueChangeFinished = onValueChangeFinished,
        modifier = modifier.fillMaxWidth().semantics { stateDescription = stateText },
        enabled = enabled,
        interactionSource = interaction,
        steps = STEPS - 1,
        valueRange = 0f..1f,
        thumb = {
            Box(
                Modifier
                    .graphicsLayer {
                        scaleY = handleScale
                        alpha = if (enabled) 1f else 0.38f
                    }.size(width = look.handleWidth, height = HANDLE_HEIGHT)
                    .background(colors.handle, handleShape),
            )
        },
        track = { state -> RadioMixTrack(fraction = state.value, colors = colors, enabled = enabled) },
    )
}

@Composable
private fun RadioMixTrack(
    fraction: Float,
    colors: RadioMixSliderColors,
    enabled: Boolean,
) {
    val look = radioMixLook(LocalAppThemeFamily.current)
    val familiar =
        rememberTrackPainter(
            painter = rememberVectorPainter(SimpIcons.History),
            pixelate = look.pixelIcons,
        )
    val new =
        rememberTrackPainter(
            painter = rememberVectorPainter(SimpIcons.AutoAwesome),
            pixelate = look.pixelIcons,
        )
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(TRACK_HEIGHT)
            .graphicsLayer { alpha = if (enabled) 1f else 0.38f },
    ) {
        val w = size.width
        val h = size.height
        val outer = CornerRadius(if (look.square) 0f else h / 2)
        val inner = CornerRadius(if (look.square) 0f else INNER_CORNER.toPx())
        val gap = HANDLE_GAP.toPx()
        val handleX = fraction.coerceIn(0f, 1f) * w
        val fillEnd = handleX - gap
        val emptyStart = handleX + gap
        if (look.segmented) {
            // Retro: ten hard blocks, not a smooth bar. The blocks left of the handle take the
            // familiar→new gradient; the rest are the empty track. A block under the handle is
            // left out, so the square thumb sits in a clean gap.
            val blockGap = 2.dp.toPx()
            for (i in 0 until STEPS) {
                val start = w * i / STEPS + blockGap / 2f
                val end = w * (i + 1) / STEPS - blockGap / 2f
                if (end <= start || (end > fillEnd && start < emptyStart)) continue
                val blockColor =
                    if (start < fillEnd) {
                        lerp(colors.fillStart, colors.fillEnd, i / (STEPS - 1f))
                    } else {
                        colors.track
                    }
                drawRect(
                    color = blockColor,
                    topLeft = Offset(start, 0f),
                    size = Size(end - start, h),
                )
            }
        } else {
            if (fillEnd > 0f) {
                drawPath(
                    roundedBar(0f, fillEnd, h, left = outer, right = inner),
                    if (look.solidFill) {
                        SolidColor(colors.fillEnd)
                    } else {
                        Brush.horizontalGradient(listOf(colors.fillStart, colors.fillEnd), startX = 0f, endX = w)
                    },
                )
            }
            if (emptyStart < w) {
                drawPath(roundedBar(emptyStart, w, h, left = inner, right = outer), colors.track)
            }
        }
        // The middle, where familiar and new are mixed evenly.
        val middle = w / 2
        val stop = STOP_RADIUS.toPx()
        if (look.showStop && abs(middle - handleX) > gap + stop) {
            drawCircle(
                color = if (middle < fillEnd) colors.onFill.copy(alpha = 0.7f) else colors.onTrack,
                radius = stop,
                center = Offset(middle, h / 2),
            )
        }
        val icon = ICON_SIZE.toPx()
        val inset = ICON_INSET.toPx()
        drawEndIcon(familiar, inset, icon, handleX, gap, fillEnd, colors)
        drawEndIcon(new, w - inset - icon, icon, handleX, gap, fillEnd, colors)
    }
}

@Composable
private fun rememberTrackPainter(
    painter: VectorPainter,
    pixelate: Boolean,
): Painter = if (pixelate) rememberPixelatedPainter(painter) else painter

/** An icon inside the track, left out while the handle's gap runs through it. */
private fun DrawScope.drawEndIcon(
    painter: Painter,
    left: Float,
    iconSize: Float,
    handleX: Float,
    gap: Float,
    fillEnd: Float,
    colors: RadioMixSliderColors,
) {
    if (handleX + gap > left && handleX - gap < left + iconSize) return
    val onFill = left + iconSize <= fillEnd
    translate(left = left, top = (size.height - iconSize) / 2) {
        with(painter) {
            draw(Size(iconSize, iconSize), colorFilter = ColorFilter.tint(if (onFill) colors.onFill else colors.onTrack))
        }
    }
}

private fun roundedBar(
    start: Float,
    end: Float,
    height: Float,
    left: CornerRadius,
    right: CornerRadius,
): Path =
    Path().apply {
        addRoundRect(
            RoundRect(
                left = start,
                top = 0f,
                right = end,
                bottom = height,
                topLeftCornerRadius = left,
                topRightCornerRadius = right,
                bottomRightCornerRadius = right,
                bottomLeftCornerRadius = left,
            ),
        )
    }

/** "Radio mix" with the slider's position in words beside it, sliding as it changes. */
@Composable
fun RadioMixHeader(
    value: Float,
    colors: RadioMixSliderColors,
    modifier: Modifier = Modifier,
    title: String = stringResource(Res.string.radio_mix),
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = typo().bodySmall, color = colors.label, modifier = Modifier.weight(1f))
        AnimatedContent(
            targetState = radioMixLabel(value),
            transitionSpec = {
                (slideInVertically { it / 2 } + fadeIn()) togetherWith (slideOutVertically { -it / 2 } + fadeOut())
            },
            label = "radioMixLabel",
        ) { label ->
            Text(stringResource(label), style = typo().bodySmall.copy(fontWeight = FontWeight.SemiBold), color = colors.value)
        }
    }
}

/**
 * The radio mix where a radio is started or is playing: the same `radio_discovery` value as the
 * slider in Settings. Start radio follows it.
 *
 * [whilePlaying]: shown in a queue — only while the queue is a real YouTube radio (not Favorites or
 * a shuffled playlist, which are queued as radios too), and letting go of the slider rebuilds that
 * radio around the song playing now (which keeps playing), so the change is heard at once rather
 * than a page later.
 */
@Composable
fun RadioMixBar(
    modifier: Modifier = Modifier,
    whilePlaying: Boolean = false,
    colors: RadioMixSliderColors = RadioMixSliderDefaults.colors(),
    dataStoreManager: DataStoreManager = koinInject(),
    mediaPlayerHandler: MediaPlayerHandler = koinInject(),
) {
    val scope = rememberCoroutineScope()
    val stored by dataStoreManager.radioDiscovery.collectAsStateWithLifecycle(initialValue = RadioMix.DEFAULT_DISCOVERY)
    val radioFlow =
        remember(mediaPlayerHandler) {
            mediaPlayerHandler.queueData.map { RadioQueueTrim.appliesTo(it?.data?.playlistType, it?.data?.playlistId) }
        }
    val isRadio by radioFlow.collectAsStateWithLifecycle(initialValue = false)
    if (whilePlaying && !isRadio) return
    // Held until the saved value comes back, so the handle does not flick back to the old spot.
    var draft by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(stored) { draft = null }
    val shown = draft ?: stored
    Column(modifier) {
        RadioMixHeader(value = shown, colors = colors)
        Spacer(Modifier.height(2.dp))
        RadioMixSlider(
            value = shown,
            onValueChange = { draft = it },
            onValueChangeFinished = {
                val picked = (draft ?: stored).snapRadioMix()
                if (picked == stored.snapRadioMix()) {
                    draft = null
                } else {
                    draft = picked
                    scope.launch {
                        dataStoreManager.setRadioDiscovery(picked)
                        if (whilePlaying) mediaPlayerHandler.toggleRadio()
                    }
                }
            },
            colors = colors,
        )
    }
}
