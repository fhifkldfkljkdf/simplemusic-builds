package com.maxrave.simpmusic.viewModel

import androidx.lifecycle.viewModelScope
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.annotation.ExperimentalCoilApi
import com.eygraber.uri.Uri
import com.maxrave.common.Config
import com.maxrave.common.QUALITY
import com.maxrave.common.SELECTED_LANGUAGE
import com.maxrave.common.VIDEO_QUALITY
import com.maxrave.domain.data.entities.DownloadState
import com.maxrave.domain.data.entities.GoogleAccountEntity
import com.maxrave.domain.data.model.lyrics.RomanizationDictionaryState
import com.maxrave.domain.data.player.GenericCastState
import com.maxrave.domain.data.player.SourceAvailability
import com.maxrave.domain.data.player.SourceKind
import com.maxrave.domain.data.player.ReverbPreset
import com.maxrave.domain.extension.toNetScapeString
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.mediaservice.handler.DownloadHandler
import com.maxrave.domain.repository.AccountRepository
import com.maxrave.domain.repository.ArtistRepository
import com.maxrave.domain.repository.CacheRepository
import com.maxrave.domain.repository.CommonRepository
import com.maxrave.domain.repository.LyricsRomanizerRepository
import com.maxrave.domain.repository.SongRepository
import com.maxrave.domain.repository.StreamRepository
import com.maxrave.domain.utils.LocalResource
import com.maxrave.logger.LogLevel
import com.maxrave.logger.Logger
import com.maxrave.simpmusic.Platform
import com.maxrave.simpmusic.getPlatform
import com.maxrave.simpmusic.viewModel.base.BaseViewModel
import com.maxrave.simpmusic.expect.updateDownloadAllowed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.singleOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.koin.core.component.inject
import org.simpmusic.lastfm.isLastfmAvailable
import org.jetbrains.compose.resources.getString as formatString
import simpmusic.composeapp.generated.resources.Res
import simpmusic.composeapp.generated.resources.backup_create_failed
import simpmusic.composeapp.generated.resources.backup_create_success
import simpmusic.composeapp.generated.resources.backup_in_progress
import simpmusic.composeapp.generated.resources.cancel
import simpmusic.composeapp.generated.resources.clear_canvas_cache
import simpmusic.composeapp.generated.resources.clear_listening_history
import simpmusic.composeapp.generated.resources.clear_downloaded_cache
import simpmusic.composeapp.generated.resources.clear_listening_history_done
import simpmusic.composeapp.generated.resources.clear_player_cache
import simpmusic.composeapp.generated.resources.clear_thumbnail_cache
import simpmusic.composeapp.generated.resources.downloading_liked_songs
import simpmusic.composeapp.generated.resources.error
import simpmusic.composeapp.generated.resources.log_out_confirm_message
import simpmusic.composeapp.generated.resources.restore_failed
import simpmusic.composeapp.generated.resources.restore_in_progress
import simpmusic.composeapp.generated.resources.romanization_japanese_dict_failed
import simpmusic.composeapp.generated.resources.romanization_japanese_dict_ready
import simpmusic.composeapp.generated.resources.warning
import simpmusic.composeapp.generated.resources.upgrade_downloads_wifi
import simpmusic.composeapp.generated.resources.upgrade_downloads_none
import kotlin.coroutines.cancellation.CancellationException
import com.maxrave.domain.mediaservice.handler.RadioMix

class SettingsViewModel(
    private val dataStoreManager: DataStoreManager,
    private val commonRepository: CommonRepository,
    private val songRepository: SongRepository,
    private val streamRepository: StreamRepository,
    private val accountRepository: AccountRepository,
    private val cacheRepository: CacheRepository,
    private val artistRepository: ArtistRepository,
    private val lyricsRomanizerRepository: LyricsRomanizerRepository,
) : BaseViewModel() {
    private val databasePath: String? = commonRepository.getDatabasePath()
    private val downloadUtils: DownloadHandler by inject()

    val castState: StateFlow<GenericCastState> get() = mediaPlayerHandler.castState

    /** READY everywhere the dictionary is bundled (Desktop), so only Android ever leaves it. */
    val japaneseDictionaryState: StateFlow<RomanizationDictionaryState> =
        lyricsRomanizerRepository.japaneseDictionaryState

    private var _location: MutableStateFlow<String?> = MutableStateFlow(null)
    val location: StateFlow<String?> = _location
    private var _language: MutableStateFlow<String?> = MutableStateFlow(null)
    val language: StateFlow<String?> = _language
    private var _loggedIn: MutableStateFlow<String?> = MutableStateFlow(null)
    val loggedIn: StateFlow<String?> = _loggedIn
    private var _normalizeVolume: MutableStateFlow<String?> = MutableStateFlow(null)
    val normalizeVolume: StateFlow<String?> = _normalizeVolume
    private var _skipSilent: MutableStateFlow<String?> = MutableStateFlow(null)
    val skipSilent: StateFlow<String?> = _skipSilent
    private var _savedPlaybackState: MutableStateFlow<String?> = MutableStateFlow(null)
    val savedPlaybackState: StateFlow<String?> = _savedPlaybackState
    private var _lastCheckForUpdate: MutableStateFlow<String?> = MutableStateFlow(null)
    val lastCheckForUpdate: StateFlow<String?> = _lastCheckForUpdate
    private var _sponsorBlockEnabled: MutableStateFlow<String?> = MutableStateFlow(null)
    val sponsorBlockEnabled: StateFlow<String?> = _sponsorBlockEnabled
    private var _sponsorBlockCategories: MutableStateFlow<ArrayList<String>?> =
        MutableStateFlow(null)
    val sponsorBlockCategories: StateFlow<ArrayList<String>?> = _sponsorBlockCategories
    private var _sendBackToGoogle: MutableStateFlow<String?> = MutableStateFlow(null)
    val sendBackToGoogle: StateFlow<String?> = _sendBackToGoogle
    private var _mainLyricsProvider: MutableStateFlow<String?> = MutableStateFlow(null)
    val mainLyricsProvider: StateFlow<String?> = _mainLyricsProvider

    private var _translationLanguage: MutableStateFlow<String?> = MutableStateFlow(null)
    val translationLanguage: StateFlow<String?> = _translationLanguage
    private var _useTranslation: MutableStateFlow<String?> = MutableStateFlow(null)
    val useTranslation: StateFlow<String?> = _useTranslation
    private var _playerCacheLimit: MutableStateFlow<Int?> = MutableStateFlow(null)
    val playerCacheLimit: StateFlow<Int?> = _playerCacheLimit
    private var _playVideoInsteadOfAudio: MutableStateFlow<String?> = MutableStateFlow(null)
    val playVideoInsteadOfAudio: StateFlow<String?> = _playVideoInsteadOfAudio

    private var _radioAudioOnly: MutableStateFlow<String?> = MutableStateFlow(null)
    val radioAudioOnly: StateFlow<String?> = _radioAudioOnly
    private var _videoQuality: MutableStateFlow<String?> = MutableStateFlow(null)
    val videoQuality: StateFlow<String?> = _videoQuality
    private var _thumbCacheSize = MutableStateFlow<Long?>(null)
    val thumbCacheSize: StateFlow<Long?> = _thumbCacheSize
    private var _canvasCacheSize: MutableStateFlow<Long?> = MutableStateFlow(null)
    val canvasCacheSize: StateFlow<Long?> = _canvasCacheSize
    private var _usingProxy = MutableStateFlow(false)
    val usingProxy: StateFlow<Boolean> = _usingProxy
    private var _proxyType = MutableStateFlow(DataStoreManager.ProxyType.PROXY_TYPE_HTTP)
    val proxyType: StateFlow<DataStoreManager.ProxyType> = _proxyType
    private var _proxyHost = MutableStateFlow("")
    val proxyHost: StateFlow<String> = _proxyHost
    private var _proxyPort = MutableStateFlow(8000)
    val proxyPort: StateFlow<Int> = _proxyPort
    private var _proxyUsername = MutableStateFlow("")
    val proxyUsername: StateFlow<String> = _proxyUsername
    private var _proxyPassword = MutableStateFlow("")
    val proxyPassword: StateFlow<String> = _proxyPassword
    private var _autoCheckUpdate = MutableStateFlow(false)
    val autoCheckUpdate: StateFlow<Boolean> = _autoCheckUpdate
    private var _updateChannel: MutableStateFlow<String> = MutableStateFlow(DataStoreManager.GITHUB)
    val updateChannel: StateFlow<String> = _updateChannel
    private val _aiProvider = MutableStateFlow<String>(DataStoreManager.AI_PROVIDER_OPENAI)
    val aiProvider: StateFlow<String> = _aiProvider
    private val _isHasApiKey = MutableStateFlow<Boolean>(false)
    val isHasApiKey: StateFlow<Boolean> = _isHasApiKey
    private val _useAITranslation = MutableStateFlow<Boolean>(false)
    val useAITranslation: StateFlow<Boolean> = _useAITranslation
    private val _customModelId = MutableStateFlow<String>("")
    val customModelId: StateFlow<String> = _customModelId
    private val _customOpenAIBaseUrl = MutableStateFlow<String>("")
    val customOpenAIBaseUrl: StateFlow<String> = _customOpenAIBaseUrl
    private val _customOpenAIHeaders = MutableStateFlow<String>("")
    val customOpenAIHeaders: StateFlow<String> = _customOpenAIHeaders
    private val _crossfadeEnabled = MutableStateFlow<Boolean>(false)
    val crossfadeEnabled: StateFlow<Boolean> = _crossfadeEnabled
    private val _crossfadeDuration = MutableStateFlow<Int>(5000)
    val crossfadeDuration: StateFlow<Int> = _crossfadeDuration
    private val _crossfadeDjMode = MutableStateFlow<Boolean>(true)
    val crossfadeDjMode: StateFlow<Boolean> = _crossfadeDjMode
    private val _crossfadeSkipAlbum = MutableStateFlow<Boolean>(false)
    val crossfadeSkipAlbum: StateFlow<Boolean> = _crossfadeSkipAlbum
    private val _autoDownloadLikedSongs = MutableStateFlow<Boolean>(false)
    val autoDownloadLikedSongs: StateFlow<Boolean> = _autoDownloadLikedSongs
    private val _youtubeSubtitleLanguage = MutableStateFlow<String>("")
    val youtubeSubtitleLanguage: StateFlow<String> = _youtubeSubtitleLanguage
    private val _lyricsOffsetMs = MutableStateFlow<Int>(0)
    val lyricsOffsetMs: StateFlow<Int> = _lyricsOffsetMs
    private val _preferredAudioLanguage = MutableStateFlow("")
    val preferredAudioLanguage: StateFlow<String> = _preferredAudioLanguage

    private var _helpBuildLyricsDatabase: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val helpBuildLyricsDatabase: StateFlow<Boolean> = _helpBuildLyricsDatabase
    private var _contributor: MutableStateFlow<Pair<String, String>> = MutableStateFlow(Pair("", ""))
    val contributor: StateFlow<Pair<String, String>> = _contributor

    private var _backupDownloaded: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val backupDownloaded: StateFlow<Boolean> = _backupDownloaded

    private var _enableLiquidGlass: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val enableLiquidGlass: StateFlow<Boolean> = _enableLiquidGlass

    private val _explicitContentEnabled = MutableStateFlow(false)
    val explicitContentEnabled: StateFlow<Boolean> = _explicitContentEnabled

    private val _discordLoggedIn = MutableStateFlow(false)
    val discordLoggedIn: StateFlow<Boolean> = _discordLoggedIn

    private val _richPresenceEnabled = MutableStateFlow(false)
    val richPresenceEnabled: StateFlow<Boolean> = _richPresenceEnabled

    /**
     * False in a FOSS build, and in a full build with no API key in `local.properties`. The whole
     * Last.fm block in settings is hidden when it is false, rather than offering a login that
     * could never succeed.
     */
    val lastfmAvailable: Boolean = isLastfmAvailable()

    private val _lastfmUsername = MutableStateFlow("")
    val lastfmUsername: StateFlow<String> = _lastfmUsername

    private val _lastfmLoggedIn = MutableStateFlow(false)
    val lastfmLoggedIn: StateFlow<Boolean> = _lastfmLoggedIn

    private val _lastfmScrobbleEnabled = MutableStateFlow(false)
    val lastfmScrobbleEnabled: StateFlow<Boolean> = _lastfmScrobbleEnabled

    private val _keepYouTubePlaylistOffline = MutableStateFlow<Boolean>(false)
    val keepYouTubePlaylistOffline: StateFlow<Boolean> = _keepYouTubePlaylistOffline

    private val _combineLocalAndYouTubeLiked = MutableStateFlow<Boolean>(false)
    val combineLocalAndYouTubeLiked: StateFlow<Boolean> = _combineLocalAndYouTubeLiked

    private val _downloadQuality = MutableStateFlow<String?>(null)
    val downloadQuality: StateFlow<String?> = _downloadQuality

    private val _videoDownloadQuality = MutableStateFlow<String?>(null)
    val videoDownloadQuality: StateFlow<String?> = _videoDownloadQuality

    private val _localTrackingEnabled = MutableStateFlow<Boolean>(false)
    val localTrackingEnabled: StateFlow<Boolean> = _localTrackingEnabled


    // Auto Backup
    private val _autoBackupEnabled = MutableStateFlow<Boolean>(false)
    val autoBackupEnabled: StateFlow<Boolean> = _autoBackupEnabled

    private val _autoBackupFrequency = MutableStateFlow<String>(DataStoreManager.AUTO_BACKUP_FREQUENCY_DAILY)
    val autoBackupFrequency: StateFlow<String> = _autoBackupFrequency

    private val _autoBackupMaxFiles = MutableStateFlow<Int>(5)
    val autoBackupMaxFiles: StateFlow<Int> = _autoBackupMaxFiles

    private val _autoBackupLastTime = MutableStateFlow<Long>(0L)
    val autoBackupLastTime: StateFlow<Long> = _autoBackupLastTime

    private var _alertData: MutableStateFlow<SettingAlertState?> = MutableStateFlow(null)
    val alertData: StateFlow<SettingAlertState?> = _alertData

    private var _basicAlertData: MutableStateFlow<SettingBasicAlertState?> = MutableStateFlow(null)
    val basicAlertData: StateFlow<SettingBasicAlertState?> = _basicAlertData

    // Fraction of storage
    private var _fraction: MutableStateFlow<SettingsStorageSectionFraction> =
        MutableStateFlow(
            SettingsStorageSectionFraction(),
        )
    val fraction: StateFlow<SettingsStorageSectionFraction> = _fraction

    // Biến để lưu trữ và hiển thị trạng thái killServiceOnExit
    private var _killServiceOnExit: MutableStateFlow<String?> = MutableStateFlow(null)
    val killServiceOnExit: StateFlow<String?> = _killServiceOnExit

    init {
        getYoutubeSubtitleLanguage()
        getPreferredAudioLanguage()
        getHelpBuildLyricsDatabase()
        viewModelScope.launch {
            enableLiquidGlass.collect {
                if (getPlatform() != Platform.Android && it) {
                    setEnableLiquidGlass(false)
                }
            }
        }
    }

    fun getAudioSessionId() = mediaPlayerHandler.player.audioSessionId

    fun getData() {
        getLocation()
        getLanguage()
        getQuality()
        getPlayerCacheSize()
        getDownloadedCacheSize()
        getPlayerCacheLimit()
        getLoggedIn()
        getNormalizeVolume()
        getSkipSilent()
        getSavedPlaybackState()
        getSendBackToGoogle()
        getLastCheckForUpdate()
        getSponsorBlockEnabled()
        getSponsorBlockCategories()
        getTranslationLanguage()
        getYoutubeSubtitleLanguage()
        getLyricsProvider()
        getLyricsOffsetMs()
        getUseTranslation()
        getPlayVideoInsteadOfAudio()
        getRadioAudioOnly()
        getVideoQuality()
        getSpotifyLogIn()
        getSpotifyLyrics()
        getSyncFollowToYouTube()
        getEqualizer()
        getAudioEffects()
        getSpotifyCanvas()
        getAMAnimatedArtwork()
        getUsingProxy()
        getCanvasCache()
        getAutoCheckUpdate()
        getAIProvider()
        getAIApiKey()
        getAITranslation()
        getCustomModelId()
        getCustomOpenAIBaseUrl()
        getCustomOpenAIHeaders()
        getKillServiceOnExit()
        getCrossfadeEnabled()
        getCrossfadeDuration()
        getCrossfadeDjMode()
        getCrossfadeSkipAlbum()
        getAutoDownloadLikedSongs()
        getContributorNameAndEmail()
        getBackupDownloaded()
        getUpdateChannel()
        getEnableLiquidGlass()
        getExplicitContentEnabled()
        getDiscordLoggedIn()
        getDiscordRichPresenceEnabled()
        getLastfmSession()
        getLastfmScrobbleEnabled()
        getKeepYouTubePlaylistOffline()
        getCombineLocalAndYouTubeLiked()
        getDownloadQuality()
        getVideoDownloadQuality()
        getLocalTrackingEnabled()
        getAutoBackupEnabled()
        getAutoBackupFrequency()
        getAutoBackupMaxFiles()
        getAutoBackupLastTime()
        viewModelScope.launch {
            calculateDataFraction(
                cacheRepository,
            )?.let {
                _fraction.value = it
            }
        }
    }

    private fun getLocalTrackingEnabled() {
        viewModelScope.launch {
            dataStoreManager.localTrackingEnabled.collect { enabled ->
                _localTrackingEnabled.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setLocalTrackingEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setLocalTrackingEnabled(enabled)
            getLocalTrackingEnabled()
        }
    }

    private fun getDownloadQuality() {
        viewModelScope.launch {
            dataStoreManager.downloadQuality.collect { quality ->
                _downloadQuality.emit(QUALITY.normalize(quality))
            }
        }
    }

    fun setDownloadQuality(quality: String) {
        viewModelScope.launch {
            dataStoreManager.setDownloadQuality(quality)
            getDownloadQuality()
        }
    }

    private fun getVideoDownloadQuality() {
        viewModelScope.launch {
            dataStoreManager.videoDownloadQuality.collect { videoQuality ->
                when (videoQuality) {
                    VIDEO_QUALITY.items[0].toString() -> _videoDownloadQuality.emit(VIDEO_QUALITY.items[0].toString())
                    VIDEO_QUALITY.items[1].toString() -> _videoDownloadQuality.emit(VIDEO_QUALITY.items[1].toString())
                    VIDEO_QUALITY.items[2].toString() -> _videoDownloadQuality.emit(VIDEO_QUALITY.items[2].toString())
                }
            }
        }
    }

    fun setVideoDownloadQuality(quality: String) {
        viewModelScope.launch {
            if (VIDEO_QUALITY.items.contains(quality)) {
                dataStoreManager.setVideoDownloadQuality(quality)
            }
            getVideoDownloadQuality()
        }
    }

    private fun getKeepYouTubePlaylistOffline() {
        viewModelScope.launch {
            dataStoreManager.keepYouTubePlaylistOffline.collect { keep ->
                _keepYouTubePlaylistOffline.value = keep == DataStoreManager.TRUE
            }
        }
    }

    fun setKeepYouTubePlaylistOffline(keep: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setKeepYouTubePlaylistOffline(keep)
            getKeepYouTubePlaylistOffline()
        }
    }

    private fun getCombineLocalAndYouTubeLiked() {
        viewModelScope.launch {
            dataStoreManager.combineLocalAndYouTubeLiked.collect { combine ->
                _combineLocalAndYouTubeLiked.value = combine == DataStoreManager.TRUE
            }
        }
    }

    fun setCombineLocalAndYouTubeLiked(combine: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setCombineLocalAndYouTubeLiked(combine)
            getCombineLocalAndYouTubeLiked()
        }
    }

    private fun getCrossfadeEnabled() {
        viewModelScope.launch {
            dataStoreManager.crossfadeEnabled.collect { enabled ->
                _crossfadeEnabled.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setCrossfadeEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setCrossfadeEnabled(enabled)
            getCrossfadeEnabled()
        }
    }

    private fun getCrossfadeDuration() {
        viewModelScope.launch {
            dataStoreManager.crossfadeDuration.collect { duration ->
                _crossfadeDuration.value = duration
            }
        }
    }

    fun setCrossfadeDuration(duration: Int) {
        viewModelScope.launch {
            dataStoreManager.setCrossfadeDuration(duration)
            getCrossfadeDuration()
        }
    }

    private fun getCrossfadeDjMode() {
        viewModelScope.launch {
            dataStoreManager.crossfadeDjMode.collect { enabled ->
                _crossfadeDjMode.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setCrossfadeDjMode(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setCrossfadeDjMode(enabled)
            getCrossfadeDjMode()
        }
    }

    private fun getCrossfadeSkipAlbum() {
        viewModelScope.launch {
            dataStoreManager.crossfadeSkipAlbum.collect { enabled ->
                _crossfadeSkipAlbum.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setCrossfadeSkipAlbum(enabled: Boolean) {
        viewModelScope.launch {
            // No re-read afterwards: the collector started in init never completes, so it already
            // picks this up. Calling the getter again would leave a second collector running for
            // the life of the ViewModel, one more per toggle.
            dataStoreManager.setCrossfadeSkipAlbum(enabled)
        }
    }

    private fun getAutoDownloadLikedSongs() {
        viewModelScope.launch {
            dataStoreManager.autoDownloadLikedSongs.collect { enabled ->
                _autoDownloadLikedSongs.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setAutoDownloadLikedSongs(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setAutoDownloadLikedSongs(enabled)
            // Every time it is switched on, not only the first: this is the catch-up, and it asks
            // the device what is really there (SongRepositoryImpl.downloadAllLikedSongs), so a
            // favourite whose copy went missing is queued again.
            if (enabled) {
                val queued = songRepository.downloadAllLikedSongs()
                if (queued > 0) {
                    // Not BaseViewModel.getString: that one takes no format arguments and would
                    // leave the placeholder in the text.
                    makeToast(formatString(Res.string.downloading_liked_songs, queued))
                }
            }
        }
    }

    private fun getDiscordLoggedIn() {
        viewModelScope.launch {
            dataStoreManager.discordToken.collect { loggedIn ->
                _discordLoggedIn.value = loggedIn.isNotEmpty()
            }
        }
    }

    private fun getLastfmSession() {
        viewModelScope.launch {
            dataStoreManager.lastfmSessionKey.collect { key ->
                _lastfmLoggedIn.value = key.isNotEmpty()
            }
        }
        viewModelScope.launch {
            dataStoreManager.lastfmUsername.collect { username ->
                _lastfmUsername.value = username
            }
        }
    }

    fun logOutLastfm() {
        viewModelScope.launch {
            dataStoreManager.setLastfmSession(sessionKey = "", username = "")
            // Scrobbling is gated on the session, so logging out must clear it here — the same
            // teardown setSpotifyLogIn and logOutDiscord already do. Doing it from the Settings
            // row instead only works if the user happens to open Settings and scroll to that row.
            dataStoreManager.setLastfmScrobbleEnabled(false)
        }
    }

    private fun getLastfmScrobbleEnabled() {
        viewModelScope.launch {
            dataStoreManager.lastfmScrobbleEnabled.collect { enabled ->
                _lastfmScrobbleEnabled.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setLastfmScrobbleEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setLastfmScrobbleEnabled(enabled)
        }
    }

    fun logOutDiscord() {
        viewModelScope.launch {
            dataStoreManager.setDiscordToken("")
            // Turn Rich Presence off on logout: without a token it can't run, and leaving the flag on
            // would both strand the user (the toggle greys out when logged out) and let the player keep
            // a dead RPC alive (issue #2157). The existing richPresenceEnabled collector refreshes the UI.
            dataStoreManager.setRichPresenceEnabled(false)
            delay(100)
            getDiscordLoggedIn()
        }
    }

    private fun getDiscordRichPresenceEnabled() {
        viewModelScope.launch {
            dataStoreManager.richPresenceEnabled.collect { enabled ->
                _richPresenceEnabled.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setDiscordRichPresenceEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setRichPresenceEnabled(enabled)
            delay(100)
            getDiscordRichPresenceEnabled()
        }
    }

    private fun getExplicitContentEnabled() {
        viewModelScope.launch {
            dataStoreManager.explicitContentEnabled.collect { enabled ->
                _explicitContentEnabled.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setExplicitContentEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setExplicitContentEnabled(enabled)
            getExplicitContentEnabled()
        }
    }

    private fun getEnableLiquidGlass() {
        viewModelScope.launch {
            dataStoreManager.enableLiquidGlass.collect { enableLiquidGlass ->
                _enableLiquidGlass.value = enableLiquidGlass == DataStoreManager.TRUE
            }
        }
    }

    fun setEnableLiquidGlass(enableLiquidGlass: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setEnableLiquidGlass(enableLiquidGlass)
            getEnableLiquidGlass()
        }
    }

    private fun getUpdateChannel() {
        viewModelScope.launch {
            dataStoreManager.updateChannel.collect { channel ->
                _updateChannel.value = channel
            }
        }
    }

    fun setUpdateChannel(channel: String) {
        viewModelScope.launch {
            dataStoreManager.setUpdateChannel(channel)
            getUpdateChannel()
        }
    }

    private fun getBackupDownloaded() {
        viewModelScope.launch {
            dataStoreManager.backupDownloaded.collect { backupDownloaded ->
                _backupDownloaded.value = backupDownloaded == DataStoreManager.TRUE
            }
        }
    }

    fun setBackupDownloaded(backupDownloaded: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setBackupDownloaded(backupDownloaded)
            getBackupDownloaded()
        }
    }

    // Auto Backup functions
    private fun getAutoBackupEnabled() {
        viewModelScope.launch {
            dataStoreManager.autoBackupEnabled.collect { enabled ->
                _autoBackupEnabled.value = enabled == DataStoreManager.TRUE
            }
        }
    }

    fun setAutoBackupEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setAutoBackupEnabled(enabled)
            getAutoBackupEnabled()
        }
    }

    private fun getAutoBackupFrequency() {
        viewModelScope.launch {
            dataStoreManager.autoBackupFrequency.collect { frequency ->
                _autoBackupFrequency.value = frequency
            }
        }
    }

    fun setAutoBackupFrequency(frequency: String) {
        viewModelScope.launch {
            dataStoreManager.setAutoBackupFrequency(frequency)
            getAutoBackupFrequency()
        }
    }

    private fun getAutoBackupMaxFiles() {
        viewModelScope.launch {
            dataStoreManager.autoBackupMaxFiles.collect { max ->
                _autoBackupMaxFiles.value = max
            }
        }
    }

    fun setAutoBackupMaxFiles(max: Int) {
        viewModelScope.launch {
            dataStoreManager.setAutoBackupMaxFiles(max)
            getAutoBackupMaxFiles()
        }
    }

    private fun getAutoBackupLastTime() {
        viewModelScope.launch {
            dataStoreManager.autoBackupLastTime.collect { time ->
                _autoBackupLastTime.value = time
            }
        }
    }

    private fun getContributorNameAndEmail() {
        viewModelScope.launch {
            combine(dataStoreManager.contributorName, dataStoreManager.contributorEmail) { name, email ->
                name to email
            }.collect { contributor ->
                _contributor.value = contributor
            }
        }
    }

    fun setContributorName(name: String) {
        viewModelScope.launch {
            dataStoreManager.setContributorLyricsDatabase(name to contributor.value.second)
            getContributorNameAndEmail()
        }
    }

    fun setContributorEmail(email: String) {
        viewModelScope.launch {
            dataStoreManager.setContributorLyricsDatabase(contributor.value.first to email)
            getContributorNameAndEmail()
        }
    }

    private fun getCustomModelId() {
        viewModelScope.launch {
            dataStoreManager.customModelId.collect { customModelId ->
                _customModelId.value = customModelId
            }
        }
    }

    fun setCustomModelId(modelId: String) {
        viewModelScope.launch {
            dataStoreManager.setCustomModelId(modelId)
            getCustomModelId()
        }
    }

    private fun getCustomOpenAIBaseUrl() {
        viewModelScope.launch {
            dataStoreManager.customOpenAIBaseUrl.collect { baseUrl ->
                _customOpenAIBaseUrl.value = baseUrl
            }
        }
    }

    fun setCustomOpenAIBaseUrl(baseUrl: String) {
        viewModelScope.launch {
            dataStoreManager.setCustomOpenAIBaseUrl(baseUrl)
            getCustomOpenAIBaseUrl()
        }
    }

    private fun getCustomOpenAIHeaders() {
        viewModelScope.launch {
            dataStoreManager.customOpenAIHeaders.collect { headers ->
                _customOpenAIHeaders.value = headers
            }
        }
    }

    fun setCustomOpenAIHeaders(headers: String) {
        viewModelScope.launch {
            dataStoreManager.setCustomOpenAIHeaders(headers)
            getCustomOpenAIHeaders()
        }
    }

    private fun getAIProvider() {
        viewModelScope.launch {
            dataStoreManager.aiProvider.collect { aiProvider ->
                _aiProvider.value = aiProvider
            }
        }
    }

    fun setAIProvider(provider: String) {
        viewModelScope.launch {
            dataStoreManager.setAIProvider(provider)
            getAIProvider()
        }
    }

    private fun getAITranslation() {
        viewModelScope.launch {
            dataStoreManager.useAITranslation.collect { useAITranslation ->
                _useAITranslation.value = useAITranslation == DataStoreManager.TRUE
            }
        }
    }

    fun setAITranslation(useAITranslation: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setUseAITranslation(useAITranslation)
            getAITranslation()
        }
    }

    private fun getAIApiKey() {
        viewModelScope.launch {
            dataStoreManager.aiApiKey.collect { aiApiKey ->
                if (aiApiKey.isNotEmpty()) {
                    _isHasApiKey.value = true
                } else {
                    _isHasApiKey.value = false
                }
            }
        }
    }

    fun setAIApiKey(apiKey: String) {
        viewModelScope.launch {
            dataStoreManager.setAIApiKey(apiKey)
            // An empty key IS the sign-out here — isHasApiKey is derived from aiApiKey.isNotEmpty()
            // — so AI translation, which is gated on it, has to come off with it.
            if (apiKey.isEmpty()) {
                dataStoreManager.setUseAITranslation(false)
            }
            getAIApiKey()
        }
    }

    private fun getAutoCheckUpdate() {
        viewModelScope.launch {
            dataStoreManager.autoCheckForUpdates.collect { autoCheckUpdate ->
                _autoCheckUpdate.value = autoCheckUpdate == DataStoreManager.TRUE
            }
        }
    }

    fun setAutoCheckUpdate(autoCheckUpdate: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setAutoCheckForUpdates(autoCheckUpdate)
            getAutoCheckUpdate()
        }
    }

    private fun getCanvasCache() {
        viewModelScope.launch {
            _canvasCacheSize.value = cacheRepository.getCacheSize(Config.CANVAS_CACHE)
        }
    }

    fun setAlertData(alertData: SettingAlertState?) {
        _alertData.value = alertData
    }

    fun setBasicAlertData(alertData: SettingBasicAlertState?) {
        _basicAlertData.value = alertData
    }

    /**
     * Asks before signing out of a linked account.
     *
     * Every one of these rows sits inside a long settings list and does its work on a single tap,
     * with no undo — and getting back in is not symmetric with getting out: Last.fm sends the user
     * through a browser again, YouTube and Spotify through a full web login. The confirmation is
     * cheap next to that.
     *
     * @param confirmLabel names the service on the confirming button, because the dialog is the
     * only thing on screen at that moment and "Log out" alone does not say out of what.
     */
    fun confirmLogOut(
        confirmLabel: String,
        onConfirm: () -> Unit,
    ) {
        viewModelScope.launch {
            setBasicAlertData(
                SettingBasicAlertState(
                    title = getString(Res.string.warning),
                    message = getString(Res.string.log_out_confirm_message),
                    confirm = confirmLabel to onConfirm,
                    dismiss = getString(Res.string.cancel),
                ),
            )
        }
    }

    private fun getUsingProxy() {
        viewModelScope.launch {
            dataStoreManager.usingProxy.collectLatest { usingProxy ->
                if (usingProxy == DataStoreManager.TRUE) {
                    getProxy()
                }
                _usingProxy.value = usingProxy == DataStoreManager.TRUE
            }
        }
    }

    fun setUsingProxy(usingProxy: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setUsingProxy(usingProxy)
            getUsingProxy()
            getProxy()
        }
    }

    private fun getProxy() {
        viewModelScope.launch {
            val host =
                launch {
                    dataStoreManager.proxyHost.collect {
                        _proxyHost.value = it
                    }
                }
            val port =
                launch {
                    dataStoreManager.proxyPort.collect {
                        _proxyPort.value = it
                    }
                }
            val type =
                launch {
                    dataStoreManager.proxyType.collect {
                        _proxyType.value = it
                        log("getProxy: $it")
                    }
                }
            val username =
                launch {
                    dataStoreManager.proxyUsername.collect {
                        _proxyUsername.value = it
                    }
                }
            val password =
                launch {
                    dataStoreManager.proxyPassword.collect {
                        _proxyPassword.value = it
                    }
                }
            host.join()
            port.join()
            type.join()
            username.join()
            password.join()
        }
    }

    fun setProxy(
        proxyType: DataStoreManager.ProxyType,
        host: String,
        port: Int,
    ) {
        log("setProxy: $proxyType, $host, $port")
        viewModelScope.launch {
            dataStoreManager.setProxyType(proxyType)
            dataStoreManager.setProxyHost(host)
            dataStoreManager.setProxyPort(port)
        }
    }

    fun setProxyCredentials(
        username: String,
        password: String,
    ) {
        log("setProxyCredentials: username=$username")
        viewModelScope.launch {
            dataStoreManager.setProxyUsername(username)
            dataStoreManager.setProxyPassword(password)
        }
    }

    fun getThumbCacheSize(context: PlatformContext) {
        viewModelScope.launch {
            val diskCache = SingletonImageLoader.get(context).diskCache
            _thumbCacheSize.emit(diskCache?.size)
        }
    }

    fun getVideoQuality() {
        viewModelScope.launch {
            dataStoreManager.videoQuality.collect { videoQuality ->
                when (videoQuality) {
                    VIDEO_QUALITY.items[0].toString() -> _videoQuality.emit(VIDEO_QUALITY.items[0].toString())
                    VIDEO_QUALITY.items[1].toString() -> _videoQuality.emit(VIDEO_QUALITY.items[1].toString())
                    VIDEO_QUALITY.items[2].toString() -> _videoQuality.emit(VIDEO_QUALITY.items[2].toString())
                }
            }
        }
    }

    fun getTranslationLanguage() {
        viewModelScope.launch {
            dataStoreManager.translationLanguage.collect { translationLanguage ->
                _translationLanguage.emit(translationLanguage)
            }
        }
    }

    fun setTranslationLanguage(language: String) {
        viewModelScope.launch {
            dataStoreManager.setTranslationLanguage(language)
            getTranslationLanguage()
        }
    }

    private fun getLyricsOffsetMs() {
        viewModelScope.launch {
            dataStoreManager.lyricsOffsetMs.collect { offsetMs ->
                _lyricsOffsetMs.emit(offsetMs)
            }
        }
    }

    // Deliberately does NOT re-call its getter the way the settings around it do: that getter
    // collects forever, so calling it again on every write leaves another collector running for the
    // life of the ViewModel. The one started in init already publishes this value.
    fun setLyricsOffsetMs(offsetMs: Int) {
        viewModelScope.launch {
            dataStoreManager.setLyricsOffsetMs(offsetMs)
        }
    }

    fun getUseTranslation() {
        viewModelScope.launch {
            dataStoreManager.enableTranslateLyric.collect { useTranslation ->
                _useTranslation.emit(useTranslation)
            }
        }
    }

    fun setUseTranslation(useTranslation: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setEnableTranslateLyric(useTranslation)
            getUseTranslation()
        }
    }

    fun getLyricsProvider() {
        viewModelScope.launch {
            dataStoreManager.lyricsProvider.collect { mainLyricsProvider ->
                _mainLyricsProvider.emit(mainLyricsProvider)
            }
        }
    }

    fun setLyricsProvider(provider: String) {
        viewModelScope.launch {
            dataStoreManager.setLyricsProvider(provider)
            getLyricsProvider()
        }
    }

    private var japaneseDictionaryWaiter: Job? = null

    /**
     * Fetches the Japanese romanization dictionary if this platform needs one and does not have
     * it yet. Called from the settings screen every time a saved selection includes Japanese, so
     * a FAILED attempt is retried by simply confirming the dialog again; READY makes this a no-op.
     * A download already running — the repository starts one by itself when it finds Japanese
     * selected and the pack missing — is joined rather than skipped, so its outcome still gets a
     * toast. Progress and outcome live in [japaneseDictionaryState], which the romanization row's
     * subtitle watches. The download runs in the repository's own scope, so leaving Settings
     * mid-way only loses the toast below, not the download.
     */
    fun downloadJapaneseDictionaryIfNeeded() {
        if (japaneseDictionaryState.value == RomanizationDictionaryState.READY) return
        // Saving the dialog again mid-download (say, to add Korean) would otherwise queue a
        // second waiter and show the same toast twice. Checked against DOWNLOADING as well: a
        // waiter outlives its download by the moment it takes to show the toast, and a save in
        // that moment, after a failure, is a real retry.
        if (japaneseDictionaryWaiter?.isActive == true &&
            japaneseDictionaryState.value == RomanizationDictionaryState.DOWNLOADING
        ) {
            return
        }
        japaneseDictionaryWaiter = viewModelScope.launch {
            // The state the download settled on, as the repository saw it end. Reading
            // japaneseDictionaryState back afterwards could already show the next attempt.
            when (lyricsRomanizerRepository.downloadJapaneseDictionary()) {
                RomanizationDictionaryState.READY ->
                    makeToast(getString(Res.string.romanization_japanese_dict_ready))
                RomanizationDictionaryState.FAILED ->
                    makeToast(getString(Res.string.romanization_japanese_dict_failed))
                else -> {}
            }
        }
    }

    fun getLocation() {
        viewModelScope.launch {
            dataStoreManager.location.collect { location ->
                _location.emit(location)
            }
        }
    }

    fun getLoggedIn() {
        viewModelScope.launch {
            dataStoreManager.loggedIn.collect { loggedIn ->
                _loggedIn.emit(loggedIn)
            }
        }
    }

    fun changeLocation(location: String) {
        viewModelScope.launch {
            dataStoreManager.setLocation(location)
            getLocation()
        }
    }

    fun getLastCheckForUpdate() {
        viewModelScope.launch {
            dataStoreManager.getString("CheckForUpdateAt").first().let { lastCheckForUpdate ->
                _lastCheckForUpdate.emit(lastCheckForUpdate)
            }
        }
    }

    fun getSponsorBlockEnabled() {
        viewModelScope.launch {
            dataStoreManager.sponsorBlockEnabled.first().let { enabled ->
                _sponsorBlockEnabled.emit(enabled)
            }
        }
    }

    fun setSponsorBlockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSponsorBlockEnabled(enabled)
            getSponsorBlockEnabled()
        }
    }

    fun getPlayVideoInsteadOfAudio() {
        viewModelScope.launch {
            dataStoreManager.watchVideoInsteadOfPlayingAudio.collect { playVideoInsteadOfAudio ->
                _playVideoInsteadOfAudio.emit(playVideoInsteadOfAudio)
            }
        }
    }

    fun setPlayVideoInsteadOfAudio(playVideoInsteadOfAudio: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setWatchVideoInsteadOfPlayingAudio(playVideoInsteadOfAudio)
            getPlayVideoInsteadOfAudio()
        }
    }

    fun getRadioAudioOnly() {
        viewModelScope.launch {
            dataStoreManager.radioAudioOnly.collect { radioAudioOnly ->
                _radioAudioOnly.emit(radioAudioOnly)
            }
        }
    }

    /**
     * No re-collect after writing, unlike the settings above: [getRadioAudioOnly] already collects
     * the DataStore flow, which emits again on every write. Calling the getter here would only
     * stack a second collector on each toggle.
     */
    fun setRadioAudioOnly(audioOnly: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setRadioAudioOnly(audioOnly)
        }
    }

    /** On unless turned off; see DataStoreManager.personalizeRadio. */
    val personalizeRadio: StateFlow<Boolean> =
        dataStoreManager.personalizeRadio
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setPersonalizeRadio(personalize: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setPersonalizeRadio(personalize)
        }
    }

    /** 0 = familiar songs … 1 = new songs; see RadioPersonalizer.rank. */
    val radioDiscovery: StateFlow<Float> =
        dataStoreManager.radioDiscovery.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RadioMix.DEFAULT_DISCOVERY)

    fun setRadioDiscovery(discovery: Float) {
        viewModelScope.launch {
            dataStoreManager.setRadioDiscovery(discovery)
        }
    }

    /** On unless turned off; see DataStoreManager.soundCloudBackup. */
    val soundCloudBackup: StateFlow<Boolean> =
        dataStoreManager.soundCloudBackup
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setSoundCloudBackup(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSoundCloudBackup(enabled)
        }
    }

    /** On unless turned off; see DataStoreManager.downloadCompleteNotification. */
    val downloadCompleteNotification: StateFlow<Boolean> =
        dataStoreManager.downloadCompleteNotification
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setDownloadCompleteNotification(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setDownloadCompleteNotification(enabled)
        }
    }

    /** Off unless turned on; see DataStoreManager.hifiSound. */
    val hifiSound: StateFlow<Boolean> =
        dataStoreManager.hifiSound
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun setHifiSound(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setHifiSound(enabled)
        }
    }

    /** Private copy: Hi-Fi sound's sources, each on unless turned off. */
    val internetArchiveSource: StateFlow<Boolean> =
        dataStoreManager.internetArchiveSource
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setInternetArchiveSource(enabled: Boolean) {
        viewModelScope.launch { dataStoreManager.setInternetArchiveSource(enabled) }
    }

    val audiusSource: StateFlow<Boolean> =
        dataStoreManager.audiusSource
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setAudiusSource(enabled: Boolean) {
        viewModelScope.launch { dataStoreManager.setAudiusSource(enabled) }
    }

    val monochromeSource: StateFlow<Boolean> =
        dataStoreManager.monochromeSource
            .map { it == DataStoreManager.TRUE }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setMonochromeSource(enabled: Boolean) {
        viewModelScope.launch { dataStoreManager.setMonochromeSource(enabled) }
    }

    fun getSponsorBlockCategories() {
        viewModelScope.launch {
            dataStoreManager.getSponsorBlockCategories().let {
                log("getSponsorBlockCategories: $it", LogLevel.WARN)
                _sponsorBlockCategories.emit(it)
            }
        }
    }

    fun setSponsorBlockCategories(list: ArrayList<String>) {
        log("setSponsorBlockCategories: $list", LogLevel.WARN)
        viewModelScope.launch {
            runBlocking(Dispatchers.IO) {
                dataStoreManager.setSponsorBlockCategories(list)
            }
            getSponsorBlockCategories()
        }
    }

    private var _quality: MutableStateFlow<String?> = MutableStateFlow(null)
    val quality: StateFlow<String?> = _quality

    fun getQuality() {
        viewModelScope.launch {
            dataStoreManager.quality.collect { quality ->
                _quality.emit(QUALITY.normalize(quality))
            }
        }
    }

    fun changeVideoQuality(item: String) {
        viewModelScope.launch {
            if (VIDEO_QUALITY.items.contains(item)) {
                dataStoreManager.setVideoQuality(item)
            }
            getVideoQuality()
        }
    }

    fun changeQuality(qualityItem: String?) {
        viewModelScope.launch {
            log("changeQuality: $qualityItem")
            dataStoreManager.setQuality(qualityItem ?: QUALITY.items.first().toString())
            getQuality()
        }
    }

    private val _cacheSize: MutableStateFlow<Long?> = MutableStateFlow(null)
    var cacheSize: StateFlow<Long?> = _cacheSize

    fun getPlayerCacheSize() {
        viewModelScope.launch {
            _cacheSize.value = cacheRepository.getCacheSize(Config.PLAYER_CACHE)
        }
    }

    fun clearPlayerCache() {
        viewModelScope.launch {
            cacheRepository.clearCache(Config.PLAYER_CACHE)
            makeToast(getString(Res.string.clear_player_cache))
            getPlayerCacheSize()
        }
    }

    private val _downloadedCacheSize: MutableStateFlow<Long?> = MutableStateFlow(null)
    var downloadedCacheSize: StateFlow<Long?> = _downloadedCacheSize

    /** Whether a download can be taken from a better source; the upgrade row is only offered then. */
    val sourceDownloadsSupported: Boolean get() = downloadUtils.supportsSourceDownloads

    /** Which song the bulk upgrade is on and how many there are; null while it is not running. */
    private val _upgradeProgress: MutableStateFlow<Pair<Int, Int>?> = MutableStateFlow(null)
    var upgradeProgress: StateFlow<Pair<Int, Int>?> = _upgradeProgress

    /**
     * Private copy: re-fetch every downloaded song from the best source that has it — Monochrome's
     * FLAC, the Internet Archive, Audius' 320 kbps upload, the SoundCloud backup — replacing the
     * copy on the device. `downloadTrack` falls back to YouTube's stream for a song with nothing
     * better, and this only *asks* when a better source was found at all, so nothing is thrown away
     * to come back the same. The sources sheet downloads one song the same way; this is the whole
     * library, one song at a time.
     */
    fun upgradeDownloads(allowMetered: Boolean = false) {
        if (!downloadUtils.supportsSourceDownloads) return
        if (_upgradeProgress.value != null) return
        // An upgrade downloads the songs again, so it runs on an unmetered connection unless the
        // caller says the listener has chosen to spend mobile data on it (allowMetered) - the
        // dialog in Settings asks, and its Upgrade is that yes.
        if (!allowMetered && !updateDownloadAllowed()) {
            makeToast(getString(Res.string.upgrade_downloads_wifi))
            return
        }
        viewModelScope.launch {
            val songs = songRepository.getDownloadedSongs().singleOrNull().orEmpty()
            if (songs.isEmpty()) {
                makeToast(getString(Res.string.upgrade_downloads_none))
                return@launch
            }
            var done = 0
            _upgradeProgress.value = 0 to songs.size
            for (song in songs) {
                runCatching {
                    // The sources are searched as the sheet opens them: wait for the searches to
                    // settle (or give up), then take the best that answered.
                    val options =
                        withTimeoutOrNull(20_000) {
                            streamRepository
                                .sourceOptions(song.videoId)
                                .first { list -> list.none { it.availability == SourceAvailability.SEARCHING } }
                        }
                    val best =
                        options
                            ?.filter {
                                it.availability == SourceAvailability.AVAILABLE &&
                                    it.kind != SourceKind.DOWNLOADED &&
                                    it.kind != SourceKind.PODCAST &&
                                    it.kind != SourceKind.YOUTUBE
                            }?.maxByOrNull { it.source?.rank ?: 0 }
                    if (best != null) {
                        downloadUtils.downloadTrack(
                            song.videoId,
                            song.title,
                            song.thumbnails.orEmpty(),
                            best.kind,
                        )
                    }
                }
                done++
                _upgradeProgress.value = done to songs.size
            }
            _upgradeProgress.value = null
        }
    }

    fun getDownloadedCacheSize() {
        viewModelScope.launch {
            _downloadedCacheSize.value = cacheRepository.getCacheSize(Config.DOWNLOAD_CACHE)
        }
    }

    fun clearDownloadedCache() {
        viewModelScope.launch {
            cacheRepository.clearCache(Config.DOWNLOAD_CACHE)
            songRepository.getDownloadedSongs().singleOrNull()?.let { songs ->
                songs.forEach { song ->
                    songRepository.updateDownloadState(song.videoId, DownloadState.STATE_NOT_DOWNLOADED)
                }
            }
            makeToast(getString(Res.string.clear_downloaded_cache))
            getDownloadedCacheSize()
            downloadUtils.removeAllDownloads()
        }
    }

    fun clearCanvasCache() {
        viewModelScope.launch {
            cacheRepository.clearCache(Config.CANVAS_CACHE)
            makeToast(getString(Res.string.clear_canvas_cache))
            getCanvasCache()
        }
    }

    fun clearListeningHistory() {
        viewModelScope.launch {
            // The sweep walks every container table and then the whole song table, and finishes with
            // a VACUUM — seconds of work on a large library, and the screen would look frozen.
            showLoadingDialog(getString(Res.string.clear_listening_history))
            val removed =
                try {
                    // NonCancellable because the sweep is only coherent once it has finished: the
                    // cached containers are deleted first and the songs they were holding alive
                    // last, so a run stopped in between — the user leaving Settings is enough to do
                    // it — has already dropped every cached playlist, album and artist and left the
                    // songs behind. Nothing resumes it afterwards, so it has to run to the end.
                    withContext(NonCancellable) { songRepository.clearHistoryAndOrphanedSongs() }
                } catch (e: CancellationException) {
                    // Not a failure, and it must not be swallowed: catching it breaks structured
                    // concurrency, and it would put the generic error toast in front of a user whose
                    // sweep had in fact just completed, inviting them to run the whole thing again.
                    throw e
                } catch (e: Throwable) {
                    Logger.e(tag, "clearHistoryAndOrphanedSongs failed: ${e.stackTraceToString()}")
                    null
                } finally {
                    // In a finally so a failure — or the user leaving the screen — cannot strand the
                    // dialog on top of the app with no way to dismiss it.
                    hideLoadingDialog()
                }
            if (removed == null) {
                makeToast(getString(Res.string.error))
                return@launch
            }
            // The taste reading in Library was written from the history just wiped; left behind, it
            // would keep describing a listener the app no longer has any record of.
            dataStoreManager.setTasteProfile(null)
            makeToast(formatString(Res.string.clear_listening_history_done, removed))
            // Only the database slice of the storage bar moved; getData() would also restart every
            // collecting getter it owns.
            calculateDataFraction(cacheRepository)?.let { _fraction.value = it }
        }
    }

    fun backup(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                makeToast(getString(Res.string.backup_in_progress))
                withContext(Dispatchers.IO) {
                    backupNative(commonRepository, uri, backupDownloaded.value)
                }
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    makeToast(getString(Res.string.backup_create_success))
                }
            }.onFailure {
                withContext(Dispatchers.Main) {
                    it.printStackTrace()
                    makeToast(getString(Res.string.backup_create_failed))
                }
            }
        }
    }

    fun restore(uri: Uri) {
        viewModelScope.launch {
            makeToast(getString(Res.string.restore_in_progress))
            withContext(Dispatchers.IO) {
                runCatching {
                    restoreNative(commonRepository, uri) {
                        getData()
                    }
                }.onFailure {
                    withContext(Dispatchers.Main) {
                        it.printStackTrace()
                        makeToast(getString(Res.string.restore_failed))
                    }
                }
            }
        }
    }

    fun getLanguage() {
        viewModelScope.launch {
            dataStoreManager.getString(SELECTED_LANGUAGE).collect { language ->
                _language.emit(language)
            }
        }
    }

    fun changeLanguage(code: String) {
        viewModelScope.launch {
            dataStoreManager.putString(SELECTED_LANGUAGE, code)
            Logger.w("SettingsViewModel", "changeLanguage: $code")
            getLanguage()
            changeLanguageNative(code)
        }
    }

    fun getNormalizeVolume() {
        viewModelScope.launch {
            dataStoreManager.normalizeVolume.collect { normalizeVolume ->
                _normalizeVolume.emit(normalizeVolume)
            }
        }
    }

    fun setNormalizeVolume(normalizeVolume: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setNormalizeVolume(normalizeVolume)
            getNormalizeVolume()
        }
    }

    fun getSendBackToGoogle() {
        viewModelScope.launch {
            dataStoreManager.sendBackToGoogle.collect { sendBackToGoogle ->
                _sendBackToGoogle.emit(sendBackToGoogle)
            }
        }
    }

    fun setSendBackToGoogle(sendBackToGoogle: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSendBackToGoogle(sendBackToGoogle)
            getSendBackToGoogle()
        }
    }

    fun getSkipSilent() {
        viewModelScope.launch {
            dataStoreManager.skipSilent.collect { skipSilent ->
                _skipSilent.emit(skipSilent)
            }
        }
    }

    fun setSkipSilent(skip: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSkipSilent(skip)
            getSkipSilent()
        }
    }

    fun getSavedPlaybackState() {
        viewModelScope.launch {
            dataStoreManager.saveStateOfPlayback.collect { savedPlaybackState ->
                _savedPlaybackState.emit(savedPlaybackState)
            }
        }
    }

    fun setSavedPlaybackState(savedPlaybackState: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSaveStateOfPlayback(savedPlaybackState)
            getSavedPlaybackState()
        }
    }

    fun getPlayerCacheLimit() {
        viewModelScope.launch {
            dataStoreManager.maxSongCacheSize.collect {
                _playerCacheLimit.emit(it)
            }
        }
    }

    fun setPlayerCacheLimit(size: Int) {
        viewModelScope.launch {
            dataStoreManager.setMaxSongCacheSize(size)
            getPlayerCacheLimit()
        }
    }

    /** Private copy: the share of storage, in percent, the player cache leaves free (0 = off). */
    val playerCacheKeepFree: StateFlow<Int> =
        dataStoreManager.playerCacheKeepFreePercent.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 20)

    fun setPlayerCacheKeepFree(percent: Int) {
        viewModelScope.launch { dataStoreManager.setPlayerCacheKeepFreePercent(percent) }
    }

    private var _googleAccounts: MutableStateFlow<LocalResource<List<GoogleAccountEntity>>> =
        MutableStateFlow(LocalResource.Loading())
    val googleAccounts: StateFlow<LocalResource<List<GoogleAccountEntity>>> = _googleAccounts

    fun getAllGoogleAccount() {
        Logger.d("getAllGoogleAccount", "getAllGoogleAccount: Go to function")
        viewModelScope.launch {
            _googleAccounts.emit(LocalResource.Loading())
            accountRepository.getGoogleAccounts().collectLatest { accounts ->
                // Counts only: every account row carries the session cookie.
                Logger.d("getAllGoogleAccount", "getAllGoogleAccount: ${accounts?.size ?: 0} saved account(s)")
                if (!accounts.isNullOrEmpty()) {
                    _googleAccounts.emit(LocalResource.Success(accounts))
                } else {
                    if (loggedIn.value == DataStoreManager.TRUE) {
                        accountRepository
                            .getAccountInfo(
                                dataStoreManager.cookie.first(),
                            ).collect {
                                Logger.d("getAllGoogleAccount", "getAllGoogleAccount: ${it.size} account(s) from YouTube")
                                if (it.isNotEmpty()) {
                                    dataStoreManager.putString("AccountName", it.first().name)
                                    dataStoreManager.putString(
                                        "AccountThumbUrl",
                                        it
                                            .first()
                                            .thumbnails
                                            .lastOrNull()
                                            ?.url ?: "",
                                    )
                                    accountRepository
                                        .insertGoogleAccount(
                                            GoogleAccountEntity(
                                                email = it.first().email,
                                                name = it.first().name,
                                                thumbnailUrl =
                                                    it
                                                        .first()
                                                        .thumbnails
                                                        .lastOrNull()
                                                        ?.url ?: "",
                                                cache = accountRepository.getYouTubeCookie(),
                                                pageId = it.first().pageId,
                                                authUser = it.first().authUser,
                                                isUsed = true,
                                            ),
                                        ).singleOrNull()
                                        ?.let { account ->
                                            Logger.d("getAllGoogleAccount", "inserted: $account")
                                        }
                                    getAllGoogleAccount()
                                } else {
                                    Logger.w("Auth", "YouTube: marked signed in, but the saved cookie returned no account — likely signed out or expired")
                                    _googleAccounts.emit(LocalResource.Success(emptyList()))
                                }
                            }
                    } else {
                        _googleAccounts.emit(LocalResource.Success(emptyList()))
                    }
                }
            }
        }
    }

    suspend fun addAccount(
        cookie: String,
        netscapeCookie: String? = null,
    ): Boolean {
        val currentCookie = dataStoreManager.cookie.first()
        val currentPageId = dataStoreManager.pageId.first()
        val currentAuthUser = dataStoreManager.authUser.first()
        val currentLoggedIn = dataStoreManager.loggedIn.first() == DataStoreManager.TRUE
        try {
            runBlocking {
                dataStoreManager.setCookie(cookie, "")
                dataStoreManager.setLoggedIn(true)
            }
            return accountRepository
                .getAccountInfo(
                    cookie,
                ).lastOrNull()
                ?.takeIf {
                    it.isNotEmpty()
                }?.let { accountInfoList ->
                    Logger.d("getAllGoogleAccount", "addAccount: ${accountInfoList.size} account(s)")
                    accountRepository.getGoogleAccounts().lastOrNull()?.forEach {
                        Logger.d("getAllGoogleAccount", "set used: start")
                        accountRepository
                            .updateGoogleAccountUsed(it.email, false)
                            .singleOrNull()
                            ?.let {
                                Logger.d("getAllGoogleAccount", "set used: $it")
                            }
                    }
                    dataStoreManager.putString("AccountName", accountInfoList.first().name)
                    dataStoreManager.putString(
                        "AccountThumbUrl",
                        accountInfoList
                            .first()
                            .thumbnails
                            .lastOrNull()
                            ?.url ?: "",
                    )
                    val cookieItem =
                        netscapeCookie ?: commonRepository
                            .getCookiesFromInternalDatabase(Config.YOUTUBE_MUSIC_MAIN_URL, getPackageName())
                            .toNetScapeString()
                    commonRepository.writeTextToFile(cookieItem, (getFileDir() + "/ytdlp-cookie.txt")).let {
                        Logger.d("getAllGoogleAccount", "addAccount: write cookie file: $it")
                    }
                    accountInfoList.forEachIndexed { index, account ->
                        accountRepository
                            .insertGoogleAccount(
                                GoogleAccountEntity(
                                    email = account.email,
                                    name = account.name,
                                    thumbnailUrl =
                                        account
                                            .thumbnails
                                            .lastOrNull()
                                            ?.url ?: "",
                                    cache = cookie,
                                    isUsed = index == 0,
                                    netscapeCookie = cookieItem,
                                    pageId = account.pageId,
                                    authUser = account.authUser,
                                ),
                            ).firstOrNull()
                            ?.let {
                                log("addAccount: inserted $it")
                            }
                    }
                    dataStoreManager.setLoggedIn(true)
                    dataStoreManager.setCookie(cookie, accountInfoList.first().pageId, accountInfoList.first().authUser)
                    Logger.i("Auth", "YouTube: signed in, ${accountInfoList.size} account(s) on this cookie")
                    getAllGoogleAccount()
                    getLoggedIn()
                    true
                } ?: run {
                Logger.w("Auth", "YouTube: sign-in failed, YouTube returned no account for this cookie")
                runBlocking {
                    dataStoreManager.setCookie(currentCookie, currentPageId, currentAuthUser)
                    dataStoreManager.setLoggedIn(currentLoggedIn)
                }
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Logger.e("Auth", "YouTube: sign-in failed: ${e.message}")
            runBlocking {
                dataStoreManager.setCookie(currentCookie, currentPageId, currentAuthUser)
                dataStoreManager.setLoggedIn(currentLoggedIn)
            }
            return false
        }
    }

    fun setUsedAccount(acc: GoogleAccountEntity?) {
        viewModelScope.launch {
            if (acc != null) {
                googleAccounts.value.data?.forEach {
                    accountRepository
                        .updateGoogleAccountUsed(it.email, false)
                        .singleOrNull()
                        ?.let {
                            Logger.d("getAllGoogleAccount", "set used: $it")
                        }
                }
                dataStoreManager.putString("AccountName", acc.name)
                dataStoreManager.putString("AccountThumbUrl", acc.thumbnailUrl)
                accountRepository
                    .updateGoogleAccountUsed(acc.email, true)
                    .singleOrNull()
                    ?.let {
                        Logger.d("getAllGoogleAccount", "set used: $it")
                    }
                acc.netscapeCookie?.let { commonRepository.writeTextToFile(it, (getFileDir() + "/ytdlp-cookie.txt")) }.let {
                    Logger.d("getAllGoogleAccount", "addAccount: write cookie file: $it")
                }
                dataStoreManager.setCookie(acc.cache ?: "", acc.pageId, acc.authUser)
                dataStoreManager.setLoggedIn(true)
                Logger.i("Auth", "YouTube: switched account")
                delay(500)
                getAllGoogleAccount()
                getLoggedIn()
            } else {
                googleAccounts.value.data?.forEach {
                    accountRepository
                        .updateGoogleAccountUsed(it.email, false)
                        .singleOrNull()
                        ?.let {
                            Logger.d("getAllGoogleAccount", "set used: $it")
                        }
                }
                dataStoreManager.putString("AccountName", "")
                dataStoreManager.putString("AccountThumbUrl", "")
                dataStoreManager.setLoggedIn(false)
                dataStoreManager.setCookie("", null)
                Logger.i("Auth", "YouTube: signed out")
                // Mirroring follows needs a session to write to, so signing out clears the flag
                // here rather than from the Settings row — same teardown as setSpotifyLogIn and
                // logOutDiscord. Only this branch: acc != null is switching account, not logout.
                dataStoreManager.setSyncFollowToYouTube(false)
                delay(500)
                getAllGoogleAccount()
                getLoggedIn()
            }
        }
    }

    fun logOutAllYouTube() {
        viewModelScope.launch {
            googleAccounts.value.data?.forEach { account ->
                accountRepository.deleteGoogleAccount(account.email)
            }
            dataStoreManager.putString("AccountName", "")
            dataStoreManager.putString("AccountThumbUrl", "")
            dataStoreManager.setLoggedIn(false)
            dataStoreManager.setCookie("", null)
            Logger.i("Auth", "YouTube: signed out of all accounts")
            dataStoreManager.setSyncFollowToYouTube(false)
            delay(500)
            getAllGoogleAccount()
            getLoggedIn()
        }
    }

    @ExperimentalCoilApi
    fun clearThumbnailCache(platformContext: PlatformContext) {
        viewModelScope.launch {
            SingletonImageLoader.get(platformContext).diskCache?.clear()
            makeToast(getString(Res.string.clear_thumbnail_cache))
            getThumbCacheSize(platformContext)
        }
    }

    private var _spotifyLogIn: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val spotifyLogIn: StateFlow<Boolean> = _spotifyLogIn

    fun getSpotifyLogIn() {
        viewModelScope.launch {
            dataStoreManager.spdc.collect { loggedIn ->
                if (loggedIn.isNotEmpty()) {
                    _spotifyLogIn.emit(true)
                } else {
                    _spotifyLogIn.emit(false)
                }
            }
        }
    }

    fun setSpotifyLogIn(loggedIn: Boolean) {
        viewModelScope.launch {
            _spotifyLogIn.emit(loggedIn)
            if (!loggedIn) {
                dataStoreManager.setSpdc("")
                // Logging out of Spotify must also tear down everything gated behind it. Otherwise the
                // lyrics/canvas flags stay stuck ON with no way to switch them off (the toggles grey out
                // when logged out) and stale tokens linger — issue #2064, same family as Discord #2157.
                dataStoreManager.setSpotifyLyrics(false)
                dataStoreManager.setSpotifyCanvas(false)
                dataStoreManager.setSpotifyClientToken("")
                dataStoreManager.setSpotifyClientTokenExpires(0)
                dataStoreManager.setSpotifyPersonalToken("")
                dataStoreManager.setSpotifyPersonalTokenExpires(0)
                delay(500)
            }
            getSpotifyLogIn()
        }
    }

    private var _equalizerEnabled: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val equalizerEnabled: StateFlow<Boolean> = _equalizerEnabled

    fun setEqualizerEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setEqualizerEnabled(enabled)
        }
    }

    private var _equalizerType: MutableStateFlow<String> = MutableStateFlow(DataStoreManager.EQUALIZER_TYPE_BUILT_IN)
    val equalizerType: StateFlow<String> = _equalizerType

    fun setEqualizerType(type: String) {
        viewModelScope.launch {
            dataStoreManager.setEqualizerType(type)
        }
    }

    private var _equalizerBands: MutableStateFlow<List<Float>> = MutableStateFlow(List(EQUALIZER_BAND_COUNT) { 0f })
    val equalizerBands: StateFlow<List<Float>> = _equalizerBands

    private var _equalizerPreamp: MutableStateFlow<Float> = MutableStateFlow(0f)
    val equalizerPreamp: StateFlow<Float> = _equalizerPreamp

    /** Raw `"<label>\n<gains>"` of the last imported AutoEq profile; the UI decides if it still applies. */
    private var _equalizerAutoEqProfile: MutableStateFlow<String> = MutableStateFlow("")
    val equalizerAutoEqProfile: StateFlow<String> = _equalizerAutoEqProfile

    /**
     * Guards the collectors below against being started twice.
     *
     * Two callers ask for them: [getData], which every visit to the settings screen runs, and the
     * equalizer block itself, which asks on its own so it keeps working if it is ever hosted
     * anywhere else. Both land on this same view model, and the collectors live in
     * [viewModelScope] rather than in a composition — so without this, toggling the switch off and
     * on left another five behind every time, each re-reading the preference file for a value
     * three others were already publishing.
     */
    private var equalizerCollectorsStarted = false

    fun getEqualizer() {
        if (equalizerCollectorsStarted) return
        equalizerCollectorsStarted = true
        viewModelScope.launch {
            launch {
                dataStoreManager.equalizerEnabled.collect {
                    _equalizerEnabled.emit(it == DataStoreManager.TRUE)
                }
            }
            launch {
                dataStoreManager.equalizerType.collect { _equalizerType.emit(it) }
            }
            launch {
                dataStoreManager.equalizerBands.collect { stored ->
                    // Stored blank means flat. Short or malformed input is padded rather than
                    // rejected, so a curve saved by a future build with more bands still loads.
                    val parsed = stored.split(",").mapNotNull { it.trim().toFloatOrNull() }
                    _equalizerBands.emit(
                        List(EQUALIZER_BAND_COUNT) { parsed.getOrElse(it) { 0f } },
                    )
                }
            }
            launch {
                dataStoreManager.equalizerPreamp.collect { _equalizerPreamp.emit(it) }
            }
            launch {
                dataStoreManager.equalizerAutoEqProfile.collect { _equalizerAutoEqProfile.emit(it) }
            }
        }
    }

    /**
     * Store a whole curve at once.
     *
     * The whole list rather than one band at a time because a single drag sweeps across several
     * bands, and because the per-band version had to read [_equalizerBands] to rebuild the list —
     * a value that only updates once the write has been through storage, so two edits in quick
     * succession could reinstate the first band's old gain.
     */
    fun setEqualizerBands(bandsDb: List<Float>) {
        viewModelScope.launch {
            dataStoreManager.setEqualizerBands(bandsDb)
        }
    }

    /**
     * Move the curve and its preamp together.
     *
     * These are two separate preference keys, so the player does briefly see one of them applied
     * against the other's old value. The preamp goes first deliberately: that way the moment in
     * between is the new headroom under the old curve — quieter — rather than a freshly boosted
     * curve still running on the previous preset's headroom, which is the direction that clips.
     */
    fun applyEqualizerPreset(
        bandsDb: List<Float>,
        preampDb: Float,
    ) {
        viewModelScope.launch {
            dataStoreManager.setEqualizerPreamp(preampDb)
            dataStoreManager.setEqualizerBands(bandsDb)
        }
    }

    fun setEqualizerPreamp(preampDb: Float) {
        viewModelScope.launch {
            dataStoreManager.setEqualizerPreamp(preampDb)
        }
    }

    fun resetEqualizer() {
        viewModelScope.launch {
            dataStoreManager.setEqualizerBands(List(EQUALIZER_BAND_COUNT) { 0f })
            dataStoreManager.setEqualizerPreamp(0f)
        }
    }

    private var _delayEnabled: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val delayEnabled: StateFlow<Boolean> = _delayEnabled

    private var _delayTimeMs: MutableStateFlow<Int> = MutableStateFlow(DEFAULT_DELAY_TIME_MS)
    val delayTimeMs: StateFlow<Int> = _delayTimeMs

    private var _delayFeedback: MutableStateFlow<Float> = MutableStateFlow(DEFAULT_DELAY_FEEDBACK)
    val delayFeedback: StateFlow<Float> = _delayFeedback

    private var _delayMix: MutableStateFlow<Float> = MutableStateFlow(DEFAULT_DELAY_MIX)
    val delayMix: StateFlow<Float> = _delayMix

    private var _reverbEnabled: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val reverbEnabled: StateFlow<Boolean> = _reverbEnabled

    private var _reverbPreset: MutableStateFlow<ReverbPreset> = MutableStateFlow(ReverbPreset.HALL)
    val reverbPreset: StateFlow<ReverbPreset> = _reverbPreset

    private var _reverbMix: MutableStateFlow<Float> = MutableStateFlow(DEFAULT_REVERB_MIX)
    val reverbMix: StateFlow<Float> = _reverbMix

    /**
     * Guards the effect collectors the same way [equalizerCollectorsStarted] guards the curve's.
     *
     * Same two callers, same trap: [getData] runs on every visit to the settings screen and the two
     * effect blocks ask on their own so they keep working if they are ever hosted elsewhere. The
     * collectors live in [viewModelScope] rather than in a composition, so without this every
     * toggle of the switch would leave another seven behind.
     */
    private var audioEffectCollectorsStarted = false

    fun getAudioEffects() {
        if (audioEffectCollectorsStarted) return
        audioEffectCollectorsStarted = true
        viewModelScope.launch {
            launch { dataStoreManager.delayEnabled.collect { _delayEnabled.emit(it == DataStoreManager.TRUE) } }
            launch { dataStoreManager.delayTimeMs.collect { _delayTimeMs.emit(it) } }
            launch { dataStoreManager.delayFeedback.collect { _delayFeedback.emit(it) } }
            launch { dataStoreManager.delayMix.collect { _delayMix.emit(it) } }
            launch { dataStoreManager.reverbEnabled.collect { _reverbEnabled.emit(it == DataStoreManager.TRUE) } }
            launch {
                dataStoreManager.reverbPreset.collect { stored ->
                    // The store hands the name back unresolved on purpose, so the fallback lives
                    // here: a room named by a build newer than this one has to land on something
                    // playable rather than throw out of a collector and kill the whole block.
                    _reverbPreset.emit(runCatching { ReverbPreset.valueOf(stored) }.getOrDefault(ReverbPreset.HALL))
                }
            }
            launch { dataStoreManager.reverbMix.collect { _reverbMix.emit(it) } }
        }
    }

    fun setDelayEnabled(enabled: Boolean) {
        viewModelScope.launch { dataStoreManager.setDelayEnabled(enabled) }
    }

    fun setDelayTimeMs(timeMs: Int) {
        viewModelScope.launch { dataStoreManager.setDelayTimeMs(timeMs) }
    }

    fun setDelayFeedback(feedback: Float) {
        viewModelScope.launch { dataStoreManager.setDelayFeedback(feedback) }
    }

    fun setDelayMix(mix: Float) {
        viewModelScope.launch { dataStoreManager.setDelayMix(mix) }
    }

    fun setReverbEnabled(enabled: Boolean) {
        viewModelScope.launch { dataStoreManager.setReverbEnabled(enabled) }
    }

    fun setReverbPreset(preset: ReverbPreset) {
        viewModelScope.launch { dataStoreManager.setReverbPreset(preset) }
    }

    fun setReverbMix(mix: Float) {
        viewModelScope.launch { dataStoreManager.setReverbMix(mix) }
    }

    /**
     * Move all three delay values together, in one coroutine.
     *
     * Three separate preference keys, so the player does briefly see one of them applied against
     * the others' old values — the same seam [applyEqualizerPreset] has. Writing them from one
     * launch at least keeps that window to a single pass instead of three racing ones, and no
     * ordering of these three is dangerous the way the equalizer's preamp is: an echo caught
     * mid-change is a wrong echo for a few milliseconds, never a clipped one.
     */
    fun applyDelayPreset(
        timeMs: Int,
        feedback: Float,
        mix: Float,
    ) {
        viewModelScope.launch {
            dataStoreManager.setDelayTimeMs(timeMs)
            dataStoreManager.setDelayFeedback(feedback)
            dataStoreManager.setDelayMix(mix)
        }
    }

    private var _syncFollowToYouTube: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val syncFollowToYouTube: StateFlow<Boolean> = _syncFollowToYouTube

    fun getSyncFollowToYouTube() {
        viewModelScope.launch {
            dataStoreManager.syncFollowToYouTube.collect {
                _syncFollowToYouTube.emit(it == DataStoreManager.TRUE)
            }
        }
    }

    fun setSyncFollowToYouTube(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSyncFollowToYouTube(enabled)
            // Turning it on is a statement about the whole library: artists followed before the
            // switch would otherwise never reach the account. Turning it off deliberately does
            // NOT unsubscribe — stopping the mirroring is not the same as asking us to undo it.
            if (enabled) {
                // Runs silently. The only toast in this feature belongs to the Follow button on
                // the artist screen, where the user performed the action and is waiting to see it
                // take effect; a switch in Settings is not the place to report on a background
                // sweep the user is not watching.
                artistRepository.syncFollowedArtistsToYouTube().collect { }
            }
        }
    }

    private var _spotifyLyrics: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val spotifyLyrics: StateFlow<Boolean> = _spotifyLyrics

    private var _spotifyCanvas: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val spotifyCanvas: StateFlow<Boolean> = _spotifyCanvas

    private var _amAnimatedArtwork: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val amAnimatedArtwork: StateFlow<Boolean> = _amAnimatedArtwork

    fun getSpotifyLyrics() {
        viewModelScope.launch {
            dataStoreManager.spotifyLyrics.collect {
                if (it == DataStoreManager.TRUE) {
                    _spotifyLyrics.emit(true)
                } else {
                    _spotifyLyrics.emit(false)
                }
            }
        }
    }

    fun setSpotifyLyrics(loggedIn: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSpotifyLyrics(loggedIn)
            getSpotifyLyrics()
        }
    }

    fun getSpotifyCanvas() {
        viewModelScope.launch {
            dataStoreManager.spotifyCanvas.collect {
                if (it == DataStoreManager.TRUE) {
                    _spotifyCanvas.emit(true)
                } else {
                    _spotifyCanvas.emit(false)
                }
            }
        }
    }

    fun setSpotifyCanvas(loggedIn: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setSpotifyCanvas(loggedIn)
            getSpotifyCanvas()
        }
    }

    fun getAMAnimatedArtwork() {
        viewModelScope.launch {
            dataStoreManager.amAnimatedArtwork.collect {
                _amAnimatedArtwork.emit(it == DataStoreManager.TRUE)
            }
        }
    }

    fun setAMAnimatedArtwork(enabled: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setAMAnimatedArtwork(enabled)
            getAMAnimatedArtwork()
        }
    }

    // Lấy giá trị của killServiceOnExit từ DataStore
    fun getKillServiceOnExit() {
        viewModelScope.launch {
            dataStoreManager.killServiceOnExit.collect { killServiceOnExit ->
                _killServiceOnExit.emit(killServiceOnExit)
            }
        }
    }

    // Lưu giá trị killServiceOnExit vào DataStore
    fun setKillServiceOnExit(kill: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setKillServiceOnExit(kill)
            getKillServiceOnExit()
        }
    }

    fun getYoutubeSubtitleLanguage() {
        viewModelScope.launch {
            dataStoreManager.youtubeSubtitleLanguage.collect { language ->
                _youtubeSubtitleLanguage.emit(language)
            }
        }
    }

    fun setYoutubeSubtitleLanguage(language: String) {
        viewModelScope.launch {
            dataStoreManager.setYoutubeSubtitleLanguage(language)
            getYoutubeSubtitleLanguage()
        }
    }

    private fun getPreferredAudioLanguage() {
        viewModelScope.launch {
            dataStoreManager.preferredAudioLanguage.collect { language ->
                _preferredAudioLanguage.emit(language)
            }
        }
    }

    // Does not re-call the getter, for the same reason as setLyricsOffsetMs: the collector started
    // in init already publishes every write.
    fun setPreferredAudioLanguage(language: String) {
        viewModelScope.launch {
            dataStoreManager.setPreferredAudioLanguage(language)
        }
    }

    fun getHelpBuildLyricsDatabase() {
        viewModelScope.launch {
            dataStoreManager.helpBuildLyricsDatabase.collect { helpBuildLyricsDatabase ->
                _helpBuildLyricsDatabase.emit(helpBuildLyricsDatabase == DataStoreManager.TRUE)
            }
        }
    }

    fun setHelpBuildLyricsDatabase(help: Boolean) {
        viewModelScope.launch {
            dataStoreManager.setHelpBuildLyricsDatabase(help)
            getHelpBuildLyricsDatabase()
        }
    }
}

data class SettingsStorageSectionFraction(
    val otherApp: Float = 0f,
    val downloadCache: Float = 0f,
    val playerCache: Float = 0f,
    val canvasCache: Float = 0f,
    val thumbCache: Float = 0f,
    val appDatabase: Float = 0f,
    val freeSpace: Float = 0f,
) {
    fun combine(): Float = otherApp + downloadCache + playerCache + canvasCache + thumbCache + appDatabase + freeSpace
}

data class SettingAlertState(
    val title: String,
    val message: String? = null,
    val textField: TextFieldData? = null,
    val selectOne: SelectData? = null,
    val multipleSelect: SelectData? = null,
    val confirm: Pair<String, (SettingAlertState) -> Unit>,
    val dismiss: String,
) {
    data class TextFieldData(
        val label: String,
        val value: String = "",
        // User typing string -> (true or false, If false, show error message)
        val verifyCodeBlock: ((String) -> Pair<Boolean, String?>)? = null,
    )

    data class SelectData(
        // Selected / Data
        val listSelect: List<Pair<Boolean, String>>,
    ) {
        fun getSelected(): String = listSelect.firstOrNull { it.first }?.second ?: ""

        fun getListSelected(): List<String> = listSelect.filter { it.first }.map { it.second }
    }
}

data class SettingBasicAlertState(
    val title: String,
    val message: String? = null,
    val confirm: Pair<String, () -> Unit>,
    val dismiss: String,
)

expect suspend fun calculateDataFraction(cacheRepository: CacheRepository): SettingsStorageSectionFraction?

expect suspend fun restoreNative(
    commonRepository: CommonRepository,
    uri: Uri,
    getData: () -> Unit = {},
)

/** Reads the whole of a file the user picked: a content Uri on Android, a plain path on Desktop. */
expect suspend fun readPickedFile(uri: Uri): ByteArray

expect suspend fun backupNative(
    commonRepository: CommonRepository,
    uri: Uri,
    backupDownloaded: Boolean,
)

expect fun getPackageName(): String

expect fun getFileDir(): String

expect fun changeLanguageNative(code: String)

/** Number of equalizer bands, matching the ISO centres the desktop backend installs. */
const val EQUALIZER_BAND_COUNT = 10

/** Band centre labels, for display only — the backend owns the actual frequencies. */
val EQUALIZER_BAND_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

// The three delay defaults and the reverb mix repeat what DataStoreManagerImpl falls back to. They
// exist here so the StateFlows start on the stored default rather than on a placeholder the
// collector then corrects — otherwise the sliders draw once at 0 and visibly jump the moment the
// preference file is read, which reads as the app losing the user's settings.

/** Quarter-note-ish spacing at 150 bpm; see `DataStoreManagerImpl.delayTimeMs`. */
const val DEFAULT_DELAY_TIME_MS = 400

/** See `DataStoreManagerImpl.delayFeedback`. */
const val DEFAULT_DELAY_FEEDBACK = 0.45f

/** See `DataStoreManagerImpl.delayMix`. */
const val DEFAULT_DELAY_MIX = 0.3f

/** See `DataStoreManagerImpl.reverbMix`. */
const val DEFAULT_REVERB_MIX = 0.35f
