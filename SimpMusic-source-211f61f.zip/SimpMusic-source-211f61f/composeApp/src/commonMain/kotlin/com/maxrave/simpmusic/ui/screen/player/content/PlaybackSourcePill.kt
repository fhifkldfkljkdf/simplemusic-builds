package com.maxrave.simpmusic.ui.screen.player.content

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maxrave.domain.data.entities.NewFormatEntity
import com.maxrave.domain.data.entities.isArchiveLossless
import com.maxrave.domain.data.entities.isSoundCloudBackup
import com.maxrave.domain.data.player.PlaybackSource
import com.maxrave.domain.data.player.SourceKind
import com.maxrave.simpmusic.ui.icon.GraphicEq
import com.maxrave.simpmusic.ui.icon.SimpIcons
import com.maxrave.simpmusic.ui.theme.typo

/**
 * Where the song now playing comes from, for the source badge under the seek bar:
 * "YouTube · OPUS 160 kbps", "SoundCloud · MP3 128 kbps", "Internet Archive · FLAC 16/44.1",
 * "Downloaded · OPUS". Null while nothing is known yet, so the badge hides instead of guessing.
 * Private copy.
 *
 * [source] is what the player says it reads from (it follows a mid-song switch); [format], the
 * song's format row, stands in until the player has said.
 */
internal fun playbackSourceLabel(
    source: PlaybackSource?,
    format: NewFormatEntity?,
    downloadedLabel: String?,
): String? {
    if (downloadedLabel != null && (source == null || source.kind == SourceKind.DOWNLOADED || source.kind == SourceKind.YOUTUBE)) {
        return listOfNotNull(downloadedLabel, (source?.codec ?: format?.codecs.toAudioCodecLabel())).joinToString(" · ")
    }
    if (source != null) return sourceLabel(source, downloadedLabel)
    format ?: return null
    val name =
        when {
            format.isArchiveLossless -> "Internet Archive"
            format.isSoundCloudBackup -> "SoundCloud"
            else -> "YouTube"
        }
    val codec =
        when {
            format.isArchiveLossless -> "FLAC"
            format.isSoundCloudBackup -> "MP3"
            else -> format.codecs.toAudioCodecLabel()
        }
    val kbps = format.bitrate?.takeIf { it > 0 }?.let { "${(it + 500) / 1000} kbps" }
    val detail = listOfNotNull(codec, kbps).joinToString(" ")
    return if (detail.isEmpty()) name else "$name · $detail"
}

/** "Internet Archive · FLAC 16/44.1", "YouTube · OPUS 160 kbps". */
internal fun sourceLabel(
    source: PlaybackSource,
    downloadedLabel: String? = null,
): String {
    val name =
        when (source.kind) {
            SourceKind.YOUTUBE -> "YouTube"
            SourceKind.INTERNET_ARCHIVE -> "Internet Archive"
            SourceKind.AUDIUS -> "Audius"
            SourceKind.SOUNDCLOUD -> "SoundCloud"
            SourceKind.DOWNLOADED -> downloadedLabel ?: "Downloaded"
        }
    val detail = sourceQuality(source)
    return if (detail.isEmpty()) name else "$name · $detail"
}

/** The quality half of [sourceLabel]: "FLAC 16/44.1", "OPUS 160 kbps", or "" when unknown. */
internal fun sourceQuality(source: PlaybackSource): String {
    val bits = source.bitsPerSample
    val rate = source.sampleRateHz
    val resolution =
        if (source.isLossless && bits != null && rate != null) {
            val khz = rate / 1000.0
            "$bits/${if (khz % 1.0 == 0.0) khz.toInt().toString() else ((khz * 10).toInt() / 10.0).toString()}"
        } else {
            null
        }
    val kbps = if (resolution == null) source.bitrateBps?.takeIf { it > 0 }?.let { "${(it + 500) / 1000} kbps" } else null
    return listOfNotNull(source.codec, resolution ?: kbps).joinToString(" ")
}

/** A small translucent pill with the source label, in the style of the Apple Music codec badge. */
@Composable
internal fun PlaybackSourcePill(
    label: String,
    contentColor: Color,
    modifier: Modifier = Modifier,
    /** Opens the sources sheet. */
    onClick: (() -> Unit)? = null,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .clip(RoundedCornerShape(9.dp))
                .background(contentColor.copy(alpha = 0.14f))
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Icon(
            imageVector = SimpIcons.GraphicEq,
            contentDescription = null,
            tint = contentColor.copy(alpha = 0.9f),
            modifier = Modifier.size(14.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = typo().labelSmall.copy(color = contentColor.copy(alpha = 0.9f)),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * "OPUS" or "AAC" from NewFormatEntity.codecs — "opus", or "mp4a.40.2" for AAC. The regex that fills
 * that column falls back to the WHOLE mimeType when it fails to match, so both shapes are recognised;
 * "aac" covers sources that report the codec by name. Upstream dropped this for a bitrate line; the
 * source pill still names the codec.
 */
internal fun String?.toAudioCodecLabel(): String? {
    val codec = this ?: return null
    return when {
        codec.contains("opus", ignoreCase = true) -> "OPUS"
        codec.contains("mp4a", ignoreCase = true) || codec.contains("aac", ignoreCase = true) -> "AAC"
        else -> null
    }
}
